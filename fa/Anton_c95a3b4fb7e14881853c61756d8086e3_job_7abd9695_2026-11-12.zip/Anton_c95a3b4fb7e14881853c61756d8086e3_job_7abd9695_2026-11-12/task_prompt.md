AX-1177 is our anti-IL-33 antibody. It has been in preclinical development against severe lower respiratory viral infection in our respiratory portfolio. For an upcoming portfolio audit, I need to justify every asset to the committee.



All of our data on AX-1177 is dumped. Treat these files as ground truth, and your recommendations should be based on our data. All recommendations and/or conclusions should be grounded in our data, as this is what the committee will want to see. 



For the committee audit, I want your recommendation: Do I keep this asset in our portfolio? Regardless of yes or no, I need a strong defensible case to present, so build out the position with as strong support and defense as the data allows.



And either way I need the forward view, because if I drop this I have to be able to say what we are dropping and why. What indication does our data actually point at? Previous portfolio development has targeted severe lower respiratory viral infection, but I'm open to repurposing the asset towards another indication. What would the next studies have to establish? Propose biomarkers, a sampling timepoint and a plan for next steps, and say which of those markers could go into patients and in what role.



Tell me what you considered and ruled out.
