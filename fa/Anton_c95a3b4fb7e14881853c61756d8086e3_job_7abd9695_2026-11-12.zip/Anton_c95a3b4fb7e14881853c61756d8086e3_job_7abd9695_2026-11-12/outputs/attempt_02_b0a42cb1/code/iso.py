import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
a = pd.read_pickle('contrasts.pkl')
def get(c): return a[a.Comparison==c].set_index('ensembl')
for cl in ['HUVEC','HGMEC']:
    for t in ['6','24']:
        x = get(f'Compound_47_IL33_vs_IL33_{cl}_{t}hrs'); y = get(f'Compound_47_IL33_vs_IL33_IC119_{cl}_{t}hrs')
        d = (x.logFC - y.logFC)  # = IL33_IC119 - IL33
        # approximate SE: se = lfc/t for each contrast; SE of isotype effect approx same as pairwise se
        se = (y.logFC/y.t).abs()
        z = d/se
        p = 2*stats.norm.sf(np.abs(z))
        from statsmodels.stats.multitest import multipletests
        q = multipletests(p, method='fdr_bh')[1]
        print(f'{cl} {t}h isotype effect (IL33+IC119 vs IL33, derived): n |z|>5 = {(np.abs(z)>5).sum()}, approx FDR<.05 = {(q<0.05).sum()}, SD of diff lfc = {d.std():.3f}')
        top = pd.DataFrame({'sym':x.symbol,'iso_eff':d,'z':z, 'AveExpr':x.AveExpr}).assign(absz=lambda r: r.z.abs()).sort_values('absz', ascending=False).head(8)
        print(top.round(3).to_string())
