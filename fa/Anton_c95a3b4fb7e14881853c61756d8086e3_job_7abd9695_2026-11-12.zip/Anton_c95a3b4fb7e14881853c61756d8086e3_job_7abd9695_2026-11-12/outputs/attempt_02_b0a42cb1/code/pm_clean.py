import pandas as pd, numpy as np, re
pd.set_option('display.width',300); pd.set_option('display.max_columns',50); pd.set_option('display.max_rows',200)
d = pd.read_pickle('pm.pkl')
d.columns = ['SID','Block','RNA','Unn3','Lobe','DisCat','Race','Sex','Age','SARS','Path','HE_eos','EPX','EDN','MBP','2D7','IL5Ra_NE','NE_dup','IL5Ra_tryp','Tryp_dup','EPO','NE','Tryptase','IL33_epi','IL33_endo','IL33_vsm','Notes']
d = d[d.Block.notna()].copy()
print('blocks', len(d), 'donors', d.SID.nunique())
# parse ordinal '3+' -> 3 ; 'ND' -> NaN; raw values check
def ordv(x):
    if pd.isna(x): return np.nan
    s = str(x).strip()
    if s.upper()=='ND': return np.nan
    m = re.match(r'^(\d)\+?$', s)
    if m: return float(m.group(1))
    return 'BAD:'+s
for c in ['EPX','EDN','MBP','2D7','IL5Ra_NE','NE_dup','IL5Ra_tryp','Tryp_dup','NE','Tryptase']:
    raw = d[c].astype(str).str.strip().value_counts().to_dict()
    print(c, raw)
# relation of derived numeric columns to ordinal
d['EPX_o'] = d.EPX.map(ordv); d['NE_o'] = d.NE_dup.map(ordv); d['Tr_o']=d.Tryp_dup.map(ordv)
d['NE_num'] = pd.to_numeric(d.NE, errors='coerce'); d['Tr_num']=pd.to_numeric(d.Tryptase, errors='coerce')
print('EPO - EPX_o:', (d.EPO - d.EPX_o).value_counts(dropna=False).to_dict())
print('NE_num - NE_o:', (d.NE_num - d.NE_o).value_counts(dropna=False).to_dict())
print('Tr_num - Tr_o:', (d.Tr_num - d.Tr_o).value_counts(dropna=False).to_dict())
for c in ['IL33_epi','IL33_endo','IL33_vsm']:
    print(c, d[c].value_counts(dropna=False).sort_index().to_dict())
d.to_pickle('pm_blocks.pkl')
