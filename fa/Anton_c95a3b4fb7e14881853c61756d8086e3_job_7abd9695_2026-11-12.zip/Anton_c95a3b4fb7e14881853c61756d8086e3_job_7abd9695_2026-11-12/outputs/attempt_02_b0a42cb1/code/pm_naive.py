import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
d = pd.read_pickle('pm_blocks.pkl')
dl = pd.read_pickle('pm_donor2.pkl')
d = d.merge(dl[['grp','covid']], left_on='SID', right_index=True)
print('blocks per group:', d.groupby('grp').size().to_dict())
print('COVID+ blocks from donors 2067/2072/2073:', d[d.SID.isin([2067,2072,2073])].shape[0], 'of', (d.covid==1).sum())
for c in ['IL33_epi','IL33_endo','IL33_vsm']:
    a = d.loc[d.covid==1,c].dropna(); b = d.loc[d.covid==0,c].dropna()
    pb = stats.mannwhitneyu(a,b).pvalue
    A = dl.loc[dl.covid==1,c].dropna(); Bq = dl.loc[dl.covid==0,c].dropna()
    pd_ = stats.mannwhitneyu(A,Bq).pvalue
    # mixed model with donor random intercept (treating score as continuous, for illustration)
    sub = d[['SID','covid',c]].dropna().rename(columns={c:'y'})
    try:
        mm = smf.mixedlm('y ~ covid', sub, groups=sub['SID']).fit(reml=True)
        pm = mm.pvalues['covid']; est = mm.params['covid']
    except Exception as e:
        pm, est = np.nan, np.nan
    # ICC from null model
    m0 = smf.mixedlm('y ~ 1', sub, groups=sub['SID']).fit(reml=True)
    icc = m0.cov_re.iloc[0,0]/(m0.cov_re.iloc[0,0]+m0.scale)
    print(f'{c}: naive block-level MWU p={pb:.4f} (n={len(a)}+{len(b)} blocks) | donor-level MWU p={pd_:.4f} (n={len(A)}+{len(Bq)} donors) | mixed-model p={pm:.4f} est={est:.2f} | ICC(donor)={icc:.2f}')
