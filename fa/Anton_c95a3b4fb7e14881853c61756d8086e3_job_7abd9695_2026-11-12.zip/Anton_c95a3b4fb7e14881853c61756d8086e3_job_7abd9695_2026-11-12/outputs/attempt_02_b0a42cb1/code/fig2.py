import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9, 'axes.spines.top':False, 'axes.spines.right':False})
il = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl')
il['SE']=il.logFC/il.t; il['bin']=pd.qcut(il.AveExpr,40,labels=False,duplicates='drop'); il['SE_ratio']=il.SE/il.groupby('bin').SE.transform('median')
fig, axes = plt.subplots(1,2, figsize=(12,5))
ax = axes[0]
ok = il.SE_ratio<=5
ax.scatter(il.AveExpr[ok], il.SE[ok], s=2, c='lightgrey', rasterized=True, label=f'expected variance (n={ok.sum():,})')
ax.scatter(il.AveExpr[~ok], il.SE[~ok], s=8, c='tab:purple', rasterized=True, label=f'SE > 5x expected (n={(~ok).sum()})')
ax.set_yscale('log'); ax.set_xlabel('AveExpr (log2 CPM, averaged over all 114 libraries)'); ax.set_ylabel('standard error of log2FC (|logFC / t|), log scale')
canon = {'SELE':'tab:red','VCAM1':'tab:red','CXCL8':'tab:red','CCL2':'tab:red','PTX3':'tab:red','IL1RL1':'tab:red','GAPDH':'k','CDH5':'tab:blue','VWF':'tab:blue','PECAM1':'tab:blue','KRT8':'tab:green','AKR1C2':'tab:green','NFKBIA':'tab:orange','TNFAIP3':'tab:orange','CSF2':'tab:orange'}
for g,cl in canon.items():
    r = il[il.symbol==g].iloc[0]
    ax.scatter(r.AveExpr, r.SE, s=25, c=cl, edgecolor='k', lw=.4, zorder=5)
    off={'IL1RL1':(4,-9),'PTX3':(4,4),'VCAM1':(4,-6),'SELE':(4,3)}.get(g,(4,2))
    ax.annotate(g, (r.AveExpr, r.SE), fontsize=7, xytext=off, textcoords='offset points', color=cl)
ax.set_title('IL-33 vs vehicle (HUVEC 6 h): per-gene standard errors\nred = canonical endothelial activation markers; blue = endothelial identity;\ngreen = epithelial-line identity; orange = robust IL-33 targets', fontsize=8.5)
ax.legend(fontsize=7, frameon=False, loc='upper left')
ax = axes[1]
sets = {
 'Y-linked (sex)': ['RPS4Y1','DDX3Y','UTY','KDM5D','EIF1AY','USP9Y','ZFY'],
 'robust IL-33/NF-kB targets': ['NFKBIA','TNFAIP3','TRAF1','RELB','NFKB2','CSF2','CSF3','IL6','CCL20','TNFRSF11B','IL18R1','CXCL2','CXCL3','CXCL5','CXCL6','ICAM1','SOD2','IRAK2','BIRC3'],
 'housekeeping': ['GAPDH','ACTB','B2M','PPIA','RPLP0','TBP','HPRT1','PGK1','EEF2','HSP90AA1','TUBB','UBC','YWHAZ'],
 'endothelial identity': ['PECAM1','CDH5','VWF','CD93','MMRN1','TIE1','TEK','KDR','ENG','ESM1','EGFL7','STAB1','EMCN','PLVAP','SOX18','ERG','FLT1','NOS3','CLDN5','ROBO4'],
 'MCF7 identity': ['ESR1','GATA3','TFF1','TFF3','GREB1','PGR','KRT8','KRT18','KRT19','XBP1','FOXA1','SPDEF','AGR2','CA12'],
 'A549 identity / NRF2': ['AKR1C1','AKR1C2','AKR1C3','AKR1B10','ALDH3A1','NQO1','TXNRD1','GPX2','G6PD','SLC7A11','CYP4F11'],
 'canonical activation markers\n(SELE, VCAM1, CXCL8, CCL2, CXCL1,\nPTGS2, PTX3, IL1RL1, TNFAIP2)': ['SELE','VCAM1','CXCL8','CCL2','CXCL1','PTGS2','PTX3','IL1RL1','TNFAIP2'],
}
data = [np.log10(il[il.symbol.isin(g)].SE_ratio.values) for g in sets.values()]
ax.boxplot(data, orientation='horizontal', tick_labels=list(sets.keys()), showfliers=True)
for i,dd in enumerate(data):
    ax.scatter(dd, np.random.normal(i+1, .05, len(dd)), s=8, alpha=.6)
ax.axvline(np.log10(5), c='tab:purple', ls='--', lw=.8); ax.text(np.log10(5)+.05, 0.6, '5x', color='tab:purple', fontsize=8)
ax.set_xlabel('log10 (SE / median SE at same expression level)')
ax.set_title('Variance inflation is concentrated in cell-identity genes and the\ncanonical activation markers (consistent with cross-library contamination\nor mislabelled library under one pooled-variance model)', fontsize=8.5)
ax.tick_params(axis='y', labelsize=7.5)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/Fig2_RNAseq_variance_QC.png', dpi=200); print('ok')
