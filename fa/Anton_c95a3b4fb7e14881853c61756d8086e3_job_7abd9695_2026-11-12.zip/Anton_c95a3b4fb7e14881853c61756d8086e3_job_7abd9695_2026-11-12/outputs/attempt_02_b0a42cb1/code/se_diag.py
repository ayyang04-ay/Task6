import pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_rows',200)
a = pd.read_pickle('contrasts.pkl')
il6 = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl'); il6['Comparison']='IL33_vs_Vehicle_HUVEC_6hrs'
il24 = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_24_hrs.pkl'); il24['Comparison']='IL33_vs_Vehicle_HUVEC_24hrs'
allc = pd.concat([a, il6, il24])
allc['SE'] = allc.logFC/allc.t
genes = ['SELE','VCAM1','CXCL8','CCL2','PTX3','IL1RL1','CSF2','CXCL6','NFKBIA','TNFAIP3','IL6','TNFRSF11B','CCL20','IL18R1','GAPDH','ACTB']
piv = allc[allc.symbol.isin(genes)].pivot_table(index='Comparison', columns='symbol', values='SE')
order = ['IL33_vs_Vehicle_HUVEC_6hrs','IL33_vs_Vehicle_HUVEC_24hrs'] + list(a.Comparison.unique())
print(piv.reindex(order)[genes].round(2).to_string())
# genome-wide: median SE per contrast; and genes with SE>3 in IL33 vs vehicle 6h
x = il6.assign(SE=il6.logFC/il6.t)
print('\nIL33 vs Vehicle 6h: SE quantiles', x.SE.quantile([.5,.9,.99,.999]).round(3).to_dict())
big = x[(x.logFC.abs()>3)].sort_values('logFC', ascending=False)
print('genes with |lfc|>3:', len(big), ' of which FDR>=0.05:', (big['adj.P.Val']>=0.05).sum())
print(big[big['adj.P.Val']>=0.05].head(25)[['symbol','logFC','AveExpr','t','adj.P.Val','SE']].round(3).to_string())
