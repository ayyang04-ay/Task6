import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
from olink_map import M
M = dict(M); M['TF'] = 'F3'   # Olink CVD II 'TF' = tissue factor
pd.set_option('display.width',300); pd.set_option('display.max_rows',400)
rep = pd.read_pickle('prot_dedup.pkl')
rep['gene'] = rep.base.map(lambda b: M.get(b, b))
S = pd.read_pickle('huvec_sig.pkl')
il6 = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl'); il6['SE']=il6.logFC/il6.t
il6['bin']=pd.qcut(il6.AveExpr,40,labels=False,duplicates='drop'); il6['SE_ratio']=il6.SE/il6.groupby('bin').SE.transform('median')
S['SE_ratio'] = il6.drop_duplicates('symbol').set_index('symbol').SE_ratio
B = rep.merge(S, left_on='gene', right_index=True, how='left')
def cls(r):
    if pd.isna(r['IL33_lfc_6']): return 'not in RNA-seq'
    if r['SE_ratio']>3: return 'RNA-seq uninformative (inflated variance)'
    for t in ['6','24']:
        if r[f'IL33_q_{t}']<0.05 and r[f'IL33_lfc_{t}']>0.58 and r[f'blk_q_{t}']<0.05 and r[f'blk_lfc_{t}']<0: return 'IL33-induced & AX-1177-reversed'
    for t in ['6','24']:
        if r[f'IL33_q_{t}']<0.05 and r[f'IL33_lfc_{t}']<-0.58 and r[f'blk_q_{t}']<0.05 and r[f'blk_lfc_{t}']>0: return 'IL33-repressed & AX-1177-restored'
    return 'not IL-33 responsive'
B['class'] = B.apply(cls, axis=1)
B['rev6'] = -100*B.blk_lfc_6/B.IL33_lfc_6; B['rev24'] = -100*B.blk_lfc_24/B.IL33_lfc_24
print(B['class'].value_counts().to_string())
ind = B['class']=='IL33-induced & AX-1177-reversed'; oth = B['class']=='not IL-33 responsive'
z = -np.log10(B['p.value'])*np.sign(np.log(B.OR))
print('\nsigned -log10p: induced median %.2f (n=%d) vs not-responsive %.2f (n=%d); MWU p=%.3f' % (z[ind].median(), ind.sum(), z[oth].median(), oth.sum(), stats.mannwhitneyu(z[ind], z[oth]).pvalue))
tab = pd.crosstab(B.loc[ind|oth,'class'], B.loc[ind|oth,'BH_dedup']<0.05); print(tab); print('Fisher OR=%.2f p=%.3f' % stats.fisher_exact(tab.values[::-1]))
# stricter: strong induction lfc>=2 at 6h
strong = ind & (B.IL33_lfc_6>=2)
print('strongly induced (lfc6>=2) n=%d; frac FDR<.05 = %.2f vs not-responsive %.2f' % (strong.sum(), (B.loc[strong,'BH_dedup']<0.05).mean(), (B.loc[oth,'BH_dedup']<0.05).mean()))
cols = ['rank','assay','gene','OR','l95','u95','p.value','BH_dedup','IL33_lfc_6','rev6','IL33_lfc_24','rev24','hgblk_lfc_6','AveExpr']
x = B[ind].sort_values('p.value')
print(x[cols].round(3).to_string())
B.to_pickle('bridge2.pkl')
