import pandas as pd, numpy as np
from scipy import stats
a = pd.read_pickle('contrasts.pkl')
W = {}
# ---------- README
W['README'] = pd.DataFrame({'item':[
 'Purpose','Source files','Re-analysis environment','Key conventions','Sheets'],
 'description':[
 'Supporting evidence tables for the AX-1177 portfolio-audit memo (AX-1177_portfolio_audit_memo.md/.docx/.pdf).',
 'AX-1177_rnaseq_huvec_il33.xlsx; AX-1177_rnaseq_contrasts.xlsx; AX-1177_serum_proteomics.xlsx; AX-1177_postmortem_lung.xlsx; AX-1177_methods_annex.pdf (treated as ground truth; no external data used in any analysis).',
 'Python (pandas/scipy/statsmodels). Scripts in /tmp/outputs/code.',
 'Compound_47 = AX-1177; IC119 = isotype; IL-33red = reduced IL-33. "% reversal" = -(AX-1177+IL-33 vs isotype+IL-33 log2FC)/(IL-33 vs vehicle log2FC) x100. "SE ratio" = per-gene SE of log2FC divided by the median SE of genes at the same expression level (flag >3-5 = inflated variance). Proteomics FDR re-computed after collapsing cross-panel duplicates (1,063 unique proteins). Post-mortem statistics at donor level (n=31), never block level.',
 '1 Data_issue_log; 2 IL33_program_reversal; 3 Antibody_alone_summary; 4 Inflated_variance_genes; 5 Proteomics_dedup_bridge; 6 Biomarker_candidates; 7 Postmortem_donor_level; 8 Postmortem_tests; 9 Next_steps_gates']})
# ---------- Data issue log
issues = [
('R1','RNA-seq','Contrast workbook sheets "6h" and "24h" are identical duplicates (same 24 contrasts, both timepoints), only row order differs.','Cell-by-cell comparison: max difference 0 for all 24 contrasts.','None on numbers; high risk of misreading sheet names as timepoints.','Relabel/deliver once.'),
('R2','RNA-seq','IL-33 vs vehicle file is sorted by log2FC; the top rows are not significant (SELE log2FC 11.2, q=0.50; VCAM1 8.7, q=0.51; CXCL8 8.2, q=0.19; CCL2 4.2, q=0.77).','t-statistics 0.7-2.0; SE 4-9 log2 units.','A logFC-ranked reading selects exactly the wrong markers.','Rank by moderated t / FDR and effect size together.'),
('R3','RNA-seq','~275 genes (1%) have SE >5x (185 >10x) the expected value for their expression level in EVERY contrast: canonical endothelial activation markers (SELE, VCAM1, CXCL8, CCL2, CXCL1, PTGS2, PTX3, IL1RL1), endothelial identity (CDH5, VWF, PECAM1, KDR, CD93), epithelial-line identity (KRT8/18/19, GATA3, TFF1, AKR1C1-3, ALDH3A1) and housekeeping genes (GAPDH SE 9.6 vs median 0.34). Y-linked genes normal.','Fig 2; sheet Inflated_variance_genes.','These genes are uninformative: IL-33 regulation can be neither confirmed nor excluded (incl. IL1RL1/sST2). Pattern is consistent with cross-library contamination (e.g. index hopping; one flow cell) or a mislabelled/contaminated library under a single pooled-variance model.','Retrieve count matrix (archive); sample-identity QC (correlation clustering, marker genes); per-cell-line refit.'),
('R4','RNA-seq','One limma-voom model across 4 very different cell types (2 primary endothelial, 2 cancer lines): one residual variance per gene pooled over all 38 groups; AveExpr averaged over all 114 libraries.','Annex s.5.','Tests are miscalibrated for cell-type-restricted genes; AveExpr cannot be used as a per-line expression filter.','Per-cell-line fits.'),
('R5','RNA-seq','No vehicle arm in HGMEC and no IL-33-vs-isotype contrast delivered for either line.','Annex s.3; contrast list.','IL-33 effect in HGMEC cannot be quantified; only blockade is observable.','Deliver IL33 vs IC119 contrasts from archive.'),
('R6','RNA-seq','A549 and MCF7 received no IL-33 (antibody-alone arms only).','Annex s.3.','No evidence on epithelial IL-33 biology, including the oxidised-IL-33 (RAGE/EGFR) pathway that AX-1177 is stated to bind.','New experiment (Stage 1.3).'),
('R7','RNA-seq','DMSO used as a comparator for an antibody; DMSO is not the antibody vehicle.','Annex s.1/3.','Compound_47 vs DMSO contrasts are not interpretable as antibody effects. IC119 (isotype) is the correct comparator.','Use isotype/PBS contrasts only.'),
('R8','RNA-seq','Single antibody concentration (10 ug/mL = 68.5 nM; 41x molar excess over 1.66 nM IL-33), concurrent addition (no pre-incubation), reduced IL-33 only (30 ng/mL, supraphysiological), single donors (HUVEC P2, HGMEC P5), n=3 wells.','Annex s.1-3.','No potency (IC50/IC90), no donor generalisability, no lung endothelium.','Stage 1.1.'),
('R9','RNA-seq','Label inconsistency: comparison named "IL33_vs_Nontreated" in a sheet called "Vehicle"; vehicle composition not specified.','File contents.','Minor.','Document vehicle.'),
('R10','RNA-seq','Antibody-alone contrasts report extreme t for trivial effects (e.g. AKR1C2 t=169 for log2FC 0.11; DCBLD2 t=51 for 0.09).','Contrast tables.','FDR alone over-calls; use an effect-size filter.','Report |log2FC|>=0.5 and expression filters.'),
('P1','Proteomics','IL-33 itself is not in the delivery, nor TSLP, IL-4, IL-5 (Inflammation panel), IL-13 and 10 other Inflammation analytes; ~100 assays in total were withheld (BH denominator reconstructs as 1,194 vs 1,094 delivered). Withheld analytes are the known low-detectability ones; retained assays have <=~9% below-LOD per outcome group.','Delivered adj.p for rank-1 assay = p x 1,194; panel composition per Olink published content (external reference for assay content only).','The drug target cannot be assessed in serum from this delivery.','Retrieve vendor NPX + LOD flags for all assays.'),
('P2','Proteomics','27 proteins measured on >1 panel (58 rows, e.g. IL-6 x4, FGF-21 x3, HGF x2) not reconciled; treated as independent tests and hits.','Sheet Proteomics_dedup_bridge.','Inflates hit counts; duplicates agree closely (a useful internal replication).','Collapse to 1,063 unique proteins (done: 186 at FDR<5%).'),
('P3','Proteomics','Annex says BH "across all assays in the delivery"; numbers reconstruct with ~1,194 tests.','Implied N from rank-1 assay.','Slightly conservative; documentation error.','Correct annex.'),
('P4','Proteomics','Odds ratios are per log unit of each assay (scale-dependent): e.g. CSF-1 OR 90 (95% CI 4-1,933), SPON2 OR 93 (1.4-6,326). |log OR| correlates with its SE (r=0.59).','Delivered CIs.','OR magnitudes are not comparable across proteins.','Rank by z/p; request per-SD ORs.'),
('P5','Proteomics','Undocumented columns composite_endpoint_0/1 contain k/56 and k/44 fractions (max ~0.09).','Denominator check.','Interpreted as fraction below LOD among 56 non-events and 44 events (=> 44% event rate).','Confirm definition.'),
('P6','Proteomics','Single centre, pre-vaccination COVID-19 only, one timepoint (enrolment), n=100, no validation cohort; no data on treatments (e.g. corticosteroids) or time from symptom onset; "log-transformed" applied to NPX (already log2) is ambiguous.','Annex s.6.','Generalisability to current viral LRTI population (post-vaccination, influenza/RSV) untested.','Stage 2 cohort.'),
('P7','Proteomics','Association is pervasive: 82% of proteins have OR>1; Storey pi0 ~0.46-0.51; many top hits are intracellular proteins (NPM1, CALR, GSTP1, PRDX1/6, PXN) consistent with cell death.','Fig 3.','High rank of any single protein (incl. sST2) is weak evidence of pathway specificity.','Test pathway specificity with patient-level data.'),
('M1','Post-mortem','74 histology blocks from 31 donors; 3 donors supply 24/49 COVID+ blocks; donor ICC 0.44-0.63.','Mixed model.','Block-level tests overstate significance (VSM p=0.007 block-level vs 0.068 donor-level).','Analyse at donor level (done).'),
('M2','Post-mortem','Donor-level fields only on the first block, and donor notes sometimes on block "1B" (2040, 2045); 2 blank separator rows; Sample ID duplicated in an unnamed column.','Sheet inspection.','Naive row-wise analysis drops most blocks or misattributes covariates.','Forward-fill by donor (done).'),
('M3','Post-mortem','Disease-category labels contradict the autopsy diagnoses in 8/31 donors: 4/10 "COVID-neg pneumonia" without pneumonia (1905, 1961, 1968, 1970); 2/16 "COVID-pos pneumonia" without acute pneumonia (2067, 2101); 2/5 "non-pneumonia" with acute pneumonia/pneumonitis (1956, 1976). "Non-pneumonia" also includes pulmonary coccidioidomycosis (1944) and pulmonary fibrosis (1861, 1965).','Pathology text.','No clean disease control and no normal-lung reference.','Pathologist adjudication; add normal-lung controls.'),
('M4','Post-mortem','Delivered numeric scores = ordinal grade + 0.5 (0->0, 1+->1.5 ... 5+->5.5), exceeding the stated 0-5 scale; IL-33 quarter-point values (1.75, 3.25...) undocumented; ceiling (39/74 endothelial blocks at the maximum).','Exact relation EPO = EPX grade + 0.5 for all non-zero blocks.','Non-linear scale; poor dynamic range; use rank-based tests only.','Re-score on raw 0-5 or digital H-score.'),
('M5','Post-mortem','Single reader, semi-quantitative; serial/duplex sections; no inter-rater data. IL-33 endothelium vs VSM rho=0.83 (possible slide-level staining effect).','Annex s.7.','Measurement error of unknown size.','Blinded second reader + kappa.'),
('M6','Post-mortem','SARS-CoV-2 status missing for donor 1905 (labelled COVID-neg).','Sheet.','Minor.','Complete record.'),
('M7','Post-mortem','IHC measures stored (nuclear) IL-33; cannot distinguish release (alarmin depletion) from down-regulation.','Biology of the readout.','Lower staining in inflamed/COVID lungs is uninterpretable as pathway activity.','Measure released IL-33 (BAL/serum) and IL33 mRNA in archived tissue RNA.'),
]
W['Data_issue_log'] = pd.DataFrame(issues, columns=['ID','dataset','issue','evidence','impact','action'])
# ---------- reversal table
rows=[]
for t,tt in [('6','6_hrs'),('24','24_hrs')]:
    il = pd.read_pickle(f'huvec_IL33_vs_Vehicle_HUVEC_{tt}.pkl').set_index('ensembl')
    il['SE']=il.logFC/il.t; il['bin']=pd.qcut(il.AveExpr,40,labels=False,duplicates='drop'); il['SE_ratio']=il.SE/il.groupby('bin').SE.transform('median')
    blk = a[a.Comparison==f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{t}hrs'].set_index('ensembl')
    hg = a[a.Comparison==f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{t}hrs'].set_index('ensembl')
    m = il[['symbol','AveExpr','logFC','adj.P.Val','SE_ratio']].join(blk[['logFC','adj.P.Val']], rsuffix='_block').join(hg[['logFC','adj.P.Val']], rsuffix='_HGMEC_block')
    m.columns = ['symbol','AveExpr_all114','IL33_vs_vehicle_log2FC','IL33_vs_vehicle_FDR','SE_ratio','AX1177_block_log2FC','AX1177_block_FDR','HGMEC_block_log2FC','HGMEC_block_FDR']
    m['pct_reversal'] = -100*m.AX1177_block_log2FC/m.IL33_vs_vehicle_log2FC
    m['robust_set'] = (m.IL33_vs_vehicle_FDR<0.01)&(m.IL33_vs_vehicle_log2FC.abs()>1)&(m.SE_ratio<3)&(m.AveExpr_all114>0)
    m = m[(m.IL33_vs_vehicle_FDR<0.05)&(m.IL33_vs_vehicle_log2FC.abs()>1)]
    m.insert(0,'timepoint',f'{t} h')
    rows.append(m.reset_index())
R = pd.concat(rows).sort_values(['timepoint','IL33_vs_vehicle_FDR'])
W['IL33_program_reversal'] = R
# ---------- antibody alone summary
rows=[]
for c in a.Comparison.unique():
    if 'IL33' in c: continue
    d = a[a.Comparison==c]; s = d[d['adj.P.Val']<0.05]
    rows.append(dict(contrast=c, FDR05=len(s), of_which_low_expression_AveExpr_lt1=(s.AveExpr<1).sum(), of_which_tiny_change_abslog2FC_lt0p5=((s.AveExpr>=1)&(s.logFC.abs()<0.5)).sum(), robust_hits=((s.AveExpr>=1)&(s.logFC.abs()>=0.5)).sum(), robust_genes=', '.join(s[(s.AveExpr>=1)&(s.logFC.abs()>=0.5)].symbol.astype(str)), interpretable=('no - DMSO is not the antibody vehicle' if 'DMSO' in c else 'yes')))
W['Antibody_alone_summary'] = pd.DataFrame(rows)
# ---------- inflated variance genes
hi = pd.read_csv('high_SE_genes.csv')[['symbol','ensembl','AveExpr','logFC','t','adj.P.Val','SE','SE_ratio']]
W['Inflated_variance_genes'] = hi.rename(columns={'logFC':'IL33_vs_vehicle_6h_log2FC','t':'t','adj.P.Val':'FDR','SE':'SE_log2FC','SE_ratio':'SE_ratio_vs_expected'})
# ---------- proteomics dedup + bridge
B = pd.read_pickle('bridge2.pkl')
B = B[['rank','assay','base','gene','panel_short','OR','l95','u95','p.value','adj.p.value','BH_dedup','composite_endpoint_0','composite_endpoint_1','class','IL33_lfc_6','IL33_q_6','blk_lfc_6','IL33_lfc_24','IL33_q_24','blk_lfc_24','hgblk_lfc_6','SE_ratio','rev6','rev24']].rename(columns={'base':'protein','gene':'gene_symbol(mapped)','panel_short':'panel_of_representative_assay','adj.p.value':'delivered_adj.p','BH_dedup':'BH_FDR_dedup_1063','composite_endpoint_0':'frac_belowLOD_nonevents(inferred)','composite_endpoint_1':'frac_belowLOD_events(inferred)','class':'in_vitro_class','IL33_lfc_6':'HUVEC_IL33_log2FC_6h','IL33_q_6':'HUVEC_IL33_FDR_6h','blk_lfc_6':'AX1177_block_log2FC_6h','IL33_lfc_24':'HUVEC_IL33_log2FC_24h','IL33_q_24':'HUVEC_IL33_FDR_24h','blk_lfc_24':'AX1177_block_log2FC_24h','hgblk_lfc_6':'HGMEC_block_log2FC_6h','SE_ratio':'RNAseq_SE_ratio','rev6':'pct_reversal_6h','rev24':'pct_reversal_24h'})
W['Proteomics_dedup_bridge'] = B.sort_values('rank')
d = pd.read_pickle('prot2.pkl')
dup = d.groupby('base').filter(lambda x: len(x)>1).sort_values(['base','p.value'])[['base','assay','panel_short','OR','l95','u95','p.value','adj.p.value']]
W['Proteomics_duplicates'] = dup
# ---------- biomarker candidates
def g(assay):
    r = B[B.assay==assay].iloc[0]; return r
bm = []
def add(tier, marker, assay, gene, role, into_patients, timepoint, rationale, caveats):
    if assay:
        r = B[B.assay==assay]
        if len(r)==0:
            r = B[B.protein==assay]
        r = r.iloc[0]
        ev_serum = f"OR {r.OR:.2f} ({r.l95:.2f}-{r.u95:.2f}) per log unit; p={r['p.value']:.2g}; FDR(dedup)={r.BH_FDR_dedup_1063:.3f}; rank {int(r['rank'])}/1063"
        if pd.isna(r.HUVEC_IL33_log2FC_6h): ev_vitro = 'not in RNA-seq'
        elif r.in_vitro_class in ('IL33-induced & AX-1177-reversed','IL33-repressed & AX-1177-restored'):
            ev_vitro = f"HUVEC IL-33 log2FC {r.HUVEC_IL33_log2FC_6h:.2f} (6h) / {r.HUVEC_IL33_log2FC_24h:.2f} (24h); reversal {r.pct_reversal_6h:.0f}% / {r.pct_reversal_24h:.0f}%"
        elif r.RNAseq_SE_ratio>5:
            ev_vitro = f"RNA-seq uninformative (SE {r.RNAseq_SE_ratio:.0f}x expected)"
        else:
            ev_vitro = f"not IL-33-responsive in HUVEC (FDR {r.HUVEC_IL33_FDR_6h:.2f} at 6h, {r.HUVEC_IL33_FDR_24h:.2f} at 24h)"
    else:
        ev_serum, ev_vitro = 'not delivered (withheld/low detectability)', 'n/a'
    bm.append(dict(tier=tier, marker=marker, gene=gene, evidence_serum=ev_serum, evidence_in_vitro=ev_vitro, proposed_role=role, into_patients=into_patients, sampling=timepoint, rationale=rationale, caveats=caveats))
add('1 - use now','soluble ST2 (sST2)','ST2','IL1RL1','Prognostic ENRICHMENT / stratification factor (not predictive, not PD)','YES - first patient study','Enrolment, pre-dose (as in our cohort)','2nd strongest of 1,063 proteins; independent of NEWS2, age, sex; IL-33 decoy receptor (pathway context).','Non-specific (inflammation, cardiac/endothelial stress); single pre-vaccination COVID cohort; cut-off must be set in an independent cohort; predictive value unknown.')
add('2 - develop assay','IL-33 (free and drug-complexed/total)',None,'IL33','TARGET ENGAGEMENT (PK/PD, dose selection); exploratory predictive','YES - after assay development/validation','Pre-dose and serial post-dose','Only direct readout of the drug target; absent from our delivery.','Likely below Olink LOD; needs high-sensitivity and drug-tolerant assays; reduced vs oxidised forms.')
add('3 - exploratory PD','Osteoprotegerin (OPG)','OPG-CVDIII','TNFRSF11B','Exploratory PHARMACODYNAMIC marker of endothelial IL-33 activity','YES - exploratory endpoint only','Pre-dose, 24 h, day 3, day 7','Large in-vitro induction, ~100% reversed; outcome-associated on two independent panels.','Many cellular sources; validate at protein level in vitro first.')
add('3 - exploratory PD','soluble IL-18R1','IL-18R1','IL18R1','Exploratory PD','YES - exploratory','Pre-dose, 24 h, day 3, day 7','Induced and reversed in both endothelial lines; outcome-associated.','Soluble-form biology unclear.')
add('3 - exploratory PD','CCL20','CCL20','CCL20','Exploratory PD','YES - exploratory','Pre-dose, 24 h, day 3, day 7','Largest robust induction of the secreted set (~590-fold at 6 h), fully reversed; outcome-associated.','Epithelial/lymphoid sources.')
add('3 - exploratory PD','CSF-1 (M-CSF)','CSF-1','CSF1','Exploratory PD','YES - exploratory','Pre-dose, 24 h, day 3, day 7','Induced and reversed; outcome-associated.','OR per log unit inflated by narrow assay range.')
add('3 - exploratory PD','Tissue factor (TF)','TF','F3','Exploratory PD - thrombo-inflammatory arm','YES - exploratory (pair with TF activity/D-dimer)','Pre-dose, 24 h, day 3, day 7','~50-fold induced by IL-33, 97% reversed; outcome-associated (nominal).','Olink measures antigen, not activity; FDR 0.05.')
add('3 - exploratory PD','PAI-1','PAI','SERPINE1','Exploratory PD - fibrinolysis arm','YES - exploratory','Pre-dose, 24 h, day 3, day 7','Induced and fully reversed; nominal outcome association.','Platelet source; FDR 0.14.')
add('3 - exploratory PD','IL-6','IL6','IL6','Exploratory PD (composite only)','YES - exploratory, within a composite','Pre-dose, 24 h','Induced and reversed; outcome-associated on 4 panels.','Highly non-specific; suppressed by corticosteroids/IL-6R blockade.')
add('4 - mechanistic PD only','CXCL5','CXCL5','CXCL5','Mechanistic PD only (not disease-linked)','Optional','Pre-dose, 24 h','Strongly induced and reversed in vitro.','No association with outcome (p=0.52).')
add('4 - mechanistic PD only','CXCL6','CXCL6','CXCL6','Mechanistic PD only','Optional','Pre-dose, 24 h','Strongly induced and reversed.','No association with outcome (p=0.95).')
add('4 - mechanistic PD only','G-CSF','G-CSF','CSF3','Mechanistic PD only','Optional','Pre-dose, 24 h','Strongly induced and reversed.','No association with outcome (p=0.23).')
add('5 - prognostic covariate','HGF','HGF','HGF','Baseline risk covariate','YES - covariate','Enrolment','Strongest outcome association (rank 1).','Not IL-33-responsive in vitro -> not PD.')
add('5 - prognostic covariate','PTX3','PTX3','PTX3','Baseline risk covariate','YES - covariate','Enrolment','Rank 5.','RNA-seq uninformative -> cannot be linked to IL-33.')
add('5 - prognostic covariate','Angiopoietin-2','ANGPT2','ANGPT2','Baseline endothelial-injury covariate','YES - covariate','Enrolment','Outcome-associated (nominal).','Not IL-33-responsive in vitro.')
add('5 - prognostic covariate','von Willebrand factor','vWF','VWF','Baseline endothelial-injury covariate','YES - covariate','Enrolment','Outcome-associated (nominal).','RNA-seq uninformative.')
bm.append(dict(tier='X - do not use', marker='E-selectin / VCAM-1 / IL-8 / MCP-1 as PD markers', gene='SELE/VCAM1/CXCL8/CCL2', evidence_serum='SELE OR 2.08 (1.11-3.87) p=0.022; VCAM1 OR 1.28 (0.69-2.37) p=0.43; IL-8 OR 2.23 (1.35-3.68) p=0.0017; MCP-1 OR 1.96-2.26 p=0.008-0.010 (2 panels)', evidence_in_vitro='RNA-seq uninformative for all four (SE 12x, 10x, 18x, 26x expected); log2FC 11.2, 8.7, 8.2, 4.2 with FDR 0.50, 0.51, 0.19, 0.77', proposed_role='Ruled out as PD (may serve as prognostic covariates)', into_patients='NO (as PD)', sampling='-', rationale='Canonical endothelial activation markers; top of the logFC-sorted file.', caveats='No valid evidence here that IL-33 regulates them or that AX-1177 reverses them.'))
bm.append(dict(tier='X - do not use', marker='IL-33 immunohistochemistry', gene='IL33', evidence_serum='n/a', evidence_in_vitro='n/a', proposed_role='Ruled out for patient selection', into_patients='NO', sampling='-', rationale='Only tissue readout we have.', caveats='Not increased in COVID lungs; ceiling; single reader; inversely related to inflammation; cannot separate release from down-regulation; lung tissue not accessible in patients.'))
W['Biomarker_candidates'] = pd.DataFrame(bm)
# ---------- post-mortem donor level
dl = pd.read_pickle('pm_donor2.pkl').reset_index()
dl = dl[['SID','grp','Sex','Age','SARS','n_blocks','acute_pneu','DAD','PE','emph','COPD_note','asthma','IL33_epi','IL33_endo','IL33_vsm','EPX_o','EDN_o','MBP_o','2D7_o','IL5Ra_NE_o','NE_dup_o','Tryp_dup_o','HE_eos_b','Notes']]
dl.columns = ['donor','label_as_delivered','sex','age','SARS_CoV_2','n_blocks','acute_pneumonia_on_autopsy(curated)','DAD_or_ALI(curated)','pulmonary_thromboemboli(curated)','emphysema(path)','COPD_in_notes','asthma_in_notes','IL33_basal_epithelium(mean)','IL33_endothelium(mean)','IL33_VSM(mean)','EPX_grade(mean)','EDN_grade','MBP_grade','2D7_grade','IL5Ra_grade','neutrophil_elastase_grade','tryptase_grade','HE_eosinophils_frac_blocks','approved_lung_conditions']
W['Postmortem_donor_level'] = dl
W['Postmortem_tests'] = pd.read_csv('pm_tests.csv')
# ---------- next steps
steps = [
('Stage 0 (0-3 mo)','0.1','Retrieve withheld Olink output (all ~1,194 assays incl. IL-33, TSLP, IL-4/5/13) with LOD flags, plus patient-level NPX and clinical data; re-analyse: per-SD ORs, incremental value of sST2 over NEWS2 (delta-AUC, bootstrap), IL-33-reversible endothelial score, adjustment for steroids/time from onset.','Existing data','Is serum IL-33 detectable/associated? Does sST2 add to NEWS2? Is the endothelial IL-33 score outcome-linked beyond generic severity?'),
('Stage 0 (0-3 mo)','0.2','Retrieve RNA-seq counts + fitted model; sample-identity QC; per-cell-line refits; IL-33 vs isotype in HGMEC; re-test SELE/VCAM1/IL8/MCP-1/IL1RL1/PTX3.','Archive','Clean, per-line pharmacology package.'),
('Stage 0 (0-3 mo)','0.3','Post-mortem re-score: blinded 2nd reader on raw 0-5 scale + digital image analysis (nuclear IL-33 H-score); pathologist-adjudicated groups; add normal-lung controls.','Existing slides','Reliable tissue IL-33 estimate.'),
('Stage 0 (0-3 mo)','0.4','Profile the 22 archived tissue RNAs (9 COVID+, 9 COVID- "pneumonia", 4 other) for IL33, IL1RL1 and the AX-1177-reversible endothelial signature (targeted panel or RNA-seq).','Existing RNA','Is the endothelial IL-33 program active in diseased human lung?'),
('GATE A','A','CONTINUE only if (a) sST2 association survives patient-level re-analysis with incremental value over NEWS2, AND (b) at least one of: serum IL-33 detectable and higher in events; or AX-1177-reversible signature elevated in viral-pneumonia lung vs non-pneumonia. Otherwise STOP.','-','-'),
('Stage 1 (3-9 mo)','1.1','Dose-response (IC50/IC90) of AX-1177 vs reduced AND oxidised IL-33 in primary human lung microvascular endothelial cells (>=3 donors), concurrent vs pre-incubation; protein readouts (TF activity, PAI-1, OPG, IL-6, CCL20, sIL-18R1, CSF-1).','New','Potency; protein-level validation of PD panel; explains 24 h partial blockade.'),
('Stage 1 (3-9 mo)','1.2','Endogenous IL-33: virus-infected primary airway epithelium (influenza, RSV, SARS-CoV-2) -> conditioned medium/co-culture with lung endothelium +/- AX-1177.','New','Does AX-1177 block disease-relevant (released) IL-33, not just 30 ng/mL recombinant?'),
('Stage 1 (3-9 mo)','1.3','Oxidised IL-33 / RAGE-EGFR signalling in primary airway epithelium +/- AX-1177.','New','Tests the stated differentiator (binds oxidised form).'),
('Stage 1 (3-9 mo)','1.4','In vivo viral pneumonia model (cross-reactivity or surrogate): lung injury, vascular leak, coagulation markers, survival, and viral load/clearance.','New','Efficacy signal and host-defence safety.'),
('GATE B','B','ADVANCE to clinical planning only if AX-1177 inhibits endogenous-IL-33-driven endothelial activation by >=50% at clinically achievable exposure and does not impair viral clearance. Otherwise STOP.','-','-'),
('Stage 2 (9-18 mo)','2.1','Prospective observational biomarker cohort (contemporary, multi-virus, hospitalised): serial serum at enrolment, 24 h, day 3, day 7; validate sST2 enrichment cut-off, IL-33 assays, PD panel; sized from Stage 0 patient-level SDs.','New','Enrichment strategy and PD endpoints for a proof-of-mechanism study.'),
]
W['Next_steps_gates'] = pd.DataFrame(steps, columns=['stage','step','what','material','question_answered'])
with pd.ExcelWriter('/tmp/outputs/AX-1177_supporting_tables.xlsx', engine='openpyxl') as xw:
    for k,v in W.items():
        v.to_excel(xw, sheet_name=k[:31], index=False)
print({k:v.shape for k,v in W.items()})
