import pandas as pd, numpy as np, re
from scipy import stats
pd.set_option('display.width',300); pd.set_option('display.max_columns',50); pd.set_option('display.max_rows',200)
d = pd.read_pickle('pm_blocks.pkl')
def ordv(x):
    if pd.isna(x): return np.nan
    s=str(x).strip()
    if s.upper()=='ND': return np.nan
    return float(re.match(r'^(\d)', s).group(1))
for c in ['EPX','EDN','MBP','2D7','IL5Ra_NE','NE_dup','IL5Ra_tryp','Tryp_dup']:
    d[c+'_o'] = d[c].map(ordv)
d['HE_eos_b'] = (d.HE_eos.str.strip()=='Y').astype(float)
# donor-level fields: take first non-null per donor
donor_fields = ['DisCat','Race','Sex','Age','SARS','Path','Notes']
dl = d.groupby('SID')[donor_fields].agg(lambda s: s.dropna().iloc[0] if s.notna().any() else np.nan)
dl['n_blocks'] = d.groupby('SID').size()
num = ['IL33_epi','IL33_endo','IL33_vsm','EPX_o','EDN_o','MBP_o','2D7_o','IL5Ra_NE_o','NE_dup_o','IL5Ra_tryp_o','Tryp_dup_o','HE_eos_b']
agg = d.groupby('SID')[num].mean()
dl = dl.join(agg)
# order preserve
dl['grp'] = dl.DisCat.map({'COVID pos pneumonia':'COVID+ pneu','COVID neg pneumonia':'COVID- pneu','COVID neg non-pneumonia':'COVID- non-pneu'})
dl['COPD'] = dl.Notes.fillna('').str.contains('COPD') | dl.Path.fillna('').str.contains('mphysema')
dl['COPD_note'] = dl.Notes.fillna('').str.contains('COPD')
dl['emph_path'] = dl.Path.fillna('').str.contains('mphysema')
dl['asthma'] = dl.Notes.fillna('').str.contains('Asthma')
dl['fibrosis'] = dl.Notes.fillna('').str.contains('Fibrosis') | dl.Path.fillna('').str.contains('ibrosis', case=True) & dl.Path.fillna('').str.contains('ulmonary fibrosis|diffuse fibrosis')
dl['path_pneumonia'] = dl.Path.fillna('').str.contains('pneumonia|pneumonitis|alveolar damage|lung injury|bronchpneumonia', case=False)
dl['DAD_ALI'] = dl.Path.fillna('').str.contains('alveolar damage|lung injury|hyalin', case=False)
dl['PE_thromb'] = dl.Path.fillna('').str.contains('embol|thromb', case=False)
print(dl[['grp','Sex','Age','SARS','n_blocks','path_pneumonia','DAD_ALI','PE_thromb','COPD_note','emph_path','asthma','IL33_epi','IL33_endo','IL33_vsm','EPX_o','MBP_o','NE_dup_o','Tryp_dup_o']].round(2).to_string())
dl.to_pickle('pm_donor.pkl')
print()
print(dl.groupby('grp').agg(n=('Age','size'), age_med=('Age','median'), female=('Sex', lambda s:(s=='F').sum()), blocks=('n_blocks','sum'), pneu_in_path=('path_pneumonia','sum'), COPDnote=('COPD_note','sum'), emph=('emph_path','sum')).to_string())
