"""Convert the delivered AX-1177 workbooks to pickles used by all downstream scripts.
Run from a working directory (e.g. /tmp/work): python 00_load.py /tmp/world/filesystem"""
import sys, pandas as pd
src = sys.argv[1] if len(sys.argv) > 1 else '/tmp/world/filesystem'
# RNA-seq contrasts: sheets '6h' and '24h' are identical duplicates (verified); keep one copy
xl = pd.read_excel(f'{src}/AX-1177_rnaseq_contrasts.xlsx', sheet_name=None, engine='openpyxl')
a, b = xl['6h'], xl['24h']
for c in a.Comparison.unique():
    x = a[a.Comparison == c].set_index('ensembl').sort_index(); y = b[b.Comparison == c].set_index('ensembl').sort_index()
    assert x.index.equals(y.index) and (x[['logFC', 't', 'P.Value']] - y[['logFC', 't', 'P.Value']]).abs().max().max() == 0
a.to_pickle('contrasts.pkl')
h = pd.read_excel(f'{src}/AX-1177_rnaseq_huvec_il33.xlsx', sheet_name=None, engine='openpyxl')
for k, v in h.items():
    v.to_pickle(f'huvec_{k}.pkl')   # huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl / _24_hrs.pkl
pd.read_excel(f'{src}/AX-1177_serum_proteomics.xlsx', engine='openpyxl').to_pickle('prot.pkl')
pd.read_excel(f'{src}/AX-1177_postmortem_lung.xlsx', engine='openpyxl').to_pickle('pm.pkl')
print('loaded')
