"""Minimal Markdown -> PDF renderer (reportlab) for the AX-1177 memo.
Supports: YAML title/subtitle, # headings, paragraphs, nested bullets, numbered lists,
blockquotes, pipe tables (with <br>), images, **bold**, *italic*, ***bold-italic***, `code`.
Usage: python md_to_pdf.py memo.md out.pdf"""
import re, sys, os
import matplotlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table,
                                TableStyle, Image, KeepTogether, PageBreak)

FD = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
pdfmetrics.registerFont(TTFont('DV', os.path.join(FD, 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B', os.path.join(FD, 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DV-I', os.path.join(FD, 'DejaVuSans-Oblique.ttf')))
pdfmetrics.registerFont(TTFont('DV-BI', os.path.join(FD, 'DejaVuSans-BoldOblique.ttf')))
pdfmetrics.registerFont(TTFont('DVM', os.path.join(FD, 'DejaVuSansMono.ttf')))
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DV-B'); addMapping('DV', 0, 1, 'DV-I'); addMapping('DV', 1, 1, 'DV-BI')

NAVY = colors.HexColor('#1f3864')
S = {
    'title': ParagraphStyle('title', fontName='DV-B', fontSize=16, leading=20, textColor=NAVY, spaceAfter=4),
    'subtitle': ParagraphStyle('subtitle', fontName='DV', fontSize=10.5, leading=14, textColor=colors.grey, spaceAfter=10),
    'h1': ParagraphStyle('h1', fontName='DV-B', fontSize=12.5, leading=16, textColor=NAVY, spaceBefore=10, spaceAfter=5),
    'h2': ParagraphStyle('h2', fontName='DV-B', fontSize=11, leading=14, textColor=NAVY, spaceBefore=8, spaceAfter=4),
    'body': ParagraphStyle('body', fontName='DV', fontSize=9, leading=12.2, spaceAfter=5),
    'quote': ParagraphStyle('quote', fontName='DV-I', fontSize=9, leading=12.2, leftIndent=14, rightIndent=10,
                            textColor=colors.HexColor('#333333'), spaceAfter=6, borderPadding=(4, 4, 4, 6),
                            backColor=colors.HexColor('#eef2f8')),
    'cell': ParagraphStyle('cell', fontName='DV', fontSize=7.4, leading=9.2),
    'cellh': ParagraphStyle('cellh', fontName='DV-B', fontSize=7.6, leading=9.4, textColor=colors.white),
    'caption': ParagraphStyle('caption', fontName='DV-I', fontSize=8, leading=10, textColor=colors.grey, spaceAfter=8),
}


def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'&lt;br\s*/?&gt;', '<br/>', t)
    t = re.sub(r'`([^`]+)`', r'<font face="DVM">\1</font>', t)
    t = re.sub(r'\*\*\*(.+?)\*\*\*', r'<b><i>\1</i></b>', t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?![\*\w])', r'<i>\1</i>', t)
    return t


def bullet_style(level, numbered=False):
    left = 12 + 13 * level
    return ParagraphStyle(f'b{level}{numbered}', parent=S['body'], leftIndent=left, bulletIndent=left - 10, spaceAfter=2.5)


def make_table(rows, width):
    header, body = rows[0], rows[1:]
    ncol = len(header)
    # column widths from content length (bounded)
    lens = []
    for j in range(ncol):
        L = [len(re.sub(r'<[^>]+>|\*', '', r[j] if j < len(r) else '')) for r in rows]
        lens.append(max(5, min(150, sum(L) / len(L) + 0.3 * max(L))))
    tot = sum(lens)
    cw = [width * l / tot for l in lens]
    data = [[Paragraph(inline(c), S['cellh']) for c in header]]
    for r in body:
        r = r + [''] * (ncol - len(r))
        data.append([Paragraph(inline(c), S['cell']) for c in r[:ncol]])
    tb = Table(data, colWidths=cw, repeatRows=1)
    st = [('BACKGROUND', (0, 0), (-1, 0), NAVY), ('VALIGN', (0, 0), (-1, -1), 'TOP'),
          ('GRID', (0, 0), (-1, -1), 0.3, colors.HexColor('#b0b7c3')),
          ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
          ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]
    for i in range(1, len(data)):
        if i % 2 == 0:
            st.append(('BACKGROUND', (0, i), (-1, i), colors.HexColor('#f3f5f9')))
    tb.setStyle(TableStyle(st))
    return tb


def render(md_path, pdf_path):
    base = os.path.dirname(os.path.abspath(md_path))
    lines = open(md_path, encoding='utf-8').read().split('\n')
    story, title, subtitle = [], '', ''
    i = 0
    if lines and lines[0].strip() == '---':
        j = lines.index('---', 1)
        for l in lines[1:j]:
            m = re.match(r'(\w+):\s*"?(.*?)"?\s*$', l)
            if m and m.group(1) == 'title': title = m.group(2)
            if m and m.group(1) == 'subtitle': subtitle = m.group(2)
        i = j + 1
    if title: story.append(Paragraph(inline(title), S['title']))
    if subtitle: story.append(Paragraph(inline(subtitle), S['subtitle']))
    W = A4[0] - 3.6 * cm
    para = []

    def flush():
        if para:
            story.append(Paragraph(inline(' '.join(x.strip() for x in para)), S['body']))
            para.clear()
    while i < len(lines):
        l = lines[i]
        if not l.strip():
            flush(); i += 1; continue
        m = re.match(r'^(#{1,3})\s+(.*)', l)
        if m:
            flush(); lvl = len(m.group(1))
            if lvl == 1 and m.group(2).startswith('Appendix B'):
                story.append(PageBreak())
            story.append(Paragraph(inline(m.group(2)), S['h1'] if lvl == 1 else S['h2'])); i += 1; continue
        if l.startswith('|'):
            flush(); rows = []
            while i < len(lines) and lines[i].startswith('|'):
                cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.match(r'^:?-{2,}:?$', c) for c in cells if c):
                    rows.append(cells)
                i += 1
            ind = len(re.match(r'^(\s*)', l).group(1))
            story.append(Spacer(1, 2)); story.append(make_table(rows, W)); story.append(Spacer(1, 6)); continue
        if l.lstrip().startswith('|'):
            flush(); rows = []
            while i < len(lines) and lines[i].lstrip().startswith('|'):
                cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.match(r'^:?-{2,}:?$', c) for c in cells if c):
                    rows.append(cells)
                i += 1
            t = make_table(rows, W - 30); t.hAlign = 'CENTER'
            story.append(t); story.append(Spacer(1, 6)); continue
        m = re.match(r'^!\[(.*?)\]\((.*?)\)', l.strip())
        if m:
            flush(); p = os.path.join(base, m.group(2))
            from reportlab.lib.utils import ImageReader
            iw, ih = ImageReader(p).getSize()
            w = W; h = w * ih / iw
            maxh = A4[1] - 6.5 * cm
            if h > maxh: h = maxh; w = h * iw / ih
            story.append(KeepTogether([Image(p, width=w, height=h), Paragraph(inline(m.group(1)), S['caption'])]))
            i += 1; continue
        if l.startswith('>'):
            flush(); q = []
            while i < len(lines) and lines[i].startswith('>'):
                q.append(lines[i].lstrip('>').strip()); i += 1
            story.append(Paragraph(inline(' '.join(q)), S['quote'])); continue
        m = re.match(r'^(\s*)([-*]|\d+\.)\s+(.*)', l)
        if m:
            flush()
            sp = len(m.group(1)); lvl = 0 if sp < 2 else (1 if sp < 5 else 2)
            numbered = m.group(2)[0].isdigit()
            text = m.group(3); i += 1
            # continuation lines (indented, not a new list item / table / blank)
            while i < len(lines) and lines[i].strip() and not re.match(r'^\s*([-*]|\d+\.)\s+', lines[i]) \
                    and not lines[i].lstrip().startswith('|') and lines[i].startswith(' '):
                text += ' ' + lines[i].strip(); i += 1
            bullet = m.group(2) if numbered else ('•' if lvl == 0 else ('–' if lvl == 1 else '·'))
            story.append(Paragraph(inline(text), bullet_style(lvl, numbered), bulletText=bullet))
            continue
        para.append(l); i += 1
    flush()

    def on_page(c, d):
        c.saveState(); c.setFont('DV', 7.5); c.setFillColor(colors.grey)
        c.drawString(1.8 * cm, 1.1 * cm, 'AX-1177 portfolio audit: recommendation and forward view')
        c.drawRightString(A4[0] - 1.8 * cm, 1.1 * cm, f'page {d.page}')
        c.restoreState()
    doc = BaseDocTemplate(pdf_path, pagesize=A4, leftMargin=1.8 * cm, rightMargin=1.8 * cm, topMargin=1.6 * cm,
                          bottomMargin=1.7 * cm, title=title, author='Portfolio analytics')
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='f')
    doc.addPageTemplates([PageTemplate(id='p', frames=[frame], onPage=on_page)])
    doc.build(story)


if __name__ == '__main__':
    render(sys.argv[1], sys.argv[2])
    print('written', sys.argv[2])
