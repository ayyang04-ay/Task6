import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
dl = pd.read_pickle('pm_donor2.pkl').copy()
print(pd.crosstab([dl.covid, dl.COPD_any], dl.acute_pneu, margins=True))
for c in ['IL33_epi','IL33_endo','IL33_vsm']:
    x = dl[[c,'COPD_any','acute_pneu','covid','Age']].dropna().copy()
    x['r'] = x[c].rank()
    m = smf.ols('r ~ COPD_any + acute_pneu + covid + Age', x).fit()
    m0 = smf.ols('r ~ COPD_any', x).fit()
    print(f'{c}: rank-OLS COPD coef unadjusted p={m0.pvalues["COPD_any"]:.3f} | adjusted (pneumonia, COVID, age): COPD p={m.pvalues["COPD_any"]:.3f}, acute_pneu coef={m.params["acute_pneu"]:.1f} p={m.pvalues["acute_pneu"]:.3f}, covid p={m.pvalues["covid"]:.3f}')
# tissue RNA availability
b = pd.read_pickle('pm_blocks.pkl')
rna = b[b.RNA.notna()][['SID','Block','RNA']].merge(dl[['grp','acute_pneu','DAD','PE','COPD_any']], left_on='SID', right_index=True)
print('\nTissue RNA available:', len(rna), 'blocks from', rna.SID.nunique(), 'donors'); print(rna.groupby('grp').SID.nunique().to_string())
print(rna.sort_values(['grp','SID']).to_string())
