import pandas as pd, numpy as np
pd.set_option('display.width',250)
a = pd.read_pickle('contrasts.pkl')
cons = [c for c in a.Comparison.unique() if 'IL33' not in c]
for c in cons:
    d = a[a.Comparison==c]
    s = d[d['adj.P.Val']<0.05].sort_values('P.Value')
    print(f'==== {c}  nFDR<.05={len(s)}')
    print(s.head(15)[['symbol','logFC','AveExpr','t','P.Value','adj.P.Val','B']].round(4).to_string())
