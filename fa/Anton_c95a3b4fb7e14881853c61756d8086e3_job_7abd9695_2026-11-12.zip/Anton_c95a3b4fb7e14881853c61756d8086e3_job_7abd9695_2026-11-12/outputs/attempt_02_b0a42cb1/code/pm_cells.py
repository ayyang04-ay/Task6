import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',300); pd.set_option('display.max_rows',200)
dl = pd.read_pickle('pm_donor2.pkl')
cells = {'EPX_o':'Eos (EPX)','EDN_o':'Eos (EDN)','MBP_o':'Eos (MBP)','2D7_o':'Basophil (2D7)','IL5Ra_NE_o':'IL-5Ra','NE_dup_o':'Neutrophil elastase','Tryp_dup_o':'Mast cell tryptase','HE_eos_b':'H&E eos apparent (frac blocks)'}
rows=[]
for c,lab in cells.items():
    a = dl.loc[dl.covid==1, c].dropna(); b = dl.loc[dl.covid==0, c].dropna()
    b2 = dl.loc[(dl.covid==0)&(dl.grp=='COVID- pneu'), c].dropna()
    p = stats.mannwhitneyu(a,b).pvalue; p2 = stats.mannwhitneyu(a,b2).pvalue
    rows.append(dict(marker=lab, COVIDpos_med=a.median(), COVIDneg_all_med=b.median(), p_vs_allneg=p, COVIDneg_pneu_med=b2.median(), p_vs_negpneu=p2))
print(pd.DataFrame(rows).round(4).to_string())
print('\nSpearman correlations (donor level, n=31) IL-33 compartments vs cell markers:')
out=[]
for il in ['IL33_epi','IL33_endo','IL33_vsm']:
    for c,lab in cells.items():
        x = dl[[il,c]].dropna()
        r,p = stats.spearmanr(x[il], x[c])
        out.append(dict(IL33=il, marker=lab, rho=r, p=p, n=len(x)))
o = pd.DataFrame(out); print(o.round(3).pivot(index='marker', columns='IL33', values='rho').to_string()); print(o.round(4).pivot(index='marker', columns='IL33', values='p').to_string())
print('\nInter-compartment IL-33 correlations:'); print(dl[['IL33_epi','IL33_endo','IL33_vsm']].corr(method='spearman').round(3))
