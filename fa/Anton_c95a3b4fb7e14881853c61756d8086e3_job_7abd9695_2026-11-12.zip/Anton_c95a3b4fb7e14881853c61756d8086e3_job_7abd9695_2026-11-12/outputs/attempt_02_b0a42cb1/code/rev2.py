import pandas as pd, numpy as np
pd.set_option('display.width',250)
a = pd.read_pickle('contrasts.pkl')
out = {}
for t,tt in [('6','6_hrs'),('24','24_hrs')]:
    il = pd.read_pickle(f'huvec_IL33_vs_Vehicle_HUVEC_{tt}.pkl').set_index('ensembl')
    il['SE']=il.logFC/il.t; il['bin']=pd.qcut(il.AveExpr,40,labels=False,duplicates='drop'); il['SE_ratio']=il.SE/il.groupby('bin').SE.transform('median')
    blk = a[a.Comparison==f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{t}hrs'].set_index('ensembl')
    m = il.join(blk[['logFC','adj.P.Val']], rsuffix='_b')
    sel = m[(m['adj.P.Val']<0.01)&(m.logFC.abs()>1)&(m.SE_ratio<3)&(m.AveExpr>0)]
    r = -sel.logFC_b/sel.logFC*100
    up = sel.logFC>0
    print(f'HUVEC {t}h: robust IL-33-regulated genes n={len(sel)} (up {up.sum()}, down {(~up).sum()})')
    print(f'   % reversal vs isotype: median {r.median():.0f}%  IQR {r.quantile(.25):.0f}-{r.quantile(.75):.0f}%;  >=75% reversal: {(r>=75).mean()*100:.0f}% of genes;  reversed & FDR<.05: {((sel["adj.P.Val_b"]<0.05)&(np.sign(sel.logFC_b)!=np.sign(sel.logFC))).mean()*100:.0f}%')
    print(f'   up-genes median reversal {r[up].median():.0f}%; down-genes {r[~up].median():.0f}%')
    out[t]=sel
