import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',300); pd.set_option('display.max_columns',50); pd.set_option('display.max_rows',200)
dl = pd.read_pickle('pm_donor.pkl')
# Manual curation from pathology text (read in full above)
acute_pneu = {  # acute pneumonia / pneumonitis / DAD / ALI explicitly stated in final diagnoses
 1130:1,1138:1,1149:1,1159:1,1165:1,1910:1,1905:0,1970:0,1968:0,1961:0,
 2035:1,2044:1,2045:1,2049:1,2040:1,2043:1,2067:0,2072:1,2073:1,2075:1,2101:0,2105:1,2108:1,2110:1,2113:1,2060:1,
 1861:0,1944:0,1956:1,1965:0,1976:1}
dad = {2044:1,2049:1,2040:1,2043:1,2072:1,2108:1,2110:1}  # DAD / hyaline membranes / acute lung injury
thromb = {2035:1,2040:1,2113:1,2060:1}  # pulmonary (thrombo)emboli
coinf = {2044:'HSV tracheitis',2043:'Aspergillus',1944:'Coccidioides'}
emph = {1905:1,1968:1,2035:1,2044:1,2045:1,2040:1,2043:1,2067:1,2072:1,2073:1,2060:1,1861:1}
dl['acute_pneu'] = dl.index.map(lambda s: acute_pneu[int(s)])
dl['DAD'] = dl.index.map(lambda s: dad.get(int(s),0))
dl['PE'] = dl.index.map(lambda s: thromb.get(int(s),0))
dl['emph'] = dl.index.map(lambda s: emph.get(int(s),0))
dl['COPD_any'] = ((dl.COPD_note) | (dl.emph==1)).astype(int)
dl['covid'] = (dl.grp=='COVID+ pneu').astype(int)
dl.to_pickle('pm_donor2.pkl')
print('Curated pneumonia status vs label:'); print(pd.crosstab(dl.grp, dl.acute_pneu))
cols = ['IL33_epi','IL33_endo','IL33_vsm']
def mw(a,b):
    a=a.dropna(); b=b.dropna()
    u,p = stats.mannwhitneyu(a,b, alternative='two-sided')
    # rank-biserial / Cliff's delta
    delta = 2*u/(len(a)*len(b))-1
    return len(a),len(b),a.median(),b.median(),delta,p
rows=[]
comps = [
 ('COVID+ vs COVID- pneumonia (as labelled)', dl.grp=='COVID+ pneu', dl.grp=='COVID- pneu'),
 ('COVID+ vs all COVID- (as labelled)', dl.grp=='COVID+ pneu', dl.grp!='COVID+ pneu'),
 ('COVID+ vs COVID- non-pneumonia (as labelled)', dl.grp=='COVID+ pneu', dl.grp=='COVID- non-pneu'),
 ('COVID+ (path-confirmed pneu) vs COVID- (path-confirmed pneu)', (dl.covid==1)&(dl.acute_pneu==1), (dl.covid==0)&(dl.acute_pneu==1)),
 ('COVID- pneumonia: path-confirmed vs not', (dl.grp=='COVID- pneu')&(dl.acute_pneu==1), (dl.grp=='COVID- pneu')&(dl.acute_pneu==0)),
 ('Any acute pneumonia (path) vs none', dl.acute_pneu==1, dl.acute_pneu==0),
 ('Within COVID+: DAD/ALI vs no DAD', (dl.covid==1)&(dl.DAD==1), (dl.covid==1)&(dl.DAD==0)),
 ('Within COVID+: thromboemboli vs none', (dl.covid==1)&(dl.PE==1), (dl.covid==1)&(dl.PE==0)),
 ('COPD/emphysema vs not (all donors)', dl.COPD_any==1, dl.COPD_any==0),
 ('COPD/emphysema vs not (COVID- only)', (dl.COPD_any==1)&(dl.covid==0), (dl.COPD_any==0)&(dl.covid==0)),
 ('COPD/emphysema vs not (COVID+ only)', (dl.COPD_any==1)&(dl.covid==1), (dl.COPD_any==0)&(dl.covid==1)),
 ('Asthma note vs not', dl.asthma, ~dl.asthma),
]
for name,m1,m2 in comps:
    for c in cols:
        n1,n2,md1,md2,dlt,p = mw(dl.loc[m1,c], dl.loc[m2,c])
        rows.append(dict(comparison=name, compartment=c, n1=n1,n2=n2, median1=md1, median2=md2, cliffs_delta=round(dlt,2), p=p))
r = pd.DataFrame(rows)
print(r.round(4).to_string())
r.to_csv('pm_tests.csv', index=False)
# Kruskal across three labelled groups
for c in cols:
    g = [dl.loc[dl.grp==k, c].dropna() for k in ['COVID+ pneu','COVID- pneu','COVID- non-pneu']]
    print(c, 'Kruskal p=%.4f' % stats.kruskal(*g).pvalue, [round(x.median(),2) for x in g])
