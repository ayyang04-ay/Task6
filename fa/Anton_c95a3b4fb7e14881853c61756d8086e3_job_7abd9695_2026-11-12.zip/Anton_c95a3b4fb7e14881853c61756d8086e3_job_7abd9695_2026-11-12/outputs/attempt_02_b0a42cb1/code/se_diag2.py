import pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_rows',200)
il6 = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl')
il6['SE'] = il6.logFC/il6.t
# robust: SE relative to expected at that expression level (median SE by AveExpr bin)
il6['bin'] = pd.qcut(il6.AveExpr, 40, labels=False, duplicates='drop')
il6['SE_med_bin'] = il6.groupby('bin').SE.transform('median')
il6['SE_ratio'] = il6.SE/il6.SE_med_bin
for thr in [3,5,10]:
    print(f'genes with SE > {thr}x the median SE at their expression level:', (il6.SE_ratio>thr).sum())
hi = il6[il6.SE_ratio>5].sort_values('SE', ascending=False)
print(hi[['symbol','ensembl','logFC','AveExpr','t','adj.P.Val','SE','SE_ratio']].round(2).to_string())
print('\nGAPDH entries:', il6[il6.symbol=='GAPDH'][['ensembl','AveExpr','logFC','t','SE']].to_string())
hi.to_csv('high_SE_genes.csv', index=False)
