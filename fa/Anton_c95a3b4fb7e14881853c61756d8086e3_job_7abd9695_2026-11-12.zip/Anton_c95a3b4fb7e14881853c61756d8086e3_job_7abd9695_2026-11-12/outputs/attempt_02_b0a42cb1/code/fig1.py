import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9, 'axes.spines.top':False, 'axes.spines.right':False})
a = pd.read_pickle('contrasts.pkl')
fig, axes = plt.subplots(2,2, figsize=(11,9.5))
lab6 = {'NFKBIA':(-48,-10),'TNFAIP3':(6,4),'TRAF1':(6,-2),'CSF2':(6,0),'F3':(-22,-10),'C3':(-18,6),'IL6':(-28,-8),'CCL20':(6,2),'TNFRSF11B':(6,-8),'SERPINE1':(6,0),'THBD':(6,2),'OCLN':(6,-6),'CXCL6':(6,4),'CSF3':(-30,-2)}
lab24 = {'NFKBIA':(6,6),'CSF2':(6,0),'C3':(6,2),'IL6':(6,-4),'CCL20':(6,2),'TNFRSF11B':(6,2),'SERPINE1':(-40,8),'THBD':(6,0),'OCLN':(6,2),'CXCL6':(6,2),'CSF3':(6,0),'CFB':(6,-4)}
for k,(t,tt) in enumerate([('6','6_hrs'),('24','24_hrs')]):
    ax = axes[0,k]
    il = pd.read_pickle(f'huvec_IL33_vs_Vehicle_HUVEC_{tt}.pkl').set_index('ensembl')
    il['SE']=il.logFC/il.t; il['bin']=pd.qcut(il.AveExpr,40,labels=False,duplicates='drop'); il['SE_ratio']=il.SE/il.groupby('bin').SE.transform('median')
    blk = a[a.Comparison==f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{t}hrs'].set_index('ensembl')
    m = il.join(blk[['logFC','adj.P.Val']], rsuffix='_b')
    rob = (m['adj.P.Val']<0.01)&(m.logFC.abs()>1)&(m.SE_ratio<3)&(m.AveExpr>0)
    ax.scatter(m.logFC[~rob], m.logFC_b[~rob], s=2, c='lightgrey', rasterized=True, label='all other genes')
    ax.scatter(m.logFC[rob], m.logFC_b[rob], s=6, c='tab:red', alpha=.6, rasterized=True, label=f'robust IL-33-regulated genes (n={rob.sum()})')
    lim = 11 if t=='6' else 9
    ax.plot([-lim,lim],[lim,-lim],'k--',lw=.8, label='y = -x (complete neutralisation)')
    ax.axhline(0,c='grey',lw=.4); ax.axvline(0,c='grey',lw=.4)
    labs = lab6 if t=='6' else lab24
    for g,off in labs.items():
        r = m[m.symbol==g]
        if len(r):
            ax.annotate(g, (r.logFC.iloc[0], r.logFC_b.iloc[0]), fontsize=7, xytext=off, textcoords='offset points', arrowprops=dict(arrowstyle='-', lw=.4, color='k'))
    r = -m.logFC_b[rob]/m.logFC[rob]*100
    ax.set_title(f'HUVEC {t} h: IL-33 effect vs AX-1177 effect\nmedian reversal {r.median():.0f}% (IQR {r.quantile(.25):.0f}-{r.quantile(.75):.0f}%)', fontsize=9.5)
    ax.set_xlabel('IL-33red vs vehicle (log2FC)'); ax.set_ylabel('AX-1177+IL-33 vs isotype+IL-33 (log2FC)')
    ax.set_xlim(-4,lim+1); ax.set_ylim(-lim-2,4)
    ax.legend(fontsize=7, loc='lower left', frameon=False)
# panel C: DE counts
ax = axes[1,0]
rows=[]
for tt,lab_ in [('6_hrs','6h'),('24_hrs','24h')]:
    il = pd.read_pickle(f'huvec_IL33_vs_Vehicle_HUVEC_{tt}.pkl'); rows.append((f'IL-33 vs vehicle HUVEC {lab_}', (il['adj.P.Val']<0.05).sum(), 'IL-33 effect'))
for c in a.Comparison.unique():
    n = (a[a.Comparison==c]['adj.P.Val']<0.05).sum()
    if 'IL33_vs_IL33_IC119' in c: rows.append((c.replace('Compound_47_IL33_vs_IL33_IC119_','AX-1177 block ').replace('hrs','h'), n, 'AX-1177 blockade (vs isotype)'))
    elif 'vs_IC119' in c: rows.append((c.replace('Compound_47_vs_IC119_','AX-1177 alone ').replace('hrs','h'), n, 'AX-1177 alone (vs isotype)'))
df = pd.DataFrame(rows, columns=['contrast','n','type'])
col = {'IL-33 effect':'tab:orange','AX-1177 blockade (vs isotype)':'tab:red','AX-1177 alone (vs isotype)':'tab:blue'}
ax.barh(range(len(df)), df.n, color=[col[t] for t in df.type])
ax.set_yticks(range(len(df))); ax.set_yticklabels(df.contrast, fontsize=7.5); ax.invert_yaxis()
for i,n in enumerate(df.n): ax.text(n+40, i, str(n), va='center', fontsize=7)
ax.set_xlabel('genes at FDR < 0.05'); ax.set_title('Differential expression by contrast\n(antibody alone vs isotype: 21-73 genes/contrast; 95% near-zero-count or <1.4-fold;\nremaining 15 are singletons that never recur)', fontsize=9.5)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=v,label=k) for k,v in col.items()], fontsize=7, frameon=False, loc='lower right')
# panel D: thrombo-inflammatory program
ax = axes[1,1]
genes = ['F3','SERPINE1','PLAU','F2RL1','THBD','OCLN','C3','CFB','C1S','IL6','CCL20','TNFRSF11B','IL18R1','CSF1']
il6 = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl').drop_duplicates('symbol').set_index('symbol')
b6 = a[a.Comparison=='Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs'].drop_duplicates('symbol').set_index('symbol')
il24 = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_24_hrs.pkl').drop_duplicates('symbol').set_index('symbol')
b24 = a[a.Comparison=='Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs'].drop_duplicates('symbol').set_index('symbol')
y = np.arange(len(genes)); h=.2
ax.barh(y-1.5*h, il6.loc[genes,'logFC'], h, color='tab:orange', label='IL-33 vs vehicle 6 h')
ax.barh(y-0.5*h, b6.loc[genes,'logFC'], h, color='tab:red', label='AX-1177 block 6 h')
ax.barh(y+0.5*h, il24.loc[genes,'logFC'], h, color='navajowhite', label='IL-33 vs vehicle 24 h')
ax.barh(y+1.5*h, b24.loc[genes,'logFC'], h, color='lightcoral', label='AX-1177 block 24 h')
ax.set_yticks(y); ax.set_yticklabels(genes); ax.invert_yaxis(); ax.axvline(0,c='k',lw=.6)
ax.set_xlabel('log2FC'); ax.set_title('Coagulation / complement / barrier / secreted PD genes\n(IL-33 induces; AX-1177 reverses)', fontsize=9.5)
ax.legend(fontsize=7, frameon=False, loc='upper center', bbox_to_anchor=(0.5,-0.11), ncol=2)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/Fig1_AX1177_in_vitro_pharmacology.png', dpi=200); print('ok')
