import pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_rows',200)
S = pd.read_pickle('huvec_sig.pkl')
il6 = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl'); il6['SE']=il6.logFC/il6.t
il6['bin']=pd.qcut(il6.AveExpr,40,labels=False,duplicates='drop'); il6['SE_ratio']=il6.SE/il6.groupby('bin').SE.transform('median')
ser = il6.drop_duplicates('symbol').set_index('symbol').SE_ratio
genes = ['F3','SERPINE1','THBD','PROCR','PLAT','PLAU','PLAUR','TFPI','TFPI2','F2R','F2RL1','VWF','ANGPT2','TEK','CDH5','CLDN5','OCLN','TJP1','NOS3','EDN1','KLF2','KLF4','PTGS2','PTGIS','HMOX1','C3','C1R','C1S','CFB','CFH','CD55','SELP','ICAM1','VCAM1','SELE','NFKBIA','IL33']
x = S.reindex(genes)[['IL33_lfc_6','IL33_q_6','blk_lfc_6','blk_q_6','IL33_lfc_24','IL33_q_24','blk_lfc_24','blk_q_24']].copy()
x['SE_ratio']=ser.reindex(genes)
print(x.round(3).to_string())
