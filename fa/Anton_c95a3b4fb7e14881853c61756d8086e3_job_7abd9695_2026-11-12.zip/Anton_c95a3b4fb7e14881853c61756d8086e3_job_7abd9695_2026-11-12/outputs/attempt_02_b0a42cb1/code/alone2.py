import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
a = pd.read_pickle('contrasts.pkl')
cons = [c for c in a.Comparison.unique() if 'IL33' not in c]
hits = {}
for c in cons:
    d = a[a.Comparison==c]
    s = d[d['adj.P.Val']<0.05]
    hits[c] = set(s.ensembl)
    # classify
    low = (s.AveExpr<1).sum(); tiny=(s.logFC.abs()<0.5).sum()
    both = ((s.AveExpr>=1)&(s.logFC.abs()>=0.5)).sum()
    print(f'{c:35s} n={len(s):3d}  lowExpr(AveExpr<1)={low:3d} tinyLFC(<0.5)={tiny:3d}  robust(AveExpr>=1 & |lfc|>=0.5)={both}')
    if both:
        print('     robust:', s[(s.AveExpr>=1)&(s.logFC.abs()>=0.5)][['symbol','logFC','AveExpr','t','adj.P.Val']].round(3).values.tolist())
# recurrence
from collections import Counter
cnt = Counter(g for c in cons for g in hits[c])
rec = [(g,n) for g,n in cnt.items() if n>=2]
sym = a.drop_duplicates('ensembl').set_index('ensembl').symbol
print('\nGenes significant in >=2 antibody-alone contrasts:', len(rec))
for g,n in sorted(rec, key=lambda x:-x[1]):
    where = [c.replace('Compound_47_vs_','') for c in cons if g in hits[c]]
    print('  ', sym[g], n, where)
# Overlap with IL33 program
il6 = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl'); il24 = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_24_hrs.pkl')
ilset = set(il6[(il6['adj.P.Val']<0.05)&(il6.logFC.abs()>1)].ensembl) | set(il24[(il24['adj.P.Val']<0.05)&(il24.logFC.abs()>1)].ensembl)
print('\nIL-33 program (|lfc|>1 FDR<.05 at either time): n=', len(ilset))
for c in cons:
    ov = hits[c] & ilset
    print(f'  {c:35s} overlap={len(ov)}', [sym[g] for g in ov])
