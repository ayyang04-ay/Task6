import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9, 'axes.spines.top':False, 'axes.spines.right':False})
B = pd.read_pickle('bridge2.pkl')
B['slp'] = -np.log10(B['p.value'])*np.sign(np.log(B.OR))
fig, axes = plt.subplots(1,2, figsize=(13,5.6), gridspec_kw={'width_ratios':[1,1.15]})
ax = axes[0]
d = B.sort_values('p.value').reset_index(drop=True)
colmap = {'IL33-induced & AX-1177-reversed':'tab:red','IL33-repressed & AX-1177-restored':'tab:blue','not IL-33 responsive':'grey','RNA-seq uninformative (inflated variance)':'tab:purple','not in RNA-seq':'lightgrey'}
ax.scatter(np.arange(len(d))+1, -np.log10(d['p.value']), c=[colmap[c] for c in d['class']], s=6)
thr = d[d.BH_dedup<0.05]['p.value'].max()
ax.axhline(-np.log10(thr), ls='--', c='k', lw=.7); ax.text(700, -np.log10(thr)+.1, 'FDR 5% (de-duplicated, n=1,063)', fontsize=7)
for g,off in {'HGF':(8,-2),'ST2':(8,4),'PTX3':(8,2),'IL6':(8,0),'IL-18R1':(8,0),'OPG-CVDIII':(8,0),'CCL20':(8,-6),'CSF-1':(8,0),'TF':(-60,-22),'PAI':(8,0),'vWF':(10,14),'CXCL6':(8,4),'CXCL5':(8,0)}.items():
    r = d[d.assay==g]
    if len(r):
        i = r.index[0]; ax.annotate(g.replace('-CVDIII','')+(' (tissue factor)' if g=='TF' else ''), (i+1, -np.log10(r['p.value'].iloc[0])), xytext=off, textcoords='offset points', fontsize=7, arrowprops=dict(arrowstyle='-', lw=.4))
ax.set_xscale('log'); ax.set_xlabel('rank (1,063 unique proteins; cross-panel duplicates collapsed)'); ax.set_ylabel('-log10 p (composite endpoint, adj. age/sex/NEWS2)')
ax.set_title('Serum proteomics, 100 hospitalised COVID-19 patients (44 events)\n82% of proteins have OR>1; ~50% of the proteome non-null: a generic severity signal', fontsize=8.5)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=v,label=k) for k,v in colmap.items()], fontsize=6.5, frameon=False, loc='upper right')
ax = axes[1]
m = B[B['class'].isin(['IL33-induced & AX-1177-reversed','IL33-repressed & AX-1177-restored','not IL-33 responsive','RNA-seq uninformative (inflated variance)'])]
ax.scatter(m.IL33_lfc_6, m.slp, c=[colmap[c] for c in m['class']], s=10, alpha=.7)
ax.axhline(0,c='k',lw=.5); ax.axvline(0,c='k',lw=.5)
ax.axhline(-np.log10(thr), ls='--', c='k', lw=.6)
labs = {'IL6':(5,5),'OPG-CVDIII':(5,3),'IL-18R1':(5,3),'CCL20':(-10,8),'CSF-1':(5,-9),'TF':(5,3),'PAI':(5,-8),'CXCL6':(-5,-14),'CXCL5':(5,4),'CCL5':(5,-8),'G-CSF':(5,3),'ICAM1':(-38,10),'IL-27':(8,-12),'CX3CL1':(5,3),'HGF':(5,0),'ST2':(5,-4),'PTX3':(5,2),'SELE':(5,2),'VCAM1':(8,8),'TM':(-14,-10),'HDGF':(5,2),'TNF':(5,3),'CXCL10':(5,-6),'IL8':(-70,8),'MCP-1-CVDIII':(12,-20)}
for g,off in labs.items():
    r = m[m.assay==g]
    if len(r):
        nm = {'IL8':'IL-8 (uninformative)','MCP-1-CVDIII':'MCP-1 (uninformative)','OPG-CVDIII':'OPG','TF':'tissue factor','PAI':'PAI-1','IL-27':'EBI3/IL-27','TM':'thrombomodulin','ST2':'sST2 (uninformative in RNA-seq)'}.get(g,g)
        ax.annotate(nm, (r.IL33_lfc_6.iloc[0], r.slp.iloc[0]), xytext=off, textcoords='offset points', fontsize=7, arrowprops=dict(arrowstyle='-', lw=.4))
ax.set_xlabel('HUVEC: IL-33 vs vehicle, 6 h (log2FC of encoding gene)')
ax.set_ylabel('serum association with ICU/IMV/death (signed -log10 p)')
ind = B['class']=='IL33-induced & AX-1177-reversed'; oth = B['class']=='not IL-33 responsive'
ax.set_title('Bridge: in-vitro IL-33 response (x) vs patient outcome association (y)\nIL-33-induced & AX-1177-reversed: %d/%d (%.0f%%) at FDR<5%%\nvs %d/%d (%.0f%%) of non-responsive proteins (Fisher p=0.051)' % ((B.loc[ind,'BH_dedup']<.05).sum(), ind.sum(), 100*(B.loc[ind,'BH_dedup']<.05).mean(), (B.loc[oth,'BH_dedup']<.05).sum(), oth.sum(), 100*(B.loc[oth,'BH_dedup']<.05).mean()), fontsize=8.5)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/Fig3_serum_proteomics_bridge.png', dpi=200); print('ok')
