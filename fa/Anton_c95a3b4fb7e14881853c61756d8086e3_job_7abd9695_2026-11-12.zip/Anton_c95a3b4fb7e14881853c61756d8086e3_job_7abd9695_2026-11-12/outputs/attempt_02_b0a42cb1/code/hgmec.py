import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
a = pd.read_pickle('contrasts.pkl')
def get(c): return a[a.Comparison==c].set_index('ensembl')
for t,tt in [('6','6_hrs'),('24','24_hrs')]:
    il = pd.read_pickle(f'huvec_IL33_vs_Vehicle_HUVEC_{tt}.pkl').set_index('ensembl')
    hu = get(f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{t}hrs')
    hg = get(f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{t}hrs')
    hg2 = get(f'Compound_47_IL33_vs_IL33_HGMEC_{t}hrs')
    m = il[['symbol','logFC','adj.P.Val']].join(hu[['logFC','adj.P.Val']], rsuffix='_huBlk').join(hg[['logFC','t','adj.P.Val']], rsuffix='_hgBlk').join(hg2[['logFC','adj.P.Val']], rsuffix='_hgBlk2')
    print('=== ', t, 'h')
    print(' all-gene pearson: HUVEC block vs HGMEC block = %.3f; HUVEC IL33 vs HGMEC block = %.3f' % (stats.pearsonr(m.logFC_huBlk, m.logFC_hgBlk)[0], stats.pearsonr(m.logFC, m.logFC_hgBlk)[0]))
    s = m[m['adj.P.Val_huBlk']<0.05]
    print(' among HUVEC block DE (n=%d): pearson HUVEC-block vs HGMEC-block lfc = %.3f, slope=%.3f' % (len(s), stats.pearsonr(s.logFC_huBlk, s.logFC_hgBlk)[0], np.polyfit(s.logFC_huBlk, s.logFC_hgBlk,1)[0]))
    s2 = m[m['adj.P.Val_hgBlk']<0.05]
    print(' HGMEC block DE n=%d; of these, in same dir as HUVEC block: %.3f; HUVEC-block-significant: %.3f; opposite to HUVEC IL33 lfc: %.3f' % (len(s2), (np.sign(s2.logFC_hgBlk)==np.sign(s2.logFC_huBlk)).mean(), (s2['adj.P.Val_huBlk']<0.05).mean(), (np.sign(s2.logFC_hgBlk)!=np.sign(s2.logFC)).mean()))
    # HGMEC-derived IL-33 effect proxy: -(block lfc) = IL33_IC119 - C47_IL33 ~ IL33 effect if block complete
    print(m.sort_values('t', ascending=True).head(25)[['symbol','logFC','logFC_huBlk','logFC_hgBlk','t','adj.P.Val_hgBlk','logFC_hgBlk2']].round(3).to_string())
