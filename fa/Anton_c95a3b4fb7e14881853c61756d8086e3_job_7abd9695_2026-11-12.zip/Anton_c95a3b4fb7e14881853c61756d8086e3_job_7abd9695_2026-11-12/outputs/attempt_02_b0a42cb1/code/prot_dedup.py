import pandas as pd, numpy as np, re
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250); pd.set_option('display.max_rows',300); pd.set_option('display.max_colwidth',45)
d = pd.read_pickle('prot.pkl')
d['panel_short'] = d.panel.str.replace('Olink Target 96 ','').str.replace(r'\(v\.\d+\)','',regex=True)
SFX = ['INFI','CVDII','CVDIII','ONCII','ONCIII','CRE','IMO','ODA','MET','NEX','NEUI','DEV','CM','CMET']
def base(a):
    for s in sorted(SFX, key=len, reverse=True):
        if a.endswith('-'+s): return a[:-(len(s)+1)]
    return a
d['base'] = d.assay.map(base)
g = d.groupby('base')
dups = g.filter(lambda x: len(x)>1).sort_values(['base','p.value'])
print('unique base proteins:', d.base.nunique(), 'of', len(d), 'assays;', dups.base.nunique(), 'proteins measured on >1 panel (', len(dups), 'rows)')
print(dups[['base','assay','panel_short','OR','l95','u95','p.value','adj.p.value']].round(4).to_string())
d.to_pickle('prot2.pkl')
