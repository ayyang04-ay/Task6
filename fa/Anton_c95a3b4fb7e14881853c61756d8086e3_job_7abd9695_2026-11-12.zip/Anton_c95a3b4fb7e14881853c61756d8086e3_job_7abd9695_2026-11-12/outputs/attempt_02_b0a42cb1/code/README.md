# AX-1177 re-analysis code

Environment: `micromamba run -n singlecell python <script>` (pandas, scipy, statsmodels, matplotlib, openpyxl).
Run all scripts from one working directory, in this order:

1. `00_load.py <path-to-delivered-files>` converts the workbooks to pickles (and verifies the two contrast sheets are identical).
2. RNA-seq: `rev.py`, `rev2.py` (IL-33 program and AX-1177 reversal), `alone.py`, `alone2.py` (antibody-alone), `iso.py` (isotype effect), `hgmec.py`, `se_diag.py`, `se_diag2.py` (writes high_SE_genes.csv), `se_diag3.py` (variance-inflation diagnostics).
3. Proteomics: `prot_dedup.py` (writes prot2.pkl), `prot_overview.py` (writes prot_dedup.pkl), `bridge.py` (writes huvec_sig.pkl), `bridge2.py` (writes bridge2.pkl; Olink name map in `olink_map.py`, with TF mapped to F3/tissue factor), then `coag.py` (needs huvec_sig.pkl from bridge.py).
4. Post-mortem: `pm_clean.py` (writes pm_blocks.pkl), `pm_donor.py` (writes pm_donor.pkl), `pm_stats.py` (writes pm_donor2.pkl and pm_tests.csv), `pm_cells.py`, `pm_naive.py`, `pm_copd.py`.
5. Outputs: `fig1.py`-`fig4.py` (figures), `tables.py` (AX-1177_supporting_tables.xlsx), `md_to_pdf.py` (memo PDF; run in the `core` env: `python md_to_pdf.py memo.md memo.pdf`). The DOCX was built with pandoc (`genomics` env) using a small Lua filter that turns `<br>` into line breaks.

Curated pathology flags (acute pneumonia, DAD/ALI, thromboemboli, emphysema) are hard-coded in `pm_stats.py` from a manual reading of the delivered autopsy text. They are listed there for audit.
