import pandas as pd, numpy as np
from statsmodels.stats.multitest import multipletests
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',300)
d = pd.read_pickle('prot2.pkl')
# sanity: reproduce delivered BH
bh = multipletests(d['p.value'], method='fdr_bh')[1]
print('max |delivered adj.p - recomputed BH over 1094|:', np.abs(bh - d['adj.p.value']).max())
# CI consistency: log OR symmetric? compute SE from CI and implied p
d['logOR']=np.log(d.OR); d['se']=(np.log(d.u95)-np.log(d.l95))/(2*1.959964)
d['z']=d.logOR/d.se; d['p_wald']=2*stats.norm.sf(np.abs(d.z))
print('CI symmetry check (log scale) max asym:', (np.abs((np.log(d.u95)-d.logOR)-(d.logOR-np.log(d.l95)))).max())
print('p (delivered) vs Wald-from-CI: spearman', stats.spearmanr(d['p.value'], d.p_wald)[0], ' median ratio', np.median(d['p.value']/d.p_wald))
print('Delivered: FDR<0.05:', (d['adj.p.value']<0.05).sum(), ' FDR<0.10:', (d['adj.p.value']<0.10).sum(), ' nominal p<0.05:', (d['p.value']<0.05).sum(), 'of', len(d))
print('Direction among FDR<0.05: OR>1:', ((d['adj.p.value']<0.05)&(d.OR>1)).sum(), ' OR<1:', ((d['adj.p.value']<0.05)&(d.OR<1)).sum())
print('Direction among nominal p<0.05: OR>1:', ((d['p.value']<0.05)&(d.OR>1)).sum(), ' OR<1:', ((d['p.value']<0.05)&(d.OR<1)).sum())
print('Overall fraction OR>1:', (d.OR>1).mean().round(3))
# dedup: one representative per protein; rule: prefer assay with lowest total below-LOD fraction, then unsuffixed, then panel alphabetical (outcome-blind)
d['lodsum'] = d.composite_endpoint_0 + d.composite_endpoint_1
d['suffixed'] = d.assay != d.base
rep = d.sort_values(['base','lodsum','suffixed','panel']).groupby('base').head(1).copy()
rep['BH_dedup'] = multipletests(rep['p.value'], method='fdr_bh')[1]
print('\nDe-duplicated: n proteins', len(rep), ' FDR<0.05:', (rep.BH_dedup<0.05).sum(), ' FDR<0.10:', (rep.BH_dedup<0.10).sum())
# storey pi0
p = rep['p.value'].values
for lam in [0.5,0.7]:
    print(f'  Storey pi0 (lambda={lam}):', round(((p>lam).mean())/(1-lam),3))
rep = rep.sort_values('p.value')
rep['rank'] = np.arange(1,len(rep)+1)
print(rep.head(60)[['rank','assay','panel_short','OR','l95','u95','p.value','adj.p.value','BH_dedup','composite_endpoint_0','composite_endpoint_1']].round(5).to_string())
rep.to_pickle('prot_dedup.pkl')
print('\nST2 row:'); print(rep[rep.base=='ST2'][['rank','assay','OR','l95','u95','p.value','adj.p.value','BH_dedup']].to_string())
