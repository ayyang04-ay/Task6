import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({'font.size':9, 'axes.spines.top':False, 'axes.spines.right':False})
dl = pd.read_pickle('pm_donor2.pkl'); b = pd.read_pickle('pm_blocks.pkl')
b = b.merge(dl[['grp']], left_on='SID', right_index=True)
order = ['COVID+ pneu','COVID- pneu','COVID- non-pneu']
names = {'COVID+ pneu':'COVID+\n"pneumonia"\n16 donors/49 blocks','COVID- pneu':'COVID-\n"pneumonia"\n10/15','COVID- non-pneu':'COVID-\n"non-pneumonia"\n5/10'}
fig, axes = plt.subplots(1,4, figsize=(16,4.8), gridspec_kw={'width_ratios':[1,1,1,1.1]})
rng = np.random.default_rng(1)
for k,(c,title) in enumerate([('IL33_epi','IL-33: bronchial/bronchiolar basal epithelium'),('IL33_endo','IL-33: endothelium'),('IL33_vsm','IL-33: vascular smooth muscle')]):
    ax = axes[k]
    for i,g in enumerate(order):
        bb = b[b.grp==g][c].dropna(); ax.scatter(i+rng.normal(0,.09,len(bb)), bb, s=8, c='lightgrey', zorder=1, label='individual blocks' if i==0 else None)
        dd = dl[dl.grp==g]
        ap = dd.acute_pneu==1
        ax.scatter(i+rng.normal(0,.06,ap.sum()), dd[c][ap], s=36, c='tab:red', edgecolor='k', lw=.4, zorder=3, label='donor: acute pneumonia on autopsy' if (i==0) else None)
        ax.scatter(i+rng.normal(0,.06,(~ap).sum()), dd[c][~ap], s=36, c='white', edgecolor='k', lw=.8, zorder=3, label='donor: no acute pneumonia on autopsy' if (i==0) else None)
        ax.hlines(dd[c].median(), i-.3, i+.3, color='k', lw=2, zorder=4)
    a_ = dl.loc[dl.covid==1,c].dropna(); b_ = dl.loc[dl.covid==0,c].dropna()
    p = stats.mannwhitneyu(a_, b_).pvalue
    ax.set_xticks(range(3)); ax.set_xticklabels([names[g] for g in order], fontsize=7)
    ax.set_ylim(-0.3, 6.2); ax.axhline(5, c='tab:purple', ls=':', lw=.8); ax.text(2.45, 5.02, 'stated max (5)', fontsize=6.5, color='tab:purple', ha='right', va='bottom')
    ax.set_title(f'{title}\nCOVID+ vs all COVID- (donor level): p={p:.3f}', fontsize=8.5)
    ax.set_ylabel('IHC score as delivered (grade + 0.5)') if k==0 else None
    if k==0: ax.legend(fontsize=6.5, frameon=False, loc='lower left')
ax = axes[3]
x = dl[['IL33_endo','NE_dup_o','covid']].dropna()
r,p = stats.spearmanr(x.IL33_endo, x.NE_dup_o)
ax.scatter(x.NE_dup_o[x.covid==1]+rng.normal(0,.04,(x.covid==1).sum()), x.IL33_endo[x.covid==1], c='tab:red', s=30, edgecolor='k', lw=.4, label='COVID+')
ax.scatter(x.NE_dup_o[x.covid==0]+rng.normal(0,.04,(x.covid==0).sum()), x.IL33_endo[x.covid==0], c='tab:blue', s=30, edgecolor='k', lw=.4, label='COVID-')
ax.set_xlabel('neutrophil elastase IHC (donor mean grade)'); ax.set_ylabel('endothelial IL-33 (donor mean)')
ax.set_title(f'IL-33 staining falls as inflammation rises\nSpearman rho={r:.2f}, p={p:.3f} (n=31 donors)', fontsize=8.5)
ax.legend(fontsize=7, frameon=False)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/Fig4_postmortem_IL33_IHC.png', dpi=200); print('ok')
