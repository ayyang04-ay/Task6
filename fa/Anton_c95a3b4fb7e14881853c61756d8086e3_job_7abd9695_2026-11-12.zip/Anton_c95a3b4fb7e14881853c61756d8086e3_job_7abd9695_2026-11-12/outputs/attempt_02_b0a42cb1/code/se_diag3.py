import pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_rows',200)
il6 = pd.read_pickle('huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl')
il6['SE'] = il6.logFC/il6.t
il6['bin'] = pd.qcut(il6.AveExpr, 40, labels=False, duplicates='drop')
il6['SE_ratio'] = il6.SE/il6.groupby('bin').SE.transform('median')
sets = {
 'sex: Y-linked': ['RPS4Y1','DDX3Y','UTY','KDM5D','EIF1AY','USP9Y','ZFY'],
 'sex: XIST': ['XIST','TSIX'],
 'endothelial identity': ['PECAM1','CDH5','VWF','CD93','MMRN1','TIE1','TEK','KDR','ENG','ESM1','EGFL7','STAB1','EMCN','PLVAP','SOX18','ERG','FLT1','NOS3','CLDN5','ROBO4'],
 'MCF7 identity': ['ESR1','GATA3','TFF1','TFF3','GREB1','PGR','KRT8','KRT18','KRT19','XBP1','FOXA1','SPDEF','AGR2','CA12'],
 'A549 identity / NRF2': ['AKR1C1','AKR1C2','AKR1C3','AKR1B10','ALDH3A1','NQO1','TXNRD1','GPX2','G6PD','SLC7A11','CYP4F11','SFTPB','NKX2-1'],
 'generic epithelial': ['EPCAM','CDH1','KRT7','CLDN4','ELF3'],
 'housekeeping': ['GAPDH','ACTB','B2M','PPIA','RPLP0','TBP','HPRT1','PGK1','EEF2','HSP90AA1','TUBB','UBC','YWHAZ'],
 'IL-33/NF-kB targets (robust)': ['NFKBIA','TNFAIP3','TRAF1','RELB','NFKB2','CSF2','CSF3','IL6','CCL20','TNFRSF11B','IL18R1','CXCL2','CXCL3','CXCL5','CXCL6','ICAM1','SOD2','IRAK2','BIRC3'],
 'IL-33/NF-kB targets (suspect)': ['SELE','VCAM1','CXCL8','CCL2','CXCL1','PTGS2','PTX3','IL1RL1','TNFAIP2'],
}
rows=[]
for k,g in sets.items():
    x = il6[il6.symbol.isin(g)]
    rows.append(dict(set=k, n_found=len(x), median_SE_ratio=x.SE_ratio.median(), frac_gt5=(x.SE_ratio>5).mean(), genes_gt5=','.join(x[x.SE_ratio>5].symbol)))
print(pd.DataFrame(rows).round(2).to_string())
print('\nGenome-wide fraction SE_ratio>5:', round((il6.SE_ratio>5).mean(),4))
print(il6[il6.symbol.isin(sets['sex: Y-linked']+sets['sex: XIST'])][['symbol','AveExpr','logFC','t','SE','SE_ratio']].round(2).to_string())
