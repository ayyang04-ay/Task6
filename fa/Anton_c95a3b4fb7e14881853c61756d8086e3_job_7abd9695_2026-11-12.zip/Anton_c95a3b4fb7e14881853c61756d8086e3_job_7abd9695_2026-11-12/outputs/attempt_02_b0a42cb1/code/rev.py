import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
a = pd.read_pickle('contrasts.pkl')
def get(c):
    return a[a.Comparison==c].set_index('ensembl')
for t,tt in [('6','6_hrs'),('24','24_hrs')]:
    il = pd.read_pickle(f'huvec_IL33_vs_Vehicle_HUVEC_{tt}.pkl').set_index('ensembl')
    blk = get(f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{t}hrs')
    blk2 = get(f'Compound_47_IL33_vs_IL33_HUVEC_{t}hrs')
    m = il[['symbol','logFC','t','adj.P.Val','AveExpr']].join(blk[['logFC','t','adj.P.Val']], rsuffix='_blk').join(blk2[['logFC','t','adj.P.Val']], rsuffix='_blk2')
    print('==== HUVEC', t, 'h')
    print('all genes: spearman(IL33 lfc, block lfc)=%.3f  pearson=%.3f' % (stats.spearmanr(m.logFC, m.logFC_blk)[0], stats.pearsonr(m.logFC, m.logFC_blk)[0]))
    sig = m[(m['adj.P.Val']<0.05)]
    print('IL-33 DE genes (FDR<.05) n=%d: pearson lfc=%.3f' % (len(sig), stats.pearsonr(sig.logFC, sig.logFC_blk)[0]))
    # fraction reversed: slope of block lfc on IL33 lfc
    for name, s in [('FDR<.05', sig), ('FDR<.05 & |lfc|>1', m[(m['adj.P.Val']<0.05)&(m.logFC.abs()>1)]), ('FDR<.01 & lfc>1 & AveExpr>0', m[(m['adj.P.Val']<0.01)&(m.logFC>1)&(m.AveExpr>0)])]:
        slope = np.polyfit(s.logFC, s.logFC_blk, 1)[0]
        opp = (np.sign(s.logFC)!=np.sign(s.logFC_blk)).mean()
        opp_sig = ((np.sign(s.logFC)!=np.sign(s.logFC_blk)) & (s['adj.P.Val_blk']<0.05)).mean()
        ratio = (-s.logFC_blk/s.logFC)
        print(f'  {name:30s} n={len(s):5d} slope(block~IL33)={slope:.3f} frac_opposite={opp:.3f} frac_opp&sig={opp_sig:.3f} median %reversal={100*ratio.median():.1f}')
    # residual IL-33 effect under antibody: IL33+C47 vs vehicle = (C47IL33 - IL33) + (IL33 - veh)
    m['resid'] = m.logFC + m.logFC_blk2
    s = m[(m['adj.P.Val']<0.05)&(m.logFC.abs()>1)]
    print('  residual (C47+IL33 vs Vehicle, derived) among IL33 DE |lfc|>1: median |resid|/|IL33| = %.3f' % (np.median(np.abs(s.resid)/np.abs(s.logFC))))
    top = m.sort_values('t', ascending=False).head(30)
    top['pct_rev_vsIC119'] = -100*top.logFC_blk/top.logFC
    top['pct_rev_vsIL33'] = -100*top.logFC_blk2/top.logFC
    print(top[['symbol','logFC','t','logFC_blk','t_blk','adj.P.Val_blk','logFC_blk2','pct_rev_vsIC119','pct_rev_vsIL33']].round(3).to_string())
