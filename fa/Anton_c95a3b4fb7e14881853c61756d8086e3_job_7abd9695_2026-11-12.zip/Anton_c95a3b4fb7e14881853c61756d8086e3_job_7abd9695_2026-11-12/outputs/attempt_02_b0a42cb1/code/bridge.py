import pandas as pd, numpy as np
from scipy import stats
from olink_map import M
pd.set_option('display.width',300); pd.set_option('display.max_rows',400)
rep = pd.read_pickle('prot_dedup.pkl')
rep['gene'] = rep.base.map(lambda b: M.get(b, b))
a = pd.read_pickle('contrasts.pkl')
sig = {}
for t,tt in [('6','6_hrs'),('24','24_hrs')]:
    il = pd.read_pickle(f'huvec_IL33_vs_Vehicle_HUVEC_{tt}.pkl')
    blk = a[a.Comparison==f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{t}hrs']
    hg = a[a.Comparison==f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{t}hrs']
    x = il[['symbol','logFC','adj.P.Val','AveExpr']].rename(columns={'logFC':f'IL33_lfc_{t}','adj.P.Val':f'IL33_q_{t}','AveExpr':'AveExpr'})
    x = x.merge(blk[['symbol','logFC','adj.P.Val']].rename(columns={'logFC':f'blk_lfc_{t}','adj.P.Val':f'blk_q_{t}'}), on='symbol', how='left')
    x = x.merge(hg[['symbol','logFC','adj.P.Val']].rename(columns={'logFC':f'hgblk_lfc_{t}','adj.P.Val':f'hgblk_q_{t}'}), on='symbol', how='left')
    x = x.drop_duplicates('symbol')
    sig[t]=x.set_index('symbol')
S = sig['6'].join(sig['24'].drop(columns=['AveExpr']), how='outer')
S.to_pickle('huvec_sig.pkl')
B = rep.merge(S, left_on='gene', right_index=True, how='left')
print('Olink proteins mapped to an RNA-seq gene:', B['IL33_lfc_6'].notna().sum(), 'of', len(B))
# define AX-1177-reversible IL-33-induced gene: IL33 up (q<.05, lfc>0.58) at 6h or 24h AND reversed by C47 vs isotype (q<.05, lfc<0) at same time
def cls(r):
    for t in ['6','24']:
        if pd.notna(r[f'IL33_q_{t}']) and r[f'IL33_q_{t}']<0.05 and r[f'IL33_lfc_{t}']>0.58 and r[f'blk_q_{t}']<0.05 and r[f'blk_lfc_{t}']<0:
            return 'IL33-induced & AX-1177-reversed'
    for t in ['6','24']:
        if pd.notna(r[f'IL33_q_{t}']) and r[f'IL33_q_{t}']<0.05 and r[f'IL33_lfc_{t}']<-0.58 and r[f'blk_q_{t}']<0.05 and r[f'blk_lfc_{t}']>0:
            return 'IL33-repressed & AX-1177-restored'
    if pd.isna(r['IL33_lfc_6']): return 'not in RNA-seq'
    return 'not IL-33 responsive'
B['class'] = B.apply(cls, axis=1)
print(B['class'].value_counts())
B.to_pickle('bridge.pkl')
cols = ['rank','assay','gene','OR','l95','u95','p.value','BH_dedup','IL33_lfc_6','blk_lfc_6','IL33_lfc_24','blk_lfc_24','hgblk_lfc_6','AveExpr']
print(B[B['class']=='IL33-induced & AX-1177-reversed'].sort_values('p.value')[cols].round(4).to_string())
print(); print(B[B['class']=='IL33-repressed & AX-1177-restored'].sort_values('p.value')[cols].round(4).to_string())
# enrichment test: are IL33-induced/reversed proteins more associated with outcome than other measured proteins?
ind = B['class']=='IL33-induced & AX-1177-reversed'
oth = B['class'].isin(['not IL-33 responsive'])
z = -np.log10(B['p.value'])*np.sign(np.log(B.OR))
print('\nsigned -log10p: induced median %.2f (n=%d) vs non-responsive median %.2f (n=%d); MWU p=%.4g' % (z[ind].median(), ind.sum(), z[oth].median(), oth.sum(), stats.mannwhitneyu(z[ind], z[oth]).pvalue))
tab = pd.crosstab(ind[ind|oth], (B.BH_dedup<0.05)[ind|oth]); print(tab); print('Fisher', stats.fisher_exact(tab.values))
