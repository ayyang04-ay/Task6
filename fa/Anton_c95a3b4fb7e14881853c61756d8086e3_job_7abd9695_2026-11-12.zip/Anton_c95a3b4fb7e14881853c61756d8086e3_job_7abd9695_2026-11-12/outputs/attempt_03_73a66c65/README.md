# AX-1177 portfolio audit – deliverables

**Start here:** `AX-1177_portfolio_audit_memo.docx` (also `.html`, self-contained with figures, and `.md` source).

| Folder | Contents |
|---|---|
| `figures/` | Fig 1 IL-33 response & AX-1177 reversal (HUVEC); Fig 2 antibody-alone specificity; Fig 3 serum proteome shift & marker positions; Fig 4 in-vitro→serum bridge; Fig 5 post-mortem IL-33 IHC (donor level, label audit) |
| `tables/` | `biomarker_triage_invitro_vs_serum.csv` (candidate markers: in-vitro induction/reversal vs serum association) · `exvivo_PD_core_gene_panel.csv` (39-gene IL-33/AX-1177 core) · `huvec_il33_top100_signature_with_inhibition.csv` · `rnaseq_contrast_summary.csv` · `serum_proteomics_annotated.csv` (gene mapping, z, percentile, duplicates, in-vitro behaviour) · `serum_BH_reconstruction_withheld_assays.csv` (evidence that ~100 tested assays were not delivered) · `postmortem_donor_level_curated.csv` (donor-level scores, curated pathology, label-audit notes) |
| `code/` | Analysis scripts (Python; run with `micromamba run -n singlecell python <script>`) |

Pipeline order: `00_convert_excel.py` → `consist*.py` (statistical integrity checks) → `rev.py`, `il33top.py`, `keygenes.py`, `iso.py`, `offt*.py`, `misc.py` (RNA-seq) → `olink_map.py`, `bridge.py`, `triage.py` (serum + bridge) → `pm1.py`…`pm5.py` (post-mortem) → `figs.py` then `fig1.py`–`fig4.py` (final figures 1–4; fig 5 from `figs.py`) → `tables.py`.
Intermediate files are written to `/tmp/work/`.
