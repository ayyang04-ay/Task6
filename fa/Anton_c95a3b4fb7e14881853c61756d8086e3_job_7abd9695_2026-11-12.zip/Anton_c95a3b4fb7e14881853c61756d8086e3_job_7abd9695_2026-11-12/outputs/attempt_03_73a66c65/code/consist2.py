import pandas as pd, numpy as np
from scipy import stats, optimize
files = {'huvec6':'huvec_IL33_vs_Vehicle_HUVEC_6_hrs.csv','huvec24':'huvec_IL33_vs_Vehicle_HUVEC_24_hrs.csv','contr':'contrasts_6h.csv'}
dfs=[]
for k,f in files.items():
    d=pd.read_csv(f); d['src']=k; dfs.append(d)
D=pd.concat(dfs, ignore_index=True)
# fine grid of df
grid = np.arange(80, 90.01, 0.05)
sub = D.sample(20000, random_state=1)
sub = sub[(sub['P.Value']>1e-200)&(sub['P.Value']<0.99)]
best=[]
for g in grid:
    pe = 2*stats.t.sf(np.abs(sub['t']), g)
    best.append(np.median(np.abs(np.log(sub['P.Value'])-np.log(pe))))
g0 = grid[int(np.argmin(best))]
print('best df', g0, min(best))
pe = 2*stats.t.sf(np.abs(D['t']), g0)
D['p_exp']=pe
D['lr']=np.log10(D['P.Value'].clip(lower=1e-300))-np.log10(np.clip(pe,1e-300,None))
print(D['lr'].describe())
bad = D[np.abs(D['lr'])>0.01]
print('n rows |log10 ratio|>0.01:', len(bad))
print(bad.groupby(['src','Comparison']).size())
D.to_pickle('all_rows.pkl')
