import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150})
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); T=pd.read_pickle('T.pkl'); ann=pd.read_pickle('ann.pkl')
OUT='/tmp/outputs/figures/'
sym = ann['symbol']
# ---------------- Figure 1: pharmacology ----------------
fig, axes = plt.subplots(1,3, figsize=(13,4.3))
label_genes = ['NFKBIA','TNFAIP3','CSF2','CCL20','CXCL6','CSF3','IL6','F3','SELE','VCAM1','CXCL8','CCL2','IL1RL1','TNFRSF11B','THBD','C3','GBP5']
for ax,(tp,tp2) in zip(axes[:2],[('6_hrs','6hrs'),('24_hrs','24hrs')]):
    x = W[f'IL33_vs_Nontreated_HUVEC_{tp}']; y = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp2}']
    px = P[f'IL33_vs_Nontreated_HUVEC_{tp}']
    ns = px>=0.05
    ax.scatter(x[ns], y[ns], s=2, c='lightgrey', alpha=0.4, rasterized=True, label='IL-33 n.s.')
    ax.scatter(x[~ns], y[~ns], s=3, c='tab:blue', alpha=0.5, rasterized=True, label='IL-33 FDR<5%')
    infl = (x.abs()>1.5)&(y.abs()>1.5)&(np.sign(x)!=np.sign(y))&ns
    ax.scatter(x[infl], y[infl], s=14, facecolors='none', edgecolors='tab:red', lw=0.8, label='large, arm-consistent but n.s.\n(variance-inflated in pooled model)')
    lim = 12.5
    ax.plot([-lim,lim],[lim,-lim],'k--',lw=0.7, label='complete reversal (y = -x)')
    ax.axhline(0,c='k',lw=0.3); ax.axvline(0,c='k',lw=0.3)
    for g in label_genes:
        idx = sym.index[sym==g]
        for e in idx:
            if abs(x[e])>0.8:
                ax.annotate(g,(x[e],y[e]),fontsize=6.5,xytext=(3,2),textcoords='offset points')
    sig = px<0.05
    r = np.corrcoef(x[sig],y[sig])[0,1]
    top = T[f'IL33_vs_Nontreated_HUVEC_{tp}'].sort_values(ascending=False).index[:100]
    b = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp2}']
    resid = x + b; iso = x + b - y
    inh = np.median(1 - resid[top]/iso[top])*100
    ax.set_title(f'HUVEC {tp2}: {sig.sum():,} IL-33-regulated genes\nr = {r:.2f}; top-100 genes median inhibition {inh:.0f}%', fontsize=9)
    ax.set_xlabel('IL-33 (reduced) vs vehicle, log2FC'); ax.set_ylabel('AX-1177+IL-33 vs isotype+IL-33, log2FC')
    ax.set_xlim(-5,lim); ax.set_ylim(-lim,5)
axes[0].legend(fontsize=6, loc='lower left', frameon=False)
# panel c: DE counts
ax = axes[2]
cats = [('IL-33 vs vehicle\nHUVEC','IL33_vs_Nontreated_HUVEC_6_hrs','IL33_vs_Nontreated_HUVEC_24_hrs'),
        ('AX-1177+IL-33 vs\nisotype+IL-33 HUVEC','Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs','Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs'),
        ('AX-1177+IL-33 vs\nisotype+IL-33 HGMEC','Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs','Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs')]
alone6 = [c for c in W.columns if c.startswith('Compound_47_vs_') and c.endswith('_6hrs')]
alone24 = [c for c in W.columns if c.startswith('Compound_47_vs_') and c.endswith('_24hrs')]
labels=[]; v6=[]; v24=[]
for lab,c6,c24 in cats:
    labels.append(lab); v6.append((P[c6]<0.05).sum()); v24.append((P[c24]<0.05).sum())
labels.append('AX-1177 alone vs\nany control (max of 8)'); v6.append(max((P[c]<0.05).sum() for c in alone6)); v24.append(max((P[c]<0.05).sum() for c in alone24))
xx = np.arange(len(labels))
ax.bar(xx-0.2, v6, 0.4, label='6 h', color='tab:orange'); ax.bar(xx+0.2, v24, 0.4, label='24 h', color='tab:purple')
for i,(a,b_) in enumerate(zip(v6,v24)):
    ax.text(i-0.2,a+40,f'{a:,}',ha='center',fontsize=6.5); ax.text(i+0.2,b_+40,f'{b_:,}',ha='center',fontsize=6.5)
ax.set_xticks(xx); ax.set_xticklabels(labels, fontsize=7); ax.set_ylabel('genes at FDR < 5%'); ax.legend(frameon=False)
ax.set_title('Response is early; antibody alone is inert', fontsize=9)
plt.tight_layout(); plt.savefig(OUT+'fig1_pharmacology_huvec.png', bbox_inches='tight'); plt.close()

# ---------------- Figure 2: antibody-alone specificity ----------------
alone = [c for c in W.columns if c.startswith('Compound_47_vs_')]
order = sorted(alone, key=lambda c:(c.split('_')[-2], c.split('_')[-1], c.split('_')[3]))
C = W[order].corr(method='spearman')
fig, ax = plt.subplots(figsize=(7.5,6.3))
im = ax.imshow(C.values, cmap='RdBu_r', vmin=-1, vmax=1)
short = [c.replace('Compound_47_vs_','AX vs ').replace('hrs','h') for c in order]
ax.set_xticks(range(len(order))); ax.set_xticklabels(short, rotation=90, fontsize=6.5)
ax.set_yticks(range(len(order))); ax.set_yticklabels([f'{s}  (n={int((P[c]<0.05).sum())})' for s,c in zip(short,order)], fontsize=6.5)
plt.colorbar(im, fraction=0.04, label='Spearman r of log2FC')
ax.set_title('AX-1177 alone: correlations only between contrasts sharing the same AX-1177 arm (r≈0.5 = null expectation)\nno reproducible effect across timepoints or cell types', fontsize=8)
plt.tight_layout(); plt.savefig(OUT+'fig2_antibody_alone_specificity.png', bbox_inches='tight'); plt.close()

# ---------------- Figure 3: serum global shift ----------------
s = pd.read_pickle('serum_mapped.pkl')
fig, axes = plt.subplots(1,2, figsize=(12,4.3), gridspec_kw={'width_ratios':[1,1.3]})
ax=axes[0]
ax.hist(s.z, bins=50, density=True, color='lightsteelblue', edgecolor='white', label=f'1,094 delivered assays (median z = {s.z.median():.2f})')
xs=np.linspace(-4,5,300); ax.plot(xs, stats.norm.pdf(xs), 'k--', lw=1, label='expected if no association (N(0,1))')
for a,c in [('ST2','red'),('PTX3','darkorange'),('IL6','purple'),('CCL20','green'),('SELE','teal'),('VCAM1','grey'),('CXCL6','grey')]:
    zz = s.loc[s.assay==a,'z'].iloc[0]; ax.axvline(zz, color=c, lw=1); ax.text(zz, 0.42, a if a!='ST2' else 'sST2', rotation=90, fontsize=7, color=c, va='top', ha='right')
ax.set_xlabel('Wald z (log OR / SE), adjusted for age, sex, NEWS2'); ax.set_ylabel('density')
ax.set_title(f'Whole proteome shifted in patients with the endpoint\n{(s.OR>1).mean()*100:.0f}% of assays OR>1; {(s["p.value"]<0.05).mean()*100:.0f}% nominal p<0.05', fontsize=9)
ax.legend(fontsize=6.5, frameon=False, loc='upper left')
ax=axes[1]
ax.scatter(np.log2(s.OR), -np.log10(s['p.value']), s=5, c='lightgrey', rasterized=True)
hl = {'ST2':'sST2','PTX3':'PTX3','IL6':'IL-6','OPG-INFI':'OPG','IL-18R1':'IL-18R1','MCP-3':'MCP-3','CCL20':'CCL20','IL8':'IL-8','SELE':'E-selectin','vWF':'vWF','ANGPT2':'ANGPT2','TF':'Tissue factor','HGF':'HGF','CXCL6':'CXCL6','G-CSF':'G-CSF','VCAM1':'VCAM-1','CCL17':'CCL17','CCL11-INFI':'Eotaxin','TPSAB1':'Tryptase','NT-proBNP-CVDIII':'NT-proBNP','TNNI3':'Troponin I','RAGE':'sRAGE','EGFR':'EGFR'}
for a,lab in hl.items():
    r = s[s.assay==a].iloc[0]
    col = 'red' if a=='ST2' else ('tab:blue' if a in ['PTX3','IL6','OPG-INFI','IL-18R1','MCP-3','CCL20','IL8','SELE','TF'] else ('tab:brown' if a in ['vWF','ANGPT2','HGF'] else 'black'))
    ax.scatter(np.log2(r.OR), -np.log10(r['p.value']), s=18, c=col)
    ax.annotate(lab,(np.log2(r.OR), -np.log10(r['p.value'])), fontsize=6.5, xytext=(3,2), textcoords='offset points', color=col)
thr = s.loc[s['adj.p.value']<0.05,'p.value'].max()
ax.axhline(-np.log10(thr), ls=':', c='k', lw=0.7); ax.text(-4.3, -np.log10(thr)+0.08, 'FDR 5% (as delivered)', fontsize=6.5)
ax.set_xlabel('log2 OR per delivered unit (not comparable across assays)'); ax.set_ylabel('-log10 p')
ax.set_title('Blue: IL-33-inducible & AX-1177-reversible in endothelium; brown: endothelial/injury, not IL-33-transcribed;\nblack: type-2, cardiac and oxidised-IL-33 receptor markers', fontsize=8)
ax.set_xlim(-4.5,7)
plt.tight_layout(); plt.savefig(OUT+'fig3_serum_global_shift.png', bbox_inches='tight'); plt.close()

# ---------------- Figure 4: bridge ----------------
t = pd.read_csv('biomarker_triage_raw.csv')
t = t[t['serum_pct_vs_all'].notna() & t['IL33_6h'].notna()]
fig, ax = plt.subplots(figsize=(7.5,5))
for _,r in t.iterrows():
    persist = r.IL33_24h/r.IL33_6h if r.IL33_6h>0 else np.nan
    reversed_ = (r.AX_rev_HUVEC_6h < -0.5*r.IL33_6h) if r.IL33_6h>1 else False
    col = 'tab:blue' if reversed_ else 'grey'
    mk = 'o' if (r.IL33_6h>1 and r.q_IL33_6h<0.05) else ('s' if r.IL33_6h>1 else 'x')
    ax.scatter(r.IL33_6h, r.serum_pct_vs_all, c=col, marker=mk, s=30 + 60*max(0,min(persist,1)) if not np.isnan(persist) else 20)
    ax.annotate(r.gene if r.gene!='IL1RL1' else 'IL1RL1 (sST2)', (r.IL33_6h, r.serum_pct_vs_all), fontsize=6.5, xytext=(3,2), textcoords='offset points')
ax.axhline(95, ls=':', c='k', lw=0.7); ax.text(-1.2, 95.8, '95th percentile of all 1,094 assays', fontsize=6.5)
ax.set_xlabel('IL-33 induction in HUVEC at 6 h (log2FC)'); ax.set_ylabel('Serum association with ICU/IMV/death\n(percentile of z among all assays)')
ax.set_title('Bridging in vitro mechanism to patients\n● FDR<5% in vitro; ■ large, arm-consistent but variance-inflated; blue = reversed by AX-1177; size = fraction of induction persisting at 24 h', fontsize=7.5)
plt.tight_layout(); plt.savefig(OUT+'fig4_bridge_invitro_to_serum.png', bbox_inches='tight'); plt.close()

# ---------------- Figure 5: post-mortem ----------------
don = pd.read_pickle('pm_donor.pkl')
d = pd.read_pickle('pm_blocks.pkl')
for c in ['IL33_epi','IL33_endo','IL33_vsmc']: d[c]=pd.to_numeric(d[c], errors='coerce')
d['grp'] = d['donor'].map(don['grp'])
fig, axes = plt.subplots(1,3, figsize=(12,4))
names = {'IL33_epi':'IL-33, basal epithelium','IL33_endo':'IL-33, endothelium','IL33_vsmc':'IL-33, vascular smooth muscle'}
gorder = ['NegNonPneu','NegPneu','Pos']; glab = ['COVID-neg\n"non-pneumonia"\n(5 donors)','COVID-neg\npneumonia\n(10 donors)','COVID-pos\npneumonia\n(16 donors)']
rng = np.random.default_rng(1)
import statsmodels.api as sm, statsmodels.formula.api as smf
for ax,c in zip(axes,['IL33_epi','IL33_endo','IL33_vsmc']):
    for i,g in enumerate(gorder):
        bl = d.loc[d.grp==g,c].dropna(); ax.scatter(i+rng.uniform(-0.25,0.25,len(bl))+0.0, bl, s=8, c='lightgrey', alpha=0.7, label='block' if i==0 else None)
        dv = don.loc[don.grp==g]
        cols = ['tab:red' if a==0 else 'tab:blue' for a in dv['acute_path']]
        ax.scatter(i+rng.uniform(-0.12,0.12,len(dv)), dv[c], s=28, c=cols, edgecolors='k', lw=0.4, zorder=3)
        ax.hlines(dv[c].median(), i-0.3, i+0.3, color='k', lw=1.5, zorder=4)
    a = don.loc[don.grp=='Pos',c].dropna(); b = don.loc[don.grp!='Pos',c].dropna()
    pd_ = stats.mannwhitneyu(a,b).pvalue
    pb = stats.mannwhitneyu(d.loc[d.grp=='Pos',c].dropna(), d.loc[d.grp!='Pos',c].dropna()).pvalue
    dd = d[['donor','grp',c]].dropna().assign(pos=lambda x:(x.grp=='Pos').astype(int))
    pg = smf.gee(f'{c} ~ pos', groups='donor', data=dd, cov_struct=sm.cov_struct.Exchangeable()).fit().pvalues['pos']
    ax.axhline(5, ls=':', c='k', lw=0.6); ax.text(2.35, 5.05, 'scale max (5)', fontsize=6, ha='right')
    ax.set_xticks(range(3)); ax.set_xticklabels(glab, fontsize=7); ax.set_ylim(-0.3,5.9)
    ax.set_title(f'{names[c]}\nCOVID+ vs rest: donor-level p={pd_:.3f}; GEE p={pg:.3f}\n(naive block-level p={pb:.3f} — pseudo-replicated)', fontsize=7.5)
axes[0].set_ylabel('IHC score as delivered ("N+" coded as N+0.5)')
from matplotlib.lines import Line2D
axes[2].legend(handles=[Line2D([],[],marker='o',ls='',mfc='tab:blue',mec='k',label='donor: acute pneumonia/ALI on autopsy report'),
                        Line2D([],[],marker='o',ls='',mfc='tab:red',mec='k',label='donor: no acute pneumonia on autopsy report'),
                        Line2D([],[],marker='o',ls='',mfc='lightgrey',mec='lightgrey',label='individual histology block')], fontsize=6, frameon=False, loc='lower left')
plt.tight_layout(); plt.savefig(OUT+'fig5_postmortem_il33_ihc.png', bbox_inches='tight'); plt.close()
print('done')
