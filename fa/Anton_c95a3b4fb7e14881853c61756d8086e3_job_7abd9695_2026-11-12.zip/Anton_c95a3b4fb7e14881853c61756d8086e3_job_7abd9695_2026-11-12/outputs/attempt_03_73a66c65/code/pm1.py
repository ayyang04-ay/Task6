import pandas as pd, numpy as np, re
pd.set_option('display.width',300); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',200)
d = pd.read_pickle('pm.pkl')
d = d[d['Block'].notna()].copy()
d['donor']=d['SampleID'].astype(str)
# unique values for numeric columns
for c in ['EPX_num','NE_num','Tryp_num','IL33_epi','IL33_endo','IL33_vsmc']:
    print(c, d[c].value_counts(dropna=False).sort_index().to_dict())
for c in ['EPX_str','EDN_str','MBP_str','2D7_str','IL5Ra_NE_str','NE_dup_str','IL5Ra_Tryp_str','Tryp_dup_str','HE_eos']:
    print(c, d[c].astype(str).str.strip().value_counts(dropna=False).to_dict())
# check numeric conversion hypothesis: N+ -> N+0.5
def conv(s):
    s=str(s).strip()
    if s in ('0',): return 0.0
    m=re.match(r'^(\d)\+$', s)
    if m: return int(m.group(1))+0.5
    return np.nan if s in ('ND','nan') else s
for a,b in [('EPX_str','EPX_num'),('NE_dup_str','NE_num'),('Tryp_dup_str','Tryp_num')]:
    x = d[a].map(conv); y = pd.to_numeric(d[b], errors='coerce')
    ok = (x.astype(float)==y) | (x.isna() & y.isna())
    print(a,'->',b,'matches N+ -> N+0.5 rule:', ok.sum(), '/', len(d))
    print(d.loc[~ok, ['donor','Block',a,b]])
d.to_pickle('pm_blocks.pkl')
