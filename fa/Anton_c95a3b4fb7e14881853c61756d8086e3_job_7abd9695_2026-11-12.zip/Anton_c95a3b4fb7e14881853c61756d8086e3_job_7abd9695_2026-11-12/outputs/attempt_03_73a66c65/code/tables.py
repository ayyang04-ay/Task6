import pandas as pd, numpy as np
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); T=pd.read_pickle('T.pkl'); ann=pd.read_pickle('ann.pkl')
OUT='/tmp/outputs/tables/'
# 1. RNA-seq contrast summary
rows=[]
sigref6 = P['IL33_vs_Nontreated_HUVEC_6_hrs']<0.05; sigref24 = P['IL33_vs_Nontreated_HUVEC_24_hrs']<0.05
for c in W.columns:
    tp = '6h' if ('6_hrs' in c or c.endswith('6hrs')) else '24h'
    ref = 'IL33_vs_Nontreated_HUVEC_6_hrs' if tp=='6h' else 'IL33_vs_Nontreated_HUVEC_24_hrs'
    sg = sigref6 if tp=='6h' else sigref24
    r = np.nan if c==ref else np.corrcoef(W.loc[sg,ref], W.loc[sg,c])[0,1]
    rows.append({'contrast':c,'timepoint':tp,'n_FDR05':int((P[c]<0.05).sum()),'n_up':int(((P[c]<0.05)&(W[c]>0)).sum()),'n_down':int(((P[c]<0.05)&(W[c]<0)).sum()),
                 'r_with_HUVEC_IL33_signature_same_tp':round(r,3) if pd.notna(r) else '', 'note':''})
rs = pd.DataFrame(rows)
rs.loc[rs.contrast.str.contains('Compound_47_IL33_vs_IL33_(HUVEC|HGMEC)'),'note']='shares IL-33-alone arm with IL-33 signature (HUVEC) -> correlation inflated; prefer isotype-matched contrast'
rs.loc[rs.contrast.str.contains('IL33_IC119'),'note']='isotype-matched (preferred) neutralisation contrast'
rs.loc[rs.contrast.str.startswith('Compound_47_vs_'),'note']='antibody alone, no IL-33 (specificity check)'
rs.to_csv(OUT+'rnaseq_contrast_summary.csv', index=False)
# 2. Core IL-33 signature with inhibition (candidate ex vivo PD panel)
out=[]
for tp,tp2 in [('6_hrs','6hrs'),('24_hrs','24hrs')]:
    il=W[f'IL33_vs_Nontreated_HUVEC_{tp}']; b=W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp2}']; c=W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp2}']
    top=T[f'IL33_vs_Nontreated_HUVEC_{tp}'].sort_values(ascending=False).index[:100]
    for g in top:
        iso=il[g]+b[g]-c[g]; resid=il[g]+b[g]
        out.append({'timepoint':tp2,'ensembl':g,'symbol':ann.at[g,'symbol'],'IL33_vs_vehicle_log2FC':round(il[g],3),'IL33_t':round(T.at[g,f'IL33_vs_Nontreated_HUVEC_{tp}'],2),
                    'IL33_FDR':P.at[g,f'IL33_vs_Nontreated_HUVEC_{tp}'],'AX1177_vs_isotype_in_IL33_log2FC':round(c[g],3),'AX_FDR':P.at[g,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp2}'],
                    'pct_inhibition_vs_isotype_arm':round(100*(1-resid/iso),1)})
pd.DataFrame(out).to_csv(OUT+'huvec_il33_top100_signature_with_inhibition.csv', index=False)
# 3. biomarker triage (cleaned)
t = pd.read_csv('biomarker_triage_raw.csv')
t['variance_inflated_in_pooled_model'] = (t.IL33_6h.abs()>1.5)&(t.AX_rev_HUVEC_6h.abs()>1.5)&(t.q_IL33_6h>=0.05)
t.drop(columns=['df_flag']).round(4).to_csv(OUT+'biomarker_triage_invitro_vs_serum.csv', index=False)
# 4. serum annotated
s = pd.read_pickle('serum_mapped.pkl'); s.loc[s.assay=='Gal-9','symbol']='LGALS9'
s['z_percentile']=(s['z'].rank(pct=True)*100).round(1); s['rank_by_p']=s['p.value'].rank().astype(int)
s['measured_on_n_panels']=s.groupby('symbol')['assay'].transform('size')
g = pd.read_pickle('bridge.pkl')
s = s.merge(g[['il6','il6p','rv6','rv6p','il24']].rename(columns={'il6':'HUVEC_IL33_6h_log2FC','il6p':'HUVEC_IL33_6h_FDR','rv6':'AX1177_reversal_6h_log2FC','rv6p':'AX1177_reversal_6h_FDR','il24':'HUVEC_IL33_24h_log2FC'}), left_on='symbol', right_index=True, how='left')
s.rename(columns={'composite_endpoint_0':'frac_belowLOD_no_event_(inferred,n=56)','composite_endpoint_1':'frac_belowLOD_event_(inferred,n=44)'}, inplace=True)
s.drop(columns=['panel','in_rnaseq']).sort_values('p.value').to_csv(OUT+'serum_proteomics_annotated.csv', index=False)
# 5. withheld reconstruction
ss = s.sort_values('p.value').reset_index(drop=True); m=1194
ss['drank']=np.arange(1,len(ss)+1); ss['implied_rank']=ss['p.value']*m/ss['adj.p.value']
ss['anchor']=(np.abs(ss['implied_rank']-ss['implied_rank'].round())<1e-3)&(ss['adj.p.value']<1)
a=ss[ss.anchor].copy(); a['undelivered_tests_with_smaller_p']=(a['implied_rank'].round()-a['drank']).astype(int)
a=a[a['undelivered_tests_with_smaller_p'].diff().fillna(1)!=0]
a[['assay','p.value','adj.p.value','drank','implied_rank','undelivered_tests_with_smaller_p']].rename(columns={'drank':'rank_among_delivered','implied_rank':'rank_implied_by_BH_with_m=1194'}).to_csv(OUT+'serum_BH_reconstruction_withheld_assays.csv', index=False)
# 6. post-mortem donor-level
don = pd.read_pickle('pm_donor.pkl')
audit = {'1905':'labelled pneumonia; autopsy report lists no pneumonia; SARS-CoV-2 status missing','1970':'labelled pneumonia; no pneumonia on autopsy report','1968':'labelled pneumonia; report: possible aspiration, mucus plugging, emphysema only','1961':'labelled pneumonia; no pneumonia on autopsy report',
         '2067':'labelled COVID pneumonia (8 blocks); report: emphysema + mild chronic interstitial pneumonitis only','2101':'labelled COVID pneumonia; report: chronic interstitial inflammation/possible aspiration only',
         '1944':'labelled non-pneumonia; systemic coccidioidomycosis involving lung','1956':'labelled non-pneumonia; acute pneumonitis + haemorrhage','1976':'labelled non-pneumonia; acute and organizing pneumonia',
         '2043':'co-pathology: Aspergillus in bronchopneumonia','2044':'co-pathology: herpetic tracheitis','1861':'control with pulmonary fibrosis/emphysema/acute bronchitis','1965':'control with severe IPF/bronchiectasis'}
don['label_audit_note']=don.index.map(audit).fillna('')
cols=['grp','DiseaseCat','SARS2','Age','Gender','n_blocks','acute_path','DAD_ALI','path_emphysema','copd_or_emph','path_thromboemb','Notes','IL33_epi','IL33_endo','IL33_vsmc','EPX_sc','EDN_sc','MBP_sc','NE_dup_sc','Tryp_dup_sc','HE_eosY','label_audit_note']
don[cols].rename(columns={'acute_path':'acute_pneumonia_or_ALI_on_report(curated)','DAD_ALI':'DAD_or_ALI_on_report(curated)'}).round(3).to_csv(OUT+'postmortem_donor_level_curated.csv')
print('tables written')
