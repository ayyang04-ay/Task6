import pandas as pd, numpy as np
from scipy import stats
import statsmodels.api as sm, statsmodels.formula.api as smf
pd.set_option('display.width',250)
don = pd.read_pickle('pm_donor.pkl')
d = pd.read_pickle('pm_blocks.pkl')
import re
def strnum(s):
    s=str(s).strip()
    if s=='0': return 0.0
    m=re.match(r'^(\d)\+$', s); return float(m.group(1)) if m else np.nan
for c in ['EPX_str','EDN_str','MBP_str','2D7_str','IL5Ra_NE_str','NE_dup_str','IL5Ra_Tryp_str','Tryp_dup_str']:
    d[c.replace('_str','_sc')] = d[c].map(strnum)
for c in ['IL33_epi','IL33_endo','IL33_vsmc']: d[c]=pd.to_numeric(d[c], errors='coerce')
d['grp'] = d['donor'].map(don['grp']); d['pos']=(d.grp=='Pos').astype(int)
print('NAIVE block-level MWU (Pos vs Neg), pseudo-replicated:')
for c in ['IL33_epi','IL33_endo','IL33_vsmc']:
    a=d.loc[d.pos==1,c].dropna(); b=d.loc[d.pos==0,c].dropna()
    print(f'  {c}: n_blocks {len(a)} vs {len(b)}  p={stats.mannwhitneyu(a,b).pvalue:.4f}')
print('Cluster-robust (GEE, exchangeable, donor clusters) linear model on block scores:')
for c in ['IL33_epi','IL33_endo','IL33_vsmc']:
    dd = d[['donor','pos',c]].dropna()
    m = smf.gee(f'{c} ~ pos', groups='donor', data=dd, cov_struct=sm.cov_struct.Exchangeable()).fit()
    print(f'  {c}: diff={m.params["pos"]:.2f} p={m.pvalues["pos"]:.3f}')
print('Blocks per donor in Pos group:', d[d.pos==1].groupby('donor').size().to_dict())
print()
cells = ['EPX_sc','EDN_sc','MBP_sc','2D7_sc','IL5Ra_NE_sc','NE_dup_sc','IL5Ra_Tryp_sc','Tryp_dup_sc','HE_eosY']
print('Donor-level cell scores by group (median):')
print(don.groupby('grp')[cells].median().round(2).to_string())
for c in cells:
    grps=[don.loc[don.grp==g,c].dropna() for g in ['Pos','NegPneu','NegNonPneu']]
    print(f'  {c}: KW p={stats.kruskal(*grps).pvalue:.3f}; Pos vs NegNonPneu MWU p={stats.mannwhitneyu(grps[0],grps[2]).pvalue:.3f}; Pos vs NegPneu p={stats.mannwhitneyu(grps[0],grps[1]).pvalue:.3f}')
print()
print('Donor-level Spearman: IL-33 compartments vs inflammatory cell scores')
rows=[]
for a in ['IL33_epi','IL33_endo','IL33_vsmc']:
    for b in cells:
        x=don[[a,b]].dropna(); r,p=stats.spearmanr(x[a],x[b]); rows.append((a,b,round(r,2),round(p,3),len(x)))
print(pd.DataFrame(rows,columns=['IL33','cell','rho','p','n']).to_string())
