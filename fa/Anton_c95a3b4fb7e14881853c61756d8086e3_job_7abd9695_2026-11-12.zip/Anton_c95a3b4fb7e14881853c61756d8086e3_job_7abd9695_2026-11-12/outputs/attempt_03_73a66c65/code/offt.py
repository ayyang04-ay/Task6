import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); T=pd.read_pickle('T.pkl'); ann=pd.read_pickle('ann.pkl')
alone = [c for c in W.columns if c.startswith('Compound_47_vs_')]
sigsets = {c:set(P.index[P[c]<0.05]) for c in alone}
from collections import Counter
cnt = Counter(g for s in sigsets.values() for g in s)
print('genes significant in >=3 antibody-alone contrasts:')
rows=[]
for g,n in cnt.most_common():
    if n<3: break
    rows.append((g, ann.loc[g,'symbol'], n, ';'.join(sorted(c.replace('Compound_47_vs_','') for c in alone if g in sigsets[c]))))
for r in rows: print(r)
print()
# correlation of logFC between antibody-alone contrasts
print(W[alone].corr(method='spearman').round(2).to_string())
