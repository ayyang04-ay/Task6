import pandas as pd, numpy as np, sys
from scipy import stats
sys.path.insert(0,'.')
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); T=pd.read_pickle('T.pkl'); ann=pd.read_pickle('ann.pkl')
s = pd.read_pickle('serum_mapped.pkl')
s.loc[s.assay=='Gal-9','symbol']='LGALS9'
# symbol -> ensembl (RNA-seq); handle older symbols
sym2ens = ann.reset_index().dropna(subset=['symbol']).groupby('symbol')['ensembl'].first()
fallback = {'CERT1':'COL4A3BP','KIFBP':'KIF1BP','TAFA5':'FAM19A5','CCN5':'WISP2','CCN3':'NOV','ADGRE5':'CD97','MESD':'MESDC2','CCN1':'CYR61','CCN4':'WISP1','CBLIF':'GIF','ELOA':'TCEB3'}
def ens_for(sym):
    if sym in sym2ens.index: return sym2ens[sym]
    if sym in fallback and fallback[sym] in sym2ens.index: return sym2ens[fallback[sym]]
    return np.nan
s['ens']=s['symbol'].map(ens_for)
print('serum assays mapped to an RNA-seq gene:', s['ens'].notna().sum(), 'of', len(s))
# collapse serum duplicates: per symbol take the assay with median z (or mean z)
g = s.groupby('symbol').agg(z=('z','mean'), p=('p.value','min'), OR=('OR','median'), ens=('ens','first'), n=('assay','size'), assays=('assay',lambda x: '|'.join(x)))
g = g[g.ens.notna()].copy()
il6='IL33_vs_Nontreated_HUVEC_6_hrs'; rv6='Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs'
il24='IL33_vs_Nontreated_HUVEC_24_hrs'; rv24='Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs'
g['il6']=W.loc[g.ens, il6].values; g['il6p']=P.loc[g.ens, il6].values
g['rv6']=W.loc[g.ens, rv6].values; g['rv6p']=P.loc[g.ens, rv6].values
g['il24']=W.loc[g.ens, il24].values; g['il24p']=P.loc[g.ens, il24].values
g['rv24']=W.loc[g.ens, rv24].values
# Definitions
# strict: up by IL-33 at 6h (FDR<.05, lfc>1) and reversed (FDR<.05, lfc<-0.5)
g['strict_up'] = (g.il6p<0.05)&(g.il6>1)&(g.rv6p<0.05)&(g.rv6<-0.5)
# effect-consistent (ignore inflated variance): lfc>1 in IL33 AND lfc<-1 in reversal (independent arms)
g['consistent_up'] = (g.il6>1)&(g.rv6<-1)
g['consistent_dn'] = (g.il6<-1)&(g.rv6>1)
for col in ['strict_up','consistent_up','consistent_dn']:
    a = g[g[col]]; b = g[~g[col]]
    u = stats.mannwhitneyu(a.z, b.z, alternative='two-sided')
    ct = pd.crosstab(g[col], (g.p<0.05)&(g.z>0))
    fe = stats.fisher_exact(ct.values)
    print(f'{col}: n={len(a)} median z={a.z.median():.2f} vs rest {b.z.median():.2f}; MWU p={u.pvalue:.3g}; frac sig-positive {((a.p<0.05)&(a.z>0)).mean():.2f} vs {((b.p<0.05)&(b.z>0)).mean():.2f}; Fisher OR={fe[0]:.2f} p={fe[1]:.3g}')
pd.set_option('display.width',250); pd.set_option('display.max_rows',200)
cols=['assays','n','OR','p','z','il6','il6p','rv6','rv6p','il24','rv24']
print(g[g.consistent_up].sort_values('p')[cols].round(4).to_string())
print()
print(g[g.consistent_dn].sort_values('p')[cols].round(4).to_string())
g.to_pickle('bridge.pkl')
