import pandas as pd, numpy as np
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); T=pd.read_pickle('T.pkl'); ann=pd.read_pickle('ann.pkl')
for cl in ['HUVEC','HGMEC']:
    for tp,tph in [('6hrs','6_hrs'),('24hrs','24_hrs')]:
        b = W[f'Compound_47_IL33_vs_IL33_{cl}_{tp}']; c = W[f'Compound_47_IL33_vs_IL33_IC119_{cl}_{tp}']
        iso = b - c   # = IL33IC119 - IL33
        sig = P[f'IL33_vs_Nontreated_HUVEC_{tph}']<0.05
        ref = W[f'IL33_vs_Nontreated_HUVEC_{tph}']
        r = np.corrcoef(ref[sig], iso[sig])[0,1]; sl = np.polyfit(ref[sig], iso[sig],1)[0]
        print(f'{cl} {tp}: (IL33+IC119) - (IL33 alone) vs HUVEC IL-33 signature: r={r:.2f}, slope={sl:.2f}; median |iso lfc| all genes={iso.abs().median():.3f}')
# HUVEC: residual IL-33 response under antibody relative to vehicle
for tp,tph in [('6hrs','6_hrs'),('24hrs','24_hrs')]:
    il = W[f'IL33_vs_Nontreated_HUVEC_{tph}']; ilp = P[f'IL33_vs_Nontreated_HUVEC_{tph}']; t = T[f'IL33_vs_Nontreated_HUVEC_{tph}']
    b = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}']; c = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}']
    resid = il + b                  # (C47+IL33) - Veh
    iso_resp = il + b - c           # (IL33+IC119) - Veh
    strong = (ilp<0.05)&(il.abs()>2)
    inh = 1 - resid[strong]/iso_resp[strong]
    inh2 = 1 - resid[strong]/il[strong]
    print(f'HUVEC {tp}: strong IL-33 genes n={strong.sum()}: % inhibition vs isotype-arm response median={100*inh.median():.0f}% (IQR {100*inh.quantile(.25):.0f}-{100*inh.quantile(.75):.0f}); vs IL-33-alone response median={100*inh2.median():.0f}%')
    top = t.sort_values(ascending=False).index[:100]
    inh3 = 1 - resid[top]/iso_resp[top]
    print(f'   top-100 IL-33 genes by t: median inhibition {100*inh3.median():.0f}% (IQR {100*inh3.quantile(.25):.0f}-{100*inh3.quantile(.75):.0f})')
