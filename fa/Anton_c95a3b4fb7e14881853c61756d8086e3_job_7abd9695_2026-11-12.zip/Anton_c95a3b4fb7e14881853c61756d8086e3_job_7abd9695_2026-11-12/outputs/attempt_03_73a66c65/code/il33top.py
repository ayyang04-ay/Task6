import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); T=pd.read_pickle('T.pkl'); ann=pd.read_pickle('ann.pkl')
for tp,tp2 in [('6_hrs','6hrs'),('24_hrs','24hrs')]:
    il=f'IL33_vs_Nontreated_HUVEC_{tp}'; rv=f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp2}'; rv2=f'Compound_47_IL33_vs_IL33_HUVEC_{tp2}'
    x = pd.DataFrame({'sym':ann['symbol'],'ave':ann['AveExpr'],'IL33_lfc':W[il],'IL33_t':T[il],'IL33_padj':P[il],
                      'rev_lfc':W[rv],'rev_padj':P[rv],'rev2_lfc':W[rv2]})
    x['frac_reversed'] = -x['rev_lfc']/x['IL33_lfc']
    top = x[x.IL33_padj<0.05].sort_values('IL33_t', ascending=False).head(40)
    print('=====', il, 'top UP by t')
    print(top.round(3).to_string())
    bot = x[x.IL33_padj<0.05].sort_values('IL33_t').head(15)
    print('=====', il, 'top DOWN by t')
    print(bot.round(3).to_string())
