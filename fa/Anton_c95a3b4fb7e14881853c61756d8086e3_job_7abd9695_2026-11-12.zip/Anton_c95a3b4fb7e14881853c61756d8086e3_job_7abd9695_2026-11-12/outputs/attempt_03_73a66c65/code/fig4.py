import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150})
t = pd.read_csv('biomarker_triage_raw.csv'); OUT='/tmp/outputs/figures/'
t = t[t['serum_pct_vs_all'].notna() & t['IL33_6h'].notna()].copy()
t['infl'] = (t.IL33_6h.abs()>1.5)&(t.AX_rev_HUVEC_6h.abs()>1.5)&(t.q_IL33_6h>=0.05)
ind = t[t.IL33_6h>1]
rho,p = stats.spearmanr(ind.IL33_6h, ind.serum_pct_vs_all)
names = {'IL1RL1':'sST2 (IL1RL1)','TNFRSF11B':'OPG (TNFRSF11B)','CCL7':'MCP-3 (CCL7)','CXCL8':'IL-8 (CXCL8)','CCL2':'MCP-1 (CCL2)','F3':'tissue factor (F3)','SELE':'E-selectin (SELE)','SERPINE1':'PAI-1 (SERPINE1)','CSF3':'G-CSF (CSF3)','THBD':'thrombomodulin','AGER':'sRAGE (AGER)','IL18R1':'IL-18R1','CSF1':'CSF-1'}
offs = {'IL1RL1':(-20,8),'PTX3':(6,-3),'CCL7':(6,-9),'IL18R1':(-18,7),'TNFRSF11B':(-30,7),'IL6':(6,2),'HGF':(6,-2),'CCL20':(-10,8),'CXCL8':(7,-2),'VWF':(6,3),'ANGPT2':(6,-7),'CXCL1':(7,-6),'CSF3':(7,3)}
fig, ax = plt.subplots(figsize=(8.5,5.4))
for _,r in t.iterrows():
    reversed_ = (r.AX_rev_HUVEC_6h < -0.5*r.IL33_6h) if r.IL33_6h>1 else ((r.AX_rev_HUVEC_6h > 0.5) if r.IL33_6h<-0.5 else False)
    col = 'tab:blue' if reversed_ else 'grey'
    persist = r.IL33_24h/r.IL33_6h if abs(r.IL33_6h)>0.5 else 0
    size = 25 + 90*max(0,min(persist,1))
    if r.infl: mk='s'
    elif r.q_IL33_6h<0.05 and abs(r.IL33_6h)>0.5: mk='o'
    else: mk='X'
    ax.scatter(r.IL33_6h, r.serum_pct_vs_all, c=col, marker=mk, s=size, alpha=0.85, edgecolors='k', lw=0.3)
    ax.annotate(names.get(r.gene, r.gene), (r.IL33_6h, r.serum_pct_vs_all), fontsize=6.5, xytext=offs.get(r.gene,(6,2)), textcoords='offset points')
ax.axhline(95, ls=':', c='k', lw=0.7); ax.text(10.3, 95.8, '95th percentile', fontsize=6.5)
ax.set_xlabel('IL-33 induction in HUVEC at 6 h (log2FC vs vehicle)'); ax.set_ylabel('Serum association with ICU / IMV / death\n(percentile of z among all 1,094 assays)')
ax.set_title('In vitro IL-33 response size does not predict prognostic value in patients\n(all 76 IL-33-induced genes [log2FC>1, FDR<5%] with a serum assay: Spearman rho = -0.08, p = 0.50; selected genes shown)', fontsize=8.5)
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([],[],marker='o',ls='',mfc='tab:blue',mec='k',label='IL-33-regulated (FDR<5%) and reversed by AX-1177'),
                   Line2D([],[],marker='s',ls='',mfc='tab:blue',mec='k',label='large, arm-consistent effect; "n.s." from variance inflation'),
                   Line2D([],[],marker='X',ls='',mfc='grey',mec='k',label='not IL-33-regulated in HUVEC'),
                   Line2D([],[],marker='o',ls='',mfc='white',mec='k',ms=4,label='small = transient (mostly gone by 24 h)'),
                   Line2D([],[],marker='o',ls='',mfc='white',mec='k',ms=9,label='large = sustained at 24 h')], fontsize=6.5, frameon=False, loc='lower left', bbox_to_anchor=(0.0,0.0))
ax.set_ylim(0,105)
plt.tight_layout(); plt.savefig(OUT+'fig4_bridge_invitro_to_serum.png', bbox_inches='tight'); plt.close()
print(rho,p,len(ind))
