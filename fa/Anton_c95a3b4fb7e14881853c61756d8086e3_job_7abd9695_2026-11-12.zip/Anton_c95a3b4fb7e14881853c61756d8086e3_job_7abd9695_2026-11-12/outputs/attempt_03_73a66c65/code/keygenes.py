import pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
D = pd.read_pickle('all_rows.pkl')
from scipy import stats, optimize
ann=pd.read_pickle('ann.pkl')
genes = ['IL33','IL1RL1','IL1RAP','MYD88','AGER','EGFR','SELE','VCAM1','ICAM1','SELP','CXCL8','CXCL1','CXCL2','CXCL3','CXCL5','CXCL6','CCL2','CCL20','CX3CL1','IL6','CSF2','CSF3','IL1A','IL1B','TNF','ANGPT2','VWF','THBD','F3','SERPINE1','PLAT','TFPI','EDN1','NOS3','KDR','TEK','PTX3','HGF','C3','CXCL10','IFNB1','IL1R1','ESM1','ICAM2','PECAM1','CDH5','LCN2','MMP1','MMP10','CCL5','TNFRSF11B','HLA-DRA','VEGFA','PGF','ANGPT1','SOD2','NFKBIA']
sel = D[D['symbol'].isin(genes)]
def implied_df(t,p):
    t=abs(t)
    if p>0.999 or t<1e-3: return np.nan
    f=lambda lg: np.log(2*stats.t.sf(t, np.exp(lg))) - np.log(p)
    try: return np.exp(optimize.brentq(f, np.log(0.5), np.log(1e7)))
    except: return np.nan
cols = ['IL33_vs_Nontreated_HUVEC_6_hrs','Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs','IL33_vs_Nontreated_HUVEC_24_hrs','Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs','Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs','Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs']
out=[]
for g in genes:
    s = sel[sel.symbol==g]
    if len(s)==0: out.append({'sym':g,'note':'NOT IN TABLE (filtered low expr)'}); continue
    for ens, ss in s.groupby('ensembl'):
        r={'sym':g,'ens':ens,'ave':ss['AveExpr'].iloc[0]}
        # implied df from the IL33 6h row
        row = ss[ss.Comparison==cols[0]].iloc[0]
        r['df']=implied_df(row['t'],row['P.Value'])
        for c in cols:
            q = ss[ss.Comparison==c]
            if len(q): 
                q=q.iloc[0]; tag=c.replace('Compound_47_IL33_vs_IL33_IC119','REV').replace('IL33_vs_Nontreated','IL33').replace('_hrs','h').replace('hrs','h')
                r[tag]=f"{q['logFC']:+.2f}{'*' if q['adj.P.Val']<0.05 else ' '}"
        out.append(r)
print(pd.DataFrame(out).to_string())
