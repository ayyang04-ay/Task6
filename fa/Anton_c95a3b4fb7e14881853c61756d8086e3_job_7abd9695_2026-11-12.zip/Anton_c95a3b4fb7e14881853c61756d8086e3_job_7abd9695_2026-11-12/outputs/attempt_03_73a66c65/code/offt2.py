import pandas as pd, numpy as np
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); T=pd.read_pickle('T.pkl'); ann=pd.read_pickle('ann.pkl')
for c in ['Compound_47_vs_IC119_HUVEC_6hrs','Compound_47_vs_IC119_HUVEC_24hrs','Compound_47_vs_IC119_HGMEC_6hrs','Compound_47_vs_IC119_HGMEC_24hrs','Compound_47_vs_IC119_A549_6hrs','Compound_47_vs_IC119_A549_24hrs','Compound_47_vs_IC119_MCF7_6hrs','Compound_47_vs_IC119_MCF7_24hrs']:
    s = P.index[P[c]<0.05]
    x = pd.DataFrame({'sym':ann.loc[s,'symbol'],'lfc':W.loc[s,c].round(2),'ave':ann.loc[s,'AveExpr'].round(1)}).sort_values('lfc')
    print('==',c,len(s), '| |lfc| median', x['lfc'].abs().median())
    print(', '.join(f"{r.sym}({r.lfc:+.1f})" for r in x.itertuples()))
