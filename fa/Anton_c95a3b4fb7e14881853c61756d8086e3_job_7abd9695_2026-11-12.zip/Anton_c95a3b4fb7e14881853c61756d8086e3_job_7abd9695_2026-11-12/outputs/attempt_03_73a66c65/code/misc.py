import pandas as pd, numpy as np, re
from scipy import stats
D = pd.read_pickle('all_rows.pkl')
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); T=pd.read_pickle('T.pkl'); ann=pd.read_pickle('ann.pkl')
# implied per-gene df from HUVEC 6h IL33 rows
h = D[D.Comparison=='IL33_vs_Nontreated_HUVEC_6_hrs'].set_index('ensembl')
from scipy import optimize
def idf(t,p):
    t=abs(t)
    if t<0.5 or p>0.6: return np.nan
    f=lambda lg: np.log(2*stats.t.sf(t, np.exp(lg))) - np.log(p)
    try: return np.exp(optimize.brentq(f, np.log(0.5), np.log(1e7)))
    except: return np.nan
# use the contrast with the largest |t| per gene to estimate df robustly
Tabs = T.abs(); best_c = Tabs.idxmax(axis=1)
dfg = {}
for g in T.index:
    c = best_c[g]; t = T.at[g,c]
    p = D.loc[(D.ensembl==g)&(D.Comparison==c),'P.Value'] if False else None
dfp = D.loc[D.groupby('ensembl')['t'].apply(lambda x: x.abs().idxmax())][['ensembl','t','P.Value']]
dfp['df'] = [idf(t,p) for t,p in zip(dfp['t'], dfp['P.Value'])]
dfp = dfp.set_index('ensembl')
ann['df']=dfp['df']
outlier = ann['df']<77
print('genes with robust-eBayes outlier variance (df<77):', outlier.sum(), 'of', ann['df'].notna().sum(), 'with estimable df')
il = W['IL33_vs_Nontreated_HUVEC_6_hrs']; rv = W['Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs']
big = (il>3)&(rv<-3)
print('among genes with IL-33 lfc>3 AND reversal lfc<-3 (independent arms):', big.sum(), '; outlier-variance fraction:', round(outlier[big].mean(),3), 'vs background', round(outlier.mean(),3))
nonsig_big = big & (P['IL33_vs_Nontreated_HUVEC_6_hrs']>=0.05)
print('  of which NOT significant for IL-33 vs vehicle at 6h:', nonsig_big.sum(), '->', ', '.join(ann.loc[nonsig_big,'symbol'].fillna('NA').tolist()))
# Excel date mangling
sy = ann['symbol'].dropna().astype(str)
mang = sy[sy.str.match(r'^\d{1,2}-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)$|^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-\d{1,2}$|^\d{5}$|^\d+\.\d+E\+\d+$', case=False)]
print('Excel-mangled symbols:', len(mang), mang.tolist()[:20])
print('symbols missing:', ann['symbol'].isna().sum(), '| entrez missing:', ann['entrez'].isna().sum())
print('duplicated symbols:', ann['symbol'].dropna().duplicated().sum())
# ISGs in IL-33 response
isg = ['IFIT1','IFIT2','IFIT3','MX1','MX2','ISG15','OAS1','OAS2','OAS3','OASL','RSAD2','IFI44L','IFI44','STAT1','IRF7','IRF1','CXCL10','CXCL11','GBP1','GBP5','DDX58','IFIH1','IFI6','IFITM1','IFNB1','IFNL1','HERC5','BST2','TRIM22']
x = pd.DataFrame({'sym':ann['symbol'],'il6':W['IL33_vs_Nontreated_HUVEC_6_hrs'],'p6':P['IL33_vs_Nontreated_HUVEC_6_hrs'],'il24':W['IL33_vs_Nontreated_HUVEC_24_hrs'],'p24':P['IL33_vs_Nontreated_HUVEC_24_hrs'],'rv24':W['Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs']})
print(x[x.sym.isin(isg)].sort_values('il24',ascending=False).round(3).to_string())
ann.to_pickle('ann.pkl')
