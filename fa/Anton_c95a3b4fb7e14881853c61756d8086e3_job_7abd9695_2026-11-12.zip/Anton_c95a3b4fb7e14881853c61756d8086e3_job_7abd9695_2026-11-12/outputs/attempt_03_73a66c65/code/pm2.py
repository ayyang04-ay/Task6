import pandas as pd, numpy as np, re
pd.set_option('display.width',300); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',200)
d = pd.read_pickle('pm_blocks.pkl')
def strnum(s):
    s=str(s).strip()
    if s=='0': return 0.0
    m=re.match(r'^(\d)\+$', s)
    return float(m.group(1)) if m else np.nan
for c in ['EPX_str','EDN_str','MBP_str','2D7_str','IL5Ra_NE_str','NE_dup_str','IL5Ra_Tryp_str','Tryp_dup_str']:
    d[c.replace('_str','_sc')] = d[c].map(strnum)
for c in ['IL33_epi','IL33_endo','IL33_vsmc']:
    d[c]=pd.to_numeric(d[c], errors='coerce')
d['HE_eosY'] = (d['HE_eos'].astype(str).str.strip()=='Y').astype(float)
# donor-level fields: take first non-null across blocks
first = d.groupby('donor', sort=False).agg({'DiseaseCat':'first','Race':'first','Gender':'first','Age':'first','SARS2':'first','Pathology':'first','Notes':lambda s: '; '.join(sorted(set(x for x in s.dropna()))) })
first['n_blocks']=d.groupby('donor', sort=False).size()
path = first['Pathology'].fillna('').str.lower()
first['path_acute_pneumonia'] = path.str.contains(r'bronchopneumonia|bronchpneumonia|acute pneumonitis|acute and organizing pneumonia|focal acute and organizing|consolidation|sars-cov-2 pneumonia|acute pneumonia')
first['path_DAD_ALI'] = path.str.contains(r'diffuse alveolar damage|hyalin|acute lung injury')
first['path_emphysema'] = path.str.contains(r'emphysem')
first['path_fibrosis'] = path.str.contains(r'pulmonary fibrosis|diffuse fibrosis|idiopathic pulmonary fibrosis|nonspecific fibrosis|interstitial fibrosis')
first['path_thromboemb'] = path.str.contains(r'thromboemb|pulmonary emboli')
first['notes_COPD'] = first['Notes'].str.contains('COPD')
first['notes_asthma'] = first['Notes'].str.contains('Asthma')
first['copd_or_emph'] = first['notes_COPD'] | first['path_emphysema']
num_cols = ['EPX_sc','EDN_sc','MBP_sc','2D7_sc','IL5Ra_NE_sc','NE_dup_sc','IL5Ra_Tryp_sc','Tryp_dup_sc','HE_eosY','IL33_epi','IL33_endo','IL33_vsmc']
means = d.groupby('donor', sort=False)[num_cols].mean()
don = first.join(means)
don.to_pickle('pm_donor.pkl')
print(don.drop(columns=['Pathology']).to_string())
print()
print(don.groupby('DiseaseCat')[['n_blocks']].agg(['count','sum']))
