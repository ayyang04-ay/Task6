# Step 0: convert the delivered Excel files to CSV/pickle in /tmp/work (run with: mm singlecell python 00_convert_excel.py)
import pandas as pd, os
SRC='/tmp/world/filesystem/'; W='/tmp/work/'; os.makedirs(W, exist_ok=True)
x = pd.read_excel(SRC+'AX-1177_rnaseq_contrasts.xlsx', sheet_name=None, engine='openpyxl')   # slow (~4 min)
for k,v in x.items(): v.to_csv(W+f'contrasts_{k}.csv', index=False)                         # sheets '6h' and '24h' are identical
x = pd.read_excel(SRC+'AX-1177_rnaseq_huvec_il33.xlsx', sheet_name=None, engine='openpyxl')
for k,v in x.items(): v.to_csv(W+f'huvec_{k}.csv', index=False)
pd.read_excel(SRC+'AX-1177_serum_proteomics.xlsx', engine='openpyxl').to_csv(W+'serum.csv', index=False)
v = pd.read_excel(SRC+'AX-1177_postmortem_lung.xlsx', engine='openpyxl', header=None); v.to_csv(W+'pm_raw.csv', index=False, header=False)
d = v.iloc[1:].copy()
d.columns = ['SampleID','Block','TissueRNA','unnamed','Lobe','DiseaseCat','Race','Gender','Age','SARS2','Pathology','HE_eos','EPX_str','EDN_str','MBP_str','2D7_str',
             'IL5Ra_NE_str','NE_dup_str','IL5Ra_Tryp_str','Tryp_dup_str','EPX_num','NE_num','Tryp_num','IL33_epi','IL33_endo','IL33_vsmc','Notes']
d.to_pickle(W+'pm.pkl')
print('converted')
