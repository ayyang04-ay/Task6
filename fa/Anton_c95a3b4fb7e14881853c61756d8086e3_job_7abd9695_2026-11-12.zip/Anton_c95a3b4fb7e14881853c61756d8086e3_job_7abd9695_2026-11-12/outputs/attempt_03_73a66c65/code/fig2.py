import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'figure.dpi':150})
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); OUT='/tmp/outputs/figures/'
alone = [c for c in W.columns if c.startswith('Compound_47_vs_')]
order = sorted(alone, key=lambda c:(c.split('_')[-2], c.split('_')[-1], c.split('_')[3]))
C = W[order].corr(method='spearman')
fig, ax = plt.subplots(figsize=(7.8,6.6))
im = ax.imshow(C.values, cmap='RdBu_r', vmin=-1, vmax=1)
short = [c.replace('Compound_47_vs_','AX-1177 vs ').replace('hrs',' h').replace('_',' ') for c in order]
ax.set_xticks(range(len(order))); ax.set_xticklabels(short, rotation=90, fontsize=6.5)
ax.set_yticks(range(len(order))); ax.set_yticklabels([f'{s}  [{int((P[c]<0.05).sum())} genes FDR<5%]' for s,c in zip(short,order)], fontsize=6.5)
plt.colorbar(im, fraction=0.04, label='Spearman r between contrasts (log2FC, 26,210 genes)')
ax.set_title('AX-1177 without IL-33: blocks of r≈0.5 occur only where contrasts share the same AX-1177 arm\n(the null expectation for a shared n=3 arm); r≈0 across timepoints and cell types = no reproducible off-target effect', fontsize=7.5)
plt.tight_layout(); plt.savefig(OUT+'fig2_antibody_alone_specificity.png', bbox_inches='tight'); plt.close()
