import pandas as pd, numpy as np
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); ann=pd.read_pickle('ann.pkl')
s = pd.read_pickle('serum_mapped.pkl'); s.loc[s.assay=='Gal-9','symbol']='LGALS9'
s['pct']=(s['z'].rank(pct=True)*100)
s['rank']=s['p.value'].rank().astype(int)
sym2ens = ann.reset_index().dropna(subset=['symbol']).groupby('symbol')['ensembl'].first()
cands = ['IL1RL1','CCL20','SELE','TNFRSF11B','PTX3','IL6','CXCL8','CCL2','CCL7','IL18R1','CSF1','IL1B','F3','SERPINE1','THBD','VCAM1','ICAM1','CX3CL1','CSF3','CXCL5','CXCL6','CXCL1','MMP10','CCL5','TNF','CXCL10','VWF','ANGPT2','AGER','EGFR','HGF']
rows=[]
for g in cands:
    e = sym2ens.get(g, np.nan)
    r = {'gene':g}
    if isinstance(e,str):
        r.update({'IL33_6h':W.at[e,'IL33_vs_Nontreated_HUVEC_6_hrs'],'q_IL33_6h':P.at[e,'IL33_vs_Nontreated_HUVEC_6_hrs'],
                  'IL33_24h':W.at[e,'IL33_vs_Nontreated_HUVEC_24_hrs'],'q_IL33_24h':P.at[e,'IL33_vs_Nontreated_HUVEC_24_hrs'],
                  'AX_rev_HUVEC_6h':W.at[e,'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs'],'q_rev6':P.at[e,'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs'],
                  'AX_rev_HUVEC_24h':W.at[e,'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs'],
                  'AX_rev_HGMEC_6h':W.at[e,'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs'],'q_revG6':P.at[e,'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs'],
                  'df_flag': ann.at[e,'df']<77 if pd.notna(ann.at[e,'df']) else False})
    ss = s[s.symbol==g].sort_values('p.value')
    if len(ss):
        b = ss.iloc[0]
        r.update({'olink_assays':'|'.join(ss.assay),'serum_OR':b.OR,'OR_l95':b.l95,'OR_u95':b.u95,'serum_p':b['p.value'],'serum_q':b['adj.p.value'],'serum_rank_of_1094':b['rank'],'serum_pct_vs_all':b.pct})
    rows.append(r)
t = pd.DataFrame(rows)
pd.set_option('display.width',300); pd.set_option('display.max_columns',30)
print(t.round(3).to_string())
t.to_csv('/tmp/work/biomarker_triage_raw.csv', index=False)
