import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150})
W=pd.read_pickle('W.pkl'); P=pd.read_pickle('P.pkl'); T=pd.read_pickle('T.pkl'); ann=pd.read_pickle('ann.pkl')
sym=ann['symbol']; OUT='/tmp/outputs/figures/'
fig, axes = plt.subplots(1,3, figsize=(14,4.8), gridspec_kw={'width_ratios':[1,1,0.9]})
lab6 = {'NFKBIA':(4,-10),'TNFAIP3':(5,-12),'CSF2':(-30,-8),'CCL20':(5,-4),'CXCL6':(4,4),'CSF3':(-28,6),'IL6':(5,-6),'F3':(-14,-10),'SELE':(-26,-6),'VCAM1':(6,0),'CXCL8':(-32,3),'CCL2':(5,2),'IL1RL1':(5,2),'TNFRSF11B':(6,2),'THBD':(4,4)}
lab24 = {'NFKBIA':(4,4),'CSF2':(-28,-6),'CCL20':(6,-2),'CXCL6':(4,4),'CSF3':(5,-6),'C3':(5,2),'GBP5':(-30,-4),'SELE':(5,2),'CXCL8':(-32,-6),'IL6':(5,-4)}
for ax,(tp,tp2,labs) in zip(axes[:2],[('6_hrs','6hrs',lab6),('24_hrs','24hrs',lab24)]):
    x = W[f'IL33_vs_Nontreated_HUVEC_{tp}']; y = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp2}']
    px = P[f'IL33_vs_Nontreated_HUVEC_{tp}']; ns = px>=0.05
    ax.scatter(x[ns], y[ns], s=2, c='lightgrey', alpha=0.4, rasterized=True, label='IL-33 not significant')
    ax.scatter(x[~ns], y[~ns], s=3, c='tab:blue', alpha=0.5, rasterized=True, label='IL-33 FDR<5%')
    infl = (x.abs()>3)&(y.abs()>3)&(np.sign(x)!=np.sign(y))&ns
    ax.scatter(x[infl], y[infl], s=22, facecolors='none', edgecolors='tab:red', lw=1.0, label='|log2FC|>3 in both independent\ncontrasts but "n.s." (variance\ninflated by pooled 114-library model)')
    lim=12.5; ax.plot([-lim,lim],[lim,-lim],'k--',lw=0.7,label='complete reversal (y = -x)')
    ax.axhline(0,c='k',lw=0.3); ax.axvline(0,c='k',lw=0.3)
    for g,off in labs.items():
        for e in sym.index[sym==g]:
            if abs(x[e])>0.8: ax.annotate(g,(x[e],y[e]),fontsize=6.5,xytext=off,textcoords='offset points')
    sig = px<0.05; r = np.corrcoef(x[sig],y[sig])[0,1]
    top = T[f'IL33_vs_Nontreated_HUVEC_{tp}'].sort_values(ascending=False).index[:100]
    b = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp2}']; resid = x + b; iso = x + b - y
    inh = np.median(1 - resid[top]/iso[top])*100
    ax.set_title(f'HUVEC {tp2.replace("hrs"," h")}: {sig.sum():,} IL-33-regulated genes (FDR<5%)\nr = {r:.2f} with AX-1177 reversal; top-100 genes: median {inh:.0f}% inhibition', fontsize=8.5)
    ax.set_xlabel('IL-33 (reduced, 30 ng/mL) vs vehicle, log2FC'); ax.set_ylabel('AX-1177 + IL-33 vs isotype + IL-33, log2FC')
    ax.set_xlim(-5,lim); ax.set_ylim(-lim,5)
axes[0].legend(fontsize=6, loc='lower left', frameon=False)
ax = axes[2]
rows = [('IL-33 vs vehicle (HUVEC)','IL33_vs_Nontreated_HUVEC_6_hrs','IL33_vs_Nontreated_HUVEC_24_hrs'),
        ('AX-1177 reversal (HUVEC)','Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs','Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs'),
        ('AX-1177 reversal (HGMEC)','Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs','Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs')]
alone6=[c for c in W.columns if c.startswith('Compound_47_vs_') and c.endswith('_6hrs')]
alone24=[c for c in W.columns if c.startswith('Compound_47_vs_') and c.endswith('_24hrs')]
labels=[r[0] for r in rows]+['AX-1177 alone, no IL-33\n(max of 8 contrasts)']
v6=[(P[r[1]]<0.05).sum() for r in rows]+[max((P[c]<0.05).sum() for c in alone6)]
v24=[(P[r[2]]<0.05).sum() for r in rows]+[max((P[c]<0.05).sum() for c in alone24)]
yy=np.arange(len(labels))[::-1]
ax.barh(yy+0.2, v6, 0.4, color='tab:orange', label='6 h'); ax.barh(yy-0.2, v24, 0.4, color='tab:purple', label='24 h')
for i,(a,b_) in enumerate(zip(v6,v24)):
    ax.text(a+40, yy[i]+0.2, f'{a:,}', va='center', fontsize=7); ax.text(b_+40, yy[i]-0.2, f'{b_:,}', va='center', fontsize=7)
ax.set_yticks(yy); ax.set_yticklabels(labels, fontsize=7.5); ax.set_xlabel('genes at FDR < 5%'); ax.set_xlim(0,5000)
ax.legend(frameon=False, fontsize=7, loc='lower right'); ax.set_title('Response is early (6 h > 24 h);\nantibody alone is transcriptionally inert', fontsize=8.5)
plt.tight_layout(); plt.savefig(OUT+'fig1_pharmacology_huvec.png', bbox_inches='tight'); plt.close()
