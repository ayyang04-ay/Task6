import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150})
s = pd.read_pickle('serum_mapped.pkl'); OUT='/tmp/outputs/figures/'
fig, axes = plt.subplots(1,2, figsize=(13,4.8), gridspec_kw={'width_ratios':[1,1.25]})
ax=axes[0]
ax.hist(s.z, bins=50, density=True, color='lightsteelblue', edgecolor='white', label=f'1,094 delivered assays\n(median z = {s.z.median():.2f})')
xs=np.linspace(-4,5,300); ax.plot(xs, stats.norm.pdf(xs), 'k--', lw=1, label='expected with no\nassociation, N(0,1)')
marks=[('CXCL6','CXCL6','grey',0.20),('VCAM1','VCAM-1','grey',0.20),('SELE','E-selectin','teal',0.30),('CCL20','CCL20','green',0.38),('IL6','IL-6','purple',0.30),('PTX3','PTX3','darkorange',0.38),('ST2','sST2','red',0.45)]
for a,lab,c,h in marks:
    zz = s.loc[s.assay==a,'z'].iloc[0]; ax.plot([zz,zz],[0,h-0.005], color=c, lw=1.2)
    ax.text(zz, h, lab, rotation=90, fontsize=7, color=c, va='bottom', ha='center')
ax.set_ylim(0,0.56)
ax.set_xlabel('Wald z = log(OR)/SE  (adjusted for age, sex, NEWS2)'); ax.set_ylabel('density')
ax.set_title(f'Whole proteome is shifted in patients with ICU/IMV/death\n{(s.OR>1).mean()*100:.0f}% of assays have OR>1; {(s["p.value"]<0.05).mean()*100:.0f}% nominal p<0.05 (5% expected)', fontsize=8.5)
ax.legend(fontsize=6.5, frameon=False, loc='upper left')
ax=axes[1]
ax.scatter(np.log2(s.OR), -np.log10(s['p.value']), s=5, c='lightgrey', rasterized=True)
blue = {'ST2':('sST2 (IL1RL1)',(5,2)),'PTX3':('PTX3',(5,2)),'IL6':('IL-6',(-22,4)),'OPG-INFI':('OPG',(5,0)),'IL-18R1':('IL-18R1',(5,-2)),'MCP-3':('MCP-3',(-36,2)),'CCL20':('CCL20',(5,-8)),'IL8':('IL-8',(5,-4)),'SELE':('E-selectin',(5,-3)),'TF':('tissue factor',(5,-9)),'G-CSF':('G-CSF',(6,-2)),'VCAM1':('VCAM-1',(6,2)),'CXCL6':('CXCL6',(6,4))}
brown = {'vWF':('vWF',(5,3)),'ANGPT2':('ANGPT2',(-44,2)),'HGF':('HGF',(5,0))}
black = {'CCL17':('CCL17 (TARC)',(-58,6)),'CCL11-INFI':('eotaxin',(-36,10)),'TPSAB1':('tryptase',(6,10)),'NT-proBNP-CVDIII':('NT-proBNP',(-52,2)),'TNNI3':('troponin I',(-50,0)),'RAGE':('sRAGE',(6,-2)),'EGFR':('EGFR',(6,-6))}
for dct,col in [(blue,'tab:blue'),(brown,'tab:brown'),(black,'black')]:
    for a,(lab,off) in dct.items():
        r = s[s.assay==a].iloc[0]; c = 'red' if a=='ST2' else col
        ax.scatter(np.log2(r.OR), -np.log10(r['p.value']), s=20, c=c, zorder=3)
        ax.annotate(lab,(np.log2(r.OR), -np.log10(r['p.value'])), fontsize=6.5, xytext=off, textcoords='offset points', color=c)
thr = s.loc[s['adj.p.value']<0.05,'p.value'].max()
ax.axhline(-np.log10(thr), ls=':', c='k', lw=0.7); ax.text(-4.3, -np.log10(thr)+0.08, 'FDR 5% (as delivered)', fontsize=6.5)
ax.set_xlabel('log2 OR per delivered unit (scale differs by assay; rank by z, not OR)'); ax.set_ylabel('-log10 p')
ax.set_title('Blue: IL-33-inducible and AX-1177-reversible in endothelium (in vitro)\nBrown: endothelial/injury markers not transcribed by IL-33; black: type-2, cardiac, oxidised-IL-33 receptors', fontsize=8)
ax.set_xlim(-4.5,7)
plt.tight_layout(); plt.savefig(OUT+'fig3_serum_global_shift.png', bbox_inches='tight'); plt.close()
