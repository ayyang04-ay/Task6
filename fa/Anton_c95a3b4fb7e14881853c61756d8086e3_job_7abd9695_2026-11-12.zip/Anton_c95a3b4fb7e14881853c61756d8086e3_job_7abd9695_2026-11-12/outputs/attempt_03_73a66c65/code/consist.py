import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
import glob
files = {'huvec6':'huvec_IL33_vs_Vehicle_HUVEC_6_hrs.csv','huvec24':'huvec_IL33_vs_Vehicle_HUVEC_24_hrs.csv','contr':'contrasts_6h.csv'}
dfs=[]
for k,f in files.items():
    d=pd.read_csv(f); d['src']=k; dfs.append(d)
D=pd.concat(dfs, ignore_index=True)
# implied df via p from t for several df candidates
for df_ in [76, 80, 85, 90, 100, 1e6]:
    p_exp = 2*stats.t.sf(np.abs(D['t']), df_)
    r = np.log10(D['P.Value'].clip(lower=1e-300)) - np.log10(np.clip(p_exp,1e-300,None))
    print(df_, 'median |log10 ratio|', np.median(np.abs(r)), 'frac within 1%:', np.mean(np.abs(r)<0.0043))
