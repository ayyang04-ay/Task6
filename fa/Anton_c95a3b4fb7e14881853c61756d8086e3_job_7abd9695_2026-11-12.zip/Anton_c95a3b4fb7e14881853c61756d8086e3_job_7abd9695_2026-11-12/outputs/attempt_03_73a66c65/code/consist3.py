import pandas as pd, numpy as np
from scipy import stats, optimize
D = pd.read_pickle('all_rows.pkl')
bad = D[np.abs(D['lr'])>0.01].copy()
def implied_df(t,p):
    t=abs(t)
    f=lambda lg: np.log(2*stats.t.sf(t, np.exp(lg))) - np.log(p)
    try:
        return np.exp(optimize.brentq(f, np.log(0.5), np.log(1e7)))
    except Exception as e:
        return np.nan
bad['idf'] = [implied_df(t,p) for t,p in zip(bad['t'],bad['P.Value'])]
print(bad['idf'].describe())
# per gene: variation of implied df across contrasts
g = bad.groupby('ensembl')['idf'].agg(['count','min','max','median'])
print('n genes with inconsistent rows', len(g))
print(g['count'].value_counts().head(20))
g['range']=g['max']-g['min']
print(g.sort_values('count',ascending=False).head(30))
# how many genes appear in ALL 26 contrasts as bad?
bad.to_pickle('bad_rows.pkl')
