import pandas as pd, numpy as np
from statsmodels.stats.multitest import multipletests
D = pd.read_pickle('all_rows.pkl')
for c, g in D.groupby('Comparison', sort=False):
    bh = multipletests(g['P.Value'], method='fdr_bh')[1]
    d = np.abs(np.log10(bh.clip(1e-300)) - np.log10(g['adj.P.Val'].clip(lower=1e-300)))
    n_sig = (g['adj.P.Val']<0.05).sum()
    print(f"{c:50s} n={len(g)} maxdiff={d.max():.2e} nsig05={n_sig} nsig_up={( (g['adj.P.Val']<0.05)&(g.logFC>0)).sum()} nsig_dn={((g['adj.P.Val']<0.05)&(g.logFC<0)).sum()}")
