import pandas as pd, numpy as np
from scipy import stats
don = pd.read_pickle('pm_donor.pkl')
don['asthma']=don['Notes'].str.contains('Asthma')
don['copd_note']=don['Notes'].str.contains('COPD')
don['any_airway']=don['Notes'].str.contains('COPD|Asthma|Bronchiectasis|Bronchitis')
don['fibrosis_any']=don['Notes'].str.contains('Fibrosis') | don['path_fibrosis']
rows=[]
for feat in ['copd_note','path_emphysema','copd_or_emph','asthma','any_airway','fibrosis_any','path_thromboemb','DAD_ALI','acute_path']:
    for c in ['IL33_epi','IL33_endo','IL33_vsmc','EPX_sc','NE_dup_sc']:
        a=don.loc[don[feat]==True,c].dropna(); b=don.loc[don[feat]==False,c].dropna()
        if len(a)>1 and len(b)>1:
            rows.append((feat,c,len(a),round(a.median(),2),len(b),round(b.median(),2),round(stats.mannwhitneyu(a,b).pvalue,3)))
print(pd.DataFrame(rows,columns=['feature','score','n_yes','med_yes','n_no','med_no','MWU_p']).to_string())
print()
print('Thromboemboli by COVID status:', pd.crosstab(don.grp=='Pos', don.path_thromboemb))
print('Fisher:', stats.fisher_exact(pd.crosstab(don.grp=='Pos', don.path_thromboemb).values))
print('Age by group:', don.groupby('grp')['Age'].apply(lambda x: list(x.astype(int))).to_dict())
print('Sex by group:', pd.crosstab(don.grp, don.Gender))
