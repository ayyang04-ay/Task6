import pandas as pd, numpy as np
D = pd.read_pickle('all_rows.pkl')
W = D.pivot_table(index='ensembl', columns='Comparison', values='logFC')
P = D.pivot_table(index='ensembl', columns='Comparison', values='adj.P.Val')
T = D.pivot_table(index='ensembl', columns='Comparison', values='t')
W.to_pickle('W.pkl'); P.to_pickle('P.pkl'); T.to_pickle('T.pkl')
ann = D.drop_duplicates('ensembl').set_index('ensembl')[['symbol','entrez','gene_name','AveExpr']]
ann.to_pickle('ann.pkl')
for tp, tp2 in [('6_hrs','6hrs'),('24_hrs','24hrs')]:
    il = f'IL33_vs_Nontreated_HUVEC_{tp}'
    sig = P[il]<0.05
    for c in [f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp2}', f'Compound_47_IL33_vs_IL33_HUVEC_{tp2}', f'Compound_47_vs_IC119_HUVEC_{tp2}',
              f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp2}', f'Compound_47_IL33_vs_IL33_HGMEC_{tp2}', f'Compound_47_vs_IC119_HGMEC_{tp2}']:
        x = W.loc[sig, il]; y = W.loc[sig, c]
        r = np.corrcoef(x,y)[0,1]
        slope = np.polyfit(x,y,1)[0]
        # fraction of IL33-up genes reversed
        up = sig & (W[il]>0); dn = sig & (W[il]<0)
        rev_up = ((W.loc[up,c]<0)&(P.loc[up,c]<0.05)).mean()
        rev_dn = ((W.loc[dn,c]>0)&(P.loc[dn,c]<0.05)).mean()
        print(f'{il} vs {c}: n={sig.sum()} r={r:.3f} slope={slope:.3f} frac IL33-up sig reversed={rev_up:.2f} frac IL33-down sig reversed={rev_dn:.2f}')
    print()
