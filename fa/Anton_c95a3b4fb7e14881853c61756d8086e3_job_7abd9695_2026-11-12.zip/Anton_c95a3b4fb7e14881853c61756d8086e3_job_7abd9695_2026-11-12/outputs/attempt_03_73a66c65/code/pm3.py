import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250)
don = pd.read_pickle('pm_donor.pkl')
d = pd.read_pickle('pm_blocks.pkl')
for c in ['IL33_epi','IL33_endo','IL33_vsmc']: d[c]=pd.to_numeric(d[c], errors='coerce')
d['grp'] = d.groupby('donor')['DiseaseCat'].transform('first')
# manual curation of pathology (from reading each autopsy report)
acute = {'1130':1,'1138':1,'1149':1,'1159':1,'1165':1,'1910':1,'1905':0,'1970':0,'1968':0,'1961':0,
         '2035':1,'2044':1,'2045':1,'2049':1,'2040':1,'2043':1,'2067':0,'2072':1,'2073':1,'2075':1,'2101':0,'2105':1,'2108':1,'2110':1,'2113':1,'2060':1,
         '1861':0,'1944':1,'1956':1,'1965':0,'1976':1}
dad = {k:0 for k in acute}; 
for k in ['2044','2049','2040','2043','2072','2108','2110']: dad[k]=1
don['acute_path']=don.index.map(acute); don['DAD_ALI']=don.index.map(dad)
don['grp']=don['DiseaseCat'].map({'COVID neg pneumonia':'NegPneu','COVID pos pneumonia':'Pos','COVID neg non-pneumonia':'NegNonPneu'})
don.to_pickle('pm_donor.pkl')
print('Label vs pathology cross-tab (donors):')
print(pd.crosstab(don['grp'], don['acute_path'], margins=True))
print()
# block-level naive vs donor-level
for c in ['IL33_epi','IL33_endo','IL33_vsmc']:
    print('=====',c)
    print(' block-level means by group:', d.groupby('grp')[c].agg(['count','mean']).round(2).to_dict('index'))
    print(' donor-level medians by group:', don.groupby('grp')[c].agg(['count','median','mean']).round(2).to_dict('index'))
    grps = [don.loc[don.grp==g, c].dropna() for g in ['Pos','NegPneu','NegNonPneu']]
    print('  KW donor-level p=%.3f' % stats.kruskal(*grps).pvalue)
    print('  Pos vs all Neg (donor MWU) p=%.3f' % stats.mannwhitneyu(grps[0], pd.concat(grps[1:])).pvalue)
    # by pathology
    a = don.loc[don.acute_path==1, c].dropna(); b = don.loc[don.acute_path==0, c].dropna()
    print('  acute path (n=%d, med %.2f) vs not (n=%d, med %.2f) MWU p=%.3f' % (len(a), a.median(), len(b), b.median(), stats.mannwhitneyu(a,b).pvalue))
    a = don.loc[don.DAD_ALI==1, c].dropna(); b = don.loc[don.DAD_ALI==0, c].dropna()
    print('  DAD/ALI (n=%d, med %.2f) vs not (n=%d, med %.2f) MWU p=%.3f' % (len(a), a.median(), len(b), b.median(), stats.mannwhitneyu(a,b).pvalue))
    a = don.loc[don.copd_or_emph==True, c].dropna(); b = don.loc[don.copd_or_emph==False, c].dropna()
    print('  COPD/emphysema (n=%d, med %.2f) vs not (n=%d, med %.2f) MWU p=%.3f' % (len(a), a.median(), len(b), b.median(), stats.mannwhitneyu(a,b).pvalue))
    # ceiling
    print('  blocks at max (5.5):', (d[c]==5.5).sum(), '/', d[c].notna().sum())
