# AX-1177 portfolio audit: deliverables

| File | What it is |
|---|---|
| `AX-1177_portfolio_audit_memo.pdf` | **Committee document** (10 pp). It covers the recommendation, evidence, challenges and answers, forward view (indication, next studies, gates, biomarkers, sampling timepoint, patient roles), the "if we drop it" statement, what was considered and ruled out, data-integrity findings, and figures. |
| `AX-1177_portfolio_audit_memo.md` / `.html` | The same memo as Markdown (source) and as self-contained HTML with embedded figures. |
| `AX-1177_audit_supporting_tables.xlsx` | 11 sheets backing every number in the memo (see its README sheet). |
| `figures/fig1–fig6*.png` | In vitro neutralisation; antibody-alone specificity; serum proteomics; in vitro↔serum bridge; post-mortem lung; data integrity. |
| `scripts/` | Full re-analysis from the raw delivered files. `run_all.sh` regenerates the tables and figures (verified to reproduce identical outputs). `10_render_html.py` and `11_render_pdf.py` rebuild the memo renderings. |

**Bottom line:** keep AX-1177, but re-scoped and gated. Stop treating severe viral LRTI as an all-comers indication. Run a ≤6-month, mostly archive-based de-risking package with pre-agreed kill criteria. The re-scoped hypothesis is sST2-high / endothelial-activation hospitalised viral pneumonia, treated before ventilation.

**Inputs used (read-only):** the five files in `/tmp/world/filesystem/`. No external data were used.
