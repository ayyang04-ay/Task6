"""Map Olink assay IDs (panel-specific, not reconciled) to HGNC symbols; verify CI/p consistency; save serum_mapped.pkl"""
import os, sys, pandas as pd, numpy as np
from scipy.stats import norm
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from olink_map import base_name,to_symbol,panel_short
W=os.environ.get('AX_WORK','/tmp/work')
s=pd.read_pickle(f'{W}/serum.pkl')
s['base']=s.assay.map(base_name); s['symbol']=s.assay.map(to_symbol); s['panel_s']=s.panel.map(panel_short)
se=(np.log(s.u95)-np.log(s.l95))/(2*1.959964); pw=2*norm.sf(np.abs(np.log(s.OR)/se))
print('Wald p from CI vs delivered p, max |log10 diff|:',np.max(np.abs(np.log10(pw)-np.log10(s['p.value']))).round(5))
print('assays',len(s),'unique proteins',s.symbol.nunique(),'| q<0.05 assays',(s['adj.p.value']<0.05).sum(),'-> proteins',s.loc[s['adj.p.value']<0.05,'symbol'].nunique())
s.to_pickle(f'{W}/serum_mapped.pkl')
