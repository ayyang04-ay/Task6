"""Load the delivered AX-1177 files into pickles (WORK dir). Raw files are read-only inputs."""
import os, pandas as pd
RAW=os.environ.get('AX_RAW','/tmp/world/filesystem'); W=os.environ.get('AX_WORK','/tmp/work'); os.makedirs(W,exist_ok=True)
# RNA-seq contrasts: both sheets ('6h','24h') hold identical data for BOTH timepoints -> use one, verify identity
a=pd.read_excel(f'{RAW}/AX-1177_rnaseq_contrasts.xlsx',sheet_name='6h'); b=pd.read_excel(f'{RAW}/AX-1177_rnaseq_contrasts.xlsx',sheet_name='24h')
key=['Comparison','ensembl']
same=a.sort_values(key).reset_index(drop=True).equals(b.sort_values(key).reset_index(drop=True))
print('sheet "6h" == sheet "24h" after sorting:',same, '| contrasts:',a.Comparison.nunique(),'| rows:',len(a))
a.to_pickle(f'{W}/contrasts.pkl')
for sh,tp in [('IL33_vs_Vehicle_HUVEC_6_hrs','6_hrs'),('IL33_vs_Vehicle_HUVEC_24_hrs','24_hrs')]:
    pd.read_excel(f'{RAW}/AX-1177_rnaseq_huvec_il33.xlsx',sheet_name=sh).to_pickle(f'{W}/huvec_IL33_vs_Vehicle_HUVEC_{tp}.pkl')
pd.read_excel(f'{RAW}/AX-1177_serum_proteomics.xlsx',sheet_name=0).to_pickle(f'{W}/serum.pkl')
pd.read_excel(f'{RAW}/AX-1177_postmortem_lung.xlsx',sheet_name=0).to_pickle(f'{W}/pm.pkl')
print('loaded')
