"""Render the memo markdown to a self-contained HTML (figures embedded)."""
import os, re, base64, markdown
OUT=os.environ.get('AX_OUT','/tmp/outputs')
md=open(f'{OUT}/AX-1177_portfolio_audit_memo.md',encoding='utf-8').read()
def emb(m):
    cap,path=m.group(1),m.group(2)
    b=base64.b64encode(open(os.path.join(OUT,path),'rb').read()).decode()
    return f'<figure><img src="data:image/png;base64,{b}" alt="fig"/><figcaption>{cap}</figcaption></figure>'
md=re.sub(r'!\[(.*?)\]\((figures/[^)]+)\)',emb,md)
html=markdown.markdown(md,extensions=['tables','sane_lists'])
css='''body{font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;max-width:1100px;margin:2em auto;padding:0 1.5em;color:#1a1a1a;line-height:1.45;font-size:14px}
h1{font-size:1.7em;border-bottom:3px solid #1f4e79;padding-bottom:.3em;color:#1f4e79}h2{font-size:1.35em;color:#1f4e79;border-bottom:1px solid #ccc;padding-bottom:.2em;margin-top:1.6em}
h3{font-size:1.12em;color:#2d2d2d}table{border-collapse:collapse;width:100%;margin:.8em 0;font-size:12.5px}th,td{border:1px solid #c8c8c8;padding:5px 7px;vertical-align:top;text-align:left}
th{background:#e8eef5}tr:nth-child(even) td{background:#fafafa}blockquote{border-left:4px solid #1f4e79;background:#f1f5fa;margin:1em 0;padding:.6em 1em}
code{background:#f2f2f2;padding:1px 4px;border-radius:3px;font-size:12px}figure{margin:1.5em 0;text-align:center}figure img{max-width:100%;border:1px solid #ddd}
figcaption{font-size:12px;color:#444;text-align:left;margin-top:.4em}hr{border:none;border-top:1px solid #ddd;margin:1.5em 0}'''
open(f'{OUT}/AX-1177_portfolio_audit_memo.html','w',encoding='utf-8').write(f'<!doctype html><html><head><meta charset="utf-8"><title>AX-1177 portfolio audit position</title><style>{css}</style></head><body>{html}</body></html>')
print('html written', os.path.getsize(f'{OUT}/AX-1177_portfolio_audit_memo.html'))
