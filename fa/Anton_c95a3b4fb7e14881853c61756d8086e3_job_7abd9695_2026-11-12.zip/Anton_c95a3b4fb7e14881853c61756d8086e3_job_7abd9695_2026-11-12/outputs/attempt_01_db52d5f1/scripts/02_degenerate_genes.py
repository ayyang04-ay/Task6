"""Flag genes whose delivered limma statistics are numerically implausible: implied SE=|logFC/t| (median over 26 contrasts)
> 10x the median implied SE of genes with similar AveExpr (30 quantile bins)."""
import os, pandas as pd, numpy as np
W=os.environ.get('AX_WORK','/tmp/work')
M=pd.read_pickle(f'{W}/master.pkl')
lfc=[c for c in M.columns if c.endswith('_logFC')]
SE=pd.DataFrame({c:(M[c]/M[c.replace('_logFC','_t')]).abs() for c in lfc}).median(axis=1)
bins=pd.qcut(M.AveExpr,30); exp=bins.map(SE.groupby(bins,observed=False).median()).astype(float)
ratio=SE/exp
out=pd.DataFrame({'symbol':M.symbol,'AveExpr':M.AveExpr,'medSE':SE,'SEratio':ratio})[ratio>10].sort_values('SEratio',ascending=False)
out.index.name='ensembl'; out.to_csv(f'{W}/degenerate_genes.csv')
print('degenerate genes:',len(out)); print(', '.join(out.symbol.astype(str).head(40)))
