import os; W_=os.environ.get('AX_WORK','/tmp/work'); OUT_=os.environ.get('AX_OUT','/tmp/outputs')
import pandas as pd, numpy as np
from scipy.stats import kruskal, mannwhitneyu, spearmanr, fisher_exact
pd.set_option('display.width',300); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',400)
v=pd.read_pickle(W_+'/pm_clean.pkl')
vars_=['IL33_epi','IL33_endo','IL33_vsm','EPX_s','EDN_s','MBP_s','2D7_s','IL5Ra_NEduplex_s','NE_s','IL5Ra_TRYduplex_s','Tryptase_s','HE_eos_Y']
D=v.groupby('donor').agg({**{c:'mean' for c in vars_},'group':'first','Age':'first','Gender':'first','block':'size','note_COPD':'first','note_asthma':'first','path_DAD':'first','path_emphysema':'first','lung_notes':'first'}).rename(columns={'block':'n_blocks'})
# also block-max for IL-33 ceiling
D['IL33_endo_ceiling_frac']=v.groupby('donor').IL33_endo.apply(lambda x:(x>=5.5).mean())
D['IL33_epi_ceiling_frac']=v.groupby('donor').IL33_epi.apply(lambda x:(x>=5.5).mean())
D.to_pickle(W_+'/pm_donor.pkl')
order=['COVID- non-pneumonia','COVID- pneumonia','COVID+ pneumonia']
rows=[]
for c in vars_+['IL33_endo_ceiling_frac','IL33_epi_ceiling_frac','Age']:
    g=[D.loc[D.group==k,c].dropna() for k in order]
    kw=kruskal(*g).pvalue if all(len(x)>1 for x in g) and len(set(np.concatenate(g)))>1 else np.nan
    mw=mannwhitneyu(g[2],g[1]).pvalue   # COVID+ vs COVID- pneumonia
    mw2=mannwhitneyu(np.concatenate([g[1],g[2]]),g[0]).pvalue  # any pneumonia vs non-pneumonia
    rows.append({'variable':c, **{f'{k} median [IQR]':f'{x.median():.2f} [{x.quantile(.25):.2f}-{x.quantile(.75):.2f}] n={len(x)}' for k,x in zip(order,g)}, 'KW p':kw,'COVID+ vs COVID- pneu (MWU p)':mw,'pneumonia vs non-pneu (MWU p)':mw2})
R=pd.DataFrame(rows)
print(R.to_string(index=False))
print()
print('Sex by group:'); print(pd.crosstab(D.group,D.Gender))
print('COPD note by group:'); print(pd.crosstab(D.group,D.note_COPD))
print('Asthma note by group:'); print(pd.crosstab(D.group,D.note_asthma))
print('DAD in pathology by group:'); print(pd.crosstab(D.group,D.path_DAD))
