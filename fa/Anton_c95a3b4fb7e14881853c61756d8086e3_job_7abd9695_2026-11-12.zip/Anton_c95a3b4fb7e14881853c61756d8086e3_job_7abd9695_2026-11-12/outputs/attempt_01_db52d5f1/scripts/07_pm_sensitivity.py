import os; W_=os.environ.get('AX_WORK','/tmp/work'); OUT_=os.environ.get('AX_OUT','/tmp/outputs')
import pandas as pd, numpy as np
from scipy.stats import mannwhitneyu, spearmanr
pd.set_option('display.width',300); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',400)
v=pd.read_pickle(W_+'/pm_clean.pkl'); D=pd.read_pickle(W_+'/pm_donor.pkl')
print('=== Naive BLOCK-level (pseudo-replicated) vs DONOR-level: COVID+ vs COVID- pneumonia ===')
for c in ['IL33_epi','IL33_endo','IL33_vsm','EPX_s','EDN_s','MBP_s','NE_s','Tryptase_s']:
    a=v.loc[v.group=='COVID+ pneumonia',c].dropna(); b=v.loc[v.group=='COVID- pneumonia',c].dropna()
    da=D.loc[D.group=='COVID+ pneumonia',c].dropna(); db=D.loc[D.group=='COVID- pneumonia',c].dropna()
    print(f'{c:12s} block-level: {a.mean():.2f} (n={len(a)}) vs {b.mean():.2f} (n={len(b)}) p={mannwhitneyu(a,b).pvalue:.3f} | donor-level: {da.mean():.2f} (n={len(da)}) vs {db.mean():.2f} (n={len(db)}) p={mannwhitneyu(da,db).pvalue:.3f}')
# pathology-verified classification
man={1130:'pneu',1138:'pneu',1149:'pneu',1159:'pneu',1165:'pneu',1910:'pneu',1905:'no_pneu',1970:'no_pneu',1968:'no_pneu(aspiration?)',1961:'no_pneu',
     2035:'pneu',2044:'pneu',2045:'pneu',2049:'pneu',2040:'pneu',2043:'pneu',2067:'no_acute_pneu',2072:'pneu',2073:'pneu',2075:'pneu',2101:'no_acute_pneu',2105:'pneu',2108:'pneu',2110:'pneu',2113:'pneu',2060:'pneu',
     1861:'no_pneu',1944:'infection(cocci)',1956:'pneumonitis',1965:'no_pneu',1976:'pneu'}
D['path_class']=D.index.map(man)
print(); print(pd.crosstab(D.group,D.path_class))
D['verified']=((D.group.str.contains('pneumonia')&~D.group.str.contains('non'))&D.path_class.eq('pneu'))|(D.group.eq('COVID- non-pneumonia')&D.path_class.eq('no_pneu'))
print('\n=== Sensitivity: only donors whose category agrees with pathology text ===')
Dv=D[D.verified]
print(Dv.group.value_counts())
for c in ['IL33_epi','IL33_endo','IL33_vsm','EDN_s','MBP_s','NE_s']:
    a=Dv.loc[Dv.group=='COVID+ pneumonia',c].dropna(); b=Dv.loc[Dv.group=='COVID- pneumonia',c].dropna(); n=Dv.loc[Dv.group=='COVID- non-pneumonia',c].dropna()
    print(f'{c:10s} COVID+ {a.median():.2f} (n={len(a)}) | COVID- pneu {b.median():.2f} (n={len(b)}) | non-pneu {n.median():.2f} (n={len(n)}) | COVID+ vs COVID- pneu p={mannwhitneyu(a,b).pvalue:.3f}')
D.to_pickle(W_+'/pm_donor.pkl')
print('\n=== Within COVID+ donors (n=16): Spearman correlations ===')
C=D[D.group=='COVID+ pneumonia']
for x in ['IL33_epi','IL33_endo','IL33_vsm']:
    for y in ['EPX_s','EDN_s','MBP_s','NE_s','Tryptase_s','IL5Ra_NEduplex_s']:
        r,p=spearmanr(C[x],C[y],nan_policy='omit'); 
        print(f'  {x} vs {y}: rho={r:.2f} p={p:.3f}')
print('\n=== All donors (n=31): IL-33 vs cell markers ===')
for x in ['IL33_epi','IL33_endo','IL33_vsm']:
    for y in ['EDN_s','MBP_s','NE_s','Tryptase_s']:
        r,p=spearmanr(D[x],D[y],nan_policy='omit'); print(f'  {x} vs {y}: rho={r:.2f} p={p:.3f}')
print('\n=== DAD vs no DAD within COVID+ ===')
for c in ['IL33_epi','IL33_endo','IL33_vsm','NE_s','EDN_s']:
    a=C.loc[C.path_DAD,c].dropna(); b=C.loc[~C.path_DAD,c].dropna()
    print(f'  {c}: DAD {a.median():.2f} (n={len(a)}) vs no DAD {b.median():.2f} (n={len(b)}) p={mannwhitneyu(a,b).pvalue:.3f}')
print('\n=== COPD/asthma notes (all donors) ===')
D['obstructive']=D.note_COPD|D.note_asthma
for c in ['IL33_epi','IL33_endo','IL33_vsm','EDN_s','MBP_s','EPX_s','Tryptase_s']:
    a=D.loc[D.obstructive,c].dropna(); b=D.loc[~D.obstructive,c].dropna()
    print(f'  {c}: COPD/asthma {a.median():.2f} (n={len(a)}) vs none {b.median():.2f} (n={len(b)}) p={mannwhitneyu(a,b).pvalue:.3f}')
