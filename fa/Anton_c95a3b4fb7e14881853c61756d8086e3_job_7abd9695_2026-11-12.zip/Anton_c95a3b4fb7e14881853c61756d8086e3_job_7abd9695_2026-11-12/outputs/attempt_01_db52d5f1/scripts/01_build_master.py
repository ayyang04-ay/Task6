import os; W_=os.environ.get('AX_WORK','/tmp/work'); OUT_=os.environ.get('AX_OUT','/tmp/outputs')
import pandas as pd, numpy as np
a=pd.read_pickle(W_+'/contrasts.pkl')
base=pd.read_pickle(W_+'/huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl').set_index('ensembl')[['symbol','entrez','gene_name','AveExpr']]
M=base.copy()
for tp,tph in [('6_hrs','6h'),('24_hrs','24h')]:
    il=pd.read_pickle(W_+f'/huvec_IL33_vs_Vehicle_HUVEC_{tp}.pkl').set_index('ensembl')
    for col in ['logFC','t','P.Value','adj.P.Val']:
        M[f'IL33vVeh_HUVEC_{tph}_{col}']=il[col]
short={'Compound_47_vs_IC119':'C47vIC119','Compound_47_IL33_vs_IL33':'C47IL33vIL33','Compound_47_IL33_vs_IL33_IC119':'C47IL33vIL33IC119','Compound_47_vs_DMSO':'C47vDMSO','Compound_47_vs_PBS':'C47vPBS'}
for c in a['Comparison'].unique():
    d=a[a.Comparison==c].set_index('ensembl')
    # parse
    tp='6h' if c.endswith('_6hrs') else '24h'
    core=c.replace('_6hrs','').replace('_24hrs','')
    line=core.split('_')[-1]
    comp=core[:-(len(line)+1)]
    nm=f'{short[comp]}_{line}_{tp}'
    for col in ['logFC','t','P.Value','adj.P.Val']:
        M[f'{nm}_{col}']=d[col]
M.to_pickle(W_+'/master.pkl')
print(M.shape)
print([c for c in M.columns if c.endswith('_logFC')])
