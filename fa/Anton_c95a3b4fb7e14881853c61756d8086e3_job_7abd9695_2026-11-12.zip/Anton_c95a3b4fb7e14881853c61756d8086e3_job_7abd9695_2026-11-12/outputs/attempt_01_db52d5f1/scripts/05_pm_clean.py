import os; W_=os.environ.get('AX_WORK','/tmp/work'); OUT_=os.environ.get('AX_OUT','/tmp/outputs')
import pandas as pd, numpy as np, re
v=pd.read_pickle(W_+'/pm.pkl')
v=v[v['Sample ID'].notna()].copy()
v=v.rename(columns={'Sample ID':'donor','Histology Block ID':'block','SARS-Cov-2 ':'sars','Disease Category':'category',
 'H&E eosinophils apparent (Y/N)':'HE_eos','EPX IHC [0 (none)- 5 (severe)]':'EPX','EDN IHC [0 (none) - 5 (severe)]':'EDN','MBP IHC [0 (none) - 5 (severe)]':'MBP',
 '2D7 IHC [0 (none) - 5 (severe)]':'2D7','IL-5Ra (from duplex w NE)  [0 (none) - 5 (severe)]':'IL5Ra_NEduplex','Neutrophil elastase (from duplex w IL5Ra) [0 (none) - 5 (severe)]':'NE',
 'IL-5Ra (from duplex w tryptase)  [0 (none) - 5 (severe)]':'IL5Ra_TRYduplex','Tryptase (from duplex w IL5Ra) [0 (none) - 5 (severe)]':'Tryptase',
 'Eosinophil peroxidase':'EPX_num','Neutrophil elastase ':'NE_num','Tryptase':'TRY_num',
 'IL-33, bronchial and bronchiolar basal epithelial cells':'IL33_epi','IL-33, endothelial cells':'IL33_endo','IL-33, vascular smooth muscle cells':'IL33_vsm',
 'Notes - Approved lung conditions':'lung_notes','Tissue RNA':'tissue_rna'})
v['donor']=v['donor'].astype(int)
# forward-fill donor-level fields within donor (recorded against first block only)
for c in ['category','Race','Gender','Age','sars','Pathology','lung_notes']:
    v[c]=v.groupby('donor')[c].transform(lambda x: x.ffill().bfill())
def score(x):
    if pd.isna(x): return np.nan
    s=str(x).strip()
    if s.upper()=='ND' or s=='': return np.nan
    m=re.match(r'^(\d)\+?$',s)
    if m: return float(m.group(1))
    try: return float(s)
    except: return np.nan
for c in ['EPX','EDN','MBP','2D7','IL5Ra_NEduplex','NE','IL5Ra_TRYduplex','Tryptase']:
    v[c+'_s']=v[c].map(score)
for c in ['EPX_num','NE_num','TRY_num','IL33_epi','IL33_endo','IL33_vsm']:
    v[c]=pd.to_numeric(v[c],errors='coerce')
v['HE_eos_Y']=(v['HE_eos'].astype(str).str.strip().str.upper()=='Y').astype(float)
v['group']=v['category'].map({'COVID pos pneumonia':'COVID+ pneumonia','COVID neg pneumonia':'COVID- pneumonia','COVID neg non-pneumonia':'COVID- non-pneumonia'})
# pathology-derived flags
P=v['Pathology'].fillna('').str.lower()
v['path_pneumonia']=P.str.contains('pneumonia|bronchopneumonia|pneumonitis|consolidation')
v['path_DAD']=P.str.contains('diffuse alveolar damage|hyalin|acute lung injury')
v['path_emphysema']=P.str.contains('emphysema')
v['path_fibrosis']=P.str.contains('fibrosis')&P.str.contains('pulmonary|lung')
N=v['lung_notes'].fillna('').str.lower()
v['note_COPD']=N.str.contains('copd'); v['note_asthma']=N.str.contains('asthma')
v.to_pickle(W_+'/pm_clean.pkl')
print(v.groupby('group').donor.nunique())
print(v.groupby('group').size())
# check numeric vs string concordance
chk=v[['EPX_s','EPX_num']].dropna(); print('EPX num == s+0.5 (or 0):', ((chk.EPX_num==np.where(chk.EPX_s>0,chk.EPX_s+0.5,0))).mean())
chk=v[['NE_s','NE_num']].dropna(); print('NE num == s+0.5:', ((chk.NE_num==np.where(chk.NE_s>0,chk.NE_s+0.5,0))).mean())
chk=v[['Tryptase_s','TRY_num']].dropna(); print('TRY num == s+0.5:', ((chk.TRY_num==np.where(chk.Tryptase_s>0,chk.Tryptase_s+0.5,0))).mean())
print('IL-33 values >5 (outside 0-5 scale): epi',(v.IL33_epi>5).sum(),'/',v.IL33_epi.notna().sum(),' endo',(v.IL33_endo>5).sum(),'/',v.IL33_endo.notna().sum(),' vsm',(v.IL33_vsm>5).sum())
print('Blocks per donor:', v.groupby('donor').size().value_counts().sort_index().to_dict())
