"""Render the memo markdown (restricted subset) to a committee-ready PDF with reportlab.
Supports: #/##/### headings, paragraphs, nested '-' bullets, numbered lists, '>' blockquotes,
pipe tables, '---' rules, images ![caption](path), **bold**, *italic*, `code`."""
import os, re, matplotlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether,
                                HRFlowable, ListFlowable, ListItem, PageBreak)
from reportlab.lib.utils import ImageReader

OUT = os.environ.get('AX_OUT', '/tmp/outputs')
FD = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
pdfmetrics.registerFont(TTFont('DV', os.path.join(FD, 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B', os.path.join(FD, 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DV-I', os.path.join(FD, 'DejaVuSans-Oblique.ttf')))
pdfmetrics.registerFont(TTFont('DV-BI', os.path.join(FD, 'DejaVuSans-BoldOblique.ttf')))
pdfmetrics.registerFont(TTFont('DVM', os.path.join(FD, 'DejaVuSansMono.ttf')))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily('DV', normal='DV', bold='DV-B', italic='DV-I', boldItalic='DV-BI')

NAVY = colors.HexColor('#1f4e79')
base = ParagraphStyle('base', fontName='DV', fontSize=8.6, leading=11.4, spaceAfter=3)
S = {
    'h1': ParagraphStyle('h1', parent=base, fontName='DV-B', fontSize=15, leading=19, textColor=NAVY, spaceAfter=6),
    'h2': ParagraphStyle('h2', parent=base, fontName='DV-B', fontSize=11.5, leading=14.5, textColor=NAVY, spaceBefore=9, spaceAfter=4),
    'h3': ParagraphStyle('h3', parent=base, fontName='DV-B', fontSize=9.8, leading=12.5, spaceBefore=6, spaceAfter=3),
    'p': base,
    'quote': ParagraphStyle('q', parent=base, backColor=colors.HexColor('#eef3f9'), borderColor=NAVY, borderWidth=0,
                            borderPadding=(4, 6, 4, 6), leftIndent=8, rightIndent=4, spaceBefore=3, spaceAfter=5),
    'cell': ParagraphStyle('cell', parent=base, fontSize=7.4, leading=9.2, spaceAfter=0),
    'cellh': ParagraphStyle('cellh', parent=base, fontName='DV-B', fontSize=7.4, leading=9.2, spaceAfter=0),
    'cap': ParagraphStyle('cap', parent=base, fontSize=7.6, leading=9.6, textColor=colors.HexColor('#333333')),
}


def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'`([^`]+)`', r'<font face="DVM" size="7.6">\1</font>', t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'<i>\1</i>', t)
    return t


def make_table(rows, width):
    hdr = [c.strip() for c in rows[0].strip().strip('|').split('|')]
    body = [[c.strip() for c in r.strip().strip('|').split('|')] for r in rows[2:]]
    n = len(hdr)
    # column widths ~ sqrt of max content length
    lens = [max([len(hdr[i])] + [len(b[i]) if i < len(b) else 0 for b in body]) for i in range(n)]
    w = [max(10, l) ** 0.6 for l in lens]
    tot = sum(w)
    cw = [width * x / tot for x in w]
    data = [[Paragraph(inline(h), S['cellh']) for h in hdr]]
    for b in body:
        b = b + [''] * (n - len(b))
        data.append([Paragraph(inline(c), S['cell']) for c in b[:n]])
    t = Table(data, colWidths=cw, repeatRows=1)
    t.setStyle(TableStyle([
        ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#b8b8b8')),
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e3ebf5')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f8f8')]),
        ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
        ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]))
    return t


def build_list(items):
    """items: list of (level, kind, text) -> nested ListFlowable"""
    def rec(i, level):
        flow = []
        kind = items[i][1] if i < len(items) else 'bullet'
        while i < len(items) and items[i][0] >= level:
            lv, k, txt = items[i]
            if lv > level:
                sub, i = rec(i, lv)
                if flow:
                    last = flow[-1]
                    flow[-1] = ListItem([last._flowables[0] if hasattr(last, '_flowables') else last, sub] if False else [last, sub], leftIndent=10)
                continue
            flow.append(Paragraph(inline(txt), S['p']))
            i += 1
        if kind == 'num':
            lf = ListFlowable([f if isinstance(f, ListItem) else ListItem(f, leftIndent=12) for f in flow], bulletType='1', bulletFormat='%s.',
                              bulletFontName='DV', bulletFontSize=8.4, leftIndent=12)
        else:
            lf = ListFlowable([f if isinstance(f, ListItem) else ListItem(f, leftIndent=10) for f in flow], bulletType='bullet',
                              start='•' if level == 0 else '–', bulletFontName='DV', bulletFontSize=8, leftIndent=10)
        return lf, i
    lf, _ = rec(0, items[0][0])
    return lf


def render(md_path, pdf_path):
    lines = open(md_path, encoding='utf-8').read().split('\n')
    doc = SimpleDocTemplate(pdf_path, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm, bottomMargin=14 * mm,
                            title='AX-1177 portfolio audit position', author='AX-1177 audit re-analysis')
    W = A4[0] - 30 * mm
    story = []
    i = 0
    para = []

    def flush():
        nonlocal para
        if para:
            story.append(Paragraph(inline(' '.join(para)), S['p']))
            para = []
    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        if not s:
            flush(); i += 1; continue
        if s.startswith('## Figures'):
            flush(); story.append(PageBreak()); story.append(Paragraph(inline(s[3:]), S['h2'])); i += 1; continue
        m = re.match(r'^(#{1,3})\s+(.*)', s)
        if m:
            flush()
            story.append(Paragraph(inline(m.group(2)), S['h' + str(len(m.group(1)))]))
            i += 1; continue
        if s == '---':
            flush(); story.append(HRFlowable(width='100%', thickness=0.6, color=colors.HexColor('#c8c8c8'), spaceBefore=4, spaceAfter=4)); i += 1; continue
        m = re.match(r'^!\[(.*?)\]\((.*?)\)', s)
        if m:
            flush()
            path = os.path.join(os.path.dirname(md_path), m.group(2))
            ir = ImageReader(path); iw, ih = ir.getSize()
            w = W; h = ih * w / iw
            maxh = 200 * mm
            if h > maxh: h = maxh; w = iw * h / ih
            story.append(KeepTogether([Image(path, width=w, height=h), Spacer(1, 2), Paragraph(inline(m.group(1)), S['cap']), Spacer(1, 8)]))
            i += 1; continue
        if s.startswith('|'):
            flush()
            rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                rows.append(lines[i]); i += 1
            story.append(make_table(rows, W)); story.append(Spacer(1, 4)); continue
        if s.startswith('>'):
            flush()
            q = []
            while i < len(lines) and lines[i].strip().startswith('>'):
                q.append(lines[i].strip()[1:].strip()); i += 1
            # group into paragraphs / numbered lines
            chunks, cur = [], []
            for x in q:
                if not x:
                    if cur: chunks.append(' '.join(cur)); cur = []
                elif re.match(r'^\d+\.\s', x):
                    if cur: chunks.append(' '.join(cur)); cur = []
                    chunks.append(x)
                else:
                    cur.append(x)
            if cur: chunks.append(' '.join(cur))
            inner = '<br/>'.join(inline(c) for c in chunks)
            story.append(Paragraph(inner, S['quote'])); continue
        m = re.match(r'^(\s*)([-*]|\d+\.)\s+(.*)', ln)
        if m:
            flush()
            items = []
            while i < len(lines):
                mm_ = re.match(r'^(\s*)([-*]|\d+\.)\s+(.*)', lines[i])
                if not mm_:
                    # continuation line of a list item (indented, non-empty)
                    if lines[i].strip() and lines[i].startswith('  ') and items:
                        items[-1] = (items[-1][0], items[-1][1], items[-1][2] + ' ' + lines[i].strip()); i += 1; continue
                    break
                ind = len(mm_.group(1))
                level = 0 if ind == 0 else (1 if ind <= 4 else 2)
                kind = 'num' if mm_.group(2)[0].isdigit() else 'bullet'
                items.append((level, kind, mm_.group(3))); i += 1
            story.append(build_list(items)); continue
        para.append(s); i += 1
    flush()

    def on_page(c, d):
        c.saveState(); c.setFont('DV', 7); c.setFillColor(colors.HexColor('#666666'))
        c.drawString(15 * mm, 8 * mm, 'AX-1177 portfolio audit position — derived solely from the delivered AX-1177 data package')
        c.drawRightString(A4[0] - 15 * mm, 8 * mm, f'page {d.page}'); c.restoreState()
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)


if __name__ == '__main__':
    render(f'{OUT}/AX-1177_portfolio_audit_memo.md', f'{OUT}/AX-1177_portfolio_audit_memo.pdf')
    print('pdf written', os.path.getsize(f'{OUT}/AX-1177_portfolio_audit_memo.pdf'))
