import os; W_=os.environ.get('AX_WORK','/tmp/work'); OUT_=os.environ.get('AX_OUT','/tmp/outputs')
import sys; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
plt.rcParams.update({'font.size':9,'axes.titlesize':10,'axes.labelsize':9,'figure.dpi':150,'savefig.bbox':'tight','axes.spines.top':False,'axes.spines.right':False})
OUT=OUT_+'/figures/'; os.makedirs(OUT,exist_ok=True)
M=pd.read_pickle(W_+'/master.pkl')
deg=set(pd.read_csv(W_+'/degenerate_genes.csv').ensembl)
M['deg']=M.index.isin(deg)

# ---------------- Figure 1: in vitro pharmacology ----------------
fig,axs=plt.subplots(1,3,figsize=(14,4.8),gridspec_kw={'width_ratios':[1,1,0.8],'wspace':0.32})
lab_main=['CSF2','CCL20','CXCL6','IL6','TNFRSF11B','F3','NFKBIA','IL1B']
lab_deg=['SELE','VCAM1','CXCL8']
for ax,tp in zip(axs[:2],['6h','24h']):
    x=M[f'IL33vVeh_HUVEC_{tp}_logFC']; y=M[f'C47IL33vIL33IC119_HUVEC_{tp}_logFC']
    qx=M[f'IL33vVeh_HUVEC_{tp}_adj.P.Val']
    ns=(qx>=0.05)&~M.deg; sg=(qx<0.05)&~M.deg
    ax.scatter(x[ns],y[ns],s=2,c='#cccccc',rasterized=True,label='not IL-33-responsive (q≥0.05)')
    ax.scatter(x[sg],y[sg],s=3,c='#1f77b4',alpha=.6,rasterized=True,label='IL-33-responsive (q<0.05)')
    ax.scatter(x[M.deg],y[M.deg],s=12,facecolors='none',edgecolors='#d62728',lw=.7,label='degenerate statistics (uninterpretable)')
    lim=13; ax.plot([-lim,lim],[lim,-lim],'k--',lw=.8,label='complete neutralisation (slope −1)'); ax.axhline(0,c='k',lw=.4); ax.axvline(0,c='k',lw=.4)
    labs=(lab_main+lab_deg) if tp=='6h' else ['CSF2','CXCL6','CCL20','IL6','TNFRSF11B','SELE']
    for g in labs:
        r=M[M.symbol==g]
        if len(r):
            xx=r[f'IL33vVeh_HUVEC_{tp}_logFC'].iloc[0]; yy=r[f'C47IL33vIL33IC119_HUVEC_{tp}_logFC'].iloc[0]
            name={'TNFRSF11B':'OPG','F3':'TF'}.get(g,g)
            ax.annotate(name,(xx,yy),fontsize=6.8,xytext=(-4,-3),textcoords='offset points',ha='right',va='top',color='#d62728' if g in lab_deg else 'k')
    n1=(M[f'IL33vVeh_HUVEC_{tp}_adj.P.Val']<0.05).sum(); n2=(M[f'C47IL33vIL33IC119_HUVEC_{tp}_adj.P.Val']<0.05).sum()
    ax.set_title(f'HUVEC {tp}\nIL-33 vs vehicle: {n1:,} DE genes\nAX-1177+IL-33 vs IL-33+isotype: {n2:,} DE genes',fontsize=9)
    ax.set_xlabel('log2FC  IL-33 (30 ng/mL) vs vehicle'); ax.set_ylabel('log2FC  AX-1177+IL-33 vs IL-33+isotype')
    ax.set_xlim(-6,12.5); ax.set_ylim(-13.5,6.5)
axs[1].legend(fontsize=6.5,loc='upper right',frameon=False)
ax=axs[2]; data=[]; labels=[]
Mg=M[~M.deg]
for tp in ['6h','24h']:
    il=Mg[f'IL33vVeh_HUVEC_{tp}_logFC']; t=Mg[f'IL33vVeh_HUVEC_{tp}_t']; q=Mg[f'IL33vVeh_HUVEC_{tp}_adj.P.Val']
    A=Mg[f'C47IL33vIL33_HUVEC_{tp}_logFC']; B=Mg[f'C47IL33vIL33IC119_HUVEC_{tp}_logFC']
    sel=(q<0.01)&(il>1)&(Mg.AveExpr>1)&(t>6)
    data += [((il+A-B)/il)[sel].values*100, ((il+A)/il)[sel].values*100]
    labels += [f'IL-33\n+isotype\n{tp}', f'IL-33\n+AX-1177\n{tp}']
bp=ax.boxplot(data,tick_labels=labels,showfliers=False,patch_artist=True,widths=.6,medianprops=dict(color='k'))
for i,b in enumerate(bp['boxes']): b.set_facecolor('#bbbbbb' if i%2==0 else '#2ca02c')
ax.axhline(100,c='k',ls=':',lw=.8); ax.axhline(0,c='k',lw=.6)
ax.set_ylabel('% of IL-33 response remaining (vs vehicle)')
ax.set_title('Residual IL-33 response,\nrobust induced genes (n=195 at 6 h; n=41 at 24 h)',fontsize=9)
for i,d in enumerate(data): ax.text(i+1,np.percentile(d,75)+8,f'{abs(np.median(d)) if abs(np.median(d))<0.5 else np.median(d):.0f}%',ha='center',fontsize=7.5,fontweight='bold')
ax.tick_params(axis='x',labelsize=7)
fig.suptitle('Figure 1. AX-1177 (Compound_47, 10 µg/mL ≈ 41-fold molar excess, added concurrently) fully neutralises reduced IL-33 signalling in HUVEC at 6 h and 24 h',fontsize=10.5,y=1.04)
fig.savefig(OUT+'fig1_invitro_neutralisation.png'); plt.close(fig)

# ---------------- Figure 2: specificity / DE counts ----------------
a=pd.read_pickle(W_+'/contrasts.pkl')
rows=[]
for c in a.Comparison.unique():
    d=a[(a.Comparison==c)&(a['adj.P.Val']<0.05)]
    cred=d[(d.AveExpr>=0)&(d.logFC.abs()>=0.3)]
    rows.append((c,len(d),len(cred)))
for tp in ['6_hrs','24_hrs']:
    il=pd.read_pickle(W_+f'/huvec_IL33_vs_Vehicle_HUVEC_{tp}.pkl'); d=il[il['adj.P.Val']<0.05]
    rows.append((f'IL33_vs_Vehicle_HUVEC_{tp.replace("_hrs","hrs")}',len(d),len(d[(d.AveExpr>=0)&(d.logFC.abs()>=0.3)])))
R=pd.DataFrame(rows,columns=['contrast','nDE','credible'])
order=['IL33_vs_Vehicle_HUVEC_6hrs','IL33_vs_Vehicle_HUVEC_24hrs','Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs','Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs','Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs','Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs',
       'Compound_47_vs_IC119_HUVEC_6hrs','Compound_47_vs_IC119_HUVEC_24hrs','Compound_47_vs_IC119_HGMEC_6hrs','Compound_47_vs_IC119_HGMEC_24hrs','Compound_47_vs_IC119_A549_6hrs','Compound_47_vs_IC119_A549_24hrs','Compound_47_vs_IC119_MCF7_6hrs','Compound_47_vs_IC119_MCF7_24hrs']
R=R.set_index('contrast').loc[order].reset_index()
nice={'IL33_vs_Vehicle_HUVEC_6hrs':'IL-33 vs vehicle · HUVEC 6h','IL33_vs_Vehicle_HUVEC_24hrs':'IL-33 vs vehicle · HUVEC 24h',
'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs':'AX-1177+IL-33 vs IL-33+isotype · HUVEC 6h','Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs':'AX-1177+IL-33 vs IL-33+isotype · HUVEC 24h',
'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs':'AX-1177+IL-33 vs IL-33+isotype · HGMEC 6h','Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs':'AX-1177+IL-33 vs IL-33+isotype · HGMEC 24h'}
R['label']=[nice.get(c, c.replace('Compound_47_vs_IC119_','AX-1177 alone vs isotype · ').replace('_6hrs',' 6h').replace('_24hrs',' 24h')) for c in R.contrast]
fig,ax=plt.subplots(figsize=(8.5,4.6))
y=np.arange(len(R))[::-1]
ax.barh(y,R.nDE,color=['#1f77b4']*2+['#2ca02c']*4+['#999999']*8)
alone=R.contrast.str.startswith('Compound_47_vs_IC119').values
ax.barh(y[alone],R.credible[alone],color='none',edgecolor='k',hatch='///',lw=.5)
for yi,n,c,al in zip(y,R.nDE,R.credible,alone): ax.text(n*1.15+1,yi,(f'{n:,}  (not low-count noise: {c:,})' if al else f'{n:,}'),va='center',fontsize=7)
ax.set_yticks(y); ax.set_yticklabels(R.label,fontsize=7.5); ax.set_xscale('symlog',linthresh=10); ax.set_xlim(0,40000)
ax.set_xlabel('Number of genes with adj.P < 0.05 (symlog scale).  Hatched (AX-1177-alone rows only) = hits with AveExpr ≥ 0 and |log2FC| ≥ 0.3')
ax.set_title('Figure 2. AX-1177 alone has no coherent transcriptional activity in any of four cell types\n(14–73 nominal hits per contrast, almost all low-count lncRNA/pseudogene noise; none overlaps the IL-33 programme beyond chance)',fontsize=9.5)
fig.savefig(OUT+'fig2_specificity_DEcounts.png'); plt.close(fig)

# ---------------- Figure 3: serum ----------------
s=pd.read_pickle(W_+'/serum_mapped.pkl')
fig,axs=plt.subplots(1,2,figsize=(13,5.2),gridspec_kw={'width_ratios':[1,1.15]})
ax=axs[0]
x=np.log2(s.OR); yv=-np.log10(s['p.value'])
sig=s['adj.p.value']<0.05
ax.scatter(x[~sig],yv[~sig],s=5,c='#bbbbbb',rasterized=True,label='q ≥ 0.05')
ax.scatter(x[sig],yv[sig],s=7,c='#1f77b4',rasterized=True,label='q < 0.05 (178 assays = 169 proteins)')
hl={'ST2':'#d62728','IL-18R1':'#d62728','IL-1RT2':'#d62728','IL1B':'#d62728'}
t2=['IL5-IMO','CCL11-INFI','CCL11-IMO','CCL24','CCL17','MCP-4','TPSAB1','KIT','RNASE3','IL-5R-alpha','FCER2','HPGDS','IL17RB']
for _,r in s.iterrows():
    if r.assay in hl:
        ax.scatter(np.log2(r.OR),-np.log10(r['p.value']),s=30,c='#d62728',zorder=5)
        off={'ST2':(4,2),'IL-18R1':(6,6),'IL-1RT2':(-8,10),'IL1B':(4,2)}[r.assay]
        ax.annotate({'ST2':'sST2 (IL-33 decoy receptor)','IL-1RT2':'IL-1R2','IL-18R1':'IL-18R1','IL1B':'IL-1β'}[r.assay],(np.log2(r.OR),-np.log10(r['p.value'])),fontsize=7,xytext=off,textcoords='offset points',color='#d62728',ha='right' if off[0]<0 else 'left')
    if r.assay in t2: ax.scatter(np.log2(r.OR),-np.log10(r['p.value']),s=22,marker='D',c='#ff7f0e',zorder=5)
    if r.assay in ['HGF','IL6','OPG-INFI','PTX3','CLEC5A','CCL20','vWF','TF']: ax.annotate(r.assay,(np.log2(r.OR),-np.log10(r['p.value'])),fontsize=6.5,xytext=(3,-8),textcoords='offset points')
ax.scatter([],[],s=22,marker='D',c='#ff7f0e',label='type-2 / eosinophil / mast-cell markers')
ax.axvline(0,c='k',lw=.5); ax.set_xlabel('log2 odds ratio per log unit (adjusted for age, sex, NEWS2)'); ax.set_ylabel('−log10 p')
ax.set_title('Serum Olink (n=100 hospitalised COVID-19; 44 events)\n1,094 delivered assays vs ICU / IMV / death ≤30 d'); ax.legend(fontsize=7,frameon=False,loc='upper left')
ax.set_xlim(-3,7.5)
# forest
ax=axs[1]
sel=[('ST2','sST2 (IL1RL1) — IL-33 decoy receptor'),('IL-18R1','IL-18R1'),('IL-1RT2','IL-1R2 (decoy)'),('IL6','IL-6 (Inflammation)'),('IL6-ONCII','IL-6 (Oncology II)'),('IL6-CVDII','IL-6 (CVD II)'),('IL6-IMO','IL-6 (Immune Resp.)'),('OPG-INFI','OPG (Inflammation)'),('OPG-CVDIII','OPG (CVD III)'),('CCL20','CCL20'),('TF','Tissue factor'),('vWF','vWF'),('PTX3','PTX3'),('NT-proBNP-MET','NT-proBNP (Metab.)'),('NT-proBNP-CVDIII','NT-proBNP (CVD III)'),
     ('IL5-IMO','IL-5'),('CCL11-INFI','Eotaxin-1 (Inflammation)'),('CCL11-IMO','Eotaxin-1 (Immune Resp.)'),('CCL24','Eotaxin-2'),('CCL17','CCL17/TARC'),('MCP-4','CCL13/MCP-4'),('TPSAB1','Tryptase'),('KIT','KIT'),('RNASE3','ECP (RNASE3)'),('IL-5R-alpha','IL-5Rα')]
yy=np.arange(len(sel))[::-1]
for yi,(a_,lab_) in zip(yy,sel):
    r=s[s.assay==a_].iloc[0]
    col='#d62728' if yi>=len(sel)-3 else ('#ff7f0e' if a_ in t2 else ('#777777' if 'NT-proBNP' in a_ else '#1f77b4'))
    ax.errorbar(np.log2(r.OR),yi,xerr=[[np.log2(r.OR)-np.log2(r.l95)],[np.log2(r.u95)-np.log2(r.OR)]],fmt='o',c=col,ms=4,capsize=2,lw=1)
    ax.text(6.2,yi,f'OR {r.OR:.2f} ({r.l95:.2f}–{r.u95:.2f}); q={r["adj.p.value"]:.2g}',fontsize=6.3,va='center')
ax.set_yticks(yy); ax.set_yticklabels([l for _,l in sel],fontsize=7); ax.axvline(0,c='k',lw=.6)
ax.set_xlim(-2.5,11.5); ax.set_xlabel('log2 OR (95% CI) per log unit')
ax.axhline(len(sel)-15.5,c='k',lw=.4,ls=':')
ax.set_title('IL-1-family receptors and endothelial/IL-6 axis track severity;\ntype-2 / eosinophil / mast-cell axis is flat')
fig.suptitle('Figure 3. Serum proteomics: sST2 is the #2 of 1,094 assays; the classical downstream type-2 IL-33 axis shows no association. IL-33 itself was not delivered.',fontsize=10.5,y=1.02)
fig.savefig(OUT+'fig3_serum.png'); plt.close(fig)

# ---------------- Figure 4: bridge ----------------
J=pd.read_pickle(W_+'/serum_rna_join.pkl')
R_=J[J.in_rna & ~J.degenerate.astype(bool)]
fig,ax=plt.subplots(figsize=(8.8,5.6))
x=R_['IL33vVeh_HUVEC_6h_logFC']; y=np.log2(R_.OR)
rev=R_['IL33up_rev']; sig=R_['adj.p.value']<0.05
ax.scatter(x[~sig&~rev],y[~sig&~rev],s=6,c='#cccccc',label='serum q≥0.05, not IL-33-induced')
ax.scatter(x[sig&~rev],y[sig&~rev],s=10,c='#1f77b4',alpha=.7,label='serum q<0.05, not IL-33-induced/reversed in HUVEC')
ax.scatter(x[~sig&rev],y[~sig&rev],s=14,facecolors='none',edgecolors='#2ca02c',label='IL-33-induced & AX-1177-reversed, serum q≥0.05')
ax.scatter(x[sig&rev],y[sig&rev],s=24,c='#2ca02c',label='IL-33-induced & AX-1177-reversed, serum q<0.05 (PD candidates)')
for g in ['TNFRSF11B','IL6','CCL20','IL18R1','CSF1','IL1B','CCL7','VEGFA','F3','CXCL6','CSF3','CXCL5','CXCL10','TNF','HGF','OSM','CLEC5A','SPINK1','CTSS']:
    r=R_[R_.symbol==g]
    if len(r): ax.annotate({'TNFRSF11B':'OPG','F3':'TF','CSF3':'G-CSF','CCL7':'MCP-3'}.get(g,g),(r['IL33vVeh_HUVEC_6h_logFC'].iloc[0],np.log2(r.OR.iloc[0])),fontsize=7,xytext=((-3,6) if g in ('HGF',) else (3,3)),textcoords='offset points',ha=('right' if g in ('HGF','OSM') else 'left'))
ax.axhline(0,c='k',lw=.5); ax.axvline(0,c='k',lw=.5)
ax.set_xlabel('IL-33-induced log2FC in HUVEC at 6 h (transcript)'); ax.set_ylabel('serum log2 OR for severe outcome (protein)')
ax.set_ylim(-3.6,7.2)
ax.text(0.99,0.80,'Fisher test, IL-33-induced & reversed among severity-up proteins:\n24/103 (23%) vs 125/766 (16%); OR 1.56, p = 0.094\nSpearman ρ (all 869 mappable proteins) = 0.11',transform=ax.transAxes,ha='right',va='top',fontsize=7.2,bbox=dict(fc='white',ec='#999999'))
ax.text(0.01,0.98,'Not placeable (degenerate RNA statistics):\nsST2/IL1RL1, PTX3, IL-8, vWF, MCP-1, E-selectin —\nall severity-associated in serum',transform=ax.transAxes,ha='left',va='top',fontsize=7.2,color='#d62728',bbox=dict(fc='white',ec='#d62728'))
ax.legend(fontsize=6.5,frameon=True,loc='lower left',framealpha=1)
ax.text(3.3,6.15,'CSF-1 / CTSS ORs are inflated by per-log-unit\nscaling of narrow-range assays (CIs 4–1,933; 3–200)',fontsize=6.5,color='#555555')
ax.set_title('Figure 4. Bridge: only a subset of the AX-1177-reversible endothelial IL-33 programme is\nassociated with severity in patients (weak, non-significant enrichment)')
fig.savefig(OUT+'fig4_bridge_invitro_serum.png'); plt.close(fig)

# ---------------- Figure 5: post-mortem ----------------
D=pd.read_pickle(W_+'/pm_donor.pkl')
order=['COVID- non-pneumonia','COVID- pneumonia','COVID+ pneumonia']; cols=['#7f7f7f','#1f77b4','#d62728']
vars_=[('IL33_epi','IL-33, basal epithelium'),('IL33_endo','IL-33, endothelium'),('IL33_vsm','IL-33, vascular smooth muscle'),('NE_s','Neutrophil elastase'),('EDN_s','EDN (eosinophil)'),('Tryptase_s','Tryptase (mast cell)')]
fig,axs=plt.subplots(2,3,figsize=(11.5,7.6),sharey=False); axs=axs.ravel(); fig.subplots_adjust(hspace=0.55,wspace=0.28)
rng=np.random.default_rng(0)
from scipy.stats import mannwhitneyu
for ax,(c,t) in zip(axs,vars_):
    for i,(g,col) in enumerate(zip(order,cols)):
        vals=D.loc[D.group==g,c].dropna().values
        ax.scatter(i+rng.uniform(-.15,.15,len(vals)),vals,s=16,c=col,alpha=.8)
        ax.plot([i-.25,i+.25],[np.median(vals)]*2,c='k',lw=1.5)
    if c.startswith('IL33'): ax.axhline(5.5,c='k',ls=':',lw=.8); ax.text(2.45,5.55,'ceiling\n(5+ → 5.5)',fontsize=6,ha='right',va='bottom')
    ax.axhline(5.0,c='#999999',ls='--',lw=.5)
    p=mannwhitneyu(D.loc[D.group==order[2],c].dropna(),D.loc[D.group==order[1],c].dropna()).pvalue
    ax.set_title(f'{t}\nCOVID+ vs COVID− pneumonia: p={p:.2f}',fontsize=9)
    ax.set_xticks([0,1,2]); ax.set_xticklabels(['non-\npneumonia\n(n=5)','COVID−\npneumonia\n(n=10)','COVID+\npneumonia\n(n=16)'],fontsize=7.5)
    ax.set_ylabel('donor-mean score (nominal 0–5)',fontsize=8)
    ax.set_ylim(-0.2,6.3)
fig.suptitle('Figure 5. Post-mortem lung, donor-level (31 donors, 74 blocks). IL-33 is constitutively high in every group and not\nincreased in COVID-19 (endothelium at the scale ceiling in controls); inflammatory-cell markers track pneumonia, not SARS-CoV-2',fontsize=10,y=0.995)
fig.savefig(OUT+'fig5_postmortem.png'); plt.close(fig)

# ---------------- Figure 6: data integrity ----------------
fig,axs=plt.subplots(1,2,figsize=(12.5,4.4))
ax=axs[0]
lfc=[c for c in M.columns if c.endswith('_logFC')]
SE=pd.DataFrame({c:(M[c]/M[c.replace('_logFC','_t')]).abs() for c in lfc}).median(axis=1)
ax.scatter(M.AveExpr[~M.deg],SE[~M.deg],s=2,c='#999999',rasterized=True,label='26,032 genes')
ax.scatter(M.AveExpr[M.deg],SE[M.deg],s=8,c='#d62728',label='178 genes with implied SE >10× expected')
for g in ['CD93','CDH5','VWF','SELE','VCAM1','CXCL8','CXCL1','CCL2','PTX3','IL1RL1','ESM1','XBP1','KRT8','AKR1C2']:
    r=M[M.symbol==g]
    if len(r): ax.annotate(g,(r.AveExpr.iloc[0],SE[r.index[0]]),fontsize=6.5,xytext=(3,2),textcoords='offset points',color='#d62728')
ax.set_yscale('log'); ax.set_xlabel('AveExpr (log2 CPM, averaged over all 114 libraries)'); ax.set_ylabel('median implied SE of log2FC across 26 contrasts (|logFC / t|)')
ax.set_title('RNA-seq: implausible variance for cell-identity and\ncanonical endothelial-activation genes (single pooled fit)'); ax.legend(fontsize=7,frameon=False)
ax=axs[1]
ss=s.sort_values('p.value').reset_index(drop=True); p=ss['p.value'].values; q=ss['adj.p.value'].values
Rk=p*1194/q; r=np.arange(1,len(p)+1); gap=Rk-r
uniq=~pd.Series(q).duplicated(keep=False).values; exact=uniq&(np.abs(Rk-np.round(Rk))<0.02)
ax.step(p[exact],np.round(gap[exact]),where='post',c='#d62728')
ax.set_xscale('log'); ax.set_xlabel('assay p-value'); ax.set_ylabel('non-delivered assays with smaller p (reconstructed)')
ax.axvline(0.05,c='k',ls=':',lw=.7); ax.axvline(0.005,c='k',ls=':',lw=.7)
ax.annotate('2 hidden assays with\np ≈ 0.0002–0.001\n(would pass FDR 5%)',xy=(1.2e-3,2),xytext=(2e-5,25),fontsize=7,arrowprops=dict(arrowstyle='->',lw=.6))
ax.annotate('≈15 hidden assays with p < 0.05\n(~5 expected by chance)',xy=(0.05,15.5),xytext=(2e-4,50),fontsize=7,arrowprops=dict(arrowstyle='->',lw=.6))
ax.set_title('Serum: BH was applied over 1,194 assays but 1,094 were delivered.\n100 analysed assays are missing (IL-33, IL-4, IL-13, TSLP, IL-5 (Inflam.) ...)')
fig.suptitle('Figure 6. Data-integrity findings that change what can be claimed',fontsize=10.5,y=1.03)
fig.savefig(OUT+'fig6_data_integrity.png'); plt.close(fig)
print('figures done')
