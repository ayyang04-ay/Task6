import os; W_=os.environ.get('AX_WORK','/tmp/work'); OUT_=os.environ.get('AX_OUT','/tmp/outputs')
import pandas as pd, numpy as np
from scipy.stats import fisher_exact, mannwhitneyu
pd.set_option('display.width',300); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',400)
s=pd.read_pickle(W_+'/serum_mapped.pkl')
M=pd.read_pickle(W_+'/master.pkl')
deg=set(pd.read_csv(W_+'/degenerate_genes.csv').ensembl)
M['degenerate']=M.index.isin(deg)
# collapse RNA by symbol: if duplicated symbols, keep the row with highest AveExpr
Ms=M.reset_index().sort_values('AveExpr',ascending=False).drop_duplicates('symbol').set_index('symbol')
# protein-level serum: take the assay with median p among panels (conservative, avoids cherry-picking)
def pick(g):
    g=g.sort_values('p.value'); return g.iloc[(len(g)-1)//2]
P=s.groupby('symbol',group_keys=False).apply(pick).reset_index(drop=True)
P['n_panels']=P.symbol.map(s.symbol.value_counts())
J=P.merge(Ms, left_on='symbol', right_index=True, how='left')
J['in_rna']=J['IL33vVeh_HUVEC_6h_logFC'].notna()
J['degenerate']=J['degenerate'].fillna(False).astype(bool)
def il33_resp(r, tp):
    return (r[f'IL33vVeh_HUVEC_{tp}_adj.P.Val']<0.05)
for tp in ['6h','24h']:
    J[f'IL33up_{tp}']=(J[f'IL33vVeh_HUVEC_{tp}_adj.P.Val']<0.05)&(J[f'IL33vVeh_HUVEC_{tp}_logFC']>0.5)
    J[f'IL33dn_{tp}']=(J[f'IL33vVeh_HUVEC_{tp}_adj.P.Val']<0.05)&(J[f'IL33vVeh_HUVEC_{tp}_logFC']<-0.5)
    J[f'rev_{tp}']=(J[f'C47IL33vIL33IC119_HUVEC_{tp}_adj.P.Val']<0.05)&(np.sign(J[f'C47IL33vIL33IC119_HUVEC_{tp}_logFC'])==-np.sign(J[f'IL33vVeh_HUVEC_{tp}_logFC']))
J['IL33up_any']=J.IL33up_6h|J.IL33up_24h
J['IL33up_rev']=(J.IL33up_6h&J.rev_6h)|(J.IL33up_24h&J.rev_24h)
J['serum_sig']=J['adj.p.value']<0.05
J['serum_up']=J.serum_sig&(J.OR>1)
J.to_pickle(W_+'/serum_rna_join.pkl')
R=J[J.in_rna & ~J.degenerate]
print('serum proteins with usable RNA stats:', len(R), ' (excluded degenerate:', (J.in_rna&J.degenerate).sum(), '; not expressed/filtered in RNA:', (~J.in_rna).sum(),')')
for flag in ['IL33up_6h','IL33up_24h','IL33up_any','IL33up_rev']:
    a=(R[flag]&R.serum_up).sum(); b=(R[flag]&~R.serum_up).sum(); c=(~R[flag]&R.serum_up).sum(); d=(~R[flag]&~R.serum_up).sum()
    orr,p=fisher_exact([[a,b],[c,d]])
    print(f'{flag:12s}: IL33-induced & serum-up {a}/{a+b} ({a/(a+b):.1%}) vs not-induced {c}/{c+d} ({c/(c+d):.1%}); Fisher OR={orr:.2f} p={p:.3g}')
# continuous: serum log OR vs IL-33 logFC
from scipy.stats import spearmanr
for tp in ['6h','24h']:
    rho,p=spearmanr(R[f'IL33vVeh_HUVEC_{tp}_logFC'], np.log(R.OR))
    print(f'Spearman serum lnOR vs IL-33 logFC ({tp}): rho={rho:.3f} p={p:.3g}  n={len(R)}')
# also: among serum proteins, are the ones NOT expressed in endothelium (not in RNA) more or less associated?
print('serum-up rate: in RNA (expressed in cell lines)', J[J.in_rna].serum_up.mean().round(3), ' not in RNA', J[~J.in_rna].serum_up.mean().round(3))
cols=['symbol','assay','n_panels','OR','l95','u95','p.value','adj.p.value','IL33vVeh_HUVEC_6h_logFC','IL33vVeh_HUVEC_6h_adj.P.Val','C47IL33vIL33IC119_HUVEC_6h_logFC','C47IL33vIL33IC119_HUVEC_6h_adj.P.Val','IL33vVeh_HUVEC_24h_logFC','IL33vVeh_HUVEC_24h_adj.P.Val','C47IL33vIL33IC119_HUVEC_24h_logFC','C47IL33vIL33IC119_HUVEC_24h_adj.P.Val','C47IL33vIL33IC119_HGMEC_6h_logFC','C47IL33vIL33IC119_HGMEC_6h_adj.P.Val']
X=R[R.IL33up_rev & R.serum_up].sort_values('p.value')[cols]
X.columns=['symbol','assay','nP','OR','l95','u95','p','q','IL33_6h','q6','C47n_6h','qn6','IL33_24h','q24','C47n_24h','qn24','HGMECn_6h','qH6']
print('\n=== Serum severity proteins (q<0.05, OR>1) that are IL-33-induced in HUVEC and reversed by AX-1177 vs isotype ===')
print(X.round(3).to_string(index=False))
Y=R[R.IL33up_any & ~R.serum_sig & (R['p.value']<0.05)].sort_values('p.value')[cols[:8]+cols[8:12]]
print('\n=== nominal serum p<0.05 but q>=0.05, IL-33-induced ===')
print(Y.round(3).to_string(index=False))
Z=R[R.IL33up_rev & (R.OR<1) & (R['p.value']<0.1)][cols[:8]+cols[8:12]]
print('\n=== IL-33 induced but serum OR<1 (p<0.1) ===')
print(Z.round(3).to_string(index=False))
