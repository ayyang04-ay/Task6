#!/usr/bin/env bash
# Reproduce the AX-1177 audit re-analysis from the delivered files.
# Requires a Python env with pandas, openpyxl, scipy, statsmodels, matplotlib (here: `micromamba run -n singlecell`).
set -euo pipefail
export AX_RAW=${AX_RAW:-/tmp/world/filesystem} AX_WORK=${AX_WORK:-/tmp/work_repro} AX_OUT=${AX_OUT:-/tmp/outputs_repro}
mkdir -p "$AX_WORK" "$AX_OUT"
PY=${PY:-"micromamba run -n singlecell python -W ignore"}
D=$(cd "$(dirname "$0")" && pwd)
for s in 00_load_raw 01_build_master 02_degenerate_genes 03_serum_map 04_serum_rna_join 05_pm_clean 06_pm_donor 07_pm_sensitivity 08_figures 09_tables; do
  echo "=== $s"; $PY "$D/$s.py"
done
