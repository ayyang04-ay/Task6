import os; W_=os.environ.get('AX_WORK','/tmp/work'); OUT_=os.environ.get('AX_OUT','/tmp/outputs')
import sys; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import pandas as pd, numpy as np
from scipy.stats import mannwhitneyu, kruskal
from olink_map import panel_short
W=W_+'/'
M=pd.read_pickle(W+'master.pkl'); deg=pd.read_csv(W+'degenerate_genes.csv'); degset=set(deg.ensembl)
a=pd.read_pickle(W+'contrasts.pkl'); s=pd.read_pickle(W+'serum_mapped.pkl'); J=pd.read_pickle(W+'serum_rna_join.pkl')
v=pd.read_pickle(W+'pm_clean.pkl'); D=pd.read_pickle(W+'pm_donor.pkl')
sheets={}

# 1 in vitro contrast summary
rows=[]
for tp in ['6_hrs','24_hrs']:
    d=pd.read_pickle(W+f'huvec_IL33_vs_Vehicle_HUVEC_{tp}.pkl'); sg=d[d['adj.P.Val']<0.05]
    rows.append(dict(contrast=f'IL33_vs_Vehicle_HUVEC_{tp}',n_DE_q05=len(sg),up=(sg.logFC>0).sum(),down=(sg.logFC<0).sum(),min_p=d['P.Value'].min(),nonnoise_hits='n/a',interpretation='IL-33 response (reference)'))
for c in a.Comparison.unique():
    d=a[a.Comparison==c]; sg=d[d['adj.P.Val']<0.05]
    nn=sg[(sg.AveExpr>=0)&(sg.logFC.abs()>=0.3)]
    if c.startswith('Compound_47_vs_IC119'): it='AX-1177 alone vs isotype: specificity / agonism check (valid control)'
    elif 'vs_DMSO' in c or 'vs_PBS' in c: it='AX-1177 vs PBS/DMSO: not a valid antibody control (DMSO is not the antibody vehicle); set aside'
    elif 'IL33_vs_IL33_IC119' in c: it='Neutralisation vs isotype-matched comparator (primary)'
    else: it='Neutralisation vs IL-33 alone (overstates: isotype arm not inert at 24 h)'
    rows.append(dict(contrast=c,n_DE_q05=len(sg),up=(sg.logFC>0).sum(),down=(sg.logFC<0).sum(),min_p=d['P.Value'].min(),nonnoise_hits=(len(nn) if (c.startswith('Compound_47_vs_')) else 'n/a'),interpretation=it))
sheets['1_InVitro_contrasts']=pd.DataFrame(rows)

# 2 neutralisation per gene (robust set) 6h/24h
out=[]
Mg=M[~M.index.isin(degset)]
for tp in ['6h','24h']:
    il=Mg[f'IL33vVeh_HUVEC_{tp}_logFC']; t=Mg[f'IL33vVeh_HUVEC_{tp}_t']; q=Mg[f'IL33vVeh_HUVEC_{tp}_adj.P.Val']
    A=Mg[f'C47IL33vIL33_HUVEC_{tp}_logFC']; B=Mg[f'C47IL33vIL33IC119_HUVEC_{tp}_logFC']
    sel=(q<0.01)&(il.abs()>1)&(Mg.AveExpr>1)&(t.abs()>6)
    d=pd.DataFrame({'timepoint':tp,'ensembl':Mg.index[sel],'symbol':Mg.symbol[sel],'IL33_vs_vehicle_log2FC':il[sel],'IL33_q':q[sel],
        'AX1177+IL33_vs_IL33+isotype_log2FC':B[sel],'pct_IL33_response_remaining_with_AX1177':100*(il+A)[sel]/il[sel],'pct_IL33_response_remaining_with_isotype':100*(il+A-B)[sel]/il[sel],
        'HGMEC_AX1177+IL33_vs_IL33+isotype_log2FC':Mg[f'C47IL33vIL33IC119_HGMEC_{tp}_logFC'][sel],'HGMEC_q':Mg[f'C47IL33vIL33IC119_HGMEC_{tp}_adj.P.Val'][sel]})
    out.append(d)
sheets['2_Neutralisation_robust_genes']=pd.concat(out).sort_values(['timepoint','IL33_vs_vehicle_log2FC'],ascending=[True,False])

# 3 PD candidates & kinetics
R=J[J.in_rna & ~J.degenerate.astype(bool)].copy()
cand=R[R.IL33up_rev & (R['adj.p.value']<0.05) & (R.OR>1)].copy()
nom=R[R.IL33up_rev & (R['p.value']<0.05) & (R['adj.p.value']>=0.05) & (R.OR>1)].copy()
def kin(df,tier):
    o=pd.DataFrame({'tier':tier,'symbol':df.symbol,'olink_assay(s)':df.symbol.map(s.groupby('symbol').assay.apply(lambda x:'; '.join(x))),'n_panels':df.n_panels,
      'serum_OR_per_log_unit':df.OR,'l95':df.l95,'u95':df.u95,'serum_p':df['p.value'],'serum_q':df['adj.p.value'],
      'IL33_6h_log2FC':df['IL33vVeh_HUVEC_6h_logFC'],'IL33_6h_q':df['IL33vVeh_HUVEC_6h_adj.P.Val'],'AX1177_reversal_6h_log2FC':df['C47IL33vIL33IC119_HUVEC_6h_logFC'],'reversal_6h_q':df['C47IL33vIL33IC119_HUVEC_6h_adj.P.Val'],
      'IL33_24h_log2FC':df['IL33vVeh_HUVEC_24h_logFC'],'IL33_24h_q':df['IL33vVeh_HUVEC_24h_adj.P.Val'],'AX1177_reversal_24h_log2FC':df['C47IL33vIL33IC119_HUVEC_24h_logFC'],'reversal_24h_q':df['C47IL33vIL33IC119_HUVEC_24h_adj.P.Val'],
      'HGMEC_reversal_6h_log2FC':df['C47IL33vIL33IC119_HGMEC_6h_logFC'],'HGMEC_reversal_6h_q':df['C47IL33vIL33IC119_HGMEC_6h_adj.P.Val']})
    o['persists_and_reversed_at_24h']=(o.IL33_24h_q<0.05)&(o.IL33_24h_log2FC>0.5)&(o.reversal_24h_q<0.05)&(o.AX1177_reversal_24h_log2FC<0)
    return o
P=pd.concat([kin(cand,'A: serum q<0.05'),kin(nom,'B: serum p<0.05, q>=0.05')]).sort_values(['tier','serum_p'])
sheets['3_PD_candidates']=P

# 4 serum protein-level with mapping
g=s.groupby('symbol')
prot=g.apply(lambda x: pd.Series({'assays':'; '.join(x.assay),'panels':'; '.join(x.panel_s),'n_panels':len(x),'OR_range':f'{x.OR.min():.2f}–{x.OR.max():.2f}' if len(x)>1 else f'{x.OR.iloc[0]:.2f}',
    'best_p':x['p.value'].min(),'median_p':x['p.value'].median(),'best_q_delivered':x['adj.p.value'].min(),'max_frac_missing_or_LOD_group0':x.composite_endpoint_0.max(),'max_frac_missing_or_LOD_group1':x.composite_endpoint_1.max()})).reset_index().sort_values('best_p')
sheets['4_Serum_protein_level']=prot
sa=s[['panel_s','assay','symbol','OR','l95','u95','p.value','adj.p.value','composite_endpoint_0','composite_endpoint_1']].rename(columns={'panel_s':'panel','composite_endpoint_0':'frac_group0_(n=56)','composite_endpoint_1':'frac_group1_(n=44)'}).sort_values('p.value')
sheets['5_Serum_assay_level_mapped']=sa

# 6 serum hidden-assay reconstruction
ss=s.sort_values('p.value').reset_index(drop=True); p=ss['p.value'].values; q=ss['adj.p.value'].values
Rk=p*1194/q; r=np.arange(1,len(p)+1); gap=Rk-r
uniq=~pd.Series(q).duplicated(keep=False).values; exact=uniq&(np.abs(Rk-np.round(Rk))<0.02)
H=pd.DataFrame({'delivered_rank':r,'assay':ss.assay,'p':p,'delivered_q':q,'implied_rank_in_1194_list':np.where(exact,np.round(Rk),np.nan),'hidden_assays_with_smaller_p':np.where(exact,np.round(gap),np.nan)})
sheets['6_Serum_hidden_assays']=H

# 7 degenerate genes
dg=deg.merge(M[['symbol']].reset_index(),on=['ensembl','symbol'],how='left')
sheets['7_RNAseq_degenerate_genes']=dg.rename(columns={'medSE':'median_implied_SE_log2FC','SEratio':'ratio_to_expected_SE'})

# 8 post-mortem donor table + stats
Dd=D.reset_index()[['donor','group','path_class','n_blocks','Age','Gender','note_COPD','note_asthma','path_DAD','IL33_epi','IL33_endo','IL33_vsm','IL33_endo_ceiling_frac','EPX_s','EDN_s','MBP_s','2D7_s','NE_s','Tryptase_s','IL5Ra_NEduplex_s','IL5Ra_TRYduplex_s','HE_eos_Y','lung_notes']]
sheets['8_PostMortem_donor_level']=Dd
order=['COVID- non-pneumonia','COVID- pneumonia','COVID+ pneumonia']
rows=[]
rng=np.random.default_rng(1)
for c in ['IL33_epi','IL33_endo','IL33_vsm','EPX_s','EDN_s','MBP_s','2D7_s','NE_s','Tryptase_s','IL5Ra_NEduplex_s','HE_eos_Y']:
    gs=[D.loc[D.group==k,c].dropna().values for k in order]
    a_,b_=gs[2],gs[1]
    bs=[rng.choice(a_,len(a_)).mean()-rng.choice(b_,len(b_)).mean() for _ in range(4000)]
    rows.append({'variable':c,**{f'median_{k}':np.median(x) for k,x in zip(order,gs)},'n':'/'.join(str(len(x)) for x in gs),'KW_p':kruskal(*gs).pvalue,
                 'COVID+_vs_COVID-pneu_MWU_p':mannwhitneyu(a_,b_).pvalue,'mean_diff_COVID+_minus_COVID-pneu':a_.mean()-b_.mean(),'boot95_lo':np.percentile(bs,2.5),'boot95_hi':np.percentile(bs,97.5),
                 'pneumonia_vs_nonpneumonia_MWU_p':mannwhitneyu(np.concatenate([gs[1],gs[2]]),gs[0]).pvalue})
sheets['9_PostMortem_group_stats']=pd.DataFrame(rows)

# 10 data integrity log
log=[
('RNA-seq contrasts workbook','Sheets named "6h" and "24h" contain identical data for BOTH timepoints (24 contrasts each, different row order); the 6h sheet reports 1,048,576 rows in metadata (Excel limit) but holds 629,040 data rows — no truncation.','Low (no data loss) but sheet labels are misleading.','Use Comparison column, not sheet name.'),
('RNA-seq statistics','178 genes have implied SE >10x expected for their expression (t≈1e-5 for log2FC up to 8). Affected: endothelial identity (CD93, CDH5, VWF, ENG, TIE1, PECAM1), canonical activation genes (SELE, VCAM1, CXCL8, CXCL1, CCL2, PTX3, IL1RL1/sST2, ESM1, HMOX1, PTGS2), epithelial-line identity genes (KRT8/18/19, TFF1, GATA3, XBP1; AKR1C1-3, ALDH3A1, G6PD).','High: removes the in vitro evidence for exactly the genes that are top serum severity markers (sST2, PTX3, IL-8, vWF, MCP-1, E-selectin).','Refit per cell line from archived counts; sample-identity QC.'),
('RNA-seq AveExpr','AveExpr is averaged over all 114 libraries (4 cell types); cell-restricted genes look "low" (CSF2 AveExpr -3.2 although it is the strongest IL-33-induced gene).','Medium: AveExpr filters would discard the key IL-33 genes.','Do not filter on AveExpr; use per-cell-line expression after refit.'),
('RNA-seq design','HGMEC has no vehicle arm: the IL-33 response and % neutralisation in the microvascular line cannot be estimated from delivered contrasts.','Medium','Extract IL33+IC119 vs IC119 (HGMEC) from archived fit.'),
('RNA-seq design','Only reduced IL-33 was used; epithelial lines (A549, MCF7) never received IL-33; single antibody concentration (10 µg/mL, ~41-fold molar excess), concurrent addition, no dose-response.','High for differentiation/potency claims (oxidised-form activity untested; no IC50).','Stage 1 functional pharmacology.'),
('RNA-seq controls','Isotype IC119 is not inert in the presence of IL-33 at 24 h (IL-33+IC119 retains 86% of the IL-33 response on robust genes; 101% at 6 h). PBS/DMSO are not appropriate antibody vehicles.','Low-Medium: contrasts vs IL-33 alone overstate neutralisation; DMSO/PBS contrasts uninformative.','Use isotype-matched comparator (done).'),
('Serum proteomics','BH adjustment was computed over 1,194 assays but 1,094 were delivered (annex says "across all assays in the delivery"). 100 analysed assays are missing; reconstruction shows 2 with p≈0.0002–0.001 (would pass FDR), ~15 with p<0.05 (≈5 expected by chance).','High: the drug target IL-33 (and IL-4, IL-13, TSLP, IL-5 (Inflammation panel), IL-1α, LIF ...) is absent from the delivery.','Request the 100 assays with %<LOD and results.'),
('Serum proteomics','27 proteins measured on 2–4 panels (58 assays) under different IDs; 178 significant assays = 169 proteins. Cross-panel replicates concordant (e.g., IL-6 x4 OR 2.07–2.31).','Low (technical reassurance) but inflates counts.','Report protein-level counts.'),
('Serum proteomics','ORs are per "log unit" of an unstated base; Olink NPX is already log2-scaled. ORs are not comparable across assays (CSF-1 OR 90, 95% CI 4–1,933).','Medium: do not rank or quote by OR.','Rank by p/standardised effect; clarify transform.'),
('Serum proteomics','Columns composite_endpoint_0/_1 undocumented; values are k/56 and k/44 (max 9%), consistent with per-outcome-group fraction below LOD or missing. Implies 44 events / 56 non-events.','Low','Confirm with vendor.'),
('Serum proteomics','Single centre, n=100, pre-vaccination SARS-CoV-2 only; single timepoint (enrolment); no patient-level data; no adjustment for treatments (e.g., corticosteroids) or time from symptom onset.','High for generalisation to "severe viral LRTI".','Independent multi-pathogen cohort; patient-level data.'),
('Post-mortem','Donor-level fields recorded only on first block (must be forward-filled); 31 donors / 74 blocks; 3 COVID+ donors contribute 24 of 49 COVID+ blocks (pseudoreplication if analysed per block).','High if analysed per block.','Donor-level analysis (done).'),
('Post-mortem','IHC "n+" scores converted to n+0.5 in numeric columns, so 5+ = 5.5, above the stated 0–5 scale; IL-33 at 5.5 in 39/74 endothelial and 16/71 epithelial blocks (ceiling); single reader; ND and trailing-space values.','High: endothelial IL-33 cannot rise in controls already at ceiling.','Blinded two-reader digital re-quantification.'),
('Post-mortem','Disease category conflicts with the pathology text in 9/31 donors (e.g., "non-pneumonia" donor with acute and organizing pneumonia; "COVID+ pneumonia" donors without acute pneumonia; "COVID- pneumonia" donors without pneumonia; one donor lacks SARS-CoV-2 status). Non-pneumonia controls all have significant lung disease (IPF, coccidioidomycosis, pneumonitis).','Medium (sensitivity analysis unchanged conclusions).','Re-adjudicate categories; add normal-lung controls.'),
('Post-mortem','Tissue RNA exists for 22 blocks (Zr4940 series; 9 COVID+, 9 COVID- pneumonia, 4 non-pneumonia) but was not delivered.','Opportunity','Sequence/score the IL-33 endothelial signature (Stage 1).'),
]
sheets['10_Data_integrity_log']=pd.DataFrame(log,columns=['dataset','finding','impact_on_claims','remedy'])

# 11 biomarker plan
bm=[
('sST2 (IL1RL1)','Serum','Prognostic ENRICHMENT / stratification at enrolment','YES - first-in-patient study, as enrichment + stratification factor (not as a companion diagnostic)','OR 3.02 (1.83–5.01) per log unit, p=1.7e-5, q=0.0075, #2 of 1,063 proteins; adjusted for age, sex, NEWS2; NT-proBNP only weakly associated (OR 1.20–1.24) so not simply cardiac stretch','Enrolment / admission, pre-dose','Quantitative clinical-grade assay; cut-off from patient-level data; replication in influenza/RSV and vaccinated-era COVID. Not shown to predict AX-1177 response; PD role unresolved (IL1RL1 in vitro stats degenerate).'),
('Total IL-33 (free + AX-1177-bound); reduced vs oxidised','Serum','TARGET ENGAGEMENT / dose selection','YES once an assay exists (Phase 1b)','None in our data: IL-33 assay not delivered (presumed below LOD on Olink)','Pre-dose, 24 h, then serial','Develop form-specific sensitive assay; first check the hidden Olink IL-33 result.'),
('OPG (TNFRSF11B)','Serum','PHARMACODYNAMIC (IL-33-endothelial pathway) - lead PD marker','YES as exploratory PD endpoint','IL-33-induced log2FC 4.8 (6 h) / 2.4 (24 h), reversed by AX-1177 at both; serum OR 6.77 and 4.40 on two independent panels (q=0.014, 0.020)','Pre-dose and 24 h post-dose','Confirm in lung microvascular endothelium; validated immunoassay.'),
('IL-6','Serum','PD (secondary) + prognostic covariate','YES as exploratory PD','log2FC 5.8 / 2.8, reversed; serum OR 2.07–2.31 on four panels (q 0.012–0.019)','Pre-dose and 24 h','Non-specific; confounded by corticosteroids / IL-6R blockade in standard of care.'),
('CCL20, IL-18R1, IL-1β, CSF-1','Serum','PD panel members','YES as exploratory PD','All IL-33-induced at 6 h and 24 h and reversed by AX-1177; serum q<0.05','Pre-dose and 24 h','Non-specific NF-κB targets; CSF-1 OR inflated by scaling.'),
('Tissue factor, MCP-3 (CCL7), VEGF-A, uPA','Serum','Early PD only','OPTIONAL','Induced & reversed at 6 h only (not at 24 h); serum TF OR 3.02 (q=0.051), MCP-3 1.72 (q=0.020), VEGF-A 4.23 (q=0.024)','≤6 h post-dose if sampled','Timing-sensitive.'),
('vWF, PTX3, E-selectin, IL-8, MCP-1, ANGPT2','Serum','Prognostic covariates; PD status pending RNA-seq refit','EXPLORATORY only','Severity-associated in serum (vWF q=0.050, PTX3 q=0.012, IL-8 q=0.023); in vitro statistics degenerate (cannot say if IL-33-driven)','Enrolment','Refit RNA-seq first.'),
('Tissue IL-33 IHC','Lung tissue','None in patients','NO','Constitutive in all groups, at scale ceiling, not increased in COVID-19; invasive','n/a','Use only in translational studies with improved scoring.'),
('Eosinophil / type-2 markers (IL-5, eotaxins, tryptase, blood eosinophils)','Serum / blood','None for selection in this indication','NO','IL-5 OR 1.00; eotaxin-1 0.98–1.08; eotaxin-2 0.92; CCL17 0.85; tryptase 1.07; tissue eosinophils not COVID-specific','n/a','-'),
]
sheets['11_Biomarker_plan']=pd.DataFrame(bm,columns=['marker','matrix','proposed_role','into_patients?','evidence_in_our_data','sampling','what_must_be_shown_first'])

with pd.ExcelWriter(OUT_+'/AX-1177_audit_supporting_tables.xlsx',engine='openpyxl') as xw:
    readme=pd.DataFrame({'sheet':list(sheets.keys()),'contents':[
     'Per-contrast DE counts and how each contrast should be used',
     'Robust IL-33-regulated genes (q<0.01, |log2FC|>1, AveExpr>1, |t|>6; degenerate genes excluded): % of IL-33 response remaining with AX-1177 vs isotype',
     'Serum severity proteins that are IL-33-induced and AX-1177-reversed in HUVEC (PD candidates), with 6 h/24 h kinetics and HGMEC',
     'Serum results collapsed to protein level (Olink assay IDs mapped to gene symbols; 1,063 proteins)',
     'Serum results per delivered assay with mapped symbol',
     'Reconstruction of the 100 analysed-but-undelivered assays from the BH denominator (m=1,194)',
     'Genes whose delivered RNA-seq statistics are degenerate (uninterpretable)',
     'Post-mortem lung: donor-level table (forward-filled donor fields; block means; pathology-verified class)',
     'Post-mortem group comparisons (donor level) with effect sizes and bootstrap CIs',
     'Data-integrity findings, impact and remedy',
     'Biomarker proposals: role, whether they can go into patients, evidence, sampling, prerequisites']})
    readme.to_excel(xw,sheet_name='README',index=False)
    for k,df in sheets.items(): df.to_excel(xw,sheet_name=k[:31],index=False)
print('written', {k:len(v) for k,v in sheets.items()})
