import pandas as pd, numpy as np, openpyxl, re
pd.set_option('display.width', 300); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 300)
wb = openpyxl.load_workbook('/tmp/world/filesystem/AX-1177_postmortem_lung.xlsx')
ws = wb.active
rows = []
for r in ws.iter_rows(min_row=2, max_row=ws.max_row):
    rows.append([c.value for c in r])
hdr = [c.value for c in ws[1]]
raw = pd.DataFrame(rows, columns=[h if h else f'col{i}' for i,h in enumerate(hdr)])
cols = ['SampleID','Block','TissueRNA','SampleID2','Lobe','DiseaseCat','Race','Gender','Age','SARS','Pathology','HE_eos','EPX','EDN','MBP','C2D7','IL5Ra_dNE','NE_dIL5Ra','IL5Ra_dTrypt','Trypt_dIL5Ra','EPX_num','NE_num','Trypt_num','IL33_epi','IL33_endo','IL33_vsmc','Notes','extra']
raw.columns = cols
raw = raw[raw['Block'].notna()].copy()
print(raw.shape)
print('extra col values:', raw['extra'].dropna().unique())
# raw distinct values
for c in ['HE_eos','EPX','EDN','MBP','C2D7','IL5Ra_dNE','NE_dIL5Ra','IL5Ra_dTrypt','Trypt_dIL5Ra','EPX_num','NE_num','Trypt_num','IL33_epi','IL33_endo','IL33_vsmc']:
    print(c, sorted(map(repr, raw[c].unique())))
