import pandas as pd, numpy as np
df = pd.read_csv('/tmp/work/prot_annot.csv')
sig = df[df['adj.p.value']<0.05]
print('adj<0.05 rows:', len(sig), ' unique proteins:', sig['base'].nunique())
print('OR>1:', (sig.OR>1).sum(), ' OR<1:', (sig.OR<1).sum())
print(sig.groupby('panel').size().sort_values(ascending=False))
pd.set_option('display.width',250); pd.set_option('display.max_rows',300)
print(', '.join(f"{a}({o:.2f})" for a,o in zip(sig.assay, sig.OR)))
print()
print('Inverse (protective) associations, adj<0.1:')
print(df[(df['adj.p.value']<0.1)&(df.OR<1)][['assay','panel','OR','l95','u95','p.value','adj.p.value']].to_string())
