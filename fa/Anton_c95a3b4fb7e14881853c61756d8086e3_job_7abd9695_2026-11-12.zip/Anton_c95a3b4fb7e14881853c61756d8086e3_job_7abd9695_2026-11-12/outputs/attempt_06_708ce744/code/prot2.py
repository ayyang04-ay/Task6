import pandas as pd, numpy as np
from statsmodels.stats.multitest import multipletests
df = pd.read_csv('/tmp/work/prot_annot.csv')
# implied N for top rows: adj = p*N/rank (before monotone step)
df['impliedN_raw'] = df['adj.p.value']*df['rank']/df['p.value']
print(df[['assay','p.value','adj.p.value','rank','impliedN_raw']].head(15).to_string())
for N in [1094, 1104, 1150, 1160, 1170, 1178, 1196, 1200]:
    p = df['p.value'].values
    # BH with m=N (assume missing tests have p>max p)
    m=N; n=len(p)
    order = np.argsort(p); ranks = np.empty(n); ranks[order]=np.arange(1,n+1)
    q = p*m/ranks
    # monotone
    qs = q[order]; qs = np.minimum.accumulate(qs[::-1])[::-1]; qq = np.empty(n); qq[order]=np.minimum(qs,1)
    print(N, 'maxdiff', np.max(np.abs(qq-df['adj.p.value'].values)), 'n<0.05', (qq<0.05).sum())
