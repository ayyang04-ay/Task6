import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',100)
don = pd.read_pickle('/tmp/work/pm_donors.pkl')
# Manual classification from pathology text (read individually)
acute = {'2035':1,'2044':1,'2045':1,'2049':1,'2040':1,'2043':1,'2067':0,'2072':1,'2073':1,'2075':1,'2101':0,'2105':1,'2108':1,'2110':1,'2113':1,'2060':1,
         '1130':1,'1138':1,'1149':1,'1159':1,'1165':1,'1910':1,'1905':0,'1970':0,'1968':0,'1961':0,
         '1861':0,'1944':0,'1956':1,'1965':0,'1976':1}
dad = {k:0 for k in acute}; [dad.__setitem__(k,1) for k in ['2044','2049','2040','2043','2072','2108','2110']]
pe = {k:0 for k in acute}; [pe.__setitem__(k,1) for k in ['2035','2040','2113','2060']]
don['acute_pneu_path'] = don.index.map(acute).astype(bool)
don['DAD_ALI'] = don.index.map(dad).astype(bool)
don['thromboemb'] = don.index.map(pe).astype(bool)
print(pd.crosstab(don.group, don.acute_pneu_path), '\n', pd.crosstab(don.group, don.DAD_ALI), '\n', pd.crosstab(don.group, don.thromboemb))
print('Label/pathology discordant donors:', [k for k in don.index if (don.loc[k,'group']!='NonPneu_ctrl') != don.loc[k,'acute_pneu_path']])
print('Fisher PE COVID vs non-COVID:', round(stats.fisher_exact(pd.crosstab(don.group=='COVID_pneu', don.thromboemb))[1],3), ' DAD:', round(stats.fisher_exact(pd.crosstab(don.group=='COVID_pneu', don.DAD_ALI))[1],3))
rows=[]
for v,lab in [('IL33_epi_v','IL-33 basal epithelium'),('IL33_endo_v','IL-33 endothelium'),('IL33_vsmc_v','IL-33 VSMC'),('EPX_v','EPX'),('EDN_v','EDN'),('MBP_v','MBP'),('C2D7_v','2D7 basophil'),('IL5Ra_dNE_v','IL-5Ra (duplex NE)'),('NE_dIL5Ra_v','Neutrophil elastase'),('Trypt_dIL5Ra_v','Tryptase'),('HE_eos_v','H&E eos')]:
    a = don.loc[don.acute_pneu_path, v].dropna(); b = don.loc[~don.acute_pneu_path, v].dropna()
    e = don.loc[don.acute_pneu_path & (don.group=='COVID_pneu'), v].dropna(); f = don.loc[don.acute_pneu_path & (don.group!='COVID_pneu'), v].dropna()
    c = don.loc[don.DAD_ALI, v].dropna(); d = don.loc[~don.DAD_ALI, v].dropna()
    rows.append([lab, f'{a.median():.2f} (n={len(a)})', f'{b.median():.2f} (n={len(b)})', stats.mannwhitneyu(a,b).pvalue, f'{e.median():.2f} (n={len(e)})', f'{f.median():.2f} (n={len(f)})', stats.mannwhitneyu(e,f).pvalue, f'{c.median():.2f} vs {d.median():.2f}', stats.mannwhitneyu(c,d).pvalue])
res = pd.DataFrame(rows, columns=['marker','acute pneumonia (path-confirmed)','no acute pneumonia','p','COVID (confirmed pneu)','non-COVID (confirmed pneu)','p ','DAD/ALI vs not','p  '])
print(res.round(3).to_string())
res.to_csv('/tmp/work/pm_sensitivity.csv', index=False)
don.to_pickle('/tmp/work/pm_donors2.pkl')
