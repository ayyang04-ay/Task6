import pandas as pd, numpy as np
pd.set_option('display.width',250)
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
clean = pd.Index([g for g in W.index if g not in bad])
for tp in ['6','24']:
    il = W.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; ilq = Q.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']
    b = W.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; bq = Q.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    A = ann.AveExpr.loc[clean]
    de = ilq<0.05
    rev = de & (bq<0.05) & (np.sign(b)==-np.sign(il))
    print(f'{tp}h: IL33-vs-Veh DE={int(de.sum())}; reversed by C47 (isotype-controlled, q<0.05)={int(rev.sum())} ({100*rev.sum()/de.sum():.0f}%)')
    for lo,hi in [(-10,-2),(-2,0),(0,2),(2,5),(5,20)]:
        m = de & (A>lo) & (A<=hi)
        print(f'   AveExpr ({lo},{hi}]: DE {int(m.sum())} (up {int((m&(il>0)).sum())}, down {int((m&(il<0)).sum())}); reversed {int((m&rev).sum())} ({100*(m&rev).sum()/max(m.sum(),1):.0f}%); up reversed {100*(m&rev&(il>0)).sum()/max((m&(il>0)).sum(),1):.0f}%, down reversed {100*(m&rev&(il<0)).sum()/max((m&(il<0)).sum(),1):.0f}%')
