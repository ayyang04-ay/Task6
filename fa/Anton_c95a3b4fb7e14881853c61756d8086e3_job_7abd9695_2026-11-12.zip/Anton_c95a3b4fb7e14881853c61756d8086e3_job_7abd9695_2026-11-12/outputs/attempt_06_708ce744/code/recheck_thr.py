import pandas as pd, numpy as np
allc = pd.read_pickle('/tmp/work/all_contrasts.pkl')
allc['SE'] = np.abs(allc['logFC']/allc['t'])
for thr in [1.4,1.6,2.0,3.0]:
    b = allc[allc.SE>thr].groupby('ensembl').size()
    print(f'thr {thr}: genes with SE>thr in >=1 contrast: {len(b)}; in all 26: {(b==26).sum()}')
# distribution of per-gene max SE
mx = allc.groupby('ensembl')['SE'].max()
print(np.histogram(np.log10(mx), bins=[-2,-1,-0.5,0,0.1,0.15,0.2,0.25,0.3,0.4,0.5,1,2,5])[0])
# where do genes with max SE in (1.26, 3] come from?
mid = mx[(mx>1.3)&(mx<=3)]
ann = pd.read_pickle('/tmp/work/ann.pkl')
print(len(mid), ann.symbol.reindex(mid.index).head(60).tolist())
# for those, which contrasts exceed 1.6
sub = allc[allc.ensembl.isin(mid.index) & (allc.SE>1.6)]
print(sub.Comparison.value_counts().head(30))
