# AX-1177 audit: analysis code

All scripts read the delivered files from `/tmp/world/filesystem/` and write intermediates to `/tmp/work/`. They were run with `micromamba run -n singlecell python <script>`, except `md2pdf.py`, which uses the `core` env.

Run order:

1. **Load**
   - `load_rnaseq.py`: caches the RNA-seq workbooks as pickles.
2. **Post-mortem lung**
   - `pm_parse.py`: parses the workbook, including hidden columns and formula cells.
   - `pm_analysis.py`: builds the block-level and donor-level tables.
   - `pm_stats.py`: donor-level tests by delivered label.
   - `pm_qc.py`: marker agreement checks.
   - `pm_age.py`, `pm_copd.py`, `pm_partial.py`: covariate analyses (age, COPD/asthma, partial correlations).
   - `pm_sens2.py`: autopsy-based re-classification (manual).
   - `pm_rna.py`: archived tissue-RNA IDs.
3. **Serum proteomics**
   - `prot.py`: BH check and duplicate proteins.
   - `prot2.py`, `prot3.py`, `prot6.py`: infer the BH denominator (1,194) and reconstruct the withheld tests.
   - `prot4.py`: missing Inflammation-panel assays.
   - `prot5.py`, `prot7.py`: severity-associated and endothelial markers.
   - `map_olink.py`, `map_olink2.py`: map Olink assay names to genes.
4. **RNA-seq**
   - `rs1.py`, `rs2.py`: contrast inventory and comparison of the two sheets.
   - `rs3.py`: per-contrast QC (df, BH, signs, SE).
   - `rs4.py`, `rs5.py`, `rs19.py`, `recheck_thr.py`, `sens_thr.py`, `pcheck.py`: SE anomaly and threshold sensitivity.
   - `rs7.py`: IL-33 response.
   - `rs8.py`, `rs9.py`, `rs18.py`: antibody-alone effects, replication and null calibration.
   - `rs10.py`–`rs12.py`, `rs16.py`, `rs17.py`: blockade quantification.
   - `rs13.py`, `rs14.py`: key genes and the ISG tier.
   - `rs15.py`: HGMEC vs HUVEC.
5. **Integration**
   - `integ.py`: enrichment of the IL-33 program in the serum proteome.
   - `program_export.py`: the 454-gene program.
   - `biomarker_matrix.py`: biomarker matrix.
6. **Outputs**
   - `fig1.py`–`fig4.py`: figures.
   - `build_tables.py`: supporting workbook.
   - `md2pdf.py`: memo PDF.
