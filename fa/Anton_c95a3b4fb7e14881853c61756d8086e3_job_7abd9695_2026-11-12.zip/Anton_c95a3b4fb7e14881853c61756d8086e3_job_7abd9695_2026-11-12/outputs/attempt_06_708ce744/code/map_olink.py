import pandas as pd, numpy as np, re
prot = pd.read_csv('/tmp/work/prot_annot.csv')
ann = pd.read_pickle('/tmp/work/ann.pkl')
syms = set(ann.symbol.dropna())
alias = {'ST2':'IL1RL1','MCP-3':'CCL7','MCP-1':'CCL2','MCP-2':'CCL8','MCP-4':'CCL13','OPG':'TNFRSF11B','IL8':'CXCL8','U-PAR':'PLAUR','uPA':'PLAU','tPA':'PLAT','PAI':'SERPINE1','CASP-8':'CASP8','TRAIL-R2':'TNFRSF10B','TRAIL':'TNFSF10','IL-18R1':'IL18R1','IL-1RT2':'IL1R2','IL-1RT1':'IL1R1','vWF':'VWF','EN-RAGE':'S100A12','TWEAK':'TNFSF12','TRANCE':'TNFSF11','Flt3L':'FLT3LG','MMP-10':'MMP10','MMP-1':'MMP1','MMP-3':'MMP3','MMP-7':'MMP7','MMP-12':'MMP12','MMP-9':'MMP9','MMP-2':'MMP2','4E-BP1':'EIF4EBP1','CSF-1':'CSF1','LAP TGF-beta-1':'TGFB1','IL-10RA':'IL10RA','IL-10RB':'IL10RB','IL-12B':'IL12B','IL-15RA':'IL15RA','IL-17A':'IL17A','IL-17C':'IL17C','IL-20RA':'IL20RA','IL-4RA':'IL4R','IL-1ra':'IL1RN','IL-18BP':'IL18BP','IL-5R-alpha':'IL5RA','IL-6RA':'IL6R','IL-17RA':'IL17RA','IL-17D':'IL17D','IL2-RA':'IL2RA','IL-2RA':'IL2RA','TNF':'TNF','TNFB':'LTA','CCL11':'CCL11','SCF':'KITLG','GDF-15':'GDF15','NT-proBNP':'NPPB','BNP':'NPPB','KIM1':'HAVCR1','TIM':'HAVCR1','TIE2':'TEK','Gal-3':'LGALS3','gal-8':'LGALS8','Gal-9':'LGALS9','PGF':'PGF','VEGFA':'VEGFA','VEGFD':'VEGFD','VEGFR-2':'KDR','TNF-R1':'TNFRSF1A','TNF-R2':'TNFRSF1B','TNFRSF10A':'TNFRSF10A','TGF-alpha':'TGFA','HGF':'HGF','CD40-L':'CD40LG','CD40':'CD40','PD-L1':'CD274','PD-L2':'PDCD1LG2','SIRT2':'SIRT2','ST1A1':'SULT1A1','CST5':'CST5','LIF-R':'LIFR','ADA':'ADA','MIF':'MIF','OPN':'SPP1','Alpha-2-MRAP':'LRPAP1','ICAM 5':'ICAM5','ICAM-2':'ICAM2','ICAM-1':'ICAM1','VCAM1':'VCAM1','SELE':'SELE','SELP':'SELP','E-selectin':'SELE','P-selectin':'SELP','TF':'F3','TFPI':'TFPI','TM':'THBD','PECAM-1':'PECAM1','CTSL1':'CTSL','IgG Fc receptor II-b':'FCGR2B','FS':'FST','RAGE':'AGER','REN':'REN','AGRP':'AGRP','PAR-1':'F2R','PSGL-1':'SELPLG','DCN':'DCN','SPON2':'SPON2','THBS2':'THBS2','hOSCAR':'OSCAR','LOX-1':'OLR1','CD163':'CD163','TR-AP':'ACP5','SLAMF7':'SLAMF7','IL-27':'IL27','IL-16':'IL16','IL16':'IL16','CCL3':'CCL3','CCL4':'CCL4','CXCL1':'CXCL1','MCP-1':'CCL2','AREG':'AREG','FGF-21':'FGF21','FGF-23':'FGF23','FGF-19':'FGF19','FGF-5':'FGF5','Beta-NGF':'NGF','NT-3':'NTF3','IL-1 alpha':'IL1A','IFN-gamma':'IFNG','IL1B':'IL1B','IL6':'IL6','IL10':'IL10','IL18':'IL18','IL7':'IL7','IL12':'IL12A','IL15':'IL15','RNASE3':'RNASE3','SYND1':'SDC1','CXADR':'CXADR','ENG':'ENG','BOC':'BOC','DCBLD2':'DCBLD2','ENTPD6':'ENTPD6','GPNMB':'GPNMB','ZBTB16':'ZBTB16'}
def base(a):
    return re.sub(r'-(ONCII|CVDII|CVDIII|IMO|INFI|CRE|ODA|CAM|MET|NEX|NEUI)$','',a)
out=[]
for a in prot.assay:
    b = base(a)
    g = alias.get(b)
    if g is None:
        if b in syms: g=b
        else:
            c = b.replace('-','').replace(' ','').upper()
            g = c if c in syms else None
    out.append(g)
prot['gene']=out
print('mapped', prot.gene.notna().sum(), 'of', len(prot))
print('unmapped:', sorted(prot.loc[prot.gene.isna(),'assay'].tolist()))
prot.to_csv('/tmp/work/prot_mapped.csv', index=False)
