import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',400)
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
sym2e = {s:e for e,s in ann.symbol.dropna().items()}
isg = ['IFNB1','IFNL1','IFNL2','IFIT1','IFIT2','IFIT3','IFIT5','ISG15','ISG20','MX1','MX2','OAS1','OAS2','OAS3','OASL','RSAD2','IFI44','IFI44L','IFI6','IFI27','IFITM1','IFITM3','STAT1','STAT2','IRF1','IRF7','IRF9','GBP1','GBP2','GBP4','GBP5','CXCL10','CXCL11','CXCL9','IDO1','HERC5','DDX58','IFIH1','BST2','ZC3HAV1','TRIM22','PLSCR1','SAMD9L','EPSTI1','XAF1','USP18','CMPK2','HLA-A','HLA-B','B2M','TAP1','PSMB9']
rows=[]
for g in isg:
    e = sym2e.get(g)
    if e is None: continue
    rows.append([g, 'BAD' if e in bad else '', W.loc[e,'IL33_vs_Nontreated_HUVEC_6_hrs'], Q.loc[e,'IL33_vs_Nontreated_HUVEC_6_hrs'], W.loc[e,'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs'], W.loc[e,'IL33_vs_Nontreated_HUVEC_24_hrs'], Q.loc[e,'IL33_vs_Nontreated_HUVEC_24_hrs'], W.loc[e,'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs'], Q.loc[e,'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs']])
df = pd.DataFrame(rows, columns=['gene','flag','IL33_6h','q6','block_6h','IL33_24h','q24','block_24h','qb24'])
print(df.round(3).to_string())
sig24 = df[(df.q24<0.05)&(df.IL33_24h>0.5)]
print('ISGs induced at 24h (q<0.05, lfc>0.5):', len(sig24), 'of', len(df), '; median isotype-controlled inhibition at 24h:', round(100*np.median(-sig24.block_24h/sig24.IL33_24h)), '%')
# 24h escape genes
il = W['IL33_vs_Nontreated_HUVEC_24_hrs']; ilq = Q['IL33_vs_Nontreated_HUVEC_24_hrs']; b = W['Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs']; bq=Q['Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs']
sel = [g for g in W.index[(ilq<0.05)&(il>2)] if g not in bad]
d = pd.DataFrame({'sym':ann.symbol.loc[sel],'IL33':il.loc[sel],'block':b.loc[sel],'qb':bq.loc[sel],'A':ann.AveExpr.loc[sel]})
d['inh%'] = -100*d.block/d.IL33
print('24h IL-33-induced (lfc>2) genes with <30% inhibition and AveExpr>0 (escape candidates):')
print(d[(d['inh%']<30)&(d.A>0)].sort_values('IL33', ascending=False).round(2).to_string())
