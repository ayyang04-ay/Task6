import pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_columns',40); pd.set_option('display.max_colwidth',40)
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); SE = pd.read_pickle('/tmp/work/SE.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
P = pd.read_csv('/tmp/work/prot_mapped.csv')
sym2e = {}
for e,s in ann.symbol.dropna().items(): sym2e.setdefault(s,e)
cands = [('sST2','IL1RL1','ST2'),('IL-6','IL6','IL6'),('CCL20','CCL20','CCL20'),('OPG','TNFRSF11B','OPG-INFI'),('IL-18R1','IL18R1','IL-18R1'),('MCP-3/CCL7','CCL7','MCP-3'),('Tissue factor','F3','TF'),('GM-CSF','CSF2',None),('CXCL6','CXCL6','CXCL6'),('G-CSF','CSF3','G-CSF'),('Fractalkine','CX3CL1','CX3CL1'),('4-1BB','TNFRSF9','TNFRSF9'),('CXCL10','CXCL10','CXCL10'),('E-selectin','SELE','SELE'),('VCAM-1','VCAM1','VCAM1'),('ICAM-1','ICAM1','ICAM1'),('IL-8','CXCL8','IL8'),('PTX3','PTX3','PTX3'),('vWF','VWF','vWF'),('ANGPT2','ANGPT2','ANGPT2'),('Thrombomodulin','THBD','TM'),('PAI-1','SERPINE1','PAI'),('HGF','HGF','HGF'),('EDN (RNASE3)','RNASE3','RNASE3'),('IL-33','IL33',None),('IL-1beta','IL1B','IL1B'),('Amphiregulin','AREG','AREG-ONCII')]
rows=[]
for name,g,assay in cands:
    e = sym2e.get(g)
    r = {'marker':name,'gene':g}
    if e is not None:
        for tp in ['6','24']:
            c = f'IL33_vs_Nontreated_HUVEC_{tp}_hrs'; b = f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs'; h = f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp}hrs'
            valid = SE.loc[e,c] <= 1.6 and SE.loc[e,b] <= 1.6
            r[f'HUVEC_IL33_{tp}h_log2FC'] = round(W.loc[e,c],2); r[f'HUVEC_IL33_{tp}h_q'] = Q.loc[e,c] if valid else np.nan
            r[f'HUVEC_block_{tp}h_log2FC'] = round(W.loc[e,b],2); r[f'HUVEC_block_{tp}h_q'] = Q.loc[e,b] if valid else np.nan
            r[f'HGMEC_block_{tp}h_log2FC'] = round(W.loc[e,h],2); r[f'HGMEC_block_{tp}h_q'] = Q.loc[e,h] if SE.loc[e,h]<=1.6 else np.nan
            r[f'stats_valid_{tp}h'] = bool(valid)
    else:
        r['note_rnaseq']='not in RNA-seq gene set'
    if assay is not None:
        pr = P[P.assay==assay]
        if len(pr):
            pr = pr.iloc[0]; r.update({'serum_assay':assay,'serum_panel':pr.panel.replace('Olink Target 96 ',''),'serum_OR':round(pr.OR,2),'serum_95CI':f'{pr.l95:.2f}-{pr.u95:.2f}','serum_p':pr['p.value'],'serum_q':round(pr['adj.p.value'],4)})
    else:
        r['serum_assay'] = 'not in delivered serum data' + (' (withheld; Inflammation panel)' if g=='IL33' else ' (not on delivered panels)')
    rows.append(r)
M = pd.DataFrame(rows)
M.to_csv('/tmp/work/biomarker_matrix.csv', index=False)
show = ['marker','HUVEC_IL33_6h_log2FC','HUVEC_IL33_6h_q','HUVEC_block_6h_log2FC','HUVEC_IL33_24h_log2FC','HUVEC_block_24h_log2FC','HGMEC_block_6h_log2FC','stats_valid_6h','serum_OR','serum_95CI','serum_q']
print(M[show].to_string())
