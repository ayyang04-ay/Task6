import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 300)
don = pd.read_pickle('/tmp/work/pm_donors.pkl')
blk = pd.read_pickle('/tmp/work/pm_blocks.pkl')
vals = {'HE_eos_v':'H&E eos apparent (frac blocks)','EPX_v':'EPX IHC','EDN_v':'EDN IHC','MBP_v':'MBP IHC','C2D7_v':'2D7 (basophil) IHC','IL5Ra_dNE_v':'IL-5Ra (duplex NE)','NE_dIL5Ra_v':'Neutrophil elastase','IL5Ra_dTrypt_v':'IL-5Ra (duplex tryptase)','Trypt_dIL5Ra_v':'Tryptase (mast)','IL33_epi_v':'IL-33 basal epithelium','IL33_endo_v':'IL-33 endothelium','IL33_vsmc_v':'IL-33 vasc smooth muscle'}
G = ['COVID_pneu','NonCOVID_pneu','NonPneu_ctrl']
rows=[]
for v,lab in vals.items():
    d = {g: don.loc[don.group==g, v].dropna().values for g in G}
    kw = stats.kruskal(*[d[g] for g in G])
    mw1 = stats.mannwhitneyu(d['COVID_pneu'], d['NonCOVID_pneu'], alternative='two-sided')
    mw2 = stats.mannwhitneyu(d['COVID_pneu'], d['NonPneu_ctrl'], alternative='two-sided')
    mw3 = stats.mannwhitneyu(d['NonCOVID_pneu'], d['NonPneu_ctrl'], alternative='two-sided')
    pn = np.r_[d['COVID_pneu'], d['NonCOVID_pneu']]
    mw4 = stats.mannwhitneyu(pn, d['NonPneu_ctrl'], alternative='two-sided')
    # block-level (pseudo-replicated) for comparison
    b = {g: blk.loc[blk.group==g, v].dropna().values for g in G}
    mwb = stats.mannwhitneyu(b['COVID_pneu'], b['NonCOVID_pneu'], alternative='two-sided')
    rows.append([lab] + [f"{np.median(d[g]):.2f} [{np.percentile(d[g],25):.2f}-{np.percentile(d[g],75):.2f}] n={len(d[g])}" for g in G] + [kw.pvalue, mw1.pvalue, mw2.pvalue, mw3.pvalue, mw4.pvalue, mwb.pvalue])
res = pd.DataFrame(rows, columns=['marker']+[f'{g} median[IQR]' for g in G]+['KW_p','COVIDvsNonCOVIDpneu_p','COVIDvsCtrl_p','NonCOVIDpneu_vs_Ctrl_p','AnyPneu_vs_Ctrl_p','BLOCKLEVEL_COVIDvsNonCOVID_p'])
print(res.to_string())
res.to_csv('/tmp/work/pm_donor_stats.csv', index=False)
# ceiling effect
print()
for v in ['IL33_endo_v','IL33_epi_v','IL33_vsmc_v']:
    print(v, 'block-level fraction at ceiling 5.5:', (blk[v]==5.5).mean().round(2), ' by group:', blk.groupby('group')[v].apply(lambda s:(s==5.5).mean()).round(2).to_dict())
