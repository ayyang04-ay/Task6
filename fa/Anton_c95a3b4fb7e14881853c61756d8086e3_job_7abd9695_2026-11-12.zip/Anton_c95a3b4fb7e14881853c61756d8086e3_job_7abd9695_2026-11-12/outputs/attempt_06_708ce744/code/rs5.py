import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',400); pd.set_option('display.max_columns',40)
allc = pd.read_pickle('/tmp/work/all_contrasts.pkl')
allc['SE'] = np.abs(allc['logFC']/allc['t'])
# histogram of log10 SE pooled
lse = np.log10(allc['SE'])
hist, edges = np.histogram(lse, bins=np.arange(-2, 4.6, 0.2))
for h,e in zip(hist, edges): print(f'{e:5.1f} {h}')
# per gene: number of contrasts with SE > 3
allc['bad'] = allc['SE']>3
pg = allc.groupby('ensembl').agg(nbad=('bad','sum'), sym=('symbol','first'), ave=('AveExpr','first'))
print(pg['nbad'].value_counts().sort_index())
print(pg[pg.nbad>0].sort_values('nbad', ascending=False).head(80).to_string())
pg.to_pickle('/tmp/work/gene_badSE.pkl')
