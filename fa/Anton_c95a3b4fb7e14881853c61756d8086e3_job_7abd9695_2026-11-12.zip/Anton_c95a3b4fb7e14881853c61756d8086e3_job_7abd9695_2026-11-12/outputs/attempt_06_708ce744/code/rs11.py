import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',400); pd.set_option('display.max_columns',40)
W = pd.read_pickle('/tmp/work/W.pkl'); T = pd.read_pickle('/tmp/work/T.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
clean = pd.Index([g for g in W.index if g not in bad])
out = {}
for tp in ['6','24']:
    il = W[f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; ilq = Q[f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']
    blk = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; blk2 = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']
    resid = il + blk2   # C47IL33 - Veh (exact linear combination)
    for thr in [1,2,3]:
        for dirn in ['up','down']:
            sel = clean[(ilq.loc[clean]<0.05) & ((il.loc[clean]>thr) if dirn=='up' else (il.loc[clean]<-thr))]
            if len(sel)<3: continue
            frac_block = (-blk2.loc[sel]/il.loc[sel])
            slope = np.polyfit(il.loc[sel], blk.loc[sel], 1)[0]
            print(f'HUVEC {tp}h IL33-{dirn} |logFC|>{thr} n={len(sel):4d}: median %inhibition (vs IL33 alone) = {100*frac_block.median():.0f}% [IQR {100*frac_block.quantile(.25):.0f}-{100*frac_block.quantile(.75):.0f}], slope(blockade vs IL33 effect, isotype-controlled)={slope:.2f}; median residual C47+IL33 vs vehicle = {resid.loc[sel].median():.2f}')
    # genome-wide
    sel = clean[ilq.loc[clean]<0.05]
    r = np.corrcoef(il.loc[sel], blk.loc[sel])[0,1]
    print(f'HUVEC {tp}h all IL33-DE clean genes n={len(sel)}: r(IL33 effect, C47 blockade)={r:.3f}')
    # Opposite-direction check on all genes
# HGMEC: use HUVEC IL-33 response genes as reference
for tp in ['6','24']:
    il = W[f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; ilq = Q[f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']
    sel = clean[(ilq.loc[clean]<0.05)&(il.loc[clean].abs()>1)]
    for cl in ['HGMEC']:
        b = W[f'Compound_47_IL33_vs_IL33_IC119_{cl}_{tp}hrs']
        print(f'{cl} {tp}h: r(HUVEC IL33 effect, HGMEC C47 blockade) over HUVEC IL33 genes n={len(sel)}: {np.corrcoef(il.loc[sel], b.loc[sel])[0,1]:.3f}; slope={np.polyfit(il.loc[sel], b.loc[sel],1)[0]:.2f}')
