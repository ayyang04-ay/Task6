import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',300)
W = pd.read_pickle('/tmp/work/W.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl'); SE = pd.read_pickle('/tmp/work/SE.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl')
bad = pg[pg.nbad>0].copy()
bad['IL33_6h'] = W.loc[bad.index,'IL33_vs_Nontreated_HUVEC_6_hrs']; bad['block_6h'] = W.loc[bad.index,'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs']
bad['IL33_24h'] = W.loc[bad.index,'IL33_vs_Nontreated_HUVEC_24_hrs']; bad['block_24h'] = W.loc[bad.index,'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs']
bad['SE_IL33_6h'] = SE.loc[bad.index,'IL33_vs_Nontreated_HUVEC_6_hrs']
x = bad[(bad.IL33_6h.abs()>1)|(bad.IL33_24h.abs()>1)].sort_values('IL33_6h', ascending=False)
print(len(bad), 'bad genes;', len(x), 'with |IL-33 logFC|>1 at 6h or 24h')
print(x[['sym','nbad','ave','IL33_6h','block_6h','IL33_24h','block_24h','SE_IL33_6h']].round(2).to_string())
bad.to_csv('/tmp/work/bad_genes.csv')
