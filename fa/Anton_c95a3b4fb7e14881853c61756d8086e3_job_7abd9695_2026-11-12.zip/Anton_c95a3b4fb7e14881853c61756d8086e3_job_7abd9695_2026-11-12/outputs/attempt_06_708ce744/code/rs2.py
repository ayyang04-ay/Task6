import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',300); pd.set_option('display.max_columns',30)
a = pd.read_pickle('/tmp/work/contrasts_6h.pkl'); b = pd.read_pickle('/tmp/work/contrasts_24h.pkl')
num = ['logFC','AveExpr','t','P.Value','adj.P.Val','B']
rows=[]
for c in a['Comparison'].unique():
    x = a[a.Comparison==c].set_index('ensembl'); y = b[b.Comparison==c].set_index('ensembl')
    dupx = x.index.duplicated().sum(); dupy = y.index.duplicated().sum()
    common = x.index.intersection(y.index)
    x2 = x.loc[common]; y2 = y.loc[common]
    r = {'contrast':c, 'n6':len(x), 'n24':len(y), 'dup6':dupx, 'dup24':dupy, 'common':len(common)}
    for col in num:
        d = np.abs(x2[col].values - y2[col].values)
        r['maxdiff_'+col] = np.nanmax(d)
        r['nDiff_'+col] = int((d>1e-9).sum())
    r['sym_mismatch'] = int((x2['symbol'].fillna('')!=y2['symbol'].fillna('')).sum())
    rows.append(r)
res = pd.DataFrame(rows)
print(res.to_string())
