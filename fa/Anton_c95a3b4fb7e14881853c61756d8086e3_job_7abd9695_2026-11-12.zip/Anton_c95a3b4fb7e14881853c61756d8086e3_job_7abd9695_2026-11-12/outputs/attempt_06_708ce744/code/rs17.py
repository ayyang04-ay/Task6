import pandas as pd, numpy as np
pd.set_option('display.width',250)
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
clean = pd.Index([g for g in W.index if g not in bad])
il = W.loc[clean,'IL33_vs_Nontreated_HUVEC_24_hrs']; ilq = Q.loc[clean,'IL33_vs_Nontreated_HUVEC_24_hrs']
b = W.loc[clean,'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs']; bq = Q.loc[clean,'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs']
A = ann.AveExpr.loc[clean]; s = ann.symbol.loc[clean]
il6 = W.loc[clean,'IL33_vs_Nontreated_HUVEC_6_hrs']
m = (ilq<0.05)&(il>0.7)&(A>3)&~((bq<0.05)&(b<0))
d = pd.DataFrame({'sym':s[m],'IL33_24h':il[m],'block_24h':b[m],'qb':bq[m],'IL33_6h':il6[m],'A':A[m]}).sort_values('IL33_24h', ascending=False)
d['inh%']=-100*d.block_24h/d.IL33_24h
print(len(d)); print(d.head(60).round(2).to_string())
print('median inhibition among these:', d['inh%'].median())
