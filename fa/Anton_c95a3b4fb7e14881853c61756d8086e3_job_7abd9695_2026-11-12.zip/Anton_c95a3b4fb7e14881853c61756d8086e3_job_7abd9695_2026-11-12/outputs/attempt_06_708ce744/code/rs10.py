import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',400); pd.set_option('display.max_columns',40)
W = pd.read_pickle('/tmp/work/W.pkl'); T = pd.read_pickle('/tmp/work/T.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
clean = [g for g in W.index if g not in bad]
def s(x): return x
for cl in ['HUVEC','HGMEC']:
    for tp in ['6','24']:
        a = W[f'Compound_47_IL33_vs_IL33_{cl}_{tp}hrs']; b = W[f'Compound_47_IL33_vs_IL33_IC119_{cl}_{tp}hrs']
        iso = a - b   # = IL33IC119 - IL33
        print(f'{cl} {tp}h: derived isotype effect (IL33+IC119 minus IL33 alone): SD={iso.loc[clean].std():.3f}, |d|>1: {(iso.loc[clean].abs()>1).sum()}, r(a,b)={np.corrcoef(a.loc[clean],b.loc[clean])[0,1]:.3f}')
        # compare with antibody-alone noise SD
        c = W[f'Compound_47_vs_IC119_{cl}_{tp}hrs']
        print(f'      SD of C47 vs IC119 (no IL-33) = {c.loc[clean].std():.3f}; SD of blocking contrast = {b.loc[clean].std():.3f}')
