import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250)
don = pd.read_pickle('/tmp/work/pm_donors.pkl')
don['Notes']=don['Notes'].fillna('')
blk = pd.read_pickle('/tmp/work/pm_blocks.pkl')
# Also capture pathology-text emphysema/COPD mentions
path = blk.groupby('SampleID')['Pathology'].first().fillna('')
don['emphysema_path'] = path.reindex(don.index).str.contains('mphysem', case=False)
don['COPD'] = don.Notes.str.contains('COPD') 
don['COPD_or_emph'] = don['COPD'] | don['emphysema_path']
don['Asthma'] = don.Notes.str.contains('Asthma')
don['Fibrosis'] = don.Notes.str.contains('Fibrosis') | path.reindex(don.index).str.contains('fibrosis', case=False)
print(pd.crosstab(don.group, don.COPD), '\n', pd.crosstab(don.group, don.Asthma), '\n', pd.crosstab(don.group, don.COPD_or_emph))
for flag in ['COPD','COPD_or_emph','Asthma']:
    print('=====', flag)
    for v in ['IL33_epi_v','IL33_endo_v','IL33_vsmc_v','EPX_v','EDN_v','MBP_v','NE_dIL5Ra_v','Trypt_dIL5Ra_v']:
        a = don.loc[don[flag], v].dropna(); b = don.loc[~don[flag], v].dropna()
        p = stats.mannwhitneyu(a,b).pvalue
        d = don[[v,flag,'group']].dropna().copy(); d['r']=d[v].rank(); d['f']=d[flag].astype(int)
        m = smf.ols('r ~ f + C(group)', data=d).fit()
        print(f'  {v}: {flag}+ median {a.median():.2f} (n={len(a)}) vs - {b.median():.2f} (n={len(b)}); MW p={p:.3f}; group-adjusted rank p={m.pvalues["f"]:.3f}')
