import pandas as pd, numpy as np
from scipy import stats
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); SE = pd.read_pickle('/tmp/work/SE.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
P = pd.read_csv('/tmp/work/prot_mapped.csv')
for thr in [3.0, 1.6]:
    bad = set(SE.index[(SE>thr).any(axis=1)])
    clean = pd.Index([g for g in W.index if g not in bad])
    out = [f'thr={thr}: excluded {len(bad)}']
    for tp in ['6','24']:
        il = W.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; ilq = Q.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']
        b = W.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; bq = Q.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
        de = ilq<0.05; up = de&(il>1); rev = de&(bq<0.05)&(np.sign(b)==-np.sign(il))
        out.append(f'{tp}h: DE {int(de.sum())}, induced {int(up.sum())}, median inh {100*(-b[up]/il[up]).median():.0f}%, reversed {100*rev.sum()/de.sum():.0f}%')
    # program + enrichment
    prog=set()
    for tp in ['6','24']:
        il = W.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; ilq = Q.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']
        b = W.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; bq = Q.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
        prog |= set(clean[(ilq<0.05)&(il>1)&(bq<0.05)&(b<-1)])
    syms = set(ann.symbol.loc[list(prog)].dropna())
    Pp = P[P.in_rnaseq].sort_values('p.value').drop_duplicates('gene').copy()
    Pp['prog']=Pp.gene.isin(syms); Pp['sev']=(Pp['adj.p.value']<0.05)&(Pp.OR>1)
    a=(Pp.prog&Pp.sev).sum(); b_=(Pp.prog&~Pp.sev).sum(); c=(~Pp.prog&Pp.sev).sum(); d=(~Pp.prog&~Pp.sev).sum()
    out.append(f'program {len(prog)} genes; serum: {a}/{a+b_} vs {c}/{c+d}, Fisher p={stats.fisher_exact([[a,b_],[c,d]])[1]:.2f}')
    # HGMEC concordance
    hu = W.loc[clean,'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs']; hg = W.loc[clean,'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs']
    both = (Q.loc[clean,'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs']<0.05)&(Q.loc[clean,'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs']<0.05)
    out.append(f'HGMEC both-sig {int(both.sum())}, r={np.corrcoef(hu[both],hg[both])[0,1]:.2f}, slope={np.polyfit(hu[both],hg[both],1)[0]:.2f}')
    print(' | '.join(out))
