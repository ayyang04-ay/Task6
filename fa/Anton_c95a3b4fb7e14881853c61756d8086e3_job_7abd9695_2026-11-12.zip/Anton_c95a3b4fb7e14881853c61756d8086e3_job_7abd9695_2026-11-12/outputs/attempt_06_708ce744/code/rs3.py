import pandas as pd, numpy as np
from scipy import stats, optimize
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250); pd.set_option('display.max_rows',300); pd.set_option('display.max_columns',30)
a = pd.read_pickle('/tmp/work/contrasts_6h.pkl')
h6 = pd.read_pickle('/tmp/work/huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl'); h24 = pd.read_pickle('/tmp/work/huvec_IL33_vs_Vehicle_HUVEC_24_hrs.pkl')
allc = pd.concat([a, h6, h24], ignore_index=True)
allc.to_pickle('/tmp/work/all_contrasts.pkl')
# AveExpr consistency per gene
ae = allc.groupby('ensembl')['AveExpr'].agg(['min','max','count'])
ae['range']=ae['max']-ae['min']
print('AveExpr per-gene range across all 26 contrasts: max', ae['range'].max(), ' n genes with range>1e-6:', (ae['range']>1e-6).sum(), ' counts per gene:', ae['count'].unique())
rows=[]
for c, d in allc.groupby('Comparison', sort=False):
    t = d['t'].values; p = d['P.Value'].values
    # estimate df by least squares on log p for moderate t
    m = (np.abs(t)>0.5)&(np.abs(t)<8)
    def f(df): return np.nanmedian(np.abs(np.log(2*stats.t.sf(np.abs(t[m]),df)) - np.log(p[m])))
    res = optimize.minimize_scalar(f, bounds=(2,5000), method='bounded')
    dfh = res.x
    ppred = 2*stats.t.sf(np.abs(t), dfh)
    relerr = np.abs(np.log10(ppred) - np.log10(p))
    bh = multipletests(p, method='fdr_bh')[1]
    signmis = int(((np.sign(d['logFC'])!=np.sign(d['t'])) & (d['t'].abs()>1e-8)).sum())
    se = np.abs(d['logFC']/d['t'])
    rows.append({'contrast':c, 'n':len(d), 'df_hat':round(dfh,1), 'n_p_inconsistent(>0.1 log10)':int((relerr>0.1).sum()), 'maxBHdiff':np.max(np.abs(bh-d['adj.P.Val'])), 'n_sign_mismatch':signmis,
                 'SE_median':round(np.median(se),3), 'SE_99.9pct':round(np.percentile(se,99.9),2), 'SE_max':round(se.max(),1), 'n_SE>5':int((se>5).sum()),
                 'n_adj<0.05':int((d['adj.P.Val']<0.05).sum()), 'n_adj<0.05_up':int(((d['adj.P.Val']<0.05)&(d.logFC>0)).sum()), 'n_adj<0.05_dn':int(((d['adj.P.Val']<0.05)&(d.logFC<0)).sum())})
res = pd.DataFrame(rows)
print(res.to_string())
res.to_csv('/tmp/work/contrast_qc.csv', index=False)
