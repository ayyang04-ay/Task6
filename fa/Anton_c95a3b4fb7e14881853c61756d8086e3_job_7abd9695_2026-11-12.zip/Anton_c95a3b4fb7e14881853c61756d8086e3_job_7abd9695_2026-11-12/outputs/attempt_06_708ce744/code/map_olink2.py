import pandas as pd, numpy as np, re
prot = pd.read_csv('/tmp/work/prot_mapped.csv')
ann = pd.read_pickle('/tmp/work/ann.pkl')
syms = set(ann.symbol.dropna())
extra = {'G-CSF':'CSF3','HO-1':'HMOX1','t-PA':'PLAT','CYR61':'CCN1','JAM-A':'F11R','JAM-B':'JAM2','Gal-1':'LGALS1','Gal-4':'LGALS4','HSP 27':'HSPB1','MK':'MDK','NEMO':'IKBKG','VEGFR-3':'FLT4','Ep-CAM':'EPCAM','LDL receptor':'LDLR','PDGF subunit B':'PDGFB','PDGF subunit A':'PDGFA','CD97':'ADGRE5','TR':'TFRC','NOV':'CCN3','WISP-1':'CCN4',"5'-NT":'NT5E','AP-N':'ANPEP','BLM hydrolase':'BLMH','GM-CSF-R-alpha':'CSF2RA','IFN-gamma-R1':'IFNGR1','Dkk-4':'DKK4','GDF-2':'GDF2','GDF-8':'MSTN','FR-alpha':'FOLR1','FR-gamma':'FOLR3','SHPS-1':'SIRPA','CLM-1':'CD300LF','CLM-6':'CD300C','HAOX1':'HAO1','LAIR-2':'LAIR2','MAD homolog 5':'SMAD5','MIC-A/B':'MICA','N-CDase':'ASAH2','N2DL-2':'ULBP2','NEP':'MME','Nr-CAM':'NRCAM','PDGF-R-alpha':'PDGFRA','PIgR':'PIGR','PLC':'PLCG1','PSP-D':'SFTPD','SKR3':'ACVRL1','TGFR-2':'TGFBR2','TLT-2':'TREML2','hK11':'KLK11','hK14':'KLK14','hK8':'KLK8','sFRP-3':'FRZB','WIF-1':'WIF1','CXL17':'CXCL17','FcRL2':'FCRL2','FUT3/FUT5':'FUT3','GCP5':'TUBGCP5','GT':'B4GALT1','GFR-alpha-1':'GFRA1','GDNFR-alpha-3':'GFRA3','TR-AP':'ACP5','IL5-IMO':'IL5'}
for i,r in prot.iterrows():
    if pd.isna(r.gene):
        b = re.sub(r'-(ONCII|CVDII|CVDIII|IMO|INFI|CRE|ODA|CAM|MET|NEX|NEUI)$','',r.assay)
        g = extra.get(b, extra.get(r.assay, b))
        prot.at[i,'gene'] = g
prot['in_rnaseq'] = prot.gene.isin(syms)
print('in RNA-seq gene list:', prot.in_rnaseq.sum(), 'of', len(prot))
print('not in RNA-seq (filtered/low):', sorted(prot.loc[~prot.in_rnaseq,'gene'].tolist())[:400])
prot.to_csv('/tmp/work/prot_mapped.csv', index=False)
