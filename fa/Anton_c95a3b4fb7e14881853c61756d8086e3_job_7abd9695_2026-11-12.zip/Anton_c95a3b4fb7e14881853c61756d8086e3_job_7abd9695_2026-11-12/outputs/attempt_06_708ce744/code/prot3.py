import pandas as pd, numpy as np
df = pd.read_csv('/tmp/work/prot_annot.csv')
m=1194
p=df['p.value'].values; adj=df['adj.p.value'].values
rt = p*m/adj
df['r_true_implied']=rt
df['missing_below']=rt-df['rank']
# Identify rows where adj not determined by step-down: adj_i < adj_{i+1}? Actually BH step-down means adj_i = min_{j>=i}(p_j m / r_j). Rows where adj changes vs next row are 'own' values.
own = np.r_[adj[:-1] < adj[1:], True]
sub = df[own]
pd.set_option('display.width',200); pd.set_option('display.max_rows',400)
print(sub[['assay','p.value','adj.p.value','rank','r_true_implied','missing_below']].iloc[::10].to_string())
print(sub[['assay','p.value','adj.p.value','rank','r_true_implied','missing_below']].tail(15).to_string())
