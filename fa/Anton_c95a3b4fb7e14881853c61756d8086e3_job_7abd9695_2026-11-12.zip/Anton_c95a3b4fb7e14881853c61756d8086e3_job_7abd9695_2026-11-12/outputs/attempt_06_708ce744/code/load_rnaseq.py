import pandas as pd, numpy as np, time
t0=time.time()
x = pd.read_excel('/tmp/world/filesystem/AX-1177_rnaseq_contrasts.xlsx', sheet_name=None, engine='openpyxl')
print('read', time.time()-t0)
for k,d in x.items():
    print(k, d.shape, d.columns.tolist())
    d.to_pickle(f'/tmp/work/contrasts_{k}.pkl')
h = pd.read_excel('/tmp/world/filesystem/AX-1177_rnaseq_huvec_il33.xlsx', sheet_name=None, engine='openpyxl')
for k,d in h.items():
    d.to_pickle(f'/tmp/work/huvec_{k}.pkl')
print('done', time.time()-t0)
