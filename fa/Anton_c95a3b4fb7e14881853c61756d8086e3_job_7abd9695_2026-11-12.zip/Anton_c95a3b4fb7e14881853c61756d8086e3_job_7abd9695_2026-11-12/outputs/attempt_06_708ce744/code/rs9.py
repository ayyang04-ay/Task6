import pandas as pd, numpy as np, itertools
pd.set_option('display.width',250); pd.set_option('display.max_rows',400); pd.set_option('display.max_columns',40)
W = pd.read_pickle('/tmp/work/W.pkl'); T = pd.read_pickle('/tmp/work/T.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
cs = [c for c in W.columns if c.startswith('Compound_47_vs_')]
sets = {c: set(Q.index[Q[c]<0.05]) for c in cs}
short = lambda s: s.replace('Compound_47','C47').replace('_vs_','/').replace('hrs','h')
M = pd.DataFrame([[len(sets[a]&sets[b]) for b in cs] for a in cs], index=[short(c) for c in cs], columns=[short(c) for c in cs])
print(M.to_string())
# genes DE in >=3 antibody-alone contrasts
from collections import Counter
cnt = Counter(g for c in cs for g in sets[c])
rec = [(g, n) for g,n in cnt.items() if n>=3]
print('genes DE in >=3 of', len(cs), 'antibody-alone contrasts:', len(rec))
for g,n in sorted(rec, key=lambda x:-x[1]):
    print(ann.loc[g,'symbol'], n, [short(c) for c in cs if g in sets[c]], ' logFCs:', [round(W.loc[g,c],2) for c in cs if g in sets[c]])
# correlation of logFC between C47 vs IC119 and C47 vs DMSO / PBS within cell line (should be high because shared C47 group)
for cl in ['A549','MCF7']:
    for tp in ['6hrs','24hrs']:
        a,b,c = f'Compound_47_vs_IC119_{cl}_{tp}', f'Compound_47_vs_DMSO_{cl}_{tp}', f'Compound_47_vs_PBS_{cl}_{tp}'
        print(cl,tp,'r(IC119,DMSO)=%.2f r(IC119,PBS)=%.2f r(DMSO,PBS)=%.2f' % (np.corrcoef(W[a],W[b])[0,1], np.corrcoef(W[a],W[c])[0,1], np.corrcoef(W[b],W[c])[0,1]))
