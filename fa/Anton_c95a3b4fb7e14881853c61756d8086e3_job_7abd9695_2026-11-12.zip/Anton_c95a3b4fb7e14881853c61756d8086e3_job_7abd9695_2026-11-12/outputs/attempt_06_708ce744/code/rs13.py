import pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_rows',400); pd.set_option('display.max_columns',40)
W = pd.read_pickle('/tmp/work/W.pkl'); T = pd.read_pickle('/tmp/work/T.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
sym2e = {}
for e,s in ann.symbol.items():
    if isinstance(s,str) and s not in sym2e: sym2e[s]=e
genes = ['CSF2','CXCL6','CCL20','CX3CL1','CSF3','CXCL3','TNF','TNFRSF9','CXCL10','CXCL2','CXCL1','CXCL8','CXCL5','IL6','IL1A','IL1B','ICAM1','VCAM1','SELE','F3','TNFRSF11B','C3','CFB','SOD2','EBI3','LTB','CCL5','CCL2','PTX3','IL1RL1','IL1RAP','IL33','MMP10','ACKR1','GBP5','MX2','TRAF1','BIRC3','NFKBIA','TNFAIP3','KDR','ANGPT2','THBD','VWF','SERPINE1','EDN1','NOS3','KLF2','KLF4','ESM1','SELP','PLAT','HGF','IL18R1','IL1R1']
rows=[]
for g in genes:
    e = sym2e.get(g)
    if e is None: rows.append([g]+[None]*10); continue
    r=[g, 'BAD' if e in bad else '']
    for tp in ['6','24']:
        r += [W.loc[e,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs'], Q.loc[e,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs'], W.loc[e,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs'], Q.loc[e,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs'], W.loc[e,f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp}hrs'], Q.loc[e,f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp}hrs']]
    rows.append(r)
cols = ['gene','flag']+[f'{x}_{tp}' for tp in ['6h','24h'] for x in ['HUVEC_IL33','q','HUVEC_block','q','HGMEC_block','q']]
df = pd.DataFrame(rows, columns=cols)
fmt = df.copy()
for i,c in enumerate(cols[2:]):
    if c=='q': pass
print(df.round(3).to_string())
