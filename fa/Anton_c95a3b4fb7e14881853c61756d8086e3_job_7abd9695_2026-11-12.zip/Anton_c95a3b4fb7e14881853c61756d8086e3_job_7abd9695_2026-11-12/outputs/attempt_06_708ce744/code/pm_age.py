import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
don = pd.read_pickle('/tmp/work/pm_donors.pkl')
don['Age']=don['Age'].astype(float)
print(don.groupby('group')['Age'].describe())
print(don.groupby('group')['Gender'].value_counts().unstack())
print('KW age', stats.kruskal(*[g['Age'].values for _,g in don.groupby('group')]))
don['covid'] = (don.group=='COVID_pneu').astype(int)
don['ctrl'] = (don.group=='NonPneu_ctrl').astype(int)
for v in ['IL33_epi_v','IL33_endo_v','IL33_vsmc_v','EDN_v','MBP_v','EPX_v','NE_dIL5Ra_v']:
    d = don[[v,'Age','group']].dropna().copy()
    # rank-based ANCOVA: rank-transform outcome
    d['r'] = d[v].rank()
    m = smf.ols('r ~ C(group, Treatment("NonCOVID_pneu")) + Age', data=d).fit()
    m0 = smf.ols('r ~ C(group, Treatment("NonCOVID_pneu"))', data=d).fit()
    print(v, '| COVID vs nonCOVID pneu coef (ranks) unadj p=%.3f, age-adj p=%.3f; ctrl vs nonCOVID age-adj p=%.3f; age p=%.3f' % (m0.pvalues.iloc[1], m.pvalues.iloc[1], m.pvalues.iloc[2], m.pvalues['Age']))
