import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',400); pd.set_option('display.max_columns',40)
W = pd.read_pickle('/tmp/work/W.pkl'); T = pd.read_pickle('/tmp/work/T.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
for c in ['Compound_47_vs_IC119_HUVEC_6hrs','Compound_47_vs_IC119_HUVEC_24hrs','Compound_47_vs_IC119_HGMEC_6hrs','Compound_47_vs_IC119_HGMEC_24hrs']:
    d = pd.DataFrame({'symbol':ann.symbol,'AveExpr':ann.AveExpr,'logFC':W[c],'t':T[c],'adj':Q[c]})
    s = d[d.adj<0.05].sort_values('logFC')
    print('=====', c, 'n DE', len(s), ' AveExpr median of DE genes', round(s.AveExpr.median(),2), ' vs all genes', round(d.AveExpr.median(),2))
    print(', '.join(f"{a}({l:+.1f},A={e:.1f})" for a,l,e in s[['symbol','logFC','AveExpr']].values))
