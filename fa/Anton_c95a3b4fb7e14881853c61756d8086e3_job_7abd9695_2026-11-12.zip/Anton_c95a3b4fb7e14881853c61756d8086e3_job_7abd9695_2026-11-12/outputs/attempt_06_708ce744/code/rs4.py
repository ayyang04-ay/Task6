import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',300); pd.set_option('display.max_columns',30)
allc = pd.read_pickle('/tmp/work/all_contrasts.pkl')
allc['SE'] = np.abs(allc['logFC']/allc['t'])
c = 'IL33_vs_Nontreated_HUVEC_6_hrs'
d = allc[allc.Comparison==c].copy()
print(d.sort_values('SE', ascending=False).head(40)[['symbol','ensembl','logFC','AveExpr','t','P.Value','adj.P.Val','SE']].to_string())
print()
print(d['SE'].describe(percentiles=[.5,.9,.99,.995,.999]))
# relation between SE and AveExpr
bins = pd.cut(d['AveExpr'], [-10,-4,-3,-2,-1,0,1,2,4,6,8,20])
print(d.groupby(bins)['SE'].describe(percentiles=[.5,.99]))
