import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',300)
for k in ['6h','24h']:
    d = pd.read_pickle(f'/tmp/work/contrasts_{k}.pkl')
    print('=====', k, d.shape, 'all-NaN rows:', d.isna().all(axis=1).sum(), 'rows w/ NaN Comparison:', d['Comparison'].isna().sum())
    vc = d['Comparison'].value_counts(sort=False)
    print(vc.to_string())
for k in ['6_hrs','24_hrs']:
    d = pd.read_pickle(f'/tmp/work/huvec_IL33_vs_Vehicle_HUVEC_{k}.pkl')
    print(k, d.shape, d['Comparison'].value_counts().to_dict())
