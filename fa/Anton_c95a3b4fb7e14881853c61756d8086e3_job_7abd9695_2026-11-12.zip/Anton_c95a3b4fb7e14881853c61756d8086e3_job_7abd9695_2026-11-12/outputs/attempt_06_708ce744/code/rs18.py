import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
W = pd.read_pickle('/tmp/work/W.pkl'); SE = pd.read_pickle('/tmp/work/SE.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
clean = pd.Index([g for g in W.index if g not in bad])
DF=85.1
def nde(lfc, se):
    t = lfc/se; p = 2*stats.t.sf(np.abs(t), DF); q = multipletests(p, method='fdr_bh')[1]; return int((q<0.05).sum())
rows=[]
for cl in ['A549','MCF7']:
    for tp in ['6hrs','24hrs']:
        a = W.loc[clean,f'Compound_47_vs_PBS_{cl}_{tp}']; b = W.loc[clean,f'Compound_47_vs_DMSO_{cl}_{tp}']; c = W.loc[clean,f'Compound_47_vs_IC119_{cl}_{tp}']
        sa = SE.loc[clean,f'Compound_47_vs_PBS_{cl}_{tp}']; sb = SE.loc[clean,f'Compound_47_vs_DMSO_{cl}_{tp}']; sc = SE.loc[clean,f'Compound_47_vs_IC119_{cl}_{tp}']
        se_approx = np.sqrt((sa**2+sb**2)/2)  # approx SE for a 2-group difference within this cell line/time
        dmso_vs_pbs = a - b   # DMSO - PBS
        ic119_vs_pbs = a - c  # IC119 - PBS
        ic119_vs_dmso = b - c # IC119 - DMSO
        rows.append([cl,tp, nde(c, sc), nde(dmso_vs_pbs, se_approx), nde(ic119_vs_pbs, np.sqrt((sa**2+sc**2)/2)), nde(ic119_vs_dmso, np.sqrt((sb**2+sc**2)/2))])
for cl in ['HUVEC','HGMEC']:
    for tp in ['6hrs','24hrs']:
        c = W.loc[clean,f'Compound_47_vs_IC119_{cl}_{tp}']; sc = SE.loc[clean,f'Compound_47_vs_IC119_{cl}_{tp}']
        a = W.loc[clean,f'Compound_47_IL33_vs_IL33_{cl}_{tp}']; b = W.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_{cl}_{tp}']
        sa = SE.loc[clean,f'Compound_47_IL33_vs_IL33_{cl}_{tp}']; sb = SE.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_{cl}_{tp}']
        iso = a - b  # IL33+IC119 minus IL33
        rows.append([cl,tp, nde(c, sc), None, None, None, nde(iso, np.sqrt((sa**2+sb**2)/2))])
res = pd.DataFrame(rows, columns=['cell','time','DE_C47_vs_IC119 (delivered)','DE_DMSO_vs_PBS (derived null)','DE_IC119_vs_PBS (derived)','DE_IC119_vs_DMSO (derived)','DE_IL33+IC119_vs_IL33 (derived isotype effect)'][:7] if False else None)
cols=['cell','time','DE C47 vs IC119 (delivered)','DE DMSO vs PBS (derived, vehicle-vs-vehicle null)','DE IC119 vs PBS (derived)','DE IC119 vs DMSO (derived)','DE IL33+IC119 vs IL33 (derived isotype effect)']
rows2 = [r if len(r)==7 else r+[None] for r in rows]
res = pd.DataFrame(rows2, columns=cols)
pd.set_option('display.width',250)
print(res.to_string())
res.to_csv('/tmp/work/null_calibration.csv', index=False)
