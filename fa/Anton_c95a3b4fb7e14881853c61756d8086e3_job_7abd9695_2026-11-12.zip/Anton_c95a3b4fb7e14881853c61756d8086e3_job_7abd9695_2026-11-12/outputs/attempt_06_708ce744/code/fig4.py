import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':8, 'axes.titlesize':9, 'axes.labelsize':8})
allc = pd.read_pickle('/tmp/work/all_contrasts.pkl')
se = np.abs(allc['logFC']/allc['t'])
W = pd.read_pickle('/tmp/work/W.pkl'); T = pd.read_pickle('/tmp/work/T.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl')
fig = plt.figure(figsize=(11,4.6))
ax = fig.add_subplot(1,3,1)
ax.hist(np.log10(se), bins=np.arange(-2,4.6,0.1), color='#4d4d4d')
ax.set_yscale('log'); ax.set_xlabel('log10 implied SE = |logFC / t|  (26 contrasts x 26,210 genes)'); ax.set_ylabel('count (log scale)')
ax.axvspan(np.log10(1.6), 4.5, color='#fdae61', alpha=0.3)
ax.set_ylim(0.5, 3e6); ax.text(-1.95, 2.0e5, 'valid limma range (SE <= ~1.3)', fontsize=7)
ax.text(1.0, 3e3, '205 genes with\nimplausible SE\n(up to 16,536)', fontsize=7, color='#b35806')
ax.set_title('A. RNA-seq tables contain a second, impossible\nSE population (not producible by one voom/limma fit)', fontsize=8.5)
ax = fig.add_subplot(1,3,2)
c = 'IL33_vs_Nontreated_HUVEC_6_hrs'
bad_all = set(pg.index[pg.nbad>0])
x = W[c]; y = T[c]
SEc = (x/y).abs()
ok = SEc <= 1.6
ax.scatter(x[ok], y[ok], s=2, c='#bdbdbd', lw=0, rasterized=True, label='valid genes')
ax.scatter(x[~ok], y[~ok], s=10, c='#d95f02', lw=0, label=f'implausible SE in this contrast (n={int((~ok).sum())})')
for g in ['SELE','VCAM1','CXCL8','CXCL1','CCL2','IL1RL1','CSF2','CCL20','TNF','IL6']:
    e = ann.index[ann.symbol==g][0]
    ax.annotate(g,(x[e],y[e]),fontsize=6.5,xytext=(3,2),textcoords='offset points', color='#d95f02' if not ok[e] else 'k')
ax.set_xlabel('log2FC, IL-33 vs vehicle (HUVEC 6 h)'); ax.set_ylabel('moderated t (as delivered)')
ax.legend(fontsize=6.5, frameon=False, loc='upper left', markerscale=2)
ax.set_title('B. Canonical endothelial genes (E-selectin, VCAM-1,\nIL-8, CXCL1, IL1RL1/ST2) have huge FC but t~0', fontsize=8.5)
ax = fig.add_subplot(1,3,3); ax.axis('off')
items = [
 ('RNA-seq','205 genes with impossible statistics (76 in all 26 contrasts) incl. IL1RL1 (ST2), SELE, VCAM1, CXCL8, CXCL1, CCL2, PTX3, GAPDH; fold-changes coherent, p/q unusable'),
 ('RNA-seq','Sheets named "6h" and "24h" each hold all 24 contrasts (identical duplicates)'),
 ('RNA-seq','HGMEC has no vehicle arm and no IL-33-vs-isotype contrast: IL-33 effect in HGMEC not estimable'),
 ('RNA-seq','"Vehicle" (sheet) vs "Nontreated" (contrast label); AveExpr pooled over 4 cell lines'),
 ('Serum','BH family = 1,194 tests, 1,094 delivered; ~100 withheld incl. IL-33, IL-4, IL-5, IL-13, TSLP'),
 ('Serum','"OR per log unit" on NPX (already log2): scale ambiguous; per-unit ORs not comparable across assays'),
 ('Serum','26 proteins on >1 panel not reconciled (but agree, r=0.96)'),
 ('Tissue','8/31 donor labels conflict with autopsy reports; SARS status missing (1905)'),
 ('Tissue','IL-33 and EPX/EDN/MBP columns hidden; IL-33 = average of 2 sub-scores (max 5.5 > stated 0-5)'),
 ('Tissue','IL-5Ra (duplex) tracks neutrophil elastase (rho 0.76), not EPX (rho 0.0)'),
 ('Design','Only reduced IL-33 tested (oxidised-form claim untested); one antibody concentration; no pre-incubation; single-donor primary cells'),
]
ax.text(0,1.0,'C. Data-integrity log (details in Table S1)', fontsize=9, weight='bold', va='top')
yy = 0.92
for k,(src,txt) in enumerate(items):
    import textwrap
    lines = textwrap.wrap(txt, 58)
    ax.text(0, yy, f'{k+1}. {src}', fontsize=6.6, va='top', weight='bold')
    ax.text(0.25, yy, '\n'.join(lines), fontsize=6.6, va='top')
    yy -= 0.045*len(lines) + 0.025
fig.suptitle('Figure 4. Data-integrity findings that bear on the decision (none invalidates the main conclusions; several block specific claims)', fontsize=9.5, y=0.995)
fig.tight_layout()
fig.savefig('/tmp/outputs/figures/Fig4_data_integrity.png', dpi=200)
print('ok')
