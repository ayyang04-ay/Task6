import pandas as pd, numpy as np
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); SE = pd.read_pickle('/tmp/work/SE.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
clean = pd.Index([g for g in W.index if g not in bad])
rows = {}
for tp in ['6','24']:
    il = W.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; ilq = Q.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']
    b = W.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; bq = Q.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    up = (ilq<0.05)&(il>1)
    inh = -b[up]/il[up]
    print(f'{tp}h: induced (q<0.05, log2FC>1) n={int(up.sum())}; >=50% inhibited: {int((inh>=0.5).sum())} ({100*(inh>=0.5).mean():.0f}%); >=80%: {100*(inh>=0.8).mean():.0f}%')
    rows[tp] = set(clean[up & (bq<0.05) & (b<-1)])
u = rows['6'] | rows['24']
print('program 6h:', len(rows['6']), '24h:', len(rows['24']), 'union:', len(u), 'both:', len(rows['6'] & rows['24']))
cols = {}
for tp in ['6','24']:
    cols[f'HUVEC_IL33_vs_vehicle_{tp}h_log2FC'] = W[f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; cols[f'HUVEC_IL33_vs_vehicle_{tp}h_q'] = Q[f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']
    cols[f'HUVEC_AX1177_blockade_{tp}h_log2FC'] = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; cols[f'HUVEC_AX1177_blockade_{tp}h_q'] = Q[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    cols[f'HGMEC_AX1177_blockade_{tp}h_log2FC'] = W[f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp}hrs']; cols[f'HGMEC_AX1177_blockade_{tp}h_q'] = Q[f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp}hrs']
    cols[f'AX1177_alone_vs_isotype_HUVEC_{tp}h_log2FC'] = W[f'Compound_47_vs_IC119_HUVEC_{tp}hrs']
D = pd.DataFrame(cols).loc[sorted(u)]
D.insert(0,'symbol', ann.symbol.loc[D.index]); D.insert(1,'gene_name', ann.gene_name.loc[D.index]); D.insert(2,'AveExpr_all114', ann.AveExpr.loc[D.index].round(2))
D['in_6h_program'] = D.index.isin(rows['6']); D['in_24h_program'] = D.index.isin(rows['24'])
D['pct_inhibition_6h'] = (-100*D['HUVEC_AX1177_blockade_6h_log2FC']/D['HUVEC_IL33_vs_vehicle_6h_log2FC']).round(0)
D = D.sort_values('HUVEC_IL33_vs_vehicle_6h_log2FC', ascending=False)
D.index.name='ensembl'
D.to_csv('/tmp/work/il33_program.csv')
print(D.head(5).T)
