import pandas as pd, numpy as np
from scipy import stats
df = pd.read_csv('/tmp/work/prot_annot.csv')
m=1194; p=df['p.value'].values; adj=df['adj.p.value'].values
own = np.r_[adj[:-1] < adj[1:], True]
rt = p*m/adj
mb = rt - df['rank'].values
d = pd.DataFrame({'assay':df.assay,'p':p,'adj':adj,'rank':df['rank'],'missing_below':np.round(mb,2),'own':own})
dd = d[d.own]
# first ranks where missing_below >= 1, >=2
for k in [1,2,3,5,10,16]:
    r = dd[dd.missing_below>=k-0.01].iloc[0]
    prev = dd[dd['rank']<r['rank']].iloc[-1]
    print(f'>= {k} withheld tests with p below {r.p:.5f} (between p={prev.p:.5f} [rank {prev["rank"]}] and p={r.p:.5f} [rank {r["rank"]}])')
# expected under uniform null for 100 tests
for thr in [0.001,0.01,0.05]:
    r = dd[dd.p<=thr].iloc[-1]
    print(f'withheld tests with p<={thr}: ~{r.missing_below:.0f} (expected if 100 null tests: {100*thr:.1f}); binomial P(X>=obs | null) = {stats.binom.sf(round(r.missing_below)-1, 100, thr):.2g}')
