import pandas as pd, numpy as np, openpyxl, re
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_columns', 60); pd.set_option('display.max_rows', 300)
wb = openpyxl.load_workbook('/tmp/world/filesystem/AX-1177_postmortem_lung.xlsx')
ws = wb.active
rows = [[c.value for c in r] for r in ws.iter_rows(min_row=2, max_row=ws.max_row)]
cols = ['SampleID','Block','TissueRNA','SampleID2','Lobe','DiseaseCat','Race','Gender','Age','SARS','Pathology','HE_eos','EPX','EDN','MBP','C2D7','IL5Ra_dNE','NE_dIL5Ra','IL5Ra_dTrypt','Trypt_dIL5Ra','EPX_num','NE_num','Trypt_num','IL33_epi','IL33_endo','IL33_vsmc','Notes','extra']
raw = pd.DataFrame(rows, columns=cols)
raw = raw[raw['Block'].notna()].copy().reset_index(drop=True)
raw['SampleID'] = raw['SampleID'].astype(str).str.replace(r'\.0$','',regex=True)
def sc(v):
    if v is None: return np.nan
    if isinstance(v,(int,float)): return float(v)
    s=str(v).strip()
    if s in ('ND','N/A',''): return np.nan
    if s.startswith('='):  # formula
        return float(eval(s[1:]))
    m=re.match(r'^(\d)\+$', s)
    if m: return float(m.group(1))
    return float(s)
for c in ['EPX','EDN','MBP','C2D7','IL5Ra_dNE','NE_dIL5Ra','IL5Ra_dTrypt','Trypt_dIL5Ra','EPX_num','NE_num','Trypt_num','IL33_epi','IL33_endo','IL33_vsmc']:
    raw[c+'_v'] = raw[c].map(sc)
raw['HE_eos_v'] = raw['HE_eos'].map({'Y':1,'N':0})
# check numeric = text + 0.5 (except 0)
for a,b in [('EPX','EPX_num'),('NE_dIL5Ra','NE_num'),('Trypt_dIL5Ra','Trypt_num')]:
    exp = raw[a+'_v'].where(raw[a+'_v']==0, raw[a+'_v']+0.5)
    mism = raw[(exp!=raw[b+'_v']) & ~(exp.isna() & raw[b+'_v'].isna())]
    print(a,'->',b,'mismatches:', len(mism), mism[['SampleID','Block',a,b]].values.tolist())
# donor-level fields: forward fill within donor
for c in ['DiseaseCat','Race','Gender','Age','SARS','Pathology']:
    raw[c] = raw.groupby('SampleID')[c].transform(lambda s: s.ffill().bfill())
raw['Notes'] = raw.groupby('SampleID')['Notes'].transform(lambda s: ', '.join(sorted(set(s.dropna()))) if s.notna().any() else np.nan)
raw['group'] = raw['DiseaseCat'].map({'COVID neg pneumonia':'NonCOVID_pneu','COVID pos pneumonia':'COVID_pneu','COVID neg non-pneumonia':'NonPneu_ctrl'})
print(raw.groupby('group').agg(donors=('SampleID','nunique'), blocks=('Block','count')))
print(raw.groupby(['group','SampleID']).size().unstack(0).fillna(0).astype(int).T)
raw.to_pickle('/tmp/work/pm_blocks.pkl')
# Donor-level
vals = ['HE_eos_v','EPX_v','EDN_v','MBP_v','C2D7_v','IL5Ra_dNE_v','NE_dIL5Ra_v','IL5Ra_dTrypt_v','Trypt_dIL5Ra_v','IL33_epi_v','IL33_endo_v','IL33_vsmc_v']
don = raw.groupby('SampleID').agg({**{v:'mean' for v in vals}, 'group':'first','Age':'first','Gender':'first','SARS':'first','Notes':'first','Block':'count'}).rename(columns={'Block':'n_blocks'})
don.to_pickle('/tmp/work/pm_donors.pkl')
print(don.sort_values('group').round(2).to_string())
