import pandas as pd, numpy as np
from scipy import stats
allc = pd.read_pickle('/tmp/work/all_contrasts.pkl')
d = allc[allc.Comparison=='Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs'].copy()
d['p_pred'] = 2*stats.t.sf(np.abs(d.t), 85.1)
d['dlog'] = np.log10(d.p_pred) - np.log10(d['P.Value'])
bad = d[np.abs(d.dlog)>0.1]
print(len(bad)); print(bad[['symbol','t','P.Value','p_pred','dlog']].sort_values('P.Value').head(10).to_string())
print('P.Value range among inconsistent:', bad['P.Value'].min(), bad['P.Value'].max(), ' |t| range', bad.t.abs().min(), bad.t.abs().max())
# does a slightly different df fix it?
for df in [80, 85.1, 90, 100]:
    pp = 2*stats.t.sf(np.abs(d.t), df); dl = np.log10(pp)-np.log10(d['P.Value'])
    print(df, (np.abs(dl)>0.1).sum(), ' among |t|<8:', ((np.abs(dl)>0.1)&(d.t.abs()<8)).sum())
