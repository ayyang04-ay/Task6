import re, os
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle,
                                Image, PageBreak, NextPageTemplate, KeepTogether, HRFlowable, ListFlowable, ListItem)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping
FD = '/opt/conda/envs/core/lib/python3.11/site-packages/matplotlib/mpl-data/fonts/ttf'
pdfmetrics.registerFont(TTFont('DV', f'{FD}/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DV-B', f'{FD}/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DV-I', f'{FD}/DejaVuSans-Oblique.ttf'))
pdfmetrics.registerFont(TTFont('DV-BI', f'{FD}/DejaVuSans-BoldOblique.ttf'))
pdfmetrics.registerFont(TTFont('DVM', f'{FD}/DejaVuSansMono.ttf'))
addMapping('DV',0,0,'DV'); addMapping('DV',1,0,'DV-B'); addMapping('DV',0,1,'DV-I'); addMapping('DV',1,1,'DV-BI')

base = ParagraphStyle('base', fontName='DV', fontSize=8.6, leading=11.4, spaceAfter=3)
H1 = ParagraphStyle('H1', parent=base, fontName='DV-B', fontSize=15, leading=19, spaceAfter=6, textColor=colors.HexColor('#0b2e59'))
H2 = ParagraphStyle('H2', parent=base, fontName='DV-B', fontSize=11.5, leading=14.5, spaceBefore=8, spaceAfter=4, textColor=colors.HexColor('#0b2e59'))
H3 = ParagraphStyle('H3', parent=base, fontName='DV-B', fontSize=9.6, leading=12.5, spaceBefore=5, spaceAfter=3, textColor=colors.HexColor('#1f4e79'))
QUOTE = ParagraphStyle('Q', parent=base, leftIndent=14, rightIndent=14, borderColor=colors.HexColor('#1f4e79'), borderWidth=0, backColor=colors.HexColor('#eef4fb'), borderPadding=6, fontName='DV-I', spaceBefore=4, spaceAfter=8)
CELL = ParagraphStyle('cell', parent=base, fontSize=7.3, leading=9.2, spaceAfter=0)
CELLH = ParagraphStyle('cellh', parent=CELL, fontName='DV-B')
BUL = ParagraphStyle('bul', parent=base, spaceAfter=1.5, bulletFontName='DV')

def inline(t):
    t = t.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    t = re.sub(r'`([^`]+)`', r'<font name="DVM" size="7.6">\1</font>', t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?![\*\w])', r'<i>\1</i>', t)
    return t

def parse_table(lines, avail):
    rows = []
    for ln in lines:
        ln = ln.strip()
        if re.match(r'^\|\s*-', ln): continue
        cells = [c.strip() for c in ln.strip('|').split('|')]
        rows.append(cells)
    ncol = max(len(r) for r in rows)
    rows = [r + ['']*(ncol-len(r)) for r in rows]
    # column widths by content length (sqrt-damped)
    import math
    lens = [max(4, max(len(r[i]) for r in rows)) for i in range(ncol)]
    w = [math.sqrt(l) for l in lens]
    if ncol==2: w = [w[0]*0.9, w[1]*1.3]
    tot = sum(w); widths = [avail*x/tot for x in w]
    # ensure each column fits its longest word (strip markdown marks)
    def longest_word(i):
        ws = [len(x) for r in rows for x in re.sub(r'[*`]','',r[i]).split()]
        return max(ws) if ws else 4
    minw = [longest_word(i)*5.4 + 9 for i in range(ncol)]
    for _ in range(5):
        short = [k for k in range(ncol) if widths[k] < minw[k]]
        if not short: break
        need = sum(minw[k]-widths[k] for k in short)
        for k in short: widths[k] = minw[k]
        others = [k for k in range(ncol) if k not in short]
        tot_o = sum(widths[k] for k in others)
        for k in others: widths[k] -= need*widths[k]/tot_o
    data = []
    for k,r in enumerate(rows):
        st = CELLH if k==0 else CELL
        data.append([Paragraph(inline(c), st) for c in r])
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.3,colors.HexColor('#9aa9b8')),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dbe7f3')),
                           ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2)]))
    return t

def build(md_path, pdf_path, figs):
    lines = open(md_path).read().split('\n')
    pw, ph = A4; margin = 1.6*cm
    avail = pw - 2*margin
    story = []
    i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith('# '):
            story.append(Paragraph(inline(ln[2:]), H1)); i+=1; continue
        if ln.startswith('## '):
            story.append(Paragraph(inline(ln[3:]), H2)); i+=1; continue
        if ln.startswith('### '):
            story.append(Paragraph(inline(ln[4:]), H3)); i+=1; continue
        if ln.strip()=='---':
            story.append(HRFlowable(width='100%', thickness=0.6, color=colors.HexColor('#9aa9b8'), spaceBefore=3, spaceAfter=3)); i+=1; continue
        if ln.startswith('|'):
            tl=[]
            while i < len(lines) and lines[i].startswith('|'):
                tl.append(lines[i]); i+=1
            story.append(parse_table(tl, avail)); story.append(Spacer(1,5)); continue
        if ln.startswith('> '):
            story.append(Paragraph(inline(ln[2:]), QUOTE)); i+=1; continue
        m = re.match(r'^(\s*)([-*]|\d+\.)\s+(.*)$', ln)
        if m:
            # gather list block
            items=[]
            while i < len(lines):
                m2 = re.match(r'^(\s*)([-*]|\d+\.)\s+(.*)$', lines[i])
                if m2:
                    items.append([len(m2.group(1)), m2.group(2), m2.group(3)]); i+=1
                elif lines[i].startswith('   ') and lines[i].strip() and items:
                    items[-1][2] += ' ' + lines[i].strip(); i+=1
                else: break
            for ind, mark, txt in items:
                lvl = ind//2 if mark in '-*' else ind//3
                lvl = min(lvl, 3)
                bullet = '•' if mark in '-*' else mark
                if lvl>=1 and mark in '-*': bullet = '–' if lvl==1 else '·'
                st = ParagraphStyle('b%d'%lvl, parent=BUL, leftIndent=12+lvl*12, bulletIndent=2+lvl*12)
                story.append(Paragraph(inline(txt), st, bulletText=bullet))
            story.append(Spacer(1,3)); continue
        if ln.strip()=='':
            i+=1; continue
        # paragraph (merge consecutive non-empty lines)
        buf=[ln]; i+=1
        while i < len(lines) and lines[i].strip() and not re.match(r'^(#|\||>|\s*[-*]\s|\s*\d+\.\s|---)', lines[i]):
            buf.append(lines[i]); i+=1
        story.append(Paragraph(inline(' '.join(buf)), base))
    # figures in landscape
    while story and isinstance(story[-1], (Spacer, HRFlowable)): story.pop()
    story.append(NextPageTemplate('land')); story.append(PageBreak())
    lw, lh = landscape(A4)
    for k,(fp, cap) in enumerate(figs):
        from PIL import Image as PILImage
        im = PILImage.open(fp); w,h = im.size
        maxw = lw - 2*1.2*cm; maxh = lh - 2*1.2*cm - 1.2*cm
        sc = min(maxw/w, maxh/h)
        story.append(Image(fp, width=w*sc, height=h*sc))
        story.append(Paragraph(cap, ParagraphStyle('cap', parent=base, fontSize=7.6, leading=9.5)))
        if k < len(figs)-1: story.append(PageBreak())
    def footer(c, d):
        c.saveState(); c.setFont('DV', 7); c.setFillColor(colors.HexColor('#555555'))
        c.drawString(margin, 0.9*cm, 'AX-1177 portfolio audit. Based solely on the delivered programme files. Confidential.')
        c.drawRightString(d.pagesize[0]-margin, 0.9*cm, f'page {d.page}'); c.restoreState()
    doc = BaseDocTemplate(pdf_path, pagesize=A4, leftMargin=margin, rightMargin=margin, topMargin=1.4*cm, bottomMargin=1.5*cm, title='AX-1177 portfolio audit memo', author='Portfolio analytics')
    fr_p = Frame(margin, 1.5*cm, pw-2*margin, ph-1.4*cm-1.5*cm, id='p')
    fr_l = Frame(1.2*cm, 1.3*cm, lw-2.4*cm, lh-2.4*cm, id='l')
    doc.addPageTemplates([PageTemplate(id='port', frames=[fr_p], onPage=footer, pagesize=A4), PageTemplate(id='land', frames=[fr_l], onPage=footer, pagesize=landscape(A4))])
    doc.build(story)

figs = [('/tmp/outputs/figures/Fig1_invitro_pharmacology.png','<b>Figure 1.</b> In vitro pharmacology. (A, B) IL-33 effect vs isotype-controlled AX-1177 blockade in HUVEC at 6 h and 24 h (valid-statistics genes). (C) HGMEC vs HUVEC blockade. (D) Antibody-alone DE-gene counts vs inert-arm background and blockade contrasts. (E) Kinetics. (F) Key endothelial readouts: residual under AX-1177 = exact linear combination of delivered contrasts.'),
        ('/tmp/outputs/figures/Fig2_postmortem_lung.png','<b>Figure 2.</b> Post-mortem lung IHC analysed per donor. (A) IL-33 by delivered label. (B) IL-33 by autopsy-documented DAD/ALI. (C) Eosinophil and neutrophil markers by delivered label (blue p) vs autopsy-based classification (orange p). (D) Blocks per donor. (E) Ceiling effect. (F) Label/autopsy conflicts.'),
        ('/tmp/outputs/figures/Fig3_serum_proteomics.png','<b>Figure 3.</b> Serum proteomics vs 30-day ICU/IMV/death (n=100; 44 events). (A) All 1,094 delivered assays. (B) IL-33 endothelial-program proteins and sST2. (C) Reconstruction of the ~100 assays present in the BH denominator but absent from the file. (D) Cross-panel agreement for the 26 duplicated proteins.'),
        ('/tmp/outputs/figures/Fig4_data_integrity.png','<b>Figure 4.</b> Data-integrity findings. (A) Implied SE distribution across all contrasts. (B) IL-33 vs vehicle (HUVEC 6 h): genes with implausible SE have large fold-changes but t near 0. (C) Issue log (Table S1).')]
build('/tmp/outputs/AX-1177_portfolio_audit_memo.md', '/tmp/outputs/AX-1177_portfolio_audit_memo.pdf', figs)
print('pdf ok')
