import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',400)
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
clean = pd.Index([g for g in W.index if g not in bad])
for tp in ['6','24']:
    hu = W.loc[clean, f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; hg = W.loc[clean, f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp}hrs']
    huq = Q.loc[clean, f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; hgq = Q.loc[clean, f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp}hrs']
    both = (huq<0.05)&(hgq<0.05)
    print(f'{tp}h: HUVEC blockade DE {int((huq<0.05).sum())}, HGMEC {int((hgq<0.05).sum())}, both {int(both.sum())}; r(all clean)={np.corrcoef(hu,hg)[0,1]:.2f}; r(both sig)={np.corrcoef(hu[both],hg[both])[0,1]:.2f}; median |HGMEC|/|HUVEC| among both-sig down genes = {np.median((hg[both&(hu<0)&(hg<0)]/hu[both&(hu<0)&(hg<0)])):.2f}')
    # HGMEC-specific strong blockade
    spec = clean[(hgq<0.05)&(hg<-2)&(huq>0.2)]
    d = pd.DataFrame({'sym':ann.symbol.loc[spec],'HGMEC_block':hg.loc[spec],'HUVEC_block':hu.loc[spec],'A':ann.AveExpr.loc[spec]})
    print(f'  HGMEC-specific (HGMEC block < -2, q<0.05; HUVEC q>0.2): n={len(d)}')
    print('  ', ', '.join(f"{s}({h:.1f}/{u:.1f},A={a:.1f})" for s,h,u,a in d.sort_values('HGMEC_block').values[:50]))
