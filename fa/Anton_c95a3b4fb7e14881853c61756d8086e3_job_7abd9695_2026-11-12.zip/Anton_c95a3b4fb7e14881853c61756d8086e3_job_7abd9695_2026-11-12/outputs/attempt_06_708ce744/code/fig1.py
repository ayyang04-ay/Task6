import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':8, 'axes.titlesize':9, 'axes.labelsize':8, 'font.family':'DejaVu Sans'})
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
clean = pd.Index([g for g in W.index if g not in bad])
sym = ann.symbol
sym2e = {}
for e,s in sym.dropna().items(): sym2e.setdefault(s,e)
lab = ['CSF2','CXCL6','CCL20','CX3CL1','CSF3','TNF','IL6','ICAM1','F3','CXCL10','EBI3','THBD','C3','GBP5','MX2']
fig, axes = plt.subplots(2,3, figsize=(11,7.2))
stats_txt = {}
for j,tp in enumerate(['6','24']):
    ax = axes[0,j]
    il = W.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; ilq = Q.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']
    b = W.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; bq = Q.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    de = ilq<0.05
    ax.scatter(il[~de], b[~de], s=2, c='#d0d0d0', lw=0, rasterized=True, label='not IL-33-responsive')
    rev = de & (bq<0.05) & (np.sign(b)==-np.sign(il))
    ax.scatter(il[de & ~rev], b[de & ~rev], s=3, c='#f4a582', lw=0, rasterized=True, label='IL-33-responsive, not sig. reversed')
    ax.scatter(il[rev], b[rev], s=3, c='#2166ac', lw=0, rasterized=True, label='IL-33-responsive, sig. reversed by AX-1177')
    lim = 13
    ax.plot([-lim,lim],[lim,-lim],'k--',lw=0.8); ax.axhline(0,c='k',lw=0.5); ax.axvline(0,c='k',lw=0.5)
    up = de & (il>1)
    inh = (-b[up]/il[up]).median()
    for g in lab:
        e = sym2e.get(g)
        if e in il.index and abs(il[e])>0.8:
            ax.annotate(g, (il[e], b[e]), fontsize=6.5, xytext=(3,2), textcoords='offset points')
    ax.set_xlim(-5,12.5); ax.set_ylim(-13,5)
    ax.set_xlabel(f'IL-33 vs vehicle, HUVEC {tp} h (log2FC)'); ax.set_ylabel('AX-1177+IL-33 vs isotype+IL-33 (log2FC)')
    ax.set_title(f'{"A" if tp=="6" else "B"}. HUVEC {tp} h: isotype-controlled blockade')
    ax.text(-4.7, 4.3, f'IL-33-induced genes (log2FC>1): n={int(up.sum())}\nmedian inhibition {100*inh:.0f}%\n{100*rev.sum()/de.sum():.0f}% of all {int(de.sum())} IL-33 DE genes\nsignificantly reversed', fontsize=6.5, va='top', bbox=dict(fc='white', ec='#999999', lw=0.5))
    if j==0: ax.legend(fontsize=6, loc='lower left', markerscale=3, frameon=False, bbox_to_anchor=(0.0,0.0))
    ax.text(11.5,-11.8,'dashed: complete\nblockade (y = -x)', fontsize=6, ha='right')
# Panel C: HGMEC vs HUVEC blockade
ax = axes[0,2]
hu = W.loc[clean,'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs']; hg = W.loc[clean,'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs']
huq = Q.loc[clean,'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs']; hgq = Q.loc[clean,'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs']
both = (huq<0.05)&(hgq<0.05); either = (huq<0.05)|(hgq<0.05)
ax.scatter(hu[either&~both], hg[either&~both], s=2, c='#d0d0d0', lw=0, rasterized=True, label='sig. in one line only')
ax.scatter(hu[both], hg[both], s=3, c='#1b7837', lw=0, rasterized=True, label=f'sig. in both (n={int(both.sum())}), r={np.corrcoef(hu[both],hg[both])[0,1]:.2f}')
ax.plot([-13,5],[-13,5],'k:',lw=0.7); ax.axhline(0,c='k',lw=0.5); ax.axvline(0,c='k',lw=0.5)
sl = np.polyfit(hu[both], hg[both],1)[0]
for g in ['CSF2','CSF3','CXCL3','CCL20','CX3CL1','TNFRSF9','IL6','TNF','CXCL10','BIRC3']:
    e = sym2e.get(g); ax.annotate(g,(hu[e],hg[e]),fontsize=6.5,xytext=(3,2),textcoords='offset points')
ax.set_xlabel('HUVEC 6 h blockade (log2FC)'); ax.set_ylabel('HGMEC 6 h blockade (log2FC)')
ax.set_title('C. HGMEC vs HUVEC blockade (6 h)')
ax.text(-12.6, 2.4, f'HGMEC reproduces the HUVEC program\nat ~{sl:.2f}x magnitude; HGMEC-only hits\nare low-expression lncRNA/pseudogenes', fontsize=6.5, va='top', bbox=dict(fc='white', ec='#999999', lw=0.5))
ax.legend(fontsize=6, loc='upper left', frameon=False, markerscale=3); ax.set_xlim(-13,5); ax.set_ylim(-13,5)
# Panel D: specificity (DE counts)
ax = axes[1,0]
nc = pd.read_csv('/tmp/work/null_calibration.csv')
def cnt(c): return int((Q.loc[clean,c]<0.05).sum())
labels=[]; vals=[]; cols=[]
for cl in ['HUVEC','HGMEC','A549','MCF7']:
    for tp in ['6hrs','24hrs']:
        labels.append(f'{cl} {tp[:-3]}h'); vals.append(cnt(f'Compound_47_vs_IC119_{cl}_{tp}')); cols.append('#762a83')
bg = [v for v in nc['DE DMSO vs PBS (derived, vehicle-vs-vehicle null)'].dropna()] + [v for v in nc['DE IC119 vs PBS (derived)'].dropna()] + [v for v in nc['DE IC119 vs DMSO (derived)'].dropna()] + [v for v in nc['DE IL33+IC119 vs IL33 (derived isotype effect)'].dropna()]
blk = [cnt(f'Compound_47_IL33_vs_IL33_IC119_{cl}_{tp}') for cl in ['HUVEC','HGMEC'] for tp in ['6hrs','24hrs']]
x = np.arange(len(vals))
ax.bar(x, vals, color=cols, width=0.7, zorder=2, label='AX-1177 alone vs isotype (no IL-33)')
ax.axhspan(1, max(bg), color='#fdb863', alpha=0.35, zorder=0, label=f'background: inert-vs-inert arms ({int(min(bg))}-{int(max(bg))} DE genes)')
xb = np.arange(len(vals), len(vals)+4)+0.5
ax.bar(xb, blk, color='#2166ac', width=0.7, zorder=2, label='AX-1177 blockade of IL-33 (isotype-controlled)')
ax.set_xticks(list(x)+list(xb)); ax.set_xticklabels(labels+['HUVEC 6h','HUVEC 24h','HGMEC 6h','HGMEC 24h'], rotation=60, ha='right', fontsize=6.5)
ax.set_yscale('log'); ax.set_ylim(1, 20000); ax.set_ylabel('DE genes (BH q<0.05, valid-statistics genes)')
ax.set_title('D. Specificity vs inert-arm background')
ax.legend(fontsize=6, frameon=False, loc='upper left')
# Panel E: kinetics 6h vs 24h
ax = axes[1,1]
k = []
for tp in ['6','24']:
    il = W.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; ilq = Q.loc[clean,f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; b = W.loc[clean,f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    up = (ilq<0.05)&(il>1)
    k.append([int((ilq<0.05).sum()), int(up.sum()), 100*(-b[up]/il[up]).median()])
k = np.array(k)
ax2 = ax.twinx()
ax.bar([0,1], k[:,0], width=0.5, color='#9ecae1', label='IL-33 DE genes (HUVEC)')
ax2.plot([0,1], k[:,2], 'o-', c='#08519c', label='median % inhibition by AX-1177')
for i in range(2):
    ax.text(i, 150, f'{int(k[i,0])} IL-33 DE genes', ha='center', fontsize=7); ax2.text(i-0.05, k[i,2]+2.5, f'{k[i,2]:.0f}% inhibition', fontsize=7, color='#08519c')
ax.set_xticks([0,1]); ax.set_xticklabels(['6 h','24 h']); ax.set_ylabel('IL-33-responsive genes'); ax2.set_ylabel('median isotype-controlled inhibition (%)'); ax2.set_ylim(50,105)
ax.set_title('E. Kinetics: 6 h vs 24 h')
# Panel F: selected genes bar (6h)
ax = axes[1,2]
genes = ['CSF2','CXCL6','CCL20','CX3CL1','CSF3','TNF','IL6','F3','CXCL10','THBD']
e = [sym2e[g] for g in genes]
il6 = W.loc[e,'IL33_vs_Nontreated_HUVEC_6_hrs'].values; res6 = il6 + W.loc[e,'Compound_47_IL33_vs_IL33_HUVEC_6hrs'].values
il24 = W.loc[e,'IL33_vs_Nontreated_HUVEC_24_hrs'].values; res24 = il24 + W.loc[e,'Compound_47_IL33_vs_IL33_HUVEC_24hrs'].values
y = np.arange(len(genes))
ax.barh(y+0.2, il6, height=0.38, color='#b2182b', label='IL-33 vs vehicle (6 h)')
ax.barh(y-0.2, res6, height=0.38, color='#2166ac', label='AX-1177+IL-33 vs vehicle (6 h)')
ax.set_yticks(y); ax.set_yticklabels(genes); ax.invert_yaxis(); ax.axvline(0,c='k',lw=0.5)
ax.set_xlabel('log2FC vs vehicle (HUVEC)'); ax.legend(fontsize=6, frameon=False, loc='lower right')
ax.set_title('F. Key readouts, HUVEC 6 h')
fig.suptitle('Figure 1. AX-1177 pharmacology in primary human endothelial cells (reduced IL-33, 30 ng/mL; AX-1177 10 ug/mL, ~41-fold molar excess, added concurrently)', fontsize=9.5, y=0.995)
fig.tight_layout()
fig.savefig('/tmp/outputs/figures/Fig1_invitro_pharmacology.png', dpi=200)
print('ok', k)
