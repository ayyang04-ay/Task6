import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',400); pd.set_option('display.max_columns',40)
W = pd.read_pickle('/tmp/work/W.pkl'); T = pd.read_pickle('/tmp/work/T.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
clean = pd.Index([g for g in W.index if g not in bad])
for tp in ['6','24']:
    il = W[f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; ilq = Q[f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']
    blk = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; blkq = Q[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    for dirn in ['up','down']:
        for thr in [1,2]:
            sel = clean[(ilq.loc[clean]<0.05) & ((il.loc[clean]>thr) if dirn=='up' else (il.loc[clean]<-thr))]
            inh = -blk.loc[sel]/il.loc[sel]
            rev = ((blkq.loc[sel]<0.05) & (np.sign(blk.loc[sel])==-np.sign(il.loc[sel]))).mean()
            print(f'HUVEC {tp}h IL33-{dirn} |lfc|>{thr}: n={len(sel)}, isotype-controlled median inhibition={100*inh.median():.0f}% [IQR {100*inh.quantile(.25):.0f}-{100*inh.quantile(.75):.0f}], frac significantly reversed (adj<0.05) = {100*rev:.0f}%, median AveExpr={ann.AveExpr.loc[sel].median():.2f}')
# genes significantly reversed by C47 (isotype-controlled), up vs down composition
for cl in ['HUVEC','HGMEC']:
    for tp in ['6','24']:
        b = W[f'Compound_47_IL33_vs_IL33_IC119_{cl}_{tp}hrs']; bq = Q[f'Compound_47_IL33_vs_IL33_IC119_{cl}_{tp}hrs']
        sig = clean[bq.loc[clean]<0.05]
        print(f'{cl} {tp}h isotype-controlled blockade DE (clean): {len(sig)}; C47 lowers {int((b.loc[sig]<0).sum())}, raises {int((b.loc[sig]>0).sum())}; among |lfc|>1: lowers {int((b.loc[sig]<-1).sum())}, raises {int((b.loc[sig]>1).sum())}; median AveExpr lowered={ann.AveExpr.loc[sig[b.loc[sig]<0]].median():.2f}, raised={ann.AveExpr.loc[sig[b.loc[sig]>0]].median():.2f}')
