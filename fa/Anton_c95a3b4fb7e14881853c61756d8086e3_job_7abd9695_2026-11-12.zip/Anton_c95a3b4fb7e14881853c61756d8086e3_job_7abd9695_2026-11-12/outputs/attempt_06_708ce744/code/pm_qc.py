import pandas as pd, numpy as np
from scipy import stats
blk = pd.read_pickle('/tmp/work/pm_blocks.pkl')
def agree(a,b):
    d = blk[[a,b]].dropna()
    r = stats.spearmanr(d[a], d[b])
    exact = (d[a]==d[b]).mean(); within1 = (abs(d[a]-d[b])<=1).mean()
    return len(d), round(r.correlation,2), round(exact,2), round(within1,2)
print('IL5Ra duplexNE vs duplexTryptase (same marker, serial sections): n, rho, exact, within1 =', agree('IL5Ra_dNE_v','IL5Ra_dTrypt_v'))
print('EPX vs EDN', agree('EPX_v','EDN_v')); print('EPX vs MBP', agree('EPX_v','MBP_v')); print('EDN vs MBP', agree('EDN_v','MBP_v'))
print('IL5Ra(NE) vs EPX', agree('IL5Ra_dNE_v','EPX_v')); print('IL5Ra(NE) vs NE', agree('IL5Ra_dNE_v','NE_dIL5Ra_v'))
print('IL33 endo vs epi', agree('IL33_endo_v','IL33_epi_v')); print('IL33 endo vs vsmc', agree('IL33_endo_v','IL33_vsmc_v'))
# IL-33 vs eosinophils/neutrophils at donor level
don = pd.read_pickle('/tmp/work/pm_donors.pkl')
for a in ['IL33_epi_v','IL33_endo_v','IL33_vsmc_v']:
    for b in ['EPX_v','EDN_v','MBP_v','IL5Ra_dNE_v','NE_dIL5Ra_v','Trypt_dIL5Ra_v','Age']:
        d = don[[a,b]].dropna().astype(float)
        r = stats.spearmanr(d[a], d[b])
        print(f'donor-level {a} vs {b}: rho={r.correlation:.2f} p={r.pvalue:.3f} n={len(d)}')
