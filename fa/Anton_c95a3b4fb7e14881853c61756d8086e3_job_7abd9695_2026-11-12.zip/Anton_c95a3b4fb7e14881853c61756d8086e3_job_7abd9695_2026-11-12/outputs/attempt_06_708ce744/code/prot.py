import pandas as pd, numpy as np, re
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 50); pd.set_option('display.max_rows', 400)
df = pd.read_excel('/tmp/world/filesystem/AX-1177_serum_proteomics.xlsx')
df['rank']=np.arange(1,len(df)+1)
# verify BH
bh = multipletests(df['p.value'], method='fdr_bh')[1]
print('max abs diff BH recomputed vs delivered:', np.max(np.abs(bh-df['adj.p.value'])))
print('n tests', len(df), 'n unique assay ids', df['assay'].nunique())
print('n adj<0.05', (df['adj.p.value']<0.05).sum(), 'n adj<0.01', (df['adj.p.value']<0.01).sum(), 'n p<0.05', (df['p.value']<0.05).sum())
# check CI consistency: log(OR) midpoint of log CI
mid = np.exp((np.log(df.l95)+np.log(df.u95))/2)
print('max rel diff OR vs CI geometric midpoint', np.max(np.abs(mid/df.OR-1)))
# p from CI (Wald)
from scipy.stats import norm
se = (np.log(df.u95)-np.log(df.l95))/(2*1.959964)
z = np.log(df.OR)/se
p_w = 2*norm.sf(np.abs(z))
print('corr p vs wald p (log10):', np.corrcoef(np.log10(df['p.value']), np.log10(p_w))[0,1])
df['p_wald']=p_w
print(df[['assay','OR','p.value','p_wald']].head(10))
# find suffix-tagged duplicates
suff = df['assay'].str.extract(r'^(.*?)-(ONCII|CVDII|CVDIII|IMO|INFI|CRE|MET|DEV|NEU|NEX|ODA|CM|ONCIII|CAM|NEURO)$')
df['base'] = np.where(suff[0].notna(), suff[0], df['assay'])
df['suffix'] = suff[1]
print(df['suffix'].value_counts(dropna=False))
g = df.groupby('base')
dups = g.filter(lambda x: len(x)>1).sort_values(['base','rank'])
print('n proteins measured on >1 panel:', dups['base'].nunique(), ' total rows', len(dups))
print(dups[['base','assay','panel','OR','l95','u95','p.value','adj.p.value','rank']].to_string())
df.to_csv('/tmp/work/prot_annot.csv', index=False)
