import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',400); pd.set_option('display.max_columns',40)
allc = pd.read_pickle('/tmp/work/all_contrasts.pkl')
allc['SE'] = np.abs(allc['logFC']/allc['t'])
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl')
bad_any = set(pg.index[pg.nbad>0])
print('genes with abnormal SE in >=1 contrast:', len(bad_any))
W = allc.pivot_table(index='ensembl', columns='Comparison', values='logFC')
T = allc.pivot_table(index='ensembl', columns='Comparison', values='t')
Q = allc.pivot_table(index='ensembl', columns='Comparison', values='adj.P.Val')
SE = allc.pivot_table(index='ensembl', columns='Comparison', values='SE')
ann = allc.drop_duplicates('ensembl').set_index('ensembl')[['symbol','AveExpr','entrez','gene_name']]
W.to_pickle('/tmp/work/W.pkl'); T.to_pickle('/tmp/work/T.pkl'); Q.to_pickle('/tmp/work/Q.pkl'); SE.to_pickle('/tmp/work/SE.pkl'); ann.to_pickle('/tmp/work/ann.pkl')
for tp in ['6','24']:
    c = f'IL33_vs_Nontreated_HUVEC_{tp}_hrs'
    d = pd.DataFrame({'symbol':ann.symbol, 'logFC':W[c], 't':T[c], 'adj':Q[c], 'SE':SE[c], 'bad':[e in bad_any for e in W.index]})
    ok = d[~d.bad]
    print(f'===== HUVEC IL-33 vs vehicle {tp}h: DE (adj<0.05) total {int((d.adj<0.05).sum())}; among clean genes {int((ok.adj<0.05).sum())} (up {int(((ok.adj<0.05)&(ok.logFC>0)).sum())}, down {int(((ok.adj<0.05)&(ok.logFC<0)).sum())}); |logFC|>1 & adj<0.05: up {int(((ok.adj<0.05)&(ok.logFC>1)).sum())} down {int(((ok.adj<0.05)&(ok.logFC<-1)).sum())}')
    print('Top 60 up (clean genes, adj<0.05, by logFC):')
    print(', '.join(f"{s}({l:.1f})" for s,l in ok[ok.adj<0.05].sort_values('logFC', ascending=False).head(60)[['symbol','logFC']].values))
    print('Top 40 down:')
    print(', '.join(f"{s}({l:.1f})" for s,l in ok[ok.adj<0.05].sort_values('logFC').head(40)[['symbol','logFC']].values))
