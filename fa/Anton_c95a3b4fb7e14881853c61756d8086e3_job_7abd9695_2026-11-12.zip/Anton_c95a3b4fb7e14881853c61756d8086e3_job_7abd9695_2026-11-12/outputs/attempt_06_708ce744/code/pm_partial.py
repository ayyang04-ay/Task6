import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
don = pd.read_pickle('/tmp/work/pm_donors2.pkl'); don['Age']=don.Age.astype(float)
for y in ['IL33_endo_v','IL33_vsmc_v','IL33_epi_v']:
    for x in ['NE_dIL5Ra_v','IL5Ra_dNE_v','Trypt_dIL5Ra_v']:
        d = don[[y,x,'Age','group']].dropna().copy()
        for c in [y,x,'Age']: d['r_'+c]=d[c].rank()
        m = smf.ols(f'r_{y} ~ r_{x} + r_Age', data=d).fit()
        m2 = smf.ols(f'r_{y} ~ r_{x} + r_Age + C(group)', data=d).fit()
        print(f'{y} ~ {x} (+age ranks): beta={m.params["r_"+x]:.2f} p={m.pvalues["r_"+x]:.3f} | +group: p={m2.pvalues["r_"+x]:.3f}')
