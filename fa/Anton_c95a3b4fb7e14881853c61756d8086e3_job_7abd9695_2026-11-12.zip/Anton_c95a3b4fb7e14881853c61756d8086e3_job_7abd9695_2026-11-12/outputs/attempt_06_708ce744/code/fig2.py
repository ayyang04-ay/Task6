import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({'font.size':8, 'axes.titlesize':9, 'axes.labelsize':8})
don = pd.read_pickle('/tmp/work/pm_donors2.pkl'); blk = pd.read_pickle('/tmp/work/pm_blocks.pkl')
G = ['COVID_pneu','NonCOVID_pneu','NonPneu_ctrl']; GL = {'COVID_pneu':'COVID+\npneumonia\n(16 donors)','NonCOVID_pneu':'COVID-\npneumonia\n(10)','NonPneu_ctrl':'non-\npneumonia\n(5)'}
C = {'COVID_pneu':'#b2182b','NonCOVID_pneu':'#ef8a62','NonPneu_ctrl':'#4d4d4d'}
rng = np.random.default_rng(1)
fig, axes = plt.subplots(2,3, figsize=(11,7.4))
# A: IL-33 by group, 3 compartments
ax = axes[0,0]
comp = [('IL33_epi_v','basal epithelium'),('IL33_endo_v','endothelium'),('IL33_vsmc_v','vasc. smooth muscle')]
for ci,(v,lab) in enumerate(comp):
    for gi,g in enumerate(G):
        x0 = ci*4 + gi
        vals = don.loc[don.group==g, v].dropna()
        ax.scatter(x0 + rng.uniform(-0.25,0.25,len(vals)), vals, s=14, c=C[g], alpha=0.8, lw=0)
        ax.plot([x0-0.3,x0+0.3],[vals.median()]*2, c='k', lw=1.5)
    kw = stats.kruskal(*[don.loc[don.group==g, v].dropna() for g in G]).pvalue
    ax.text(ci*4+1, 6.15, f'{lab}\nKW p={kw:.2f}', ha='center', fontsize=7)
ax.axhline(5.5, c='grey', ls=':', lw=0.8); ax.text(-0.6, 5.58, 'scale max (5.5)', fontsize=6, ha='left', va='bottom', color='grey')
ax.set_xticks([0,1,2,4,5,6,8,9,10]); ax.set_xticklabels(['C+','C-','ctl']*3, fontsize=7)
ax.set_ylim(-0.2,7.0); ax.set_ylabel('IL-33 IHC score (donor mean of blocks)')
ax.set_title('A. Lung IL-33 is constitutive, not COVID-specific')
# B: by DAD status
ax = axes[0,1]
for ci,(v,lab) in enumerate(comp):
    for k,(flag,col) in enumerate([(True,'#7b3294'),(False,'#a6dba0')]):
        vals = don.loc[don.DAD_ALI==flag, v].dropna()
        x0 = ci*3 + k
        ax.scatter(x0 + rng.uniform(-0.22,0.22,len(vals)), vals, s=14, c=col, alpha=0.85, lw=0)
        ax.plot([x0-0.3,x0+0.3],[vals.median()]*2, c='k', lw=1.5)
    a = don.loc[don.DAD_ALI, v].dropna(); b = don.loc[~don.DAD_ALI, v].dropna()
    ax.text(ci*3+0.5, 6.05, f'{lab}\nMW p={stats.mannwhitneyu(a,b).pvalue:.3f}', ha='center', fontsize=7)
ax.set_xticks([0,1,3,4,6,7]); ax.set_xticklabels(['DAD','no DAD']*3, fontsize=7)
ax.set_ylim(-0.2,6.9); ax.set_ylabel('IL-33 IHC score (donor)')
ax.set_title('B. Vascular IL-33 trends lower in DAD/ALI lungs\n(7/16 COVID vs 0/15 non-COVID have DAD; n.s.)', fontsize=8.5)
# C: eosinophil MBP/EDN label vs pathology
ax = axes[0,2]
pos=0; ticks=[]; tl=[]
for v,lab in [('MBP_v','MBP'),('EDN_v','EDN'),('NE_dIL5Ra_v','Neutrophil\nelastase')]:
    # by label
    lp = don.group!='NonPneu_ctrl'
    for k,(mask,col,name) in enumerate([(lp,'#2166ac','label: pneumonia'),(~lp,'#92c5de','label: non-pneu'),(don.acute_pneu_path,'#b35806','path: acute pneu'),(~don.acute_pneu_path,'#fdb863','path: none')]):
        vals = don.loc[mask, v].dropna(); x0 = pos + k + (0.5 if k>=2 else 0)
        ax.scatter(x0 + rng.uniform(-0.2,0.2,len(vals)), vals, s=9, c=col, alpha=0.85, lw=0, label=name if v=='MBP_v' else None)
        ax.plot([x0-0.28,x0+0.28],[vals.median()]*2,c='k',lw=1.4)
    p1 = stats.mannwhitneyu(don.loc[lp,v].dropna(), don.loc[~lp,v].dropna()).pvalue
    p2 = stats.mannwhitneyu(don.loc[don.acute_pneu_path,v].dropna(), don.loc[~don.acute_pneu_path,v].dropna()).pvalue
    ax.text(pos+0.5, 4.85, f'p={p1:.3f}', ha='center', fontsize=6.5, color='#2166ac'); ax.text(pos+3.0, 4.85, f'p={p2:.3f}', ha='center', fontsize=6.5, color='#b35806')
    ticks.append(pos+1.75); tl.append(lab); pos += 5
ax.set_xticks(ticks); ax.set_xticklabels(tl); ax.set_ylim(-0.3,6.4); ax.set_ylabel('IHC score (donor)')
ax.legend(fontsize=6, loc='upper center', frameon=False, ncol=2, title='blue p: by delivered label; orange p: by autopsy report', title_fontsize=6)
ax.set_title('C. Eosinophil signal does not survive autopsy-based\nre-classification; neutrophil signal does', fontsize=8.5)
# D: pseudo-replication
ax = axes[1,0]
cnt = blk.groupby(['group','SampleID']).size().reset_index(name='n').sort_values(['group','n'], ascending=[True,False])
cols = [C[g] for g in cnt.group]
ax.bar(range(len(cnt)), cnt.n, color=cols)
ax.set_xticks(range(len(cnt))); ax.set_xticklabels(cnt.SampleID, rotation=90, fontsize=5.5)
ax.set_ylabel('histology blocks per donor')
ax.set_title('D. Pseudo-replication: 3 donors = 24 of 49\nCOVID blocks (analysis done per donor)', fontsize=8.5)
for g in G: ax.bar([0],[0],color=C[g],label=GL[g].replace('\n',' '))
ax.legend(fontsize=6, frameon=False)
# E: ceiling
ax = axes[1,1]
for k,(v,lab) in enumerate(comp):
    fr = [ (blk.loc[blk.group==g, v]==5.5).mean()*100 for g in G]
    ax.bar(np.arange(3)+k*4, fr, color=[C[g] for g in G])
    ax.text(k*4+1, 97, lab, ha='center', fontsize=7)
ax.set_xticks([0,1,2,4,5,6,8,9,10]); ax.set_xticklabels(['C+','C-','ctl']*3, fontsize=7); ax.set_ylim(0,105)
ax.set_ylabel('% blocks at scale maximum (5.5)')
ax.set_title('E. Ceiling effect limits IHC as a\nquantitative or selection readout', fontsize=8.5)
# F: discordance table as text
ax = axes[1,2]; ax.axis('off')
rows = [('1905','COVID- pneumonia','no pneumonia; SARS status missing'),('1961','COVID- pneumonia','no pneumonia reported'),('1968','COVID- pneumonia','possible aspiration, no pneumonia'),('1970','COVID- pneumonia','no lung findings reported'),('1956','non-pneumonia','acute pneumonitis'),('1976','non-pneumonia','acute & organizing pneumonia'),('2067','COVID+ pneumonia','mild chronic pneumonitis only'),('2101','COVID+ pneumonia','chronic inflammation/aspiration')]
ax.text(0,1.0,'F. Donors whose label conflicts with their own\n   autopsy report (8 of 31)', fontsize=9, va='top', weight='bold')
y=0.84
ax.text(0,y,'Donor',fontsize=7,weight='bold'); ax.text(0.13,y,'Delivered label',fontsize=7,weight='bold'); ax.text(0.53,y,'Autopsy report (lung)',fontsize=7,weight='bold')
for r in rows:
    y-=0.085; ax.text(0,y,r[0],fontsize=6.8); ax.text(0.13,y,r[1],fontsize=6.8); ax.text(0.53,y,r[2],fontsize=6.8)
ax.text(0,y-0.12,'Other scoring caveats: single reader; IL-33 scores are averages\nof two sub-scores (cell X2 formula) on a scale exceeding the\nstated 0-5 range; IL-33/EPX/EDN/MBP columns hidden in workbook.',fontsize=6.5,va='top',color='#444444')
fig.suptitle('Figure 2. Post-mortem lung IHC (31 donors, 74 blocks): no COVID-specific IL-33 or eosinophil signal at donor level', fontsize=9.5, y=0.995)
fig.tight_layout()
fig.savefig('/tmp/outputs/figures/Fig2_postmortem_lung.png', dpi=200)
print('ok')
