import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({'font.size':8, 'axes.titlesize':9, 'axes.labelsize':8})
P = pd.read_csv('/tmp/work/prot_mapped.csv')
Pg = pd.read_csv('/tmp/work/prot_program.csv')
prog_genes = set(Pg.loc[Pg.prog_up,'gene'])
endo = {'VWF','PTX3','VEGFA','ANGPT2','PLAUR','F3','SELE','FLT1','HGF','SERPINE1','TFPI','TEK','ICAM1','VCAM1','PECAM1','CDH5','KDR','ENG','THBD','ESM1','SELP'}
t2 = {'CCL11','CCL17','CCL24','IL5','CCL13','RNASE3','IL5RA','IL4R','CCL26','IL13RA1'}
fig, axes = plt.subplots(2,2, figsize=(11,8.6))
ax = axes[0,0]
x = np.log2(P.OR); y = -np.log10(P['p.value'])
thr = P.loc[P['adj.p.value']<0.05,'p.value'].max()
cat = np.where(P.assay=='ST2','st2', np.where(P.gene.isin(prog_genes),'prog', np.where(P.gene.isin(endo),'endo', np.where(P.gene.isin(t2),'t2','other'))))
sty = {'other':('#cccccc',6,'other assays'),'prog':('#2166ac',16,'IL-33-induced & AX-1177-reversed in HUVEC (assays)'),'endo':('#1b7837',16,'endothelial activation/injury markers'),'t2':('#762a83',16,'type-2 / eosinophil markers'),'st2':('#d73027',60,'sST2 (IL-33 decoy receptor)')}
for c in ['other','t2','endo','prog','st2']:
    m = cat==c; ax.scatter(x[m], y[m], s=sty[c][1], c=sty[c][0], lw=0, label=f'{sty[c][2]} (n={int(m.sum())})', zorder=3 if c!='other' else 1)
ax.axhline(-np.log10(thr), c='k', ls='--', lw=0.7); ax.text(5.9, -np.log10(thr)+0.08, 'BH q=0.05', fontsize=6.5, ha='right')
for a in ['ST2','HGF','PTX3','IL6','OPG-INFI','IL-18R1','CCL20','vWF','TF','ANGPT2','CXCL6','G-CSF','CX3CL1','TNFRSF9','CXCL10','CCL11-INFI','CCL17','IL5-IMO','RNASE3','VEGFA-INFI','U-PAR','SELE']:
    r = P[P.assay==a]
    if len(r): ax.annotate(a.replace('-INFI','').replace('-IMO',''), (np.log2(r.OR.values[0]), -np.log10(r['p.value'].values[0])), fontsize=6, xytext=(3,1), textcoords='offset points')
ax.set_xlabel('log2 odds ratio per log unit (adjusted for age, sex, NEWS2)'); ax.set_ylabel('-log10 p')
ax.set_xlim(-2,6.2); ax.legend(fontsize=6, frameon=True, loc='lower right', framealpha=0.9)
ax.set_title('A. Severe outcome (ICU/IMV/death, 44/100) vs enrolment serum:\n169 proteins associated; sST2 ranks #2 of 1,094 assays', fontsize=8.5)
# B forest
ax = axes[0,1]
rows = ['ST2','IL6','OPG-INFI','IL-18R1','CCL20','MCP-3','CSF-1','IL1B','TF','CX3CL1','TNF','G-CSF','CXCL10','CXCL5','TNFRSF9','CXCL6','CCL5']
d = P.set_index('assay').loc[rows]
yy = np.arange(len(rows))[::-1]
for yi,(a,r) in zip(yy, d.iterrows()):
    col = '#d73027' if a=='ST2' else ('#2166ac' if r['adj.p.value']<0.05 else '#92c5de')
    ax.plot([np.log2(r.l95), min(np.log2(r.u95),7.0)],[yi,yi], c=col, lw=1.5); ax.scatter(np.log2(r.OR), yi, c=col, s=18, zorder=3)
    ax.text(7.25, yi, f"q={r['adj.p.value']:.3f}", fontsize=6, va='center')
ax.axvline(0,c='k',lw=0.6)
ax.set_yticks(yy); ax.set_yticklabels([r.replace('-INFI','') + ('' if r=='ST2' else '') for r in rows], fontsize=7)
ax.set_xlabel('log2 OR (95% CI) per log unit'); ax.set_xlim(-3,8.3)
a_, b_ = 13, 67; c_, d_ = 145, 842
ax.set_title(f'B. IL-33 endothelial program in serum is not outcome-enriched:\n{a_}/{b_} program proteins vs {c_}/{d_} others associated (Fisher p=0.62)', fontsize=8.5)
ax.text(-2.9, -1.3, 'dark blue: q<0.05; light blue: n.s. (G-CSF, CXCL6, CX3CL1, TNFRSF9, CXCL10: strongest\nin-vitro IL-33 genes, flat in patients); CSF-1 CI truncated (OR 90, narrow-range assay)', fontsize=6, va='top')
ax.set_ylim(-2.6, len(rows))
# C withheld tests reconstruction
ax = axes[1,0]
df = pd.read_csv('/tmp/work/prot_annot.csv'); m=1194
p = df['p.value'].values; adj = df['adj.p.value'].values
own = np.r_[adj[:-1] < adj[1:], True]
mb = p*m/adj - df['rank'].values
pp = p[own]; mm_ = np.round(mb[own])
ax.step(pp, mm_, where='post', c='#b2182b', label='withheld tests with p below x (reconstructed)')
grid = np.logspace(-5,0,200); ax.plot(grid, 100*grid, c='k', ls='--', lw=0.8, label='expected if the 100 withheld tests were null')
ax.set_xscale('log'); ax.set_xlabel('p-value threshold'); ax.set_ylabel('number of withheld assays')
ax.set_ylim(0,105); ax.legend(fontsize=6.5, frameon=False, loc='upper left')
for thr_,lab,off in [(0.00031,'1 withheld assay at p~0.0002-0.0003\n(would rank ~#20 of 1,194)',(-110,55)),(0.01,'~5 with p<0.01 (1 expected)',(-40,30)),(0.05,'~16 with p<0.05 (5 expected)',(-110,40))]:
    v = mm_[pp<=thr_][-1]; ax.scatter([thr_],[v], c='#b2182b', s=14, zorder=3); ax.annotate(lab,(thr_,v), xytext=off, textcoords='offset points', fontsize=6.5, arrowprops=dict(arrowstyle='-', lw=0.5, color='#777777'))
ax.set_title('C. BH denominator is 1,194 but 1,094 assays delivered: ~100 withheld,\nenriched for small p; includes IL-33, IL-4, IL-5, IL-13, TSLP (Inflammation panel)', fontsize=8.5)
# D cross-panel reproducibility
ax = axes[1,1]
dup = P.copy(); dup['base'] = dup['assay'].str.replace(r'-(ONCII|CVDII|CVDIII|IMO|INFI|CRE|ODA|CAM|MET|NEX|NEUI)$','',regex=True)
pairs=[]
for b,g in dup.groupby('base'):
    if len(g)>1:
        g = g.sort_values('panel'); v = np.log(g.OR.values)
        for i in range(len(v)):
            for j in range(i+1,len(v)): pairs.append((b, v[i], v[j]))
pairs = pd.DataFrame(pairs, columns=['protein','a','b'])
ax.scatter(np.exp(pairs.a), np.exp(pairs.b), s=16, c='#4d4d4d')
for _,r in pairs.drop_duplicates('protein').iterrows():
    if r.protein in ['IL6','HGF','OPG','TNFRSF10A','VEGFA','ZBTB16','IL10','AREG','CCL11']: ax.annotate(r.protein,(np.exp(r.a),np.exp(r.b)),fontsize=6,xytext=(3,1),textcoords='offset points')
lim=[0.4,9]; ax.plot(lim,lim,'k:',lw=0.7); ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(lim); ax.set_ylim(lim)
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
for axis in [ax.xaxis, ax.yaxis]:
    axis.set_major_locator(FixedLocator([0.5,1,2,4,8])); axis.set_major_formatter(FixedFormatter(['0.5','1','2','4','8'])); axis.set_minor_locator(NullLocator())
r = np.corrcoef(pairs.a, pairs.b)[0,1]
ax.set_xlabel('OR, panel 1'); ax.set_ylabel('OR, panel 2 (same protein)')
ax.set_title(f'D. Same protein on different panels agrees (26 proteins, {len(pairs)} pairs,\nr={r:.2f} on log OR): assay data are internally consistent', fontsize=8.5)
fig.suptitle('Figure 3. Clinical serum proteomics (100 hospitalised COVID-19 patients, pre-vaccination, single centre; Olink, 13 panels)', fontsize=9.5, y=0.995)
fig.tight_layout()
fig.savefig('/tmp/outputs/figures/Fig3_serum_proteomics.png', dpi=200)
print('ok', thr, r)
