import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',400); pd.set_option('display.max_columns',40)
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
pg = pd.read_pickle('/tmp/work/gene_badSE.pkl'); bad = set(pg.index[pg.nbad>0])
prot = pd.read_csv('/tmp/work/prot_mapped.csv')
# gene-level program
prog = {}
for tp in ['6','24']:
    il = W[f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']; ilq = Q[f'IL33_vs_Nontreated_HUVEC_{tp}_hrs']
    b = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; bq = Q[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    up = (ilq<0.05)&(il>1)&(bq<0.05)&(b<-1)
    dn = (ilq<0.05)&(il<-1)&(bq<0.05)&(b>1)
    prog[f'up{tp}'] = set(W.index[up]) - bad
    prog[f'dn{tp}'] = set(W.index[dn]) - bad
    print(tp, 'IL33-up & C47-reversed:', len(prog[f'up{tp}']), '  IL33-down & C47-reversed:', len(prog[f'dn{tp}']))
up_any = prog['up6'] | prog['up24']; dn_any = prog['dn6'] | prog['dn24']
sym_up = set(ann.symbol.loc[list(up_any)].dropna()); sym_dn = set(ann.symbol.loc[list(dn_any)].dropna())
# HGMEC blockade-defined
hg = set()
for tp in ['6','24']:
    b = W[f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp}hrs']; bq = Q[f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp}hrs']
    hg |= set(W.index[(bq<0.05)&(b<-1)]) - bad
sym_hg = set(ann.symbol.loc[list(hg)].dropna())
P = prot[prot.in_rnaseq].copy()
P['prog_up'] = P.gene.isin(sym_up); P['prog_dn']=P.gene.isin(sym_dn); P['hgmec_block']=P.gene.isin(sym_hg)
P['sev'] = (P['adj.p.value']<0.05)&(P.OR>1)
P['z'] = np.sign(np.log(P.OR))*stats.norm.isf(P['p.value']/2)
# collapse duplicated proteins: keep best p per gene
Pg = P.sort_values('p.value').drop_duplicates('gene')
print('Unique measured proteins with RNA-seq gene:', len(Pg))
for col in ['prog_up','hgmec_block','prog_dn']:
    a = ((Pg[col])&(Pg.sev)).sum(); b_ = ((Pg[col])&(~Pg.sev)).sum(); c = ((~Pg[col])&(Pg.sev)).sum(); d = ((~Pg[col])&(~Pg.sev)).sum()
    OR, p = stats.fisher_exact([[a,b_],[c,d]])
    mw = stats.mannwhitneyu(Pg.loc[Pg[col],'z'], Pg.loc[~Pg[col],'z'])
    print(f'{col}: in-program proteins {a+b_}, severity-assoc {a} ({100*a/max(a+b_,1):.0f}%) vs others {c}/{c+d} ({100*c/(c+d):.0f}%); Fisher OR={OR:.2f} p={p:.3g}; MW z-shift p={mw.pvalue:.3g}')
print()
print(Pg[Pg.prog_up].sort_values('p.value')[['assay','gene','OR','l95','u95','p.value','adj.p.value','hgmec_block']].to_string())
print()
print('HGMEC-blockade (not HUVEC prog) proteins:')
print(Pg[Pg.hgmec_block & ~Pg.prog_up].sort_values('p.value')[['assay','gene','OR','p.value','adj.p.value']].to_string())
Pg.to_csv('/tmp/work/prot_program.csv', index=False)
pd.Series(sorted(sym_up)).to_csv('/tmp/work/il33_program_up_symbols.csv', index=False)
