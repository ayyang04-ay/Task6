import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter

# ---------- S1 data integrity log
S1 = pd.DataFrame([
 ['DI-01','AX-1177_rnaseq_contrasts.xlsx; AX-1177_rnaseq_huvec_il33.xlsx','205 genes carry statistically impossible values (implied SE = |logFC/t| > 3, up to 16,536; 281 genes at a stricter SE > 1.6 cut-off, e.g. ICAM1 at ~1.75 in HUVEC contrasts) versus 0.02-1.3 for the bulk of genes (bimodal, Fig 4A). Headline results are identical under either cut-off. 76 genes are affected in all 26 contrasts, including IL1RL1 (ST2), SELE, VCAM1, CXCL8, CXCL1, CCL2, PTX3, PTGS2, VWF, CDH5, PECAM1, KDR, CD93 and GAPDH.','A single voom/limma fit on log-CPM (df ~85 for every contrast) cannot produce SE > ~20. Fold-changes of affected genes are biologically coherent (e.g. SELE +11.2 with IL-33, -11.0 with AX-1177, ~0 in every antibody-alone contrast) but their t/p/q are unusable.','All inference in this review uses the ~26,000 genes with valid statistics. Affected canonical genes (E-selectin, VCAM-1, IL-8, IL1RL1/ST2) are cited descriptively only. Whether IL-33 induces IL1RL1 (sST2) in endothelium, which matters for sST2 as a PD marker, is unresolved.','Retrieve count matrix and fitted model from programme archive; re-fit (ideally per cell line); re-issue affected genes.'],
 ['DI-02','AX-1177_rnaseq_contrasts.xlsx','Sheets named "6h" and "24h" each contain all 24 contrasts (12 at 6 h, 12 at 24 h); the two sheets are identical (0 differences in 629,040 rows x 6 numeric columns). The 6h sheet dimension metadata reports 1,048,576 rows (Excel max), but only 629,040 data rows exist (no truncation).','Verified by row-level comparison.','None on results; risk of analysts reading only one sheet and missing contrasts.','Rename sheets; deliver one sheet or one sheet per timepoint.'],
 ['DI-03','AX-1177_rnaseq_contrasts.xlsx','No IL-33-vs-control contrast for HGMEC; HGMEC has no vehicle arm (methods). The IL-33 effect in HGMEC cannot be estimated from delivered data; only AX-1177 blockade of IL-33 is available.','Contrast list; methods section 3.','HGMEC response magnitude vs HUVEC and completeness of blockade in HGMEC are confounded.','Deliver IL33 vs IC119 (HGMEC); add vehicle arm in future designs.'],
 ['DI-04','AX-1177_rnaseq_huvec_il33.xlsx','Sheet names say "Vehicle"; Comparison column says "Nontreated". AveExpr is pooled over all 114 libraries (4 cell types) so it does not indicate expression in a given cell line.','Column values; methods section 5.','Low; AveExpr must not be used as an HUVEC/HGMEC expression filter.','Confirm comparator identity; supply per-cell-line expression.'],
 ['DI-05','AX-1177_serum_proteomics.xlsx','Delivered adjusted p-values are reproduced exactly only if BH was applied to 1,194 tests; 1,094 are delivered. ~100 tested assays were withheld after adjustment. Reconstruction shows the withheld set is enriched for small p: ~16 with p<0.05 (5 expected if null; binomial p=4e-5), ~5 with p<0.01, one at p~0.0002-0.0003 (would rank ~#20).','adj = p x 1194 / rank for top-ranked rows (HGF, HGF-ONCII, NUCB2...); step-down reconstruction gives integer counts of missing tests (Fig 3C).','The drug target IL-33 and IL-4, IL-5, IL-13, TSLP, IL-2, IL-1a, IL-2RB, IL-20, IL-22RA1, IL-24, LIF, NRTN, beta-NGF, FGF-23 (15 Inflammation-panel assays) are absent (IL-5 is still available from the Immune Response panel). 13 x 92 = 1,196 panel assays; 1,194 in the BH family, so at least 100 of the 102 undelivered assays were tested. Some undelivered assays are outcome-associated. No conclusion about serum IL-33 is possible.','Retrieve all 1,194 results and per-patient NPX incl. below-LOD handling.'],
 ['DI-06','AX-1177_serum_proteomics.xlsx','"Biomarker values were log transformed": Olink NPX is already log2; OR "per log unit" is scale-ambiguous. Per-unit ORs are not comparable across assays (e.g. CSF-1 OR 90 reflects a narrow-range assay).','Methods section 6; OR distribution.','Effect sizes cannot be ranked; ranking here uses p-values.','Re-express as OR per SD and report incremental AUC over NEWS2.'],
 ['DI-07','AX-1177_serum_proteomics.xlsx','26 proteins measured on >1 panel (56 rows) are not reconciled and are all counted in the BH family. Cross-panel agreement is high (r=0.96 on log OR), which supports technical reliability.','Suffix parsing and pairwise comparison (Fig 3D).','Minor over-correction; duplicates are not independent confirmations.','Collapse to unique proteins for inference.'],
 ['DI-08','AX-1177_postmortem_lung.xlsx','8 of 31 donors have a disease label that conflicts with their own autopsy report (1905, 1961, 1968, 1970 labelled pneumonia without pneumonia; 1956, 1976 labelled non-pneumonia with acute pneumonitis/pneumonia; 2067, 2101 labelled COVID pneumonia with only chronic changes). SARS-CoV-2 status missing for 1905.','Manual reading of the Pathology field.','The apparent eosinophil (EDN/MBP) elevation in pneumonia disappears after re-classification; IL-33 conclusions unchanged.','Independent blinded pathology re-classification.'],
 ['DI-09','AX-1177_postmortem_lung.xlsx','IL-33 IHC columns (X-Z) and EPX/EDN/MBP/2D7 columns are hidden in the workbook. Cell X2 holds the formula =(2+4.5)/2, i.e. IL-33 scores are averages of two sub-scores; values reach 5.5, above the stated 0-5 scale. Numeric EPX/NE/tryptase columns equal the text score +0.5 (except 0). Single reader; blinding not stated.','openpyxl inspection.','Ordinal, ceiling-limited scores (endothelial IL-33 at maximum in 53% of blocks). Analysed non-parametrically at donor level.','Document scoring algorithm; second blinded reader; digital image analysis.'],
 ['DI-10','AX-1177_postmortem_lung.xlsx','Blocks are not independent: 3 COVID donors contribute 24 of 49 COVID blocks. Donor-level fields are recorded on the first block only (and on a non-first block for 2040 and 2045 notes; block 1B precedes 1A for 1159).','Block counts per donor.','Block-level statistics are pseudo-replicated; all inference here is per donor.','Analyse per donor or with mixed models.'],
 ['DI-11','AX-1177_postmortem_lung.xlsx','IL-5Ra scored on duplex sections tracks neutrophil elastase (rho 0.76) and not EPX (rho 0.00), while the two IL-5Ra duplex readings agree with each other (rho 0.93).','Block-level Spearman correlations.','IL-5Ra duplex scores are not a valid eosinophil readout as scored.','Review chromogen separation/scoring.'],
 ['DI-12','AX-1177_methods_annex.pdf (design)','Only reduced IL-33 tested (AX-1177 is claimed to bind reduced and oxidised forms); single AX-1177 concentration (~41-fold molar excess over IL-33); concurrent addition, no pre-incubation; single-donor HUVEC (P2) and HGMEC (P5); no IL-33 stimulation of epithelial cells (A549/MCF7 received antibody only, with DMSO/PBS comparators that are not appropriate controls for an antibody). Affinity/potency data held in the biologics file were not provided.','Methods sections 1-3.','Potency, oxidised-form activity (the claimed differentiator), donor generalisability and epithelial pharmacology are untested in this package.','Pull biologics file; run dose-response with both IL-33 forms in multi-donor lung cells.'],
 ['DI-13 (minor)','AX-1177_rnaseq_contrasts.xlsx; AX-1177_rnaseq_huvec_il33.xlsx','Delivered p-values deviate from the t-distribution prediction (df 85.1) only for |t| > 5.5 (p < 5e-7); up to ~190 genes per contrast.','Deviation disappears for moderate t; pattern consistent with gene-specific prior df (robust empirical Bayes).','None: all affected genes are far beyond any significance threshold.','Confirm eBayes settings (robust=TRUE?) in the methods.'],
], columns=['ID','File','Finding','Evidence','Impact on conclusions','Action'])

# ---------- S2 post-mortem donor table
don = pd.read_pickle('/tmp/work/pm_donors2.pkl').copy()
don = don.reset_index().rename(columns={'index':'SampleID'})
keep = ['SampleID','group','Age','Gender','SARS','Notes','n_blocks','acute_pneu_path','DAD_ALI','thromboemb','IL33_epi_v','IL33_endo_v','IL33_vsmc_v','EPX_v','EDN_v','MBP_v','C2D7_v','IL5Ra_dNE_v','NE_dIL5Ra_v','IL5Ra_dTrypt_v','Trypt_dIL5Ra_v','HE_eos_v']
S2 = don[keep].rename(columns={'group':'delivered_label','acute_pneu_path':'acute_pneumonia_per_autopsy','DAD_ALI':'DAD_or_ALI_per_autopsy','thromboemb':'thromboemboli_per_autopsy','IL33_epi_v':'IL33_basal_epith (donor mean)','IL33_endo_v':'IL33_endothelium','IL33_vsmc_v':'IL33_VSMC','EPX_v':'EPX','EDN_v':'EDN','MBP_v':'MBP','C2D7_v':'2D7_basophil','IL5Ra_dNE_v':'IL5Ra_duplexNE','NE_dIL5Ra_v':'neutrophil_elastase','IL5Ra_dTrypt_v':'IL5Ra_duplexTryptase','Trypt_dIL5Ra_v':'tryptase','HE_eos_v':'HE_eos_fraction_blocks'}).round(3)
rna = pd.read_pickle('/tmp/work/pm_blocks.pkl'); rmap = rna[rna.TissueRNA.notna()].set_index('SampleID')['TissueRNA'].to_dict()
S2['archived_tissue_RNA_id'] = S2.SampleID.map(rmap)
S3a = pd.read_csv('/tmp/work/pm_donor_stats.csv')
S3b = pd.read_csv('/tmp/work/pm_sensitivity.csv')

# ---------- S4 IL-33 program
S4 = pd.read_csv('/tmp/work/il33_program.csv')
# ---------- S5 serum
P = pd.read_csv('/tmp/work/prot_mapped.csv'); Pg = pd.read_csv('/tmp/work/prot_program.csv')
prog = set(Pg.loc[Pg.prog_up,'gene'])
S5 = P[['panel','assay','gene','OR','l95','u95','p.value','adj.p.value','composite_endpoint_0','composite_endpoint_1']].copy()
S5 = S5.rename(columns={'composite_endpoint_0':'frac_below_LOD_no_event(n=56)','composite_endpoint_1':'frac_below_LOD_event(n=44)','gene':'mapped_gene'})
S5['IL33_endothelial_program_gene'] = S5.mapped_gene.isin(prog)
S5['rank_by_p'] = np.arange(1,len(S5)+1)
# ---------- S6 biomarker matrix + roles
M = pd.read_csv('/tmp/work/biomarker_matrix.csv')
roles = {
 'sST2':('Prognostic enrichment (baseline, enrolment serum). Candidate PD only if IL-33 is shown to drive sST2 (RNA-seq IL1RL1 statistics invalid) and assay interference by drug-IL-33-sST2 complexes is excluded.','YES - enrichment/stratification factor in first-in-patient study, after absolute immunoassay + pre-specified cut-off + external validation','Enrolment, pre-dose'),
 'IL-6':('PD/response panel member (IL-33-inducible and AX-1177-reversible in vitro; prognostic in serum); not IL-33-specific in vivo.','YES - exploratory PD panel (placebo-referenced)','Pre-dose; early on-treatment (<=24 h); day 3-5'),
 'CCL20':('PD/response panel member (as IL-6).','YES - exploratory PD panel','Pre-dose; <=24 h; day 3-5'),
 'OPG':('PD/response panel member (as IL-6).','YES - exploratory PD panel','Pre-dose; <=24 h; day 3-5'),
 'IL-18R1':('PD/response panel member (as IL-6).','YES - exploratory PD panel','Pre-dose; <=24 h; day 3-5'),
 'MCP-3/CCL7':('PD/response panel member (reversible in both EC types; prognostic).','YES - exploratory PD panel','Pre-dose; <=24 h'),
 'Tissue factor':('Mechanistic procoagulant readout (IL-33 +5.6 log2, reversed); borderline prognostic (q=0.051).','YES - exploratory PD/mechanism','Pre-dose; <=24 h'),
 'GM-CSF':('Most IL-33-specific endothelial readout in vitro (+10.3 log2, fully reversed); not on delivered panels.','NO (ex vivo/in vitro PD assay only)','6 h post-stimulation (primary), 24 h'),
 'CXCL6':('Highly IL-33-specific in vitro; flat vs outcome in serum.','NO for selection; ex vivo PD','6 h'),
 'G-CSF':('Highly IL-33-specific in vitro; flat vs outcome in serum.','NO for selection; ex vivo PD','6 h'),
 'Fractalkine':('Highly IL-33-specific in vitro; n.s. vs outcome.','NO for selection; ex vivo PD','6 h'),
 '4-1BB':('Highly IL-33-specific in vitro; flat vs outcome.','NO for selection; ex vivo PD','6 h'),
 'CXCL10':('IL-33-induced, partly escapes blockade by 24 h (ISG tier); flat vs outcome.','NO','6 h / 24 h'),
 'E-selectin':('Largest IL-33 fold-change in vitro but statistics invalid; serum q=0.09.','Exploratory only after RNA-seq re-fit','-'),
 'VCAM-1':('In vitro statistics invalid; serum flat.','NO','-'),
 'ICAM-1':('In vitro statistics invalid; serum n.s.','NO','-'),
 'IL-8':('In vitro statistics invalid; serum q=0.023.','Exploratory only after re-fit','-'),
 'PTX3':('Strong prognostic marker (q=0.012); in vitro statistics invalid.','YES - prognostic/disease-activity covariate','Enrolment'),
 'vWF':('Endotheliopathy marker, prognostic (q=0.050); in vitro fold-change ~0 with IL-33 (statistics invalid for VWF).','YES - disease-activity covariate / exploratory efficacy','Enrolment; day 3-5'),
 'ANGPT2':('Endotheliopathy marker, borderline prognostic; not IL-33-regulated in vitro.','YES - disease-activity covariate','Enrolment'),
 'Thrombomodulin':('IL-33 lowers THBD (-1.0 log2, q=2e-10), AX-1177 restores; serum n.s.','NO (mechanistic in vitro only)','6 h'),
 'PAI-1':('IL-33-induced in vitro (+1.7); serum borderline.','Exploratory','-'),
 'HGF':('Top prognostic protein (q=0.004) but not IL-33-regulated in vitro.','YES - prognostic covariate only','Enrolment'),
 'EDN (RNASE3)':('No robust tissue or serum eosinophil signal.','NO','-'),
 'IL-33':('Target engagement (free/total IL-33, IL-33:sST2 complex) - withheld from serum delivery; needs drug-tolerant assays.','YES - Phase 1 PD/target engagement once assays exist; selection only if Gate 0 shows association','Pre-dose; post-dose PK/PD schedule'),
 'IL-1beta':('IL-33-inducible and reversible; prognostic (q=0.046); not IL-33-specific.','Exploratory PD','Pre-dose; <=24 h'),
 'Amphiregulin':('Prognostic (q=0.03) but only weakly IL-33-responsive in HUVEC.','Exploratory','-'),
}
M['proposed_role'] = M.marker.map(lambda m: roles.get(m,('','',''))[0]); M['into_patients?'] = M.marker.map(lambda m: roles.get(m,('','',''))[1]); M['sampling'] = M.marker.map(lambda m: roles.get(m,('','',''))[2])
S6 = M
# ---------- S7 invalid-statistics genes
S7 = pd.read_csv('/tmp/work/bad_genes.csv').rename(columns={'sym':'symbol','nbad':'n_contrasts_affected_of_26','ave':'AveExpr_all114'})
# ---------- S8 null calibration & S9 contrast QC
S8 = pd.read_csv('/tmp/work/null_calibration.csv')
S9 = pd.read_csv('/tmp/work/contrast_qc.csv')
# ---------- S10 plan
S10 = pd.DataFrame([
 ['Gate 0 - data recovery (no new experiments)','Weeks 0-6','(a) Retrieve all 1,194 Olink results + per-patient NPX, incl. IL-33, IL-4/5/13, TSLP; re-model as OR per SD with incremental AUC over NEWS2, and add renal/cardiac covariates if recorded. (b) Retrieve RNA-seq counts; re-fit; resolve the 205 invalid genes, especially IL1RL1 isoforms (sST2 vs ST2L), SELE, VCAM1, CXCL8. (c) Blinded re-classification of post-mortem cases; second reader for IL-33.','Is the IL-33 axis (not just sST2) associated with severity? Does IL-33 drive sST2 expression in endothelium?','GO if serum IL-33 (level or detectability) or the IL-33:sST2 relationship tracks outcome independently of NEWS2; if IL-33 is undetectable in most samples, treat it as uninformative and rely on Gate 1. NO-GO if IL-33 is measurable and clearly null while sST2 associates only as a generic inflammation marker (loses significance after adjusting for IL-6/CRP-type markers).'],
 ['Gate 1a - in situ test in archived lung RNA','Months 1-3','Profile the 22 archived lung RNAs (Zr4940; 9 COVID, 9 non-COVID pneumonia, 4 controls) by RNA-seq; score the 454-gene AX-1177-reversible IL-33 endothelial program; compare by autopsy-confirmed DAD/acute pneumonia; correlate with endothelial IL-33 IHC.','Is IL-33 signalling active in the diseased human lung, and specifically in DAD?','GO if the program score is higher in DAD/COVID lungs than in non-COVID pneumonia and controls, with a pre-specified effect (e.g. >=0.5 SD). NO-GO if no difference.'],
 ['Gate 1b - pharmacology that matters','Months 1-4','Dose-response (IC50) of AX-1177 against IL-33red and IL-33ox in primary lung microvascular EC and primary bronchial epithelial ALI (>=3 donors each), with pre-incubation, concurrent and delayed (therapeutic) addition; readouts at 6 h (primary) and 24 h: GM-CSF, CXCL6, CCL20, IL-6, TF, THBD, sST2 protein. Include a marketed-class benchmark if one is available.','Is AX-1177 potent and differentiated (oxidised-form neutralisation)? How large is the treatment window after IL-33 exposure?','GO if sub-nM potency against both forms and ox-IL-33 effects neutralised; NO-GO if ox-IL-33 is not neutralised (the differentiation claim fails).'],
 ['Gate 1c - infection model + antiviral safety','Months 2-5','Virus-infected airway epithelium (ALI; SARS-CoV-2 and at least one of influenza/RSV) -> conditioned medium or co-culture with lung microvascular EC, +/- AX-1177. Measure EC activation (program score, TF/THBD), released IL-33, viral titre and ISG responses.','Does endogenous IL-33 released by infected epithelium drive endothelial activation, and does blocking it impair antiviral defence?','GO if a meaningful share (pre-specify, e.g. >=30%) of infection-induced EC activation is AX-1177-reversible AND viral control is not impaired. NO-GO otherwise.'],
 ['Gate 2 - clinical biomarker validation + in vivo','Months 4-12','External cohort (vaccinated era; COVID + influenza/RSV hospitalised): sST2, IL-33 species, endothelial panel at enrolment; 30-day composite; pre-specified cut-off. Develop drug-tolerant IL-33 total/free and IL-33:sST2 complex assays. Check species cross-reactivity, then run PK/PD and a viral pneumonia efficacy model with endothelial/coagulation read-outs.','Is there a reproducible, biomarker-defined population, and is there in vivo efficacy?','GO to IND-enabling work only if sST2 (or an IL-33-axis marker) replicates prognostically across viruses AND in vivo efficacy is shown.'],
], columns=['Stage','Indicative timing','Work','Decision question','Go / no-go criterion'])

sheets = [('README',None),('S1_data_integrity',S1),('S2_postmortem_donors',S2),('S3a_pm_stats_labels',S3a),('S3b_pm_stats_autopsy',S3b),('S4_IL33_EC_program',S4),('S5_serum_all_assays',S5),('S6_biomarker_matrix',S6),('S7_invalid_stat_genes',S7),('S8_null_calibration',S8),('S9_contrast_QC',S9),('S10_gated_plan',S10)]
readme = pd.DataFrame({'Sheet':[s for s,_ in sheets[1:]],'Contents':[
 'Data-integrity and design issues, evidence, impact on conclusions, action',
 'Donor-level post-mortem table (blocks averaged per donor), with autopsy-based re-classification and archived RNA IDs',
 'Donor-level group comparisons using delivered labels (Kruskal-Wallis / Mann-Whitney; block-level p shown for contrast only)',
 'Donor-level comparisons using autopsy-based classification (acute pneumonia; DAD/ALI; COVID vs non-COVID within confirmed pneumonia)',
 'IL-33 endothelial program: 454 genes induced by IL-33 in HUVEC and reversed by AX-1177 (isotype-controlled) at 6 h and/or 24 h; valid-statistics genes only',
 'All 1,094 delivered serum assays with mapped gene symbol, below-LOD fractions and IL-33-program flag',
 'Candidate biomarkers: in vitro induction/blockade, serum association, proposed role, patient readiness, sampling',
 'Genes with statistically impossible SE in >=1 contrast (n=205)',
 'Derived inert-vs-inert contrasts used as background for antibody-alone effects (approximate t from delivered SEs)',
 'Per-contrast QC: implied df, BH reproducibility, sign consistency, SE anomalies, DE counts',
 'Proposed gated plan with decision questions and go/no-go criteria']})
out = '/tmp/outputs/AX-1177_supporting_tables.xlsx'
with pd.ExcelWriter(out, engine='openpyxl') as xw:
    readme.to_excel(xw, sheet_name='README', index=False)
    for name, df in sheets[1:]:
        df.to_excel(xw, sheet_name=name, index=False)
wb = load_workbook(out)
for ws in wb.worksheets:
    for c in ws[1]:
        c.font = Font(bold=True); c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    for i,col in enumerate(ws.columns, start=1):
        maxlen = max((len(str(c.value)) if c.value is not None else 0) for c in list(col)[:200])
        ws.column_dimensions[get_column_letter(i)].width = min(max(10, maxlen*0.9), 70)
    if ws.title in ('S1_data_integrity','S10_gated_plan','S6_biomarker_matrix','README'):
        for row in ws.iter_rows(min_row=2):
            for c in row: c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'A2'
wb.save(out)
print('saved', out)
