import pandas as pd, numpy as np
blk = pd.read_pickle('/tmp/work/pm_blocks.pkl')
don = pd.read_pickle('/tmp/work/pm_donors2.pkl')
r = blk[blk.TissueRNA.notna()][['SampleID','Block','TissueRNA','group']]
print(r.to_string())
print(r.groupby('group').SampleID.nunique(), '\n total blocks with RNA:', len(r), ' donors:', r.SampleID.nunique())
ids = sorted(r.TissueRNA, key=lambda s:int(s.split('_')[1])); print(ids)
