import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',200)
df = pd.read_csv('/tmp/work/prot_mapped.csv')
endo = ['VWF','PTX3','VEGFA','TEK','ANGPT1','ANGPT2','ESM1','SELE','SELP','VCAM1','ICAM1','ICAM2','PECAM1','THBD','PLAT','PLAU','PLAUR','SERPINE1','F3','TFPI','EDN1','KDR','FLT1','FLT4','ENG','CDH5','MCAM','EDIL3','ROBO4','NOS3','ADM','HGF','ANGPTL4','CCN1','CCN2','SDC1','F11R','JAM2','CLEC14A','EGFL7','CD93','CXCL12','THBS1','THBS2','TIMP1','MMP9','LGALS3','GDF15','IL1RL1']
sel = df[df.gene.isin(endo)].sort_values('p.value')
print(sel[['assay','gene','panel','OR','l95','u95','p.value','adj.p.value']].to_string())
