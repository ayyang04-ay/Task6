# AX-1177 portfolio audit: deliverables

| File | What it is |
|---|---|
| `AX-1177_committee_brief.pdf` / `.html` / `.md` | The committee brief: recommendation, evidence scorecard, indication, forward plan (biomarkers, sampling timepoints, gates and kill criteria), findings by dataset, data-integrity log, and what was considered and ruled out. The three formats have the same content |
| `figures/` | Fig 1 neutralisation (HUVEC); Fig 2 serum volcano; Fig 3 in vitro↔serum bridge; Fig 4 RNA-seq SE anomaly; Fig 5 post-mortem (donor level); Fig 6 IL-33 programme heatmap with serum ORs |
| `tables/key_numbers.json` | Every number cited in the brief, as computed |
| `tables/rnaseq_*` | Contrast summary, neutralisation summary, per-gene IL-33 programme with derived contrasts and % inhibition, implausible-SE genes, antibody-alone reproducibility, tiny-SE artefacts |
| `tables/il33_endothelial_signature_10genes.csv` | Proposed 10-gene signature for the tissue gate (G2) and the ex vivo serum bioassay (G1) |
| `tables/serum_*` | Marker groups (IL-33 axis, type-2, endothelial, neutrophil, organ injury), the in vitro↔serum bridge, cross-panel duplicates |
| `tables/postmortem_*` | Donor-level dataset, donor-level tests (delivered labels and pathology-verified groups), label-vs-autopsy reconciliation, data-quality log |
| `analysis/` | Reproducible pipeline: `run_all.sh` runs `rnaseq_analysis.py`, `serum_analysis.py`, `postmortem_analysis.py`, `figure_program_heatmap.py`, `build_html.py` and `build_pdf.py` (helpers: `common.py`, `olink_map.py`). It reads the delivered files read-only from `/tmp/world/filesystem` |

**Scope note:** all conclusions rest on the four delivered files. Nothing external was used as evidence. Affinity and potency data for AX-1177 are held in the programme biologics file and are not part of this package.
