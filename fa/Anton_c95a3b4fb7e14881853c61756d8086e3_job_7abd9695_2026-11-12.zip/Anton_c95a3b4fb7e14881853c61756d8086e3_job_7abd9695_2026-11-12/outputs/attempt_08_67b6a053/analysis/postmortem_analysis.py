"""AX-1177 post-mortem lung IHC: donor-level re-analysis.

The unit of analysis is the DONOR (blocks are not independent; 3 donors contribute 24 of 49 COVID+ blocks).
Scores are ordinal (0-5 declared; several columns contain values of 5.5); non-parametric tests on donor means.
Group labels are checked against the free-text autopsy diagnoses delivered in the same file.
"""
import re, numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from common import load_postmortem, VERIFIED, record, TAB, FIG

df = load_postmortem()
record('pm_n_blocks', len(df)); record('pm_n_donors', int(df['sample'].nunique()))
bl = df.groupby('grp').size().to_dict(); dn = df.groupby('grp')['sample'].nunique().to_dict()
record('pm_blocks_by_label', bl); record('pm_donors_by_label', dn)
top3 = df[df.grp == 'COVID+ pneumonia'].groupby('sample').size().sort_values(ascending=False).head(3)
record('pm_top3_covidpos_donor_blocks', top3.to_dict())

# ---------------------------------------------------------------- 1. Data-quality log
issues = []
def add(kind, where, detail): issues.append(dict(issue=kind, location=where, detail=detail))
for c, lab in [('IL33_epi', 'IL-33 basal epithelium'), ('IL33_endo', 'IL-33 endothelium'), ('NE_d', 'Neutrophil elastase (derived col V)')]:
    n = int((df[c + '_n'] > 5).sum()); add('value outside declared 0-5 scale', lab, f'{n} blocks scored 5.5')
add('formula stored in data cell', 'IL-33 basal epithelium, Excel row 2 (donor 1130)', "'=(2+4.5)/2' -> 3.25; implies the IL-33 score is an average of sub-scores on an undocumented scale")
for c in ['EDN','MBP','D7_2','IL5Ra_NE','NE','IL5Ra_TRYP','TRYPTASE','IL33_epi']:
    n = int(df[c].astype(str).str.strip().isin(['ND', 'N/A']).sum())
    if n: add('not done / not available', c, f'{n} blocks')
add('score stored as text', 'EPX..tryptase columns', "scores stored as '1+','4+ ' etc. (12 with trailing spaces)")
for a, b_ in [('EPX', 'EPX_d'), ('NE', 'NE_d'), ('TRYPTASE', 'TRYP_d')]:
    ok = np.isclose(np.where(df[a + '_n'] > 0, df[a + '_n'] + 0.5, 0.0), df[b_ + '_n']) | (df[a + '_n'].isna() & df[b_ + '_n'].isna())
    add('redundant derived column', f'{b_} (cols U-W)', f'equals {a} score + 0.5 when >0 in {int(ok.sum())}/{len(df)} blocks; pushes values to 5.5')
add('merged cell spans two donors', 'SARS-CoV-2 status, J12:J13', "donor 1905 has no status of its own (inherits 'neg' from donor 1910 via the merge)")
for s in ['2040', '2045']:
    add('donor-level field on non-first block', f'Notes (col AA), donor {s}', 'contradicts annex: donor fields are said to be on the first block')
add('mixed identifier types', 'Sample ID', 'stored as text for some donors and integer for others')
add('duplex scoring artefact', 'IL-5Ra (duplex with NE / with tryptase)', 'IL-5Ra score tracks the partner stain, not eosinophil granule proteins (see table)')

# ---------------------------------------------------------------- 2. Donor-level table
sc = ['HE_eos_n', 'EPX_n', 'EDN_n', 'MBP_n', 'D7_2_n', 'IL5Ra_NE_n', 'NE_n', 'IL5Ra_TRYP_n', 'TRYPTASE_n', 'IL33_epi_n', 'IL33_endo_n', 'IL33_vsm_n']
don = df.groupby('sample').agg({**{c: 'mean' for c in sc}, 'grp': 'first', 'age': 'first', 'sex': 'first', 'notes': 'first', 'pathology': 'first',
                                'tissue_rna': lambda s: ';'.join(s.dropna().astype(str))})
don['n_blocks'] = df.groupby('sample').size()
don['verified_group'] = don.index.map(VERIFIED)
don['batch'] = df.groupby('sample').block.first().str.slice(0, 8)
kw = {'DAD/ALI': r'diffuse alveolar damage|hyalin|acute lung injury', 'bronchopneumonia': r'bronchopneumonia|bronchpneumonia',
      'acute/organizing pneumonia or pneumonitis': r'acute (?:and organizing )?pneumoni|organizing pneumonia|pneumonitis|consolidation',
      'thromboemboli': r'thromb|embol'}
for k, pat in kw.items(): don[k] = don.pathology.astype(str).str.contains(pat, flags=re.I, regex=True)
don.drop(columns=['pathology']).to_csv(f'{TAB}/postmortem_donor_level.csv')

lab_vs_path = don[['grp', 'verified_group', 'DAD/ALI', 'bronchopneumonia', 'acute/organizing pneumonia or pneumonitis', 'thromboemboli', 'n_blocks']].copy()
lab_vs_path['first_lung_diagnoses'] = don.pathology.astype(str).map(lambda t: ' | '.join([ln.strip() for ln in t.split('\n') if re.search(r'lung|pneumon|pulmon|alveol|bronch|emphysem|embol', ln, re.I) and not re.search(r'valve', ln, re.I)][:3]))
disc = lab_vs_path[((lab_vs_path.grp == 'COVID- pneumonia') & (lab_vs_path.verified_group == 'No acute lung infection/injury')) |
                   ((lab_vs_path.grp == 'COVID- non-pneumonia') & (lab_vs_path.verified_group != 'No acute lung infection/injury')) |
                   ((lab_vs_path.grp == 'COVID+ pneumonia') & (lab_vs_path.verified_group == 'COVID+ no acute pneumonia in report'))]
lab_vs_path.to_csv(f'{TAB}/postmortem_label_vs_pathology.csv')
record('pm_label_pathology_discordant_donors', disc.index.tolist())
for s, r in disc.iterrows():
    add('group label inconsistent with autopsy diagnoses', f'donor {s} labelled {r.grp}', r.first_lung_diagnoses[:200] or 'no acute lung diagnosis listed')
pd.DataFrame(issues).to_csv(f'{TAB}/postmortem_data_quality_log.csv', index=False)
te = don.groupby('grp')['thromboemboli'].agg(['sum', 'count']); record('pm_thromboemboli_by_label', te.to_dict())

# ---------------------------------------------------------------- 3. Tests
lab_order = ['COVID+ pneumonia', 'COVID- pneumonia', 'COVID- non-pneumonia']
rows = []
for c in sc:
    a = [don.loc[don.grp == g, c].dropna() for g in lab_order]
    b_ = [df.loc[df.grp == g, c].dropna() for g in lab_order]
    v1 = don.loc[don.verified_group == 'COVID+ acute pneumonia/ALI', c].dropna(); v2 = don.loc[don.verified_group == 'COVID- acute pneumonia', c].dropna()
    v3 = don.loc[don.verified_group == 'No acute lung infection/injury', c].dropna()
    d = don[don.verified_group.isin(['COVID+ acute pneumonia/ALI', 'COVID- acute pneumonia', 'No acute lung infection/injury'])].copy()
    d['pna'] = (d.verified_group != 'No acute lung infection/injury').astype(int)
    m = smf.ols(f'{c} ~ pna + age', data=d).fit()
    rows.append({'marker': c.replace('_n', ''),
                 **{f'median {g} (label)': round(x.median(), 2) for g, x in zip(lab_order, a)},
                 'KW p, donors (label)': stats.kruskal(*a).pvalue, 'KW p, BLOCKS (pseudo-replicated; wrong)': stats.kruskal(*b_).pvalue,
                 'MW p COVID+ vs COVID- pneumonia (label)': stats.mannwhitneyu(a[0], a[1]).pvalue,
                 'median COVID+ PNA (verified)': round(v1.median(), 2), 'median COVID- PNA (verified)': round(v2.median(), 2), 'median no acute lung inj (verified)': round(v3.median(), 2),
                 'MW p COVID+ vs COVID- PNA (verified)': stats.mannwhitneyu(v1, v2).pvalue,
                 'MW p any PNA vs none (verified)': stats.mannwhitneyu(pd.concat([v1, v2]), v3).pvalue,
                 'pneumonia coef, age-adjusted OLS (verified)': m.params['pna'], 'p (age-adjusted)': m.pvalues['pna'], 'age coef': m.params['age'], 'p age': m.pvalues['age']})
tests = pd.DataFrame(rows); tests.to_csv(f'{TAB}/postmortem_group_tests_donor_level.csv', index=False)
for _, r in tests.iterrows(): record(f'pm_test_{r.marker}', {k: (float(v) if isinstance(v, (float, np.floating)) else v) for k, v in r.items() if k != 'marker'})

# duplex artefact and age correlations
x = df[['IL5Ra_NE_n', 'NE_n', 'IL5Ra_TRYP_n', 'TRYPTASE_n', 'EPX_n', 'EDN_n', 'MBP_n']].dropna()
record('pm_IL5Ra_duplexNE_equals_NE_frac', float((df.IL5Ra_NE_n == df.NE_n)[df.IL5Ra_NE_n.notna() & df.NE_n.notna()].mean()))
record('pm_IL5Ra_duplexNE_within1_NE_frac', float(((df.IL5Ra_NE_n - df.NE_n).abs() <= 1)[df.IL5Ra_NE_n.notna() & df.NE_n.notna()].mean()))
record('pm_spearman_block_IL5Ra_vs', {c: float(stats.spearmanr(x.IL5Ra_NE_n, x[c])[0]) for c in ['NE_n', 'IL5Ra_TRYP_n', 'EPX_n', 'EDN_n', 'MBP_n']})
record('pm_spearman_donor_IL33endo_age', [float(v) for v in stats.spearmanr(don.IL33_endo_n, don.age)])
record('pm_spearman_donor_IL33vsm_age', [float(v) for v in stats.spearmanr(don.IL33_vsm_n, don.age)])
record('pm_age_by_label_KW_p', float(stats.kruskal(*[don.loc[don.grp == g, 'age'] for g in lab_order]).pvalue))
record('pm_endothelial_IL33_blocks_at_5p5', int((df.IL33_endo_n == 5.5).sum()))
record('pm_frac_donors_endothelial_IL33_ge_4p25', float((don.IL33_endo_n >= 4.25).mean()))
# lung-disease history (notes column) vs IL-33 / granulocyte scores
don['copd_history'] = don.notes.fillna('').astype(str).str.contains('COPD')
copd = {}
for c in ['IL33_epi_n', 'IL33_endo_n', 'IL33_vsm_n', 'EDN_n', 'MBP_n', 'NE_n']:
    a_, b2 = don.loc[don.copd_history, c].dropna(), don.loc[~don.copd_history, c].dropna()
    copd[c] = dict(n_copd=len(a_), n_other=len(b2), median_copd=float(a_.median()), median_other=float(b2.median()), p=float(stats.mannwhitneyu(a_, b2).pvalue))
record('pm_copd_history_comparison', copd)
record('pm_tissue_rna_donors_by_verified_group', don[don.tissue_rna != ''].verified_group.value_counts().to_dict())

# ---------------------------------------------------------------- 4. Figure
fig, axes = plt.subplots(2, 4, figsize=(15, 7.2))
panels = [('IL33_endo_n', 'IL-33, endothelium'), ('IL33_epi_n', 'IL-33, basal epithelium'), ('IL33_vsm_n', 'IL-33, vascular SMC'), ('NE_n', 'Neutrophil elastase'),
          ('EDN_n', 'EDN (eosinophil)'), ('MBP_n', 'MBP (eosinophil)'), ('IL5Ra_NE_n', 'IL-5Ra (duplex w/ NE)'), ('HE_eos_n', 'H&E eosinophils (frac blocks Y)')]
vorder = ['COVID+ acute pneumonia/ALI', 'COVID- acute pneumonia', 'No acute lung infection/injury']
cols = {'COVID+ pneumonia': 'tab:red', 'COVID- pneumonia': 'tab:blue', 'COVID- non-pneumonia': 'tab:green'}
rng = np.random.default_rng(1)
for ax, (c, title) in zip(axes.ravel(), panels):
    for i, g in enumerate(vorder):
        sub = don[don.verified_group == g]
        ax.scatter(i + rng.uniform(-.15, .15, len(sub)), sub[c], c=[cols[x] for x in sub.grp], s=28, edgecolor='k', lw=.4)
        ax.hlines(sub[c].median(), i - .25, i + .25, color='k')
    ax.set_xticks(range(3)); ax.set_xticklabels(['COVID+\nPNA/ALI', 'COVID-\nPNA', 'no acute\nlung injury'], fontsize=8)
    ax.axhline(5, ls=':', c='0.5', lw=.7)
    r = tests.set_index('marker').loc[c.replace('_n', '')]
    ax.set_ylim(-0.25, 5.75)
    ax.set_title(f"{title}\nC+ vs C- PNA p={r['MW p COVID+ vs COVID- PNA (verified)']:.2f} | PNA vs none p={r['MW p any PNA vs none (verified)']:.3f} (age-adj {r['p (age-adjusted)']:.3f})", fontsize=8)
from matplotlib.lines import Line2D
fig.legend(handles=[Line2D([0], [0], marker='o', ls='', c=v, label=f'delivered label: {k}') for k, v in cols.items()], loc='lower center', ncol=3, fontsize=8)
fig.suptitle('Fig 5. Post-mortem lung, donor-level (n=27 with unambiguous pathology). No marker separates COVID+ from COVID- pneumonia;\n'
             'endothelial IL-33 is near the ceiling in every group (dotted line = top of declared 0-5 scale); neutrophil elastase is the robust pneumonia marker', fontsize=10)
fig.tight_layout(rect=[0, .05, 1, 1]); fig.savefig(f'{FIG}/fig5_postmortem_donor_level.png', dpi=160); plt.close(fig)
print('postmortem analysis done'); print(disc[['grp', 'verified_group', 'first_lung_diagnoses']].to_string())
