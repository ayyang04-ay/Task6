"""AX-1177 clinical serum proteomics (Olink Target 96 x 13 panels; 100 hospitalised COVID-19 patients; composite ICU/IMV/death <=30 d).

Only per-assay summary statistics were delivered (OR per log unit, 95% CI, p, BH-adjusted p, two per-group fraction columns).
No patient-level data -> no discrimination/calibration, no per-SD effects, no joint models.
"""
import numpy as np, pandas as pd
from scipy import stats
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from common import load_serum, record, TAB, FIG
from olink_map import base

p = load_serum()
record('serum_n_assays', len(p)); record('serum_n_panels', int(p.panel.nunique()))

# ---------------------------------------------------------------- 1. Cohort size implied by the per-group fraction columns
f0 = sorted(set(np.round(p.composite_endpoint_0 * 56, 6))); f1 = sorted(set(np.round(p.composite_endpoint_1 * 44, 6)))
record('serum_fraction_cols_are_multiples_of_1_56_and_1_44', bool(all(float(x).is_integer() for x in f0) and all(float(x).is_integer() for x in f1)))
record('serum_max_fraction_col', float(p[['composite_endpoint_0', 'composite_endpoint_1']].max().max()))
record('serum_n_assays_with_nonzero_fraction', int(((p.composite_endpoint_0 > 0) | (p.composite_endpoint_1 > 0)).sum()))

# ---------------------------------------------------------------- 2. Integrity checks
# (a) BH reproducibility
pv = p['p.value'].values; o = np.argsort(pv)
def bh(m):
    q = pv[o] * m / np.arange(1, len(pv) + 1); q = np.minimum.accumulate(q[::-1])[::-1]; q = np.minimum(q, 1); out = np.empty_like(q); out[o] = q; return out
record('serum_BH_max_abs_diff_vs_delivered_m1094', float(np.max(np.abs(bh(len(p)) - p['adj.p.value']))))
record('serum_BH_implied_m_at_rank1', float(p['adj.p.value'].iloc[0] / p['p.value'].iloc[0]))
# (b) Wald consistency of OR/CI/p
se = (np.log(p.u95) - np.log(p.l95)) / (2 * 1.96); z = np.log(p.OR) / se
record('serum_wald_p_max_log10_diff', float(np.max(np.abs(np.log10(2 * stats.norm.sf(np.abs(z))) - np.log10(p['p.value'])))))
p['z'] = z
# (c) cross-panel duplicates
dup = p.groupby('gene').filter(lambda g: len(g) > 1).sort_values(['gene', 'rank'])
dup[['gene', 'assay', 'panel_short', 'OR', 'l95', 'u95', 'p.value', 'adj.p.value', 'rank']].to_csv(f'{TAB}/serum_cross_panel_duplicates.csv', index=False)
record('serum_n_genes_on_multiple_panels', int(dup.gene.nunique())); record('serum_n_assays_in_duplicate_sets', int(len(dup)))
u = p.sort_values('p.value').drop_duplicates('gene')
record('serum_n_unique_proteins', int(len(u)))
record('serum_n_assays_FDR05', int((p['adj.p.value'] < 0.05).sum())); record('serum_n_unique_FDR05', int((u['adj.p.value'] < 0.05).sum()))
record('serum_frac_OR_gt1', float((p.OR > 1).mean()))
record('serum_n_OR_gt10', int((p.OR > 10).sum()))
# (d) Inflammation-panel content absent from the delivery (standard 92-assay content per vendor documentation)
INF92 = ['IL8','VEGFA','CD8A','MCP-3','GDNF','CDCP1','CD244','IL7','OPG','LAP TGF-beta-1','uPA','IL6','IL-17C','MCP-1','IL-17A','CXCL11','AXIN1',
 'TRAIL','IL-20RA','CXCL9','CST5','IL-2RB','IL-1 alpha','OSM','IL2','CXCL1','TSLP','CCL4','CD6','SCF','IL18','SLAMF1','TGF-alpha','MCP-4','CCL11',
 'TNFSF14','FGF-23','IL-10RA','FGF-5','MMP-1','LIF-R','FGF-21','CCL19','IL-15RA','IL-10RB','IL-22 RA1','IL-18R1','PD-L1','Beta-NGF','CXCL5',
 'TRANCE','HGF','IL-12B','IL-24','IL13','ARTN','MMP-10','IL10','TNF','CCL23','CD5','CCL3','Flt3L','CXCL6','CXCL10','4E-BP1','IL-20','SIRT2',
 'CCL28','DNER','EN-RAGE','CD40','IL33','IFN-gamma','FGF-19','IL4','LIF','NRTN','MCP-2','CASP-8','CCL25','CX3CL1','TNFRSF9','NT-3','TWEAK',
 'CCL20','ST1A1','STAMBP','IL5','ADA','TNFB','CSF-1']
assert len(INF92) == 92
inf_delivered = set(p.loc[p.panel.str.contains('Inflammation'), 'assay'].map(base))
missing_inf = [a for a in INF92 if a not in inf_delivered]
extra = sorted(inf_delivered - set(INF92))
record('serum_inflammation_panel_delivered', len(inf_delivered)); record('serum_inflammation_panel_missing', missing_inf)
record('serum_inflammation_unexpected_names', extra)
record('serum_IL33_present', bool(p.assay.str.upper().str.replace('-', '').str.contains('IL33').any()))

# ---------------------------------------------------------------- 3. IL-33 axis, type-2, endothelial, neutrophil, organ markers
groups = {
 'IL-33 axis / IL-1 family': ['IL1RL1', 'IL1R1', 'IL1R2', 'IL1RN', 'IL18', 'IL18R1', 'IL18BP', 'IL1RL2', 'IL1B', 'AGER', 'EGFR'],
 'Type-2 / eosinophil / mast cell': ['IL5', 'IL5RA', 'CCL11', 'CCL24', 'CCL17', 'RNASE3', 'TPSAB1', 'KIT', 'IL17RB', 'IL4R', 'IL13RA1', 'CCL18'],
 'Endothelial activation / injury': ['VWF', 'ANGPT2', 'ANGPT1', 'SELE', 'SELP', 'VCAM1', 'ICAM1', 'ESM1', 'THBD', 'F3', 'SERPINE1', 'PTX3', 'VEGFA', 'FLT1', 'CDH5', 'PECAM1', 'TEK'],
 'Neutrophil activation': ['PRTN3', 'CD177', 'CTSC', 'FCAR', 'CLEC5A', 'LCN2', 'S100A12', 'CEACAM8', 'MPO', 'AZU1', 'TREM1', 'VSTM1'],
 'Epithelial injury / repair': ['HGF', 'AREG', 'TGFA', 'KRT19', 'SCGB3A2', 'SFTPD', 'SFTPA1', 'AGR2'],
 'Kidney / cardiac injury': ['HAVCR1', 'LCN2', 'CST3', 'REN', 'NPPB', 'TNNI3', 'GDF15', 'MB'],
 'General inflammation': ['IL6', 'OSM', 'CXCL8', 'CCL2', 'CCL7', 'CCL20', 'TNFRSF11B', 'CSF1', 'TNF', 'IFNG', 'CXCL10', 'IL10']}
rows = []
for gname, genes in groups.items():
    for g in genes:
        sub = p[p.gene == g]
        for _, r in sub.iterrows():
            rows.append(dict(group=gname, gene=g, assay=r.assay, panel=r.panel_short, OR_per_log_unit=r.OR, l95=r.l95, u95=r.u95,
                             p=r['p.value'], BH_q=r['adj.p.value'], rank_of_1094=r['rank']))
        if len(sub) == 0:
            rows.append(dict(group=gname, gene=g, assay='NOT IN DELIVERY'))
mk = pd.DataFrame(rows); mk.to_csv(f'{TAB}/serum_marker_groups.csv', index=False)
st2 = p[p.assay == 'ST2'].iloc[0]
record('serum_ST2', dict(OR=st2.OR, l95=st2.l95, u95=st2.u95, p=st2['p.value'], q=st2['adj.p.value'], rank=int(st2['rank']),
                         rank_unique=int(np.where(u.gene.values == 'IL1RL1')[0][0] + 1), frac_missing=[st2.composite_endpoint_0, st2.composite_endpoint_1]))

# ---------------------------------------------------------------- 4. Bridge to in vitro: IL-33-inducible, AX-1177-reversible gene products
prog = pd.read_csv(f'{TAB}/rnaseq_il33_program_and_neutralisation_per_gene.csv', index_col=0)
abn = set(pd.read_csv(f'{TAB}/rnaseq_implausible_SE_genes.csv').symbol.astype(str))
pr = prog.dropna(subset=['symbol']).drop_duplicates('symbol').set_index('symbol')
b = u.merge(pr, left_on='gene', right_index=True, how='left')
b['in_rnaseq'] = b['IL33_vs_Veh_6h'].notna() | b.gene.isin(abn)
b['implausible_SE_in_rnaseq'] = b.gene.isin(abn)
b['il33_induced'] = ((b['adjP_IL33_vs_Veh_6h'] < 0.05) & (b['IL33_vs_Veh_6h'] > 1)) | ((b['adjP_IL33_vs_Veh_24h'] < 0.05) & (b['IL33_vs_Veh_24h'] > 1))
b['ax1177_reversed'] = ((b['adjP_AX1177+IL33_vs_iso+IL33_6h'] < 0.05) & (b['AX1177+IL33_vs_iso+IL33_6h'] < 0)) | \
                       ((b['adjP_AX1177+IL33_vs_iso+IL33_24h'] < 0.05) & (b['AX1177+IL33_vs_iso+IL33_24h'] < 0))
cols = ['gene', 'assay', 'OR', 'l95', 'u95', 'p.value', 'adj.p.value', 'IL33_vs_Veh_6h', 'adjP_IL33_vs_Veh_6h', 'IL33+AX1177_vs_Veh_6h',
        'pct_inhibition_6h', 'IL33_vs_Veh_24h', 'IL33+AX1177_vs_Veh_24h', 'HGMEC_AX1177+IL33_vs_iso+IL33_6h', 'adjP_HGMEC_AX1177+IL33_vs_iso+IL33_6h',
        'il33_induced', 'ax1177_reversed', 'implausible_SE_in_rnaseq']
bridge = b[(b.il33_induced & b.ax1177_reversed) | b.implausible_SE_in_rnaseq].sort_values('p.value')[cols]
bridge.to_csv(f'{TAB}/serum_invitro_bridge.csv', index=False)
cand = bridge[(bridge.il33_induced) & (bridge.ax1177_reversed) & (bridge['adj.p.value'] < 0.05)]
record('bridge_FDR05_candidates', cand.gene.tolist())
# enrichment test: are IL-33-inducible gene products over-represented among outcome-associated serum proteins?
tested = b[b['IL33_vs_Veh_6h'].notna() & ~b.implausible_SE_in_rnaseq]
a1 = tested[tested.il33_induced]; a0 = tested[~tested.il33_induced]
tab = [[int((a1['adj.p.value'] < 0.05).sum()), int((a1['adj.p.value'] >= 0.05).sum())], [int((a0['adj.p.value'] < 0.05).sum()), int((a0['adj.p.value'] >= 0.05).sum())]]
fe = stats.fisher_exact(tab)
record('bridge_enrichment', dict(n_induced=len(a1), frac_FDR05_induced=float((a1['adj.p.value'] < 0.05).mean()),
                                 n_other=len(a0), frac_FDR05_other=float((a0['adj.p.value'] < 0.05).mean()), fisher_OR=float(fe[0]), fisher_p=float(fe[1]),
                                 median_OR_induced=float(a1.OR.median()), median_OR_other=float(a0.OR.median()),
                                 mw_p_logOR=float(stats.mannwhitneyu(np.log(a1.OR), np.log(a0.OR)).pvalue)))

# ---------------------------------------------------------------- 5. Figures
fig, ax = plt.subplots(figsize=(9.5, 6.2))
x = np.log2(p.OR); y = -np.log10(p['p.value'])
ax.scatter(x, y, s=6, c='0.75', rasterized=True, label='all 1,094 assays')
sig = p['adj.p.value'] < 0.05
ax.scatter(x[sig], y[sig], s=8, c='0.45', rasterized=True, label='BH q < 0.05 (178 assays)')
hl = {'ST2': ('tab:red', 'sST2 (IL-33 decoy receptor)'), 'HGF': ('k', None), 'PTX3': ('k', None), 'IL6': ('tab:blue', None), 'CCL20': ('tab:blue', None),
      'OPG-INFI': ('tab:blue', None), 'IL-18R1': ('tab:blue', None), 'CSF-1': ('tab:blue', None), 'IL1B': ('tab:blue', None), 'MCP-3': ('tab:blue', None),
      'TF': ('tab:purple', None), 'PAI': ('tab:purple', None), 'vWF': ('tab:purple', None), 'ANGPT2': ('tab:purple', None),
      'IL5-IMO': ('tab:green', None), 'CCL11-INFI': ('tab:green', None), 'CCL24': ('tab:green', None), 'CCL17': ('tab:green', None), 'TPSAB1': ('tab:green', None),
      'IL-5R-alpha': ('tab:green', None), 'RNASE3': ('tab:green', None), 'RAGE': ('tab:orange', None), 'EGFR': ('tab:orange', None)}
offs = {'MCP-3': (-34, 6), 'CCL20': (4, -10), 'ANGPT2': (12, -14), 'IL1B': (-8, 9), 'vWF': (5, 4), 'PAI': (-26, 6), 'RAGE': (6, -4),
        'IL-5R-alpha': (-60, -10), 'RNASE3': (-52, 2), 'IL5-IMO': (-40, 10), 'CCL11-INFI': (-20, 24), 'CCL24': (-48, 14), 'CCL17': (-48, -4), 'TF': (-8, 9),
        'TPSAB1': (8, 14), 'EGFR': (10, 2)}
for a, (col, lab) in hl.items():
    r = p[p.assay == a].iloc[0]
    ax.scatter(np.log2(r.OR), -np.log10(r['p.value']), s=40, c=col, edgecolor='k', zorder=3)
    dx, dy = offs.get(a, (4, 2))
    ax.annotate(a.replace('-INFI', ''), (np.log2(r.OR), -np.log10(r['p.value'])), fontsize=8, xytext=(dx, dy), textcoords='offset points', color=col,
                arrowprops=dict(arrowstyle='-', color=col, lw=.4) if a in offs else None)
thr = p.loc[sig, 'p.value'].max(); ax.axhline(-np.log10(thr), ls='--', c='0.4', lw=.8)
ax.set_xlabel('log2 OR per log unit (composite ICU/IMV/death <=30 d; adjusted age, sex, NEWS2)'); ax.set_ylabel('-log10 p')
from matplotlib.lines import Line2D
leg = [Line2D([0], [0], marker='o', ls='', c=c, label=l) for c, l in [('tab:red', 'sST2 (IL-33 decoy; #2 of 1,063 proteins)'), ('tab:blue', 'IL-33-inducible & AX-1177-reversible in HUVEC'),
       ('tab:purple', 'endothelial / coagulation'), ('tab:green', 'type-2 / eosinophil / mast cell'), ('tab:orange', 'IL-33ox pathway (RAGE, EGFR)'), ('k', 'top generic injury markers')]]
ax.legend(handles=leg, fontsize=8, loc='upper left'); ax.set_xlim(-3, 7.5)
ax.set_title('Fig 2. Serum proteins vs 30-day severe outcome (n=100; 44 events). 82% of ORs > 1: global shift.\nsST2 is near the top; IL-33 itself is not in the delivery; type-2 markers are null.', fontsize=10)
fig.tight_layout(); fig.savefig(f'{FIG}/fig2_serum_volcano.png', dpi=160); plt.close(fig)

# bridge scatter
tb = b[b['IL33_vs_Veh_6h'].notna()].copy()
fig, ax = plt.subplots(figsize=(8.5, 5.8))
ax.scatter(tb['IL33_vs_Veh_6h'], np.log2(tb.OR), s=8, c='0.75', label='Olink protein with RNA-seq gene')
c2 = tb[tb.il33_induced & tb.ax1177_reversed]
ax.scatter(c2['IL33_vs_Veh_6h'], np.log2(c2.OR), s=14, c='tab:blue', label='IL-33-induced and AX-1177-reversed (HUVEC)')
c3 = c2[c2['adj.p.value'] < 0.05]
ax.scatter(c3['IL33_vs_Veh_6h'], np.log2(c3.OR), s=60, facecolor='none', edgecolor='tab:red', lw=1.5, label='... and serum BH q<0.05')
boffs = {'MCP-3': (6, -12), 'B4GALT1': (6, -2), 'SERPINB8': (6, -8), 'TRIM21': (-10, 8), 'VSTM1': (6, 4)}
for _, r in c3.iterrows():
    dx, dy = boffs.get(r.assay, (3, 3))
    ax.annotate(r.assay.replace('-INFI', ''), (r['IL33_vs_Veh_6h'], np.log2(r.OR)), fontsize=8, xytext=(dx, dy), textcoords='offset points')
for a, (dx, dy) in {'TF': (4, 6), 'PAI': (14, 24), 'CX3CL1': (-10, -14)}.items():
    r = tb[tb.assay == a]
    if len(r): ax.annotate(a + ' (q>0.05)', (r['IL33_vs_Veh_6h'].iloc[0], np.log2(r.OR.iloc[0])), fontsize=7, color='0.3', xytext=(dx, dy), textcoords='offset points',
                           arrowprops=dict(arrowstyle='-', color='0.5', lw=.4))
ax.axhline(0, c='k', lw=.6); ax.axvline(0, c='k', lw=.6)
ax.set_xlabel('IL-33 vs vehicle log2FC, HUVEC 6 h (in vitro)'); ax.set_ylabel('serum log2 OR per log unit (clinical)')
e = fe
ax.set_title(f'Fig 3. Translational bridge. Candidate PD markers exist, but IL-33-inducible products are NOT enriched\namong outcome-associated proteins ({100*tab[0][0]/sum(tab[0]):.0f}% vs {100*tab[1][0]/sum(tab[1]):.0f}% at q<0.05; Fisher p={e[1]:.2f})', fontsize=10)
ax.legend(fontsize=8, loc='lower right'); fig.tight_layout(); fig.savefig(f'{FIG}/fig3_bridge_invitro_serum.png', dpi=160); plt.close(fig)
print('serum analysis done')
