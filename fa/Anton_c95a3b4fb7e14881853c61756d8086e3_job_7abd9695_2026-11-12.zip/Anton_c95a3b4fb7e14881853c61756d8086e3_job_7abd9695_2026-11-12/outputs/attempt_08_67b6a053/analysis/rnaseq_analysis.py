"""AX-1177 in vitro transcriptomics: IL-33 response, neutralisation, antibody-alone effects, data-integrity checks.

Design facts used (methods annex): HUVEC arms = Vehicle, IC119, Compound_47(=AX-1177), IL-33red, IL-33red+IC119, IL-33red+Compound_47;
HGMEC has NO vehicle arm; A549/MCF7 received no IL-33. One limma-voom model across all 114 libraries, one coefficient per group,
so any linear combination of delivered contrasts gives an exact derived contrast between group means (point estimate only).
"""
import numpy as np, pandas as pd
from scipy import stats
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from common import load_rnaseq, pivot, C, record, TAB, FIG

allc = load_rnaseq()
sym = allc.drop_duplicates('ensembl').set_index('ensembl').symbol
ave = allc.drop_duplicates('ensembl').set_index('ensembl').AveExpr

# ------------------------------------------------------------------ 1. Integrity: implausible standard errors
SE = pivot(allc, 'SE').abs()
huvec_se = SE[[C['IL33_6'], C['IL33_24']]]
abn = huvec_se.index[(huvec_se > 3).any(axis=1)]
record('rnaseq_median_gene_SE_IL33_6h', float(huvec_se[C['IL33_6']].median()))
record('rnaseq_SE_99th_pct_IL33_6h', float(huvec_se[C['IL33_6']].quantile(0.99)))
record('rnaseq_n_implausible_SE_genes', int(len(abn)))
record('rnaseq_max_SE', float(huvec_se.max().max()))
L_all = pivot(allc, 'logFC'); T_all = pivot(allc, 't'); Q_all = pivot(allc, 'adj.P.Val')
abn_tab = pd.DataFrame({'symbol': sym[abn], 'AveExpr_all114': ave[abn],
                        'SE_IL33vsVeh_6h': huvec_se.loc[abn, C['IL33_6']], 'logFC_IL33vsVeh_6h': L_all.loc[abn, C['IL33_6']],
                        't_IL33vsVeh_6h': T_all.loc[abn, C['IL33_6']], 'adjP_IL33vsVeh_6h': Q_all.loc[abn, C['IL33_6']],
                        'logFC_IL33vsVeh_24h': L_all.loc[abn, C['IL33_24']], 'adjP_IL33vsVeh_24h': Q_all.loc[abn, C['IL33_24']]})
abn_tab = abn_tab.sort_values('SE_IL33vsVeh_6h', ascending=False)
abn_tab.to_csv(f'{TAB}/rnaseq_implausible_SE_genes.csv')
canon = ['SELE', 'VCAM1', 'CXCL8', 'CXCL1', 'CCL2', 'PTX3', 'IL1RL1', 'VWF', 'CDH5', 'PECAM1', 'ESM1', 'PTGS2']
record('rnaseq_canonical_genes_with_implausible_SE', [g for g in canon if g in set(abn_tab.symbol)])

# tiny-SE / huge-t hits (statistically significant, biologically trivial)
tiny = allc[(allc.SE.abs() < 0.005) & (allc['adj.P.Val'] < 0.05)][['Comparison', 'symbol', 'logFC', 't', 'adj.P.Val', 'SE']]
tiny.sort_values('t', key=np.abs, ascending=False).to_csv(f'{TAB}/rnaseq_tiny_SE_significant_hits.csv', index=False)

# ------------------------------------------------------------------ 2. Contrast summary
rows = []
for k, g in allc.groupby('Comparison', sort=False):
    sig = g['adj.P.Val'] < 0.05
    gg = g[~g.ensembl.isin(abn)]
    rows.append(dict(contrast=k, DEG_adjP05=int(sig.sum()), up=int((sig & (g.logFC > 0)).sum()), down=int((sig & (g.logFC < 0)).sum()),
                     DEG_adjP05_absLFC1=int((sig & (g.logFC.abs() >= 1)).sum()),
                     DEG_adjP05_absLFC1_excl_implausibleSE=int(((gg['adj.P.Val'] < 0.05) & (gg.logFC.abs() >= 1)).sum())))
summ = pd.DataFrame(rows); summ.to_csv(f'{TAB}/rnaseq_contrast_summary.csv', index=False)
for k in ['IL33_6', 'IL33_24', 'LCLI_6', 'LCLI_24', 'G_LCLI_6', 'G_LCLI_24']:
    r = summ.set_index('contrast').loc[C[k]]
    record(f'rnaseq_DEG_{k}', int(r.DEG_adjP05)); record(f'rnaseq_DEG_up_{k}', int(r.up)); record(f'rnaseq_DEG_lfc1_{k}', int(r.DEG_adjP05_absLFC1))

# ------------------------------------------------------------------ 3. Neutralisation in HUVEC (exact derived contrasts from the single fit)
L = pivot(allc, 'logFC', exclude=abn); Q = pivot(allc, 'adj.P.Val', exclude=abn)
prog = pd.DataFrame(index=L.index)
prog['symbol'] = sym[prog.index]; prog['AveExpr_all114'] = ave[prog.index]
for tp in ['6', '24']:
    LV, LCL, LCLI = L[C['IL33_' + tp]], L[C['LCL_' + tp]], L[C['LCLI_' + tp]]
    prog[f'IL33_vs_Veh_{tp}h'] = LV                                  # L  - V   (delivered)
    prog[f'adjP_IL33_vs_Veh_{tp}h'] = Q[C['IL33_' + tp]]
    prog[f'IL33+iso_vs_Veh_{tp}h'] = LV + LCL - LCLI                 # LI - V   (derived: uses LI and V group means only)
    prog[f'IL33+AX1177_vs_Veh_{tp}h'] = LV + LCL                     # LC - V   (derived: uses LC and V group means only)
    prog[f'AX1177+IL33_vs_iso+IL33_{tp}h'] = LCLI                    # LC - LI  (delivered)
    prog[f'adjP_AX1177+IL33_vs_iso+IL33_{tp}h'] = Q[C['LCLI_' + tp]]
    prog[f'pct_inhibition_{tp}h'] = 100 * (1 - prog[f'IL33+AX1177_vs_Veh_{tp}h'] / prog[f'IL33+iso_vs_Veh_{tp}h'])
    prog[f'AX1177_alone_vs_iso_{tp}h'] = L[C['CI_' + tp]]
    prog[f'HGMEC_AX1177+IL33_vs_iso+IL33_{tp}h'] = L[C['G_LCLI_' + tp]]
    prog[f'adjP_HGMEC_AX1177+IL33_vs_iso+IL33_{tp}h'] = Q[C['G_LCLI_' + tp]]
prog.to_csv(f'{TAB}/rnaseq_il33_program_and_neutralisation_per_gene.csv')

neut_rows = []
for tp in ['6', '24']:
    for thr in [1e-2, 1e-6]:
        up = (prog[f'adjP_IL33_vs_Veh_{tp}h'] < thr) & (prog[f'IL33_vs_Veh_{tp}h'] > 1)
        inh = prog.loc[up, f'pct_inhibition_{tp}h']
        r = dict(timepoint=tp + 'h', selection=f'IL-33 vs vehicle adjP<{thr:g}, logFC>1', n_genes=int(up.sum()),
                 median_logFC_IL33_vs_veh=prog.loc[up, f'IL33_vs_Veh_{tp}h'].median(),
                 median_logFC_IL33_plus_isotype_vs_veh=prog.loc[up, f'IL33+iso_vs_Veh_{tp}h'].median(),
                 median_logFC_IL33_plus_AX1177_vs_veh=prog.loc[up, f'IL33+AX1177_vs_Veh_{tp}h'].median(),
                 median_pct_inhibition=inh.median(), q25_pct_inhibition=inh.quantile(.25), q75_pct_inhibition=inh.quantile(.75),
                 frac_genes_ge80pct_inhibited=float((inh >= 80).mean()),
                 median_AX1177_alone_vs_iso=prog.loc[up, f'AX1177_alone_vs_iso_{tp}h'].median(),
                 HGMEC_frac_sig_reduced=float(((prog.loc[up, f'adjP_HGMEC_AX1177+IL33_vs_iso+IL33_{tp}h'] < 0.05) &
                                               (prog.loc[up, f'HGMEC_AX1177+IL33_vs_iso+IL33_{tp}h'] < 0)).mean()),
                 HGMEC_median_logFC=prog.loc[up, f'HGMEC_AX1177+IL33_vs_iso+IL33_{tp}h'].median(),
                 HUVEC_median_logFC_same_contrast=prog.loc[up, f'AX1177+IL33_vs_iso+IL33_{tp}h'].median())
        neut_rows.append(r)
        tag = f'{tp}h_thr{thr:g}'
        for k2 in ['n_genes', 'median_logFC_IL33_vs_veh', 'median_logFC_IL33_plus_isotype_vs_veh', 'median_logFC_IL33_plus_AX1177_vs_veh',
                   'median_pct_inhibition', 'q25_pct_inhibition', 'q75_pct_inhibition', 'frac_genes_ge80pct_inhibited',
                   'HGMEC_frac_sig_reduced', 'HGMEC_median_logFC', 'HUVEC_median_logFC_same_contrast']:
            record(f'neut_{tag}_{k2}', r[k2])
pd.DataFrame(neut_rows).to_csv(f'{TAB}/rnaseq_neutralisation_summary.csv', index=False)

# HGMEC-only suppressed genes (reduced by AX-1177 vs isotype in HGMEC 6 h, but not IL-33-induced in HUVEC)
hg_dn = (prog['adjP_HGMEC_AX1177+IL33_vs_iso+IL33_6h'] < 0.05) & (prog['HGMEC_AX1177+IL33_vs_iso+IL33_6h'] < -1)
huv_up = ((prog['adjP_IL33_vs_Veh_6h'] < 0.05) & (prog['IL33_vs_Veh_6h'] > 0.5)) | ((prog['adjP_IL33_vs_Veh_24h'] < 0.05) & (prog['IL33_vs_Veh_24h'] > 0.5))
only = prog[hg_dn & ~huv_up]
record('hgmec_6h_suppressed_n', int(hg_dn.sum())); record('hgmec_only_suppressed_n', int(len(only)))
record('hgmec_only_frac_AveExpr_lt0', float((only.AveExpr_all114 < 0).mean()))
record('hgmec_only_frac_lncRNA_like', float(only.symbol.astype(str).str.match(r'^(A[CLP]\d|LINC|MIR|RF0|SNOR|Z\d)').mean()))
# proposed 10-gene IL-33 endothelial signature for G2 (tissue) and the ex vivo serum bioassay
SIG = ['NFKBIA', 'TNFAIP3', 'TRAF1', 'CCL20', 'CSF2', 'CXCL2', 'CXCL3', 'F3', 'IL6', 'TNFRSF11B']
sig = prog[prog.symbol.isin(SIG)].set_index('symbol').loc[SIG]
sig_out = sig[['IL33_vs_Veh_6h', 'adjP_IL33_vs_Veh_6h', 'IL33+iso_vs_Veh_6h', 'IL33+AX1177_vs_Veh_6h', 'pct_inhibition_6h',
               'IL33_vs_Veh_24h', 'IL33+AX1177_vs_Veh_24h', 'HGMEC_AX1177+IL33_vs_iso+IL33_6h', 'adjP_HGMEC_AX1177+IL33_vs_iso+IL33_6h']].copy()
sig_out['implausible_SE'] = sig_out.index.isin(set(abn_tab.symbol))
sig_out.round(4).to_csv(f'{TAB}/il33_endothelial_signature_10genes.csv')
record('signature_genes_any_implausible_SE', bool(sig_out.implausible_SE.any()))
# named program genes for the brief
named = ['NFKBIA', 'TNFAIP3', 'TRAF1', 'RELB', 'BIRC3', 'CSF2', 'CSF3', 'CXCL2', 'CXCL3', 'CXCL5', 'CXCL6', 'CCL20', 'CX3CL1', 'IL6', 'TNF',
         'IL1B', 'TNFRSF11B', 'IL18R1', 'CSF1', 'CCL7', 'F3', 'SERPINE1', 'THBD', 'PLAU', 'ICAM1', 'CXCL10']
nm = prog[prog.symbol.isin(named)].set_index('symbol').loc[named]
nm[['IL33_vs_Veh_6h', 'adjP_IL33_vs_Veh_6h', 'IL33+iso_vs_Veh_6h', 'IL33+AX1177_vs_Veh_6h', 'adjP_AX1177+IL33_vs_iso+IL33_6h',
    'IL33_vs_Veh_24h', 'IL33+AX1177_vs_Veh_24h', 'HGMEC_AX1177+IL33_vs_iso+IL33_6h', 'adjP_HGMEC_AX1177+IL33_vs_iso+IL33_6h']].round(3)\
    .to_csv(f'{TAB}/rnaseq_named_program_genes.csv')

# ------------------------------------------------------------------ 4. Antibody alone (AX-1177 vs isotype): reproducibility of hits
alone = [k for k in allc.Comparison.unique() if k.startswith('Compound_47_vs_IC119_')]
sets = {k: set(Q.index[(Q[k] < 0.05) & (L[k].abs() >= 1)]) for k in alone}
rows = []
for k in alone:
    s = list(sets[k])
    rows.append(dict(contrast=k, n_hits_adjP05_absLFC1=len(s), frac_low_expression_AveExpr_lt0=float(np.mean(ave[s] < 0)) if s else np.nan,
                     max_overlap_with_any_other_antibody_alone_contrast=max(len(sets[k] & sets[o]) for o in alone if o != k)))
alone_tab = pd.DataFrame(rows); alone_tab.to_csv(f'{TAB}/rnaseq_antibody_alone_summary.csv', index=False)
record('alone_hits_range', [int(alone_tab.n_hits_adjP05_absLFC1.min()), int(alone_tab.n_hits_adjP05_absLFC1.max())])
record('alone_frac_lowexpr_range', [float(alone_tab.frac_low_expression_AveExpr_lt0.min()), float(alone_tab.frac_low_expression_AveExpr_lt0.max())])
record('alone_max_pairwise_overlap', int(alone_tab.max_overlap_with_any_other_antibody_alone_contrast.max()))
hi = ave[ave > 2].index.intersection(L.index)
cc = L.loc[hi, alone].corr().values; offd = cc[~np.eye(len(alone), dtype=bool)]
record('alone_logFC_cross_contrast_corr_range', [float(offd.min()), float(offd.max())])
for tp in ['6', '24']:
    record(f'alone_vs_IL33program_corr_{tp}h', float(stats.pearsonr(L[C['IL33_' + tp]], L[C['CI_' + tp]])[0]))

# ------------------------------------------------------------------ 5. Figures
fig, axes = plt.subplots(1, 2, figsize=(12, 5.3), sharey=True)
for ax, tp in zip(axes, ['6', '24']):
    x = prog[f'IL33_vs_Veh_{tp}h']; resp = (prog[f'adjP_IL33_vs_Veh_{tp}h'] < 0.01) & (x.abs() > 1)
    ax.scatter(x[~resp], prog.loc[~resp, f'IL33+AX1177_vs_Veh_{tp}h'], s=2, c='0.85', rasterized=True, label='other genes')
    ax.scatter(x[resp], prog.loc[resp, f'IL33+iso_vs_Veh_{tp}h'], s=7, c='tab:orange', alpha=.6, label='IL-33 + isotype (IC119) vs vehicle')
    ax.scatter(x[resp], prog.loc[resp, f'IL33+AX1177_vs_Veh_{tp}h'], s=7, c='tab:blue', alpha=.6, label='IL-33 + AX-1177 vs vehicle')
    lim = [-6, 12]; ax.plot(lim, lim, 'k--', lw=.7); ax.axhline(0, c='k', lw=.7)
    ax.set_xlim(lim); ax.set_ylim(lim); ax.set_xlabel('IL-33 vs vehicle, log2FC (HUVEC)')
    n = int(resp.sum()); med = prog.loc[resp & (x > 0), f'pct_inhibition_{tp}h'].median()
    ax.set_title(f'HUVEC {tp} h: {n} IL-33-responsive genes (adjP<0.01, |log2FC|>1)\nmedian inhibition of induced genes by AX-1177: {med:.0f}%', fontsize=10)
axes[0].set_ylabel('log2FC vs vehicle (derived from the single fitted model)'); axes[0].legend(loc='upper left', fontsize=8, markerscale=2)
fig.suptitle('Fig 1. AX-1177 abolishes the IL-33(red) transcriptional program in primary endothelial cells; isotype does not', fontsize=11)
fig.tight_layout(); fig.savefig(f'{FIG}/fig1_neutralisation_HUVEC.png', dpi=160); plt.close(fig)

# SE anomaly figure
d = allc[allc.Comparison == C['IL33_6']].copy(); d['abn'] = d.ensembl.isin(abn)
fig, ax = plt.subplots(1, 2, figsize=(12, 4.8))
ax[0].scatter(d.loc[~d.abn, 'logFC'], d.loc[~d.abn, 't'], s=2, c='0.6', rasterized=True, label='genes with plausible SE')
ax[0].scatter(d.loc[d.abn, 'logFC'], d.loc[d.abn, 't'], s=12, c='red', label=f'{len(abn)} genes with SE > 3 log2 units')
offs = {'SELE': (-10, 8), 'VCAM1': (-5, 10), 'CXCL1': (4, -12), 'CXCL8': (-30, 10), 'IL1RL1': (-25, -16), 'PTGS2': (2, 8), 'CCL2': (-12, 10), 'PTX3': (-8, -16)}
for g, (dx, dy) in offs.items():
    r = d[d.symbol == g]
    if len(r): ax[0].annotate(g, (r.logFC.iloc[0], r.t.iloc[0]), fontsize=8, color='red', xytext=(dx, dy), textcoords='offset points',
                              arrowprops=dict(arrowstyle='-', color='red', lw=.5))
ax[0].set_xlabel('log2FC, IL-33 vs vehicle, HUVEC 6 h'); ax[0].set_ylabel('moderated t'); ax[0].legend(fontsize=8)
ax[0].set_title('Large fold-changes with t≈0: canonical activation genes and IL1RL1 (ST2)', fontsize=10)
ax[1].hist(np.log10(d.SE.abs()), bins=80, color='0.5', log=True); ax[1].axvline(np.log10(3), c='red', ls='--'); ax[1].text(np.log10(3)*1.05, 1000, 'SE = 3', color='red', fontsize=8)
ax[1].set_xlabel('log10 |SE| = log10 |logFC / t|'); ax[1].set_ylabel('genes (log scale)')
ax[1].set_title('Implied standard errors: main mode 0.03–1; tail up to >10,000', fontsize=10)
fig.suptitle('Fig 4. Data-integrity flag in the delivered limma tables (cannot arise from a correct group-means fit on log-CPM)', fontsize=11)
fig.tight_layout(); fig.savefig(f'{FIG}/fig4_rnaseq_SE_anomaly.png', dpi=160); plt.close(fig)
print('rnaseq analysis done; implausible-SE genes:', len(abn))
