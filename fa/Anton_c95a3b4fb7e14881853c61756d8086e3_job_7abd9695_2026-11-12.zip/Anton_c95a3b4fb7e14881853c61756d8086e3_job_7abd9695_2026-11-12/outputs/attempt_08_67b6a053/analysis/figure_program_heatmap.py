"""Fig 6: the IL-33 endothelial program by function, its neutralisation by AX-1177, and the serum association of the encoded proteins."""
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from common import TAB, FIG, load_serum

prog = pd.read_csv(f'{TAB}/rnaseq_il33_program_and_neutralisation_per_gene.csv', index_col=0).dropna(subset=['symbol']).drop_duplicates('symbol').set_index('symbol')
ser = load_serum().sort_values('p.value').drop_duplicates('gene').set_index('gene')
groups = [('NF-kB', ['NFKBIA', 'TNFAIP3', 'TRAF1', 'RELB', 'BIRC3', 'IRAK2']),
          ('Neutrophil\nchemokines/CSFs', ['CXCL2', 'CXCL3', 'CXCL5', 'CXCL6', 'CSF3', 'CSF2']),
          ('Cytokines /\nchemokines', ['IL6', 'TNF', 'IL1B', 'CCL20', 'CX3CL1', 'CCL7', 'CSF1', 'TNFRSF11B', 'IL18R1']),
          ('Coagulation', ['F3', 'SERPINE1', 'THBD', 'PLAU'])]
cols = [('IL33_vs_Veh_6h', 'IL-33\nvs veh\n6 h'), ('IL33+iso_vs_Veh_6h', 'IL-33+iso\nvs veh\n6 h'), ('IL33+AX1177_vs_Veh_6h', 'IL-33+AX-1177\nvs veh\n6 h'),
        ('IL33_vs_Veh_24h', 'IL-33\nvs veh\n24 h'), ('IL33+AX1177_vs_Veh_24h', 'IL-33+AX-1177\nvs veh\n24 h'),
        ('HGMEC_AX1177+IL33_vs_iso+IL33_6h', 'HGMEC\nAX+IL-33 vs\niso+IL-33 6 h')]
rows, labels, seps = [], [], []
for gname, genes in groups:
    for g in genes:
        rows.append([prog.loc[g, c] for c, _ in cols]); labels.append(g)
    seps.append(len(rows))
M = np.array(rows, dtype=float)
fig = plt.figure(figsize=(13, 10.5))
gs = fig.add_gridspec(2, 2, width_ratios=[6, 2.3], height_ratios=[20, 0.6], left=0.14, right=0.99, top=0.92, bottom=0.06, wspace=0.02, hspace=0.25)
ax = fig.add_subplot(gs[0, 0]); ax2 = fig.add_subplot(gs[0, 1], sharey=ax); cax = fig.add_subplot(gs[1, 0])
im = ax.imshow(M, cmap='RdBu_r', norm=TwoSlopeNorm(0, -6, 10), aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]): ax.text(j, i, f'{M[i, j]:.1f}', ha='center', va='center', fontsize=7, color='k' if abs(M[i, j]) < 5 else 'w')
ax.set_xticks(range(len(cols))); ax.set_xticklabels([l for _, l in cols], fontsize=8)
ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels, fontsize=8)
for s_ in seps[:-1]: ax.axhline(s_ - .5, c='k', lw=1)
start_ = 0
for (gname, genes), s_ in zip(groups, seps):
    ax.text(-1.55, (start_ + s_ - 1) / 2, gname, rotation=90, ha='center', va='center', fontsize=8, fontweight='bold'); start_ = s_
ax.axvline(2.5, c='k', lw=.6); ax.axvline(4.5, c='k', lw=.6)
fig.colorbar(im, cax=cax, orientation='horizontal', label='log2 fold-change (in vitro)')
orr, lab2 = [], []
alias = {'TNFRSF11B': 'OPG', 'CCL7': 'MCP-3', 'CSF1': 'CSF-1', 'F3': 'TF (tissue factor)', 'SERPINE1': 'PAI-1', 'THBD': 'TM', 'PLAU': 'uPA', 'IL18R1': 'IL-18R1', 'CSF3': 'G-CSF'}
for g in labels:
    if g in ser.index:
        r = ser.loc[g]; orr.append(np.log2(r.OR)); lab2.append(f"{alias.get(g, g)}: OR {r.OR:.2f}, q={r['adj.p.value']:.3f}")
    else:
        orr.append(np.nan); lab2.append('not on delivered panels')
O = np.array(orr)[:, None]
ax2.imshow(np.ma.masked_invalid(O), cmap='Reds', vmin=0, vmax=3, aspect='auto', extent=(-.5, .5, len(labels) - .5, -.5))
for i, t in enumerate(lab2): ax2.text(0.6, i, t, fontsize=7, va='center')
ax2.set_xlim(-.5, 7.5); ax2.set_xticks([0]); ax2.set_xticklabels(['serum\nlog2 OR'], fontsize=8)
plt.setp(ax2.get_yticklabels(), visible=False); ax2.tick_params(axis='y', length=0)
for s_ in seps[:-1]: ax2.axhline(s_ - .5, c='k', lw=1)
for sp in ['right', 'top']: ax2.spines[sp].set_visible(False)
fig.suptitle('Fig 6. What IL-33(red) does to primary human endothelium, what AX-1177 undoes, and which products track outcome in patients\n'
             '(derived group-mean contrasts from the single delivered fit; serum OR per log unit, adjusted age/sex/NEWS2)', fontsize=10)
fig.savefig(f'{FIG}/fig6_il33_program_heatmap.png', dpi=160); plt.close(fig)
print('fig6 done')
