#!/usr/bin/env bash
# Regenerates every table, figure and cited number in the AX-1177 audit brief from the delivered files,
# then renders the brief to self-contained HTML.
# Requires the 'chem' micromamba env (pandas, openpyxl, scipy, statsmodels, matplotlib, markdown).
# First run parses the 1.2M-row contrasts workbook (~6 min) and caches it under /tmp/work/cache.
set -euo pipefail
cd "$(dirname "$0")"
rm -f ../tables/key_numbers.json
micromamba run -n chem python rnaseq_analysis.py
micromamba run -n chem python serum_analysis.py
micromamba run -n chem python postmortem_analysis.py > /dev/null
micromamba run -n chem python figure_program_heatmap.py
micromamba run -n chem python build_html.py
micromamba run -n chem python build_pdf.py
echo "all analyses complete"
