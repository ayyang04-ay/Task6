"""Shared loaders for the AX-1177 audit analysis.

All analyses read the delivered files read-only from RAW and write to OUT.
The 1.2 M-row contrasts workbook is slow to parse (~6 min), so it is cached as parquet.
"""
import os, re, json
import numpy as np, pandas as pd

RAW = '/tmp/world/filesystem'
OUT = '/tmp/outputs'
CACHE = '/tmp/work/cache'
FIG = os.path.join(OUT, 'figures'); TAB = os.path.join(OUT, 'tables')
for d in (CACHE, FIG, TAB): os.makedirs(d, exist_ok=True)

KEY_NUMBERS_FILE = os.path.join(OUT, 'tables', 'key_numbers.json')

def record(key, value):
    """Append a number that is cited in the report, so every figure in the brief is traceable."""
    d = {}
    if os.path.exists(KEY_NUMBERS_FILE):
        with open(KEY_NUMBERS_FILE) as fh: d = json.load(fh)
    if isinstance(value, (np.floating,)): value = float(value)
    if isinstance(value, (np.integer,)): value = int(value)
    d[key] = value
    with open(KEY_NUMBERS_FILE, 'w') as fh: json.dump(d, fh, indent=1, default=str)

# ----------------------------------------------------------------------------- RNA-seq
def load_rnaseq():
    """Return one long table with all 26 delivered contrasts (24 in the contrasts workbook + 2 HUVEC IL-33 vs vehicle)."""
    pq = os.path.join(CACHE, 'rnaseq_all.parquet'); chk = os.path.join(CACHE, 'rnaseq_sheetcheck.json')
    if os.path.exists(pq) and os.path.exists(chk):
        with open(chk) as fh:
            for k, v in json.load(fh).items(): record(k, v)
        return pd.read_parquet(pq)
    sheets = pd.read_excel(os.path.join(RAW, 'AX-1177_rnaseq_contrasts.xlsx'), sheet_name=None)
    a, b = sheets['6h'], sheets['24h']
    # QC: the two sheets are labelled 6h / 24h but both carry all 24 contrasts; check they are identical
    key = ['Comparison', 'ensembl']
    m = a.merge(b, on=key, suffixes=('_a', '_b'))
    identical = bool(len(m) == len(a) == len(b) and np.allclose(m.logFC_a, m.logFC_b) and np.allclose(m.t_a, m.t_b))
    checks = {'rnaseq_sheets_6h_24h_identical': identical, 'rnaseq_contrasts_per_sheet': int(a.Comparison.nunique()),
              'rnaseq_sheet6h_contains_24h_contrasts': bool(a.Comparison.str.contains('24hrs').any()),
              'rnaseq_sheet24h_contains_6h_contrasts': bool(b.Comparison.str.contains('6hrs').any())}
    for k, v in checks.items(): record(k, v)
    with open(chk, 'w') as fh: json.dump(checks, fh)
    h = pd.read_excel(os.path.join(RAW, 'AX-1177_rnaseq_huvec_il33.xlsx'), sheet_name=None)
    allc = pd.concat([a] + list(h.values()), ignore_index=True)
    allc['SE'] = allc.logFC / allc.t
    allc.to_parquet(pq)
    return allc

def pivot(allc, value, exclude=None):
    x = allc if exclude is None else allc[~allc.ensembl.isin(exclude)]
    return x.pivot(index='ensembl', columns='Comparison', values=value)

C = {  # short names for the contrasts used in the analysis
 'IL33_6': 'IL33_vs_Nontreated_HUVEC_6_hrs', 'IL33_24': 'IL33_vs_Nontreated_HUVEC_24_hrs',
 'LCL_6': 'Compound_47_IL33_vs_IL33_HUVEC_6hrs', 'LCL_24': 'Compound_47_IL33_vs_IL33_HUVEC_24hrs',
 'LCLI_6': 'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs', 'LCLI_24': 'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs',
 'CI_6': 'Compound_47_vs_IC119_HUVEC_6hrs', 'CI_24': 'Compound_47_vs_IC119_HUVEC_24hrs',
 'G_LCL_6': 'Compound_47_IL33_vs_IL33_HGMEC_6hrs', 'G_LCL_24': 'Compound_47_IL33_vs_IL33_HGMEC_24hrs',
 'G_LCLI_6': 'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs', 'G_LCLI_24': 'Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs',
 'G_CI_6': 'Compound_47_vs_IC119_HGMEC_6hrs', 'G_CI_24': 'Compound_47_vs_IC119_HGMEC_24hrs',
}

# ----------------------------------------------------------------------------- Serum proteomics
def load_serum():
    p = pd.read_excel(os.path.join(RAW, 'AX-1177_serum_proteomics.xlsx'), sheet_name=0)
    p['rank'] = np.arange(1, len(p) + 1)
    import sys; sys.path.insert(0, os.path.dirname(__file__))
    from olink_map import to_gene
    p['gene'] = p.assay.map(to_gene)
    p['panel_short'] = p.panel.str.replace('Olink Target 96 ', '', regex=False)
    return p

# ----------------------------------------------------------------------------- Post-mortem IHC
PM_COLS = ['sample','block','tissue_rna','sample2','lobe','category','race','sex','age','sars2','pathology','HE_eos','EPX','EDN','MBP',
           'D7_2','IL5Ra_NE','NE','IL5Ra_TRYP','TRYPTASE','EPX_d','NE_d','TRYP_d','IL33_epi','IL33_endo','IL33_vsm','notes','colAB']
SCORE_COLS = ['EPX','EDN','MBP','D7_2','IL5Ra_NE','NE','IL5Ra_TRYP','TRYPTASE','EPX_d','NE_d','TRYP_d','IL33_epi','IL33_endo','IL33_vsm']

def _parse_score(v):
    if v is None or (isinstance(v, float) and np.isnan(v)): return np.nan
    if isinstance(v, (int, float)): return float(v)
    s = str(v).strip()
    if s in ('ND', 'N/A', ''): return np.nan
    if s.startswith('='):            # one cell holds an Excel formula, '=(2+4.5)/2'
        if not re.fullmatch(r'=[\d\.\+\-\*/\(\) ]+', s): raise ValueError(s)
        return float(eval(s[1:]))
    m = re.fullmatch(r'(\d+(?:\.\d+)?)\+?', s)
    if m: return float(m.group(1))
    raise ValueError(f'unparsed score {s!r}')

def load_postmortem():
    """Block-level table: merged cells expanded, scores parsed, donor-level fields filled within donor."""
    import openpyxl
    wb = openpyxl.load_workbook(os.path.join(RAW, 'AX-1177_postmortem_lung.xlsx'))
    ws = wb.active
    vals = [[c.value for c in row] for row in ws.iter_rows()]
    merged = [str(r) for r in ws.merged_cells.ranges]
    for rng in ws.merged_cells.ranges:
        v = ws.cell(rng.min_row, rng.min_col).value
        for r in range(rng.min_row, rng.max_row + 1):
            for cc in range(rng.min_col, rng.max_col + 1):
                vals[r - 1][cc - 1] = v
    rows = [r for r in vals[1:] if any(x is not None for x in r)]
    df = pd.DataFrame(rows, columns=PM_COLS)
    df['raw_excel_row'] = [i + 2 for i, r in enumerate(vals[1:]) if any(x is not None for x in r)]
    df['sample'] = df['sample'].astype(str).str.strip()
    for c in SCORE_COLS: df[c + '_n'] = df[c].map(_parse_score)
    df['HE_eos_n'] = (df.HE_eos.astype(str).str.strip() == 'Y').astype(float)
    for c in ['category', 'race', 'sex', 'age', 'sars2', 'pathology', 'notes']:
        df[c] = df.groupby('sample')[c].transform(lambda s: s.dropna().iloc[0] if s.notna().any() else np.nan)
    df['grp'] = df.category.map({'COVID pos pneumonia': 'COVID+ pneumonia', 'COVID neg pneumonia': 'COVID- pneumonia',
                                 'COVID neg non-pneumonia': 'COVID- non-pneumonia'})
    df['age'] = df.age.astype(float)
    df.attrs['merged'] = merged
    return df

# Pathology-verified grouping (from the free-text autopsy diagnoses in the delivered file; see postmortem_analysis.py)
VERIFIED = {
 **{s: 'COVID+ acute pneumonia/ALI' for s in ['2035','2040','2043','2044','2045','2049','2060','2072','2073','2075','2105','2108','2110','2113']},
 **{s: 'COVID+ no acute pneumonia in report' for s in ['2067','2101']},
 **{s: 'COVID- acute pneumonia' for s in ['1130','1138','1149','1159','1165','1910','1976']},
 **{s: 'COVID- other lung infection/injury' for s in ['1956','1944']},
 **{s: 'No acute lung infection/injury' for s in ['1905','1961','1968','1970','1861','1965']}}
