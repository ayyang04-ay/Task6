"""Render the committee brief to PDF (reportlab), from the same Markdown source as the HTML."""
import os, re, html as htmlmod
import markdown, matplotlib
from bs4 import BeautifulSoup, NavigableString, Tag
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, ListFlowable, ListItem,
                                KeepTogether, PageBreak, HRFlowable)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping

OUT = '/tmp/outputs'
fdir = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
for name, f in [('DejaVu', 'DejaVuSans.ttf'), ('DejaVu-Bold', 'DejaVuSans-Bold.ttf'), ('DejaVu-Oblique', 'DejaVuSans-Oblique.ttf'),
                ('DejaVu-BoldOblique', 'DejaVuSans-BoldOblique.ttf'), ('DejaVuMono', 'DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name, os.path.join(fdir, f)))
addMapping('DejaVu', 0, 0, 'DejaVu'); addMapping('DejaVu', 1, 0, 'DejaVu-Bold'); addMapping('DejaVu', 0, 1, 'DejaVu-Oblique'); addMapping('DejaVu', 1, 1, 'DejaVu-BoldOblique')

ss = getSampleStyleSheet()
BLUE = colors.HexColor('#0b3d91')
S = {
 'body': ParagraphStyle('body', parent=ss['BodyText'], fontName='DejaVu', fontSize=9, leading=12, spaceAfter=4),
 'h1': ParagraphStyle('h1', parent=ss['Title'], fontName='DejaVu-Bold', fontSize=17, leading=21, textColor=BLUE, alignment=0, spaceAfter=8),
 'h2': ParagraphStyle('h2', parent=ss['Heading2'], fontName='DejaVu-Bold', fontSize=13, leading=16, textColor=BLUE, spaceBefore=12, spaceAfter=6),
 'h3': ParagraphStyle('h3', parent=ss['Heading3'], fontName='DejaVu-Bold', fontSize=10.5, leading=13.5, spaceBefore=8, spaceAfter=4),
 'cell': ParagraphStyle('cell', fontName='DejaVu', fontSize=7.3, leading=9),
 'cellh': ParagraphStyle('cellh', fontName='DejaVu-Bold', fontSize=7.5, leading=9.2),
 'quote': ParagraphStyle('quote', fontName='DejaVu', fontSize=9, leading=12),
}

def inline(el):
    """Convert an element's children to reportlab mini-markup."""
    out = []
    for ch in el.children:
        if isinstance(ch, NavigableString):
            out.append(htmlmod.escape(str(ch), quote=False))
        elif isinstance(ch, Tag):
            if ch.name in ('strong', 'b'): out.append(f'<b>{inline(ch)}</b>')
            elif ch.name in ('em', 'i'): out.append(f'<i>{inline(ch)}</i>')
            elif ch.name == 'code': out.append(f'<font face="DejaVuMono" size="8">{inline(ch)}</font>')
            elif ch.name == 'br': out.append('<br/>')
            elif ch.name == 'a': out.append(inline(ch))
            elif ch.name in ('ul', 'ol', 'img', 'table', 'p', 'blockquote'): pass   # handled as blocks
            else: out.append(inline(ch))
    return ''.join(out).strip()

def table_flowable(t, width):
    rows = []
    for tr in t.find_all('tr'):
        cells = tr.find_all(['th', 'td'])
        rows.append([Paragraph(inline(c) or ' ', S['cellh'] if c.name == 'th' else S['cell']) for c in cells])
    ncol = max(len(r) for r in rows)
    # column widths proportional to (capped) text length
    lens = [0] * ncol; maxword = [0] * ncol
    for tr in t.find_all('tr'):
        for j, c in enumerate(tr.find_all(['th', 'td'])):
            txt = c.get_text()
            lens[j] = max(lens[j], min(len(txt), 220))
            maxword[j] = max([maxword[j]] + [len(w) for w in re.split(r'[\s/]+', txt)])
    minw = [min(mw, 24) * 4.4 + 8 for mw in maxword]          # keep the longest word on one line (7.3-pt font)
    lens = [max(l, 8) ** 0.8 for l in lens]
    cw = [width * l / sum(lens) for l in lens]
    for _ in range(10):                                        # enforce minimum widths, rescale the rest
        short = [j for j in range(ncol) if cw[j] < minw[j]]
        if not short: break
        fixed = sum(minw[j] for j in short); rest = [j for j in range(ncol) if j not in short]
        if not rest or fixed >= width: cw = [width * m / sum(minw) for m in minw]; break
        tot_rest = sum(lens[j] for j in rest)
        cw = [minw[j] if j in short else (width - fixed) * lens[j] / tot_rest for j in range(ncol)]
    tb = Table(rows, colWidths=cw, repeatRows=1)
    tb.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#c8ccd4')),
                            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#eef2f8')),
                            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                            ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
                            ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
                            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#fafbfd')])]))
    return tb

def list_flowable(lst, width, depth=0):
    items = []
    for li in lst.find_all('li', recursive=False):
        parts, buf = [], []
        def flush():
            txt = ''.join(buf).strip()
            if txt: parts.append(Paragraph(txt, S['body']))
            buf.clear()
        for ch in li.children:                      # keep document order: text, paragraphs, tables, sub-lists
            if isinstance(ch, NavigableString):
                buf.append(htmlmod.escape(str(ch), quote=False)); continue
            if not isinstance(ch, Tag): continue
            if ch.name == 'p': flush(); parts.append(Paragraph(inline(ch), S['body']))
            elif ch.name in ('ul', 'ol'): flush(); parts.append(list_flowable(ch, width - 14, depth + 1))
            elif ch.name == 'table': flush(); parts.append(table_flowable(ch, width - 20)); parts.append(Spacer(1, 3))
            else:
                tmp = BeautifulSoup('<span></span>', 'html.parser').span; tmp.append(ch.__copy__()); buf.append(inline(tmp))
        flush()
        items.append(ListItem(parts if len(parts) > 1 else (parts[0] if parts else Paragraph('', S['body'])), leftIndent=12))
    kind = 'bullet' if lst.name == 'ul' else '1'
    start = '•' if kind == 'bullet' else int(lst.get('start', 1))
    return ListFlowable(items, bulletType=kind, start=start, leftIndent=12, bulletFontName='DejaVu', bulletFontSize=8)

def blocks(container, width):
    fl = []
    for el in container.children:
        if not isinstance(el, Tag): continue
        if el.name in ('h1', 'h2', 'h3'):
            fl.append(Paragraph(inline(el), S[el.name]))
        elif el.name == 'p':
            img = el.find('img')
            if img is not None:
                src = img['src']; path = os.path.join(OUT, src)
                im = Image(path); iw, ih = im.imageWidth, im.imageHeight
                w = width; h = ih * w / iw
                if h > 20 * cm: h = 20 * cm; w = iw * h / ih
                im.drawWidth, im.drawHeight = w, h
                fl.append(im); fl.append(Spacer(1, 6))
            else:
                fl.append(Paragraph(inline(el), S['body']))
        elif el.name in ('ul', 'ol'):
            fl.append(list_flowable(el, width))
        elif el.name == 'table':
            fl.append(table_flowable(el, width)); fl.append(Spacer(1, 6))
        elif el.name == 'blockquote':
            inner = blocks(el, width - 16)
            box = Table([[inner]], colWidths=[width])
            box.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f3f7ff')),
                                     ('LINEBEFORE', (0, 0), (0, -1), 4, BLUE), ('LEFTPADDING', (0, 0), (-1, -1), 8),
                                     ('TOPPADDING', (0, 0), (-1, -1), 5), ('BOTTOMPADDING', (0, 0), (-1, -1), 5)]))
            fl.append(box); fl.append(Spacer(1, 6))
        elif el.name == 'hr':
            fl.append(HRFlowable(width='100%', thickness=0.6, color=colors.HexColor('#ccd'), spaceBefore=4, spaceAfter=6))
    return fl

md = open(os.path.join(OUT, 'AX-1177_committee_brief.md'), encoding='utf-8').read()
soup = BeautifulSoup(markdown.markdown(md, extensions=['tables', 'sane_lists']), 'html.parser')
doc = SimpleDocTemplate(os.path.join(OUT, 'AX-1177_committee_brief.pdf'), pagesize=A4, leftMargin=1.6 * cm, rightMargin=1.6 * cm,
                        topMargin=1.5 * cm, bottomMargin=1.5 * cm, title='AX-1177 portfolio audit brief', author='Portfolio analytics')
W = A4[0] - 3.2 * cm
def footer(canvas, d):
    canvas.saveState(); canvas.setFont('DejaVu', 7); canvas.setFillColor(colors.grey)
    canvas.drawString(1.6 * cm, 0.9 * cm, 'AX-1177 portfolio audit brief. Grounded in the AX-1177 data package only; numbers reproducible via analysis/run_all.sh')
    canvas.drawRightString(A4[0] - 1.6 * cm, 0.9 * cm, f'page {d.page}'); canvas.restoreState()
doc.build(blocks(soup, W), onFirstPage=footer, onLaterPages=footer)
print('pdf written')
