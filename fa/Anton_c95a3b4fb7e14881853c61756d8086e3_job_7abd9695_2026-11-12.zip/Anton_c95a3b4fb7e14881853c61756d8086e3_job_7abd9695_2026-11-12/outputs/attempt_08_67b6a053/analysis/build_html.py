"""Render the committee brief (Markdown) to a single self-contained HTML file with embedded figures."""
import base64, os, re, markdown
OUT = '/tmp/outputs'
md = open(os.path.join(OUT, 'AX-1177_committee_brief.md'), encoding='utf-8').read()
html_body = markdown.markdown(md, extensions=['tables', 'fenced_code', 'sane_lists'])
def embed(m):
    src = m.group(1)
    path = os.path.join(OUT, src)
    if not os.path.exists(path): return m.group(0)
    b64 = base64.b64encode(open(path, 'rb').read()).decode()
    return f'src="data:image/png;base64,{b64}"'
html_body = re.sub(r'src="(figures/[^"]+\.png)"', embed, html_body)
css = """
body{font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;max-width:1100px;margin:2em auto;padding:0 1.5em;line-height:1.45;color:#1d1d1f;font-size:14.5px}
h1{font-size:1.7em;border-bottom:3px solid #0b3d91;padding-bottom:.3em}
h2{font-size:1.35em;color:#0b3d91;border-bottom:1px solid #ccd;padding-bottom:.2em;margin-top:1.8em}
h3{font-size:1.12em;color:#222;margin-top:1.3em}
table{border-collapse:collapse;margin:.8em 0;font-size:12.5px;width:100%}
th,td{border:1px solid #c8ccd4;padding:5px 7px;vertical-align:top;text-align:left}
th{background:#eef2f8}
tr:nth-child(even) td{background:#fafbfd}
blockquote{background:#f3f7ff;border-left:5px solid #0b3d91;margin:1em 0;padding:.6em 1em}
code{background:#f2f2f2;padding:1px 4px;border-radius:3px;font-size:.92em}
img{max-width:100%;border:1px solid #ddd;margin:.5em 0 1.5em 0}
"""
html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>AX-1177 portfolio audit brief</title><style>{css}</style></head>
<body>{html_body}</body></html>"""
open(os.path.join(OUT, 'AX-1177_committee_brief.html'), 'w', encoding='utf-8').write(html)
print('html written', len(html)//1024, 'KB')
