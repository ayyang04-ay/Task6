# AX-1177 (anti-IL-33 mAb) — Portfolio Audit
### Recommendation, defence and forward view

*Prepared for: Portfolio Committee. Basis: the complete AX-1177 internal data package (methods annex; endothelial/epithelial RNA-seq contrasts; serum proteomics from 100 hospitalised COVID-19 patients; post-mortem lung IHC from 31 donors), re-analysed from the delivered files. Every conclusion below is drawn from these data. Outside knowledge is limited to basic target biology (e.g. that sST2 is the soluble decoy form of the IL-33 receptor and that IL-33 is a nuclear alarmin) and the vendor’s published Olink panel content, which is flagged where used.*


## 1. Recommendation

> **Do not keep AX-1177 in the respiratory portfolio as a severe viral lower-respiratory-tract-infection (LRTI) programme. Stop that indication now.**
>
> **Hold the molecule; do not terminate it yet.** Run one short, low-cost check (≤ 3 months) using only data and tissue we already own, and re-admit AX-1177 to the portfolio only if it passes Gates 0–1 in Section 5.4. Otherwise terminate.
>
> **In one line: our data validate the drug, not the disease hypothesis.** AX-1177 is a clean, potent IL-33 neutraliser in human endothelial cells. But none of our human data show that IL-33 is raised in, specific to, or a driver of severe viral LRTI. The direct measurement of the target in patients was made but not delivered to us.

**What the committee is being asked to accept.** We stop a programme whose central hypothesis has failed every test our own data allow: tissue, serum mechanism, and target measurement. We keep, at minimal cost (analyst time plus a targeted expression panel on 22 archived lung RNAs), a well-characterised molecule plus a ready-made biomarker kit (an sST2 enrichment marker and an endothelial PD panel). That kit can decide its fate within one quarter.


## 2. The case: what our data show

| # | Finding | Strength of evidence | Key numbers |
|---|---|---|---|
| 1 | AX-1177 neutralises reduced-IL-33 signalling in endothelium and is inert without IL-33 | Strong (in vitro; one donor per line, one dose) | IL-33: 4,031 DE genes (HUVEC 6 h). AX-1177 blocks a median 95–100% of the induced response at 6 h and 73–83% at 24 h (isotype-matched). HGMEC r=0.70. AX-1177 alone: 0–9 robust genes/contrast |
| 2 | IL-33 is constitutive in human lung and not higher in COVID-19 or pneumonia | Consistent negative (31 donors) | Donor-level KW p=0.65 / 0.11 / 0.16 (epithelium / endothelium / VSM); COVID+ numerically lowest |
| 3 | The drug target was measured in serum but not delivered | Critical gap | BH m=1,194 vs 1,094 delivered; Inflammation panel 77/92, missing IL-33, TSLP, IL-4/5/13 (per vendor panel content) |
| 4 | Severity is cell death + neutrophils; the AX-1177-reversible IL-33 programme does not explain it | Moderate–strong negative | IL-33-inducible proteins 17.2% vs 17.8% FDR-significant (p=1.0); intracellular z 3.4, neutrophil 2.7, type-2 0.2 |
| 5 | sST2 is the most robust prognostic marker but not evidence of IL-33 causality | Strong (prognostic); weak (mechanistic) | OR 3.0/log unit (1.8–5.0), adj p=0.007; rank 2/1,094 (1 after shift adjustment) |
| 6 | Quality defects in every dataset, mostly inflating positives | Structural | 27 duplicated proteins; 74 blocks/31 donors; 9/31 labels contradicted by pathology; 382 genes with >3× SE inflation |


### 2.1 The molecule works, in the cells we tested (Figure 1)

- IL-33 (reduced form, 30 ng/mL) triggers a large endothelial inflammatory programme in HUVEC: 4,031 genes change at 6 h (FDR<0.05) and 1,836 at 24 h. The top responders are canonical NF-κB targets (NFKBIA t=44, TNFAIP3, TRAF1, RELB, BIRC3). Also induced: leukocyte adhesion molecules (E-selectin +11.2 log2, VCAM-1 +8.7, ICAM-1 +6.0), neutrophil chemokines (CXCL1/2/3/5/6/8, CCL20), GM-CSF/G-CSF, TNF, IL-1α/β, and a pro-coagulant switch (tissue factor +5.6, PAI-1 +1.7, thrombomodulin −1.0).
- **AX-1177 blocks essentially all of the IL-33-induced response at 6 h.** Against the isotype-matched arm (AX-1177+IL-33 vs isotype+IL-33, independent of the IL-33-alone arm), the median block is 100% (IQR 93–106%) for the 289 well-expressed induced genes. Across all 635 induced genes, including noisy low-count transcripts, it is 95–98%. At 24 h the block is 73–83% (82% for well-expressed genes). The IL-33 response itself replicates between the two independent IL-33-exposed arms (r=0.97). Glomerular microvascular endothelium (HGMEC) shows the same AX-1177-reversible programme (r=0.70 across signature genes), at ~44% of the HUVEC magnitude.
- **AX-1177 is transcriptionally inert without IL-33.** Across HUVEC, HGMEC, A549 and MCF7 at 6 and 24 h, it changes only 0–9 genes robustly, with no coherent pathway. The delivered "FDR hits" in these contrasts are variance artefacts (e.g. AKR1C2 log2FC 0.06 at p=10⁻⁷³) or low-count noise (Figure S1). Neither off-target biology nor endogenous IL-33 tone appears in culture.
- Limits: one donor per endothelial line; one dose of antibody and IL-33 (~40-fold molar excess); antibody added with IL-33 (no pre-incubation); reduced IL-33 only. The epithelial lines (A549, MCF7) never received IL-33. Potency, activity against oxidised IL-33 (the asset’s stated differentiator) and activity in lung cells are therefore **not demonstrated**.


### 2.2 The disease hypothesis is not supported in human lung (Figure 2)

- IL-33 protein is constitutively abundant in basal epithelium, endothelium and vascular smooth muscle in every one of 31 elderly donors. In endothelium, 53% of blocks sit at the top of the score range.
- **It is not higher in COVID-19 or in pneumonia.** At donor level, IL-33 does not differ across COVID+ pneumonia (16), COVID− pneumonia (10) and non-pneumonia (5). Kruskal–Wallis p = 0.65 (epithelium), 0.11 (endothelium) and 0.16 (VSM). COVID+ donors are numerically the *lowest* in all three compartments.
- The only IL-33 signal is a modest *fall* in endothelial IL-33 where acute pneumonia and neutrophils are present. It tracks neutrophil elastase (ρ=−0.43, p=0.016) and is lower in pathology-verified COVID+ acute pneumonia than in lungs without pneumonia (mixed model p=0.034). COVID+ and COVID− pneumonia do not differ (p=0.34). The finding is pathogen-agnostic, and it cannot distinguish alarmin release from activation-induced loss of expression.
- The eosinophil "pneumonia" signal in the delivered labels (EDN/MBP, p≈0.005) is an artefact of labelling. It disappears when donors are classified from their pathology reports (EDN p=0.11). 9 of 31 donor labels contradict the pathology text. IL-5Rα staining tracks neutrophil elastase (ρ=0.89), not eosinophil granule proteins (ρ≤0.20). Neutrophil infiltration is the robust tissue finding.


### 2.3 Patient serum: sST2 predicts, but the IL-33 programme does not explain severity, and IL-33 itself is missing (Figure 3)

- **sST2 (the soluble IL-33 decoy receptor) is our most robust prognostic marker.** OR 3.0 per log unit (95% CI 1.8–5.0), p=1.7×10⁻⁵, adj p=0.007, rank 2 of 1,094. It is rank 1 after correcting for a panel-level global shift. Adjusted for age, sex and NEWS2.
- **The AX-1177-reversible endothelial programme is not enriched among severity markers.** I took the 99 serum proteins that IL-33 induces in vitro and AX-1177 reverses. 17.2% are FDR-significant for the composite endpoint, versus 17.8% of the 792 proteins IL-33 does not touch (Fisher p=1.0; Mann–Whitney on z, p=0.87). Only 7 of the top 50 severity proteins are IL-33-inducible. The most endothelium-specific IL-33 products are weak or null: E-selectin p=0.02, VCAM-1 p=0.43, G-CSF p=0.23.
- Severity in this cohort is driven by **cell death/leakage and neutrophil activation**. Intracellular proteins have median z 3.4 (26/29 FDR-significant), neutrophil markers 2.7 (12/24), interferon markers 2.0, type-2/eosinophil/mast-cell markers 0.2 (IL-5 OR 1.00, eotaxin 1.08, tryptase 1.07).
- **The drug’s target was not delivered.** The delivered adjusted p-values imply Benjamini–Hochberg over 1,194 tests; only 1,094 assays were delivered. The Inflammation panel is missing 15 of its 92 analytes. By the vendor’s published panel content, those include IL-33 itself, plus TSLP, IL-4, IL-5 and IL-13. IL-33 was most likely run and dropped for being below the detection limit.


## 3. Anticipated challenges, and the answers our data support

**Q: “sST2 is #2 of 1,094, and #1 after adjustment. Isn’t that the IL-33 pathway driving severity?”**

A: sST2 is the decoy receptor. Injured endothelium and epithelium release it under many stimuli, and high sST2 *sequesters* IL-33 rather than signals it. In our own cells, IL-33 raises IL1RL1 only modestly and transiently in HUVEC (+1.6 log2 at 6 h, +0.4 at 24 h; not statistically resolvable in the delivered model) and not at all in glomerular endothelium. The one measurement that would connect sST2 to IL-33 is circulating IL-33, and it was run but not delivered. sST2 is the right *enrichment* marker. It is not evidence that neutralising IL-33 changes outcome.

**Q: “AX-1177 switches off IL-6, PTX3, OPG, tissue factor and CCL20, and all of them predict severity. Doesn’t that show we can hit severity biology?”**

A: In a dish where exogenous IL-33 is the only stimulus, yes. In patients, those proteins come from many cell types responding to many signals, including the IL-1 and TNF that IL-33 itself induces (IL1A +4.6, TNF +7.9 log2 at 6 h). The fair test is whether IL-33-inducible proteins are *more* prognostic than the rest. They are not (17.2% vs 17.8%). The proteins most specific to endothelial IL-33 signalling (E-selectin, VCAM-1, G-CSF) carry little or no prognostic information.

**Q: “Lower endothelial IL-33 in pneumonia means the alarmin is being released, i.e. the pathway is active.”**

A: That reading is compatible with our data, but so is activation-induced loss of expression, and our HUVEC data show a (non-significant) fall in IL33 mRNA after IL-33 stimulation (−0.9 log2 at 24 h). The effect is modest (about 0.6–0.8 points on a ceiling-limited score), comes from a single reader, and does not differ between COVID+ and COVID− pneumonia. It justifies measuring free IL-33. It does not justify clinical spend.

**Q: “Absence of evidence is not evidence of absence. The tissue study is small.”**

A: Correct for small effects: 16 vs 10 donors only detects large differences. But the direction is *opposite* to the hypothesis in all three compartments, which makes a hidden large increase implausible. And the serum data independently point the same way: the IL-33-reversible programme is not enriched among severity markers.

**Q: “The data-quality problems cut both ways. A clean re-analysis might rescue the signal.”**

A: Agreed. That is why Gate 0 is retrieval and re-analysis, at analyst-time cost only. But we should not fund clinical development on this package. Fixing the RNA-seq model would mostly sharpen the in vitro pharmacology, which is already strong. It cannot create a disease link.

**Q: “The molecule is good. Why not simply keep it?”**

A: Molecule quality is necessary but not sufficient. A lung indication needs four facts we do not have: activity against oxidised IL-33, activity in lung cells, potency, and a therapeutic window. On the window: only co-addition was tested, and block falls from 95–100% at 6 h to 73–83% by 24 h. The hold-with-gates option preserves the asset for one quarter without development spend.

**Q: “Why not pivot to COPD/asthma, where anti-IL-33 is better established?”**

A: Not on our data. IL-33 and eosinophil scores do not differ by COPD/asthma annotation (all p>0.1). The eosinophil signal is a labelling artefact, and serum type-2 markers are null. We have no epithelial IL-33 experiments. An airway pivot would rest entirely on external evidence and would need its own data package. It cannot be defended from this one.


## 4. If we drop it: what we are dropping, and why

**What we are dropping.** A human IgG1 anti-IL-33 that does three things. (i) It neutralises reduced-IL-33 signalling in venous and glomerular endothelial cells, blocking essentially all (median 95–100%) of a ~600-gene NF-κB / adhesion / chemokine / GM-CSF / G-CSF / tissue-factor programme at 6 h. (ii) It is transcriptionally inert without IL-33 in four human cell types. (iii) It comes with a patient-measurable biomarker kit: sST2 for enrichment and an endothelial PD panel (E-selectin, OPG, tissue factor, CCL20, PTX3).

**What it never acquired.** Any human evidence that IL-33 is raised in, specific to, or causal for the target disease. Also missing: functional data on oxidised IL-33 and on lung cells, potency, and a therapeutic window.

**Why we drop it.** The viral-LRTI hypothesis failed each test our data could apply. In tissue, IL-33 is not increased and there is no virus specificity. In serum, the IL-33-reversible programme is not enriched among severity proteins. And the target measurement was not delivered. The positive signals (sST2; prognostic proteins that AX-1177 can reverse in vitro) are explained equally well by non-specific injury and neutrophil biology, which dominates severity in this cohort.


## 5. Forward view


### 5.1 What indication do our data actually point at?

Not “viral” LRTI, and not COVID-19 specifically. To the extent our data point anywhere, they point at **pathogen-agnostic, endothelium- and neutrophil-driven acute lung injury (severe pneumonia / ARDS regardless of cause), enriched by high sST2**. Three lines of evidence converge:

- **In vitro:** IL-33’s action is an endothelial NF-κB, leukocyte-recruiting, pro-coagulant programme, and AX-1177 blocks it.
- **In tissue:** the only IL-33 signal (endothelial IL-33 falling as neutrophils rise) is the same in COVID+ and COVID− pneumonia.
- **In serum:** severity is neutrophil- and injury-driven, sST2 is the most robust prognostic marker, and several AX-1177-reversible endothelial proteins are prognostic (tissue factor, OPG, PTX3; PAI-1 borderline).

This is a **hypothesis, not a validated indication**, but it is the only one our data support at all. A weaker secondary hypothesis is microvascular endothelial injury outside the lung: glomerular endothelium responds, though at ~44% of the HUVEC magnitude, transiently, and with no patient data. Type-2 airway disease, cardiovascular disease and COVID-specific positioning are not supported (Section 6).


### 5.2 What the next studies would have to establish

|  | Must establish | Status in our data |
|---|---|---|
| E1 | Target presence: bioactive (free) IL-33 is detectable and raised in the target population at enrolment | Unknown. Assay run but not delivered (probably below detection) |
| E2 | Target activity in tissue: the AX-1177-reversible endothelial IL-33 programme is active in human acute lung injury, beyond generic injury | Unknown. Only indirect IHC (endothelial IL-33 loss with neutrophils) |
| E3 | PD specificity: the PD panel responds to IL-33, and AX-1177 does not suppress it when IL-1β/TNF drive it | Unknown. Only IL-33 was used as a stimulus |
| E4 | Relevant pharmacology: potency vs reduced AND oxidised IL-33; activity in lung microvascular endothelium and airway epithelium (≥3 donors); therapeutic window with delayed addition | Unknown. One dose, reduced form, co-addition, single donors, no lung cells given IL-33 |
| E5 | Population: sST2-high identifies IL-33 pathway activity (not just severity) in a contemporary, multi-pathogen cohort | Unknown. Single-centre, pre-vaccination, COVID-only cohort |


### 5.3 Biomarkers: which could go into patients, and in what role

| Marker | What our data show | Usable in patients? | Proposed role |
|---|---|---|---|
| sST2 (IL1RL1) | Rank 2/1,094 (1 after shift adjustment); OR 3.0/log unit, adj p=0.007 | Yes: established immunoassays | **Baseline prognostic enrichment / stratification.** Not a PD marker; not validated as predictive of AX-1177 benefit |
| Free and total IL-33 | Run on the Olink Inflammation panel but not delivered (likely below LOD) | Not yet: needs a high-sensitivity assay | **Target engagement** (free ↓, drug–IL-33 complex ↑ after dosing); baseline stratifier if detectable |
| E-selectin | Most IL-33-inducible, AX-1177-reversible endothelial product (+11.2/−11.0 log2 HUVEC 6 h; −8.7 HGMEC); serum p=0.02 | Yes | **Lead endothelium-restricted PD marker** |
| OPG (TNFRSF11B) | +4.8 (6 h) and +2.4 (24 h), reversed; HGMEC −1.9; prognostic on two panels (adj p 0.014 / 0.020) | Yes | PD (sustained) + prognostic covariate |
| Tissue factor (F3) | +5.6, reversed (FDR 10⁻²⁶); serum p=0.009 | Yes | Exploratory PD (immunothrombosis) |
| PTX3 | +2.2, reversed (FDR unreliable: SE inflated); serum rank 6 (3 after shift adjustment) | Yes | Prognostic covariate; exploratory PD |
| CCL20, CCL7, CX3CL1, VCAM-1, ICAM-1, G-CSF | Large IL-33 induction, AX-1177-reversed; prognostic value ranges from strong (CCL20, CCL7) to null (VCAM-1, G-CSF) | Yes | Exploratory mechanistic PD panel, not enrichment |
| IL-6, CXCL8, CCL2 | IL-33-inducible but made by many cells; IL-6 prognostic on 4 panels | Yes | Prognostic covariates only (standard-of-care confounded) |
| HGF, GDF-15, vWF, CLEC5A, PRTN3 | Strongly prognostic; not IL-33-driven in vitro | Yes | Global-injury / neutrophil covariates, needed to show any IL-33 signal is specific |
| Lung IL-33 and granulocyte IHC; IL-5Rα | Post-mortem only; IL-5Rα not eosinophil-specific here | No | Translational only |
| 79-gene endothelial IL-33 signature | In vitro, AX-1177-reversible, sustained to 24 h, replicated in HGMEC | No (tissue/cell assays) | Gate 1 tissue scoring; in vitro potency read-out |

**Sampling timepoint.** (i) **In vitro: 6 h after IL-33 is the primary read-out.** The programme is largest then (4,031 vs 1,836 DE genes at 24 h) and AX-1177 block is most complete (95–100% vs 73–83%). 24 h is secondary, for sustained and late-wave genes (OPG, G-CSF, C3, MMP-10). (ii) **Patients: baseline at enrolment / hospital admission, before study drug, is the one timepoint our data validate.** That is where sST2, OPG, PTX3, tissue factor and IL-6 carried prognostic information, so it is the enrichment timepoint. (iii) **PD: sample early after dosing** (24 h and 72 h, plus day 7), because the IL-33 endothelial programme is front-loaded (E-selectin +11.2 at 6 h vs +4.7 at 24 h; tissue factor +5.6 vs +1.2). The exact window must come from the Gate 3 kinetic cohort, since our package contains no in vivo kinetics. The same front-loading means any future clinical study would have to dose early in the course of lung injury.


### 5.4 Gated plan with kill criteria

| Gate | Question | Time / cost | What is done | Go | Kill |
|---|---|---|---|---|---|
| Gate 0 | Retrieve, re-fit, re-adjudicate (no new experiments) | ≤ 6 weeks; analyst time only | (a) Full Olink output incl. IL-33, LOD flags, patient-level NPX. (b) Per-cell-line refit of RNA-seq from archived counts. (c) Pathologist re-adjudication of 31 donors; second blinded IHC reader; document IL-33 score derivation. | GO if IL-33 is detectable (>LOD) in ≥50% of patients AND relates to outcome or to sST2 after adjustment. If IL-33 is <LOD, Gate 0 is inconclusive: run Gate 1 only, with no assay-development spend unless Gate 1 passes. | Terminate if IL-33 is detectable but unrelated to outcome or sST2. |
| Gate 1 | Is the IL-33 endothelial programme active in human lung? | ≤ 3 months; existing tissue RNA (22 donors) + a targeted expression panel | Score the 79-gene AX-1177-reversible endothelial IL-33 signature (targeted panel) in the 22 archived lung RNAs (8 COVID+ acute pneumonia, 9 COVID- acute pneumonia/infection, 5 no acute pneumonia). | GO if signature score is higher in acute pneumonia than in non-pneumonia lungs (pre-specified ≥ 1 SD) AND inversely related to endothelial IL-33 IHC. | Terminate if no difference. |
| Gate 2 | Pharmacology that matters for a lung indication | 3–6 months; new in vitro (only after Gates 0–1) | Lung microvascular endothelium + primary airway epithelium (ALI), ≥3 donors each; reduced AND oxidised IL-33; AX-1177 dose-response (IC50); delayed addition (0/1/3/6 h after IL-33); IL-1β/TNF counter-screen; primary readout 6 h, secondary 24 h; per-cell-line statistics. | GO if IC50 is within projected exposure, ≥80% block at 6 h when added up to 3 h after IL-33, oxidised-IL-33 signalling blocked, and the PD panel is not suppressed by AX-1177 under IL-1β/TNF. | Terminate if oxidised form or lung cells are not neutralised. |
| Gate 3 | Patient biomarker qualification | 6–12 months; prospective observational cohort | Multi-centre, contemporary (vaccinated, SoC-treated) severe pneumonia, viral (SARS-CoV-2, influenza, RSV) and non-viral; serial EDTA plasma at admission (pre-treatment), 24 h, 72 h, day 7. Markers: free/total IL-33, sST2, endothelial PD panel, global-injury and neutrophil covariates. | GO to a Phase 2a design if IL-33 and/or sST2 explain endothelial-panel variance beyond global injury, and an sST2 enrichment cut-point is defined. | Terminate if the endothelial panel tracks only global injury. |

Gates 0–1 decide re-admission. Gates 2–3 would be the first steps of a re-admitted programme, and only after Gate 3 would a Phase 2a be considered. Its design would use sST2-high enrichment, E-selectin/OPG/tissue-factor PD endpoints, free IL-33 target engagement, and global-injury covariates.


## 6. What I considered and ruled out

| Option / claim | Verdict | Why (our data) |
|---|---|---|
| Keep AX-1177 in severe viral LRTI as planned | Not supported | No virus-specific IL-33 signal in lung (donor-level KW p=0.65/0.11/0.16; COVID+ numerically lower). IL-33 not delivered in serum. AX-1177-reversible programme not enriched among severity proteins (17.2% vs 17.8% FDR<5%; p=1.0). |
| Treat sST2 (#2 of 1,094) as proof that IL-33 drives severity | Ruled out | sST2 is a decoy receptor and a generic injury marker. IL-33 itself was not delivered. IL-33 induces IL1RL1 only modestly and transiently in HUVEC (+1.6 log2 at 6 h) and not in HGMEC. A prognostic marker is not evidence that blocking the pathway helps. |
| Use the delivered top-hit list and OR magnitudes | Ruled out | Duplicated proteins (27), OR scale not comparable, global shift (35% nominal p<0.05), BH over undelivered assays. |
| Block-level post-mortem statistics | Ruled out | Pseudo-replication: block-level p=0.02 for endothelial IL-33 becomes 0.14 at donor level. |
| Eosinophil/type-2 mechanism in viral pneumonia | Ruled out on our data | EDN/MBP "pneumonia" signal is label-dependent (KW p 0.015 becomes 0.11 with verified labels). IL-5Rα tracks neutrophils, not eosinophils. Serum type-2 markers null (median z 0.19; IL-5 OR 1.00, eotaxin 1.08, tryptase 1.07). |
| COVID-specific positioning | Ruled out | No COVID+ vs COVID- pneumonia difference in IL-33 or granulocytes (all donor-level p≥0.15). |
| Pivot to COPD/asthma (type-2 airway disease) on the strength of our data | Not supported by our data | No IL-33 or eosinophil difference by COPD/asthma annotation (all p>0.1). No epithelial IL-33 experiments. Serum type-2 axis null. Any airway pivot would rest on external evidence, not this package. |
| Kidney microvascular disease (HGMEC response) | Hypothesis only | HGMEC show the same programme but ~44% of the HUVEC magnitude at 6 h and mostly gone by 24 h. No HGMEC vehicle arm. No patient kidney data (KIM-1 p=0.03 in COVID serum only). |
| Cardiovascular indication (sST2 is an HF marker; IL-33 in VSM) | Ruled out | No cardiovascular data. VSM IL-33 is lower, not higher, in pneumonia. NT-proBNP only weakly prognostic (p=0.05). |
| Off-target/safety concern from antibody alone | Ruled out (in vitro) | AX-1177 alone: 0–9 robust genes per contrast in 4 cell types x 2 timepoints, with no coherent pathway. The FDR "hits" are variance artefacts or low-count noise. |
| IL-6 as the PD marker | Ruled out as primary | IL-33-inducible and prognostic (4 panels), but produced by many cells and suppressed by standard-of-care steroids and IL-6R blockade. Keep as a covariate only. |
| Tissue IHC or transcript markers as patient biomarkers | Not feasible | Post-mortem/biopsy only. Used for translational gates, not in patients. |


## 7. Data-quality audit of the delivered package

Every dataset had structural or analytical defects that would mislead a naive reading. Most of them inflate positive findings. Each was handled as shown; the full log is in the workbook (sheet 4).

| ID | Issue | Evidence | Handling |
|---|---|---|---|
| S1 | 1,094 assay rows are not 1,094 proteins | 27 proteins measured on 2–4 panels (58 rows; 1,063 unique). IL-6 appears 4x (ranks 11, 15, 20, 28); HGF, OPG and TNFRSF10A 2x each in the top 50. | Collapsed to gene level (best assay). Duplicates agree (r=0.99) and were used as a reproducibility check. |
| S2 | Multiple-testing adjustment does not match the delivery | Delivered adj.p / recomputed BH = 1.0914 = 1,194/1,094 for the top rows, i.e. BH was run over m=1,194 tests. The annex says "across all assays in the delivery". | Request the full output (all analysed assays, LOD flags, patient-level NPX). |
| S3 | The drug target (IL-33) is absent from the delivery | Panels delivered with 75–92 of their 92 assays. Inflammation panel: 77/92. By the vendor's published panel content (external reference), the 15 missing Inflammation analytes include IL-33, TSLP, IL-4, IL-5, IL-13, IL-2 and IL-1α. | Flagged as the single most important data gap; request the IL-33 data and LOD status (Gate 0). |
| S4 | Undocumented columns composite_endpoint_0 / _1 | All values are multiples of 1/56 and 1/44 (max 5/56 and 4/44). This fits a per-group fraction of samples below LOD with 56 non-events and 44 events. | Documented as an inference; request the definition. |
| S5 | Odds ratios are "per log unit" and not comparable across assays | Log base is unstated, and NPX is already log2. Examples: CSF-1 OR 90 (CI 4–1,933); SPON2 OR 93 (CI 1.4–6,326). | Ranked by z = log(OR)/SE, derived from the CI (matches reported p, r>0.9999). |
| S6 | Global positive shift across most assays | 82% of assays have OR>1, 35% p<0.05 and 16% FDR<0.05. Median z is 0.5 on Cardiometabolic/Neurology vs 1.3–1.8 on the other 11 panels. Intracellular proteins have median z 3.4. | Within-panel shift-adjusted ranking as a sensitivity analysis (sST2 becomes #1). |
| S7 | Cohort design limits transfer to the current indication | Single centre, n=100, pre-vaccination period, SARS-CoV-2 only, clotted serum at enrolment only. The composite endpoint includes ICU admission. | Stated as a limitation; addressed in Gate 3. |
| P1 | Pseudo-replication: histology blocks are not independent | 74 blocks from 31 donors; 3 COVID+ donors contribute 24/49 COVID+ blocks. Within-donor ICC 0.44–0.82. | Donor-level non-parametric tests plus mixed models with a donor random effect. |
| P2 | Donor-level fields sit only on the first block | Category, age, sex and SARS-CoV-2 status are blank on later blocks; clinical notes are scattered across blocks. | Propagated within donor; notes combined per donor. |
| P3 | Category labels contradict the pathology text for 9/31 donors | "COVID+ pneumonia" without acute pneumonia: 2067 (8 blocks), 2101. "COVID- pneumonia" without pneumonia: 1905, 1961, 1968, 1970. "Non-pneumonia" controls with lung infection or pneumonitis: 1944 (coccidioidomycosis), 1956, 1976. SARS-CoV-2 status is blank for 1905. Controls include IPF and fibrosis. | Sensitivity analysis with hand-curated, pathology-verified classes. |
| P4 | IL-33 scores exceed the declared 0-5 scale and sit at a ceiling | Values up to 5.5 (16 epithelial and 39/74 endothelial blocks). Non-integer values with undocumented derivation. Derived granulocyte columns equal score + 0.5. | Treated as ordinal; flagged; request the scoring derivation. |
| P5 | Single reader, semi-quantitative, blinding not stated | Per annex. | Second, blinded reader / digital quantification requested (Gate 0). |
| P6 | IL-5Rα staining is not an eosinophil readout in these sections | IL-5Rα tracks neutrophil elastase (ρ=0.89) and not EPX/EDN/MBP (ρ 0.03–0.20), while EPX and EDN agree (ρ=0.85). | Not used as an eosinophil marker. |
| P7 | End-stage, elderly, comorbid donors | Mean age 82.5 (64–98); extensive cardiovascular and renal comorbidity. Interval from infection to death unknown. | Stated as a limitation. |
| R1 | Sheet names misleading; one sheet padded with empty rows | Sheets "6h" and "24h" are byte-identical and each holds all 24 contrasts for both timepoints. "6h" carries 419,535 empty rows (reaching the Excel maximum of 1,048,576). | De-duplicated; contrasts parsed by name. |
| R2 | Vehicle vs "Nontreated" naming | File and sheets say IL33_vs_Vehicle; the contrast column says IL33_vs_Nontreated. | Treated as the Vehicle arm. |
| R3 | Each endothelial line comes from a single donor | HUVEC (P2) and HGMEC (P5) are single-donor commercial primaries, so n=3 are replicate wells. | Flagged; ≥3 donors required in Gate 2. |
| R4 | HGMEC has no vehicle arm | Design table: the Vehicle arm is HUVEC only. | Inferred IL-33 dependence from the AX-1177 x IL-33 interaction. |
| R5 | No IL-33 arms in epithelial lines; reduced IL-33 only | A549/MCF7 received antibody or vehicle only. MCF7 is a breast line. Oxidised IL-33 (RAGE/EGFR) was not tested. | Flagged; Gate 2. |
| R6 | Single dose of antibody and IL-33; no pre-incubation | IL-33 1.7 nM vs AX-1177 68 nM (~40-fold molar excess); added concurrently. | Flagged; dose-response and delayed-addition experiments in Gate 2. |
| R7 | Pooled single model across 4 heterogeneous cell lines gives unreliable FDR for a subset of genes | 382 genes have >3x inflated SE (70 >100x), including SELE, VCAM1, ICAM1, CXCL8, CXCL1, CCL2, PTX3, IL1RL1 and GAPDH. SE varies up to 225,000-fold across contrasts (AKR1C2). Spurious hits, e.g. AKR1C2 logFC 0.06 at p=1e-73. AveExpr is averaged over all 114 libraries. | Used effect sizes replicated across independent sample groups; flagged SE-inflated genes; request per-cell-line refit from counts (Gate 0). |
| R8 | Counts and model object not delivered | Per annex. | Request archived counts. |
| M1 | Potency/affinity data not in package | Held in the biologics file. | Request the biologics file summary. |


## 8. Methods (summary)

- **RNA-seq.** I parsed all delivered contrasts (the two workbook sheets are identical; empty padding rows removed) and merged them with the HUVEC IL-33-vs-vehicle file, which is the same model (identical AveExpr). Neutralisation was assessed with the isotype-matched contrast (AX-1177+IL-33 vs isotype+IL-33), which shares no sample group with IL-33-vs-vehicle. Residual IL-33 effect = [(AX-1177+IL-33) − vehicle] / [IL-33 − vehicle], computed from contrast logFCs. Gene-wide SE inflation = median |logFC/t| across contrasts relative to genes of similar AveExpr. Genes >3× inflated were flagged, and effect sizes replicated across independent groups were used instead of FDR. "Robust" DE means FDR0 and SE inflation <3×. The HGMEC IL-33 dependence was inferred from the AX-1177 × IL-33 interaction, since there is no HGMEC vehicle arm.
- **Serum proteomics.** I mapped Olink assay names to HGNC symbols (e.g. ST2→IL1RL1, OPG→TNFRSF11B, TF→F3 tissue factor) and collapsed 1,094 assays to 1,063 proteins. Ranking used z = ln(OR)/SE with SE from the 95% CI (this reproduces the reported p, r>0.9999). A panel-median/MAD-standardised z served as a global-shift sensitivity analysis. Bridging classes come from in vitro concordance: IL-33 vs vehicle ≥1 log2 and AX-1177 neutralisation ≤−1 log2 at the same timepoint. Enrichment was tested with Fisher’s exact and Mann–Whitney tests. The number of BH tests was back-calculated from the delivered adjusted p-values.
- **Post-mortem.** I propagated donor-level fields within donor, parsed ordinal scores, and ran the primary analysis at donor level (mean of blocks; Kruskal–Wallis / Mann–Whitney; Spearman). Block-level sensitivity used linear mixed models with a donor random intercept. Categories were re-adjudicated by hand from each donor’s pathology text (acute pneumonia/infection present vs absent) as a sensitivity analysis.
- **Deliverables.** This memo (PDF/Markdown); figures (PNG); *AX-1177_supporting_tables.xlsx* (13 sheets: candidate biomarkers, gates, ruled-out options, data-quality log, serum gene- and assay-level tables, post-mortem donor table and statistics, RNA-seq contrast summary, 79-gene IL-33 signature, genome-wide IL-33/AX-1177 table); analysis code in *code/*.


## Figures

![Figure 1. In vitro pharmacology. A–B: IL-33 effect vs AX-1177 neutralisation effect (HUVEC 6 h, 24 h); points on the dashed line are completely reversed. C: robust DE genes per contrast; AX-1177 alone is inert. D: residual IL-33 effect under AX-1177 relative to vehicle. E: HGMEC reproduces the HUVEC programme at lower magnitude. F: the IL-33 response is front-loaded for serum-measurable products.](figures/Fig1_invitro_pharmacology.png)

*Figure 1. In vitro pharmacology. A–B: IL-33 effect vs AX-1177 neutralisation effect (HUVEC 6 h, 24 h); points on the dashed line are completely reversed. C: robust DE genes per contrast; AX-1177 alone is inert. D: residual IL-33 effect under AX-1177 relative to vehicle. E: HGMEC reproduces the HUVEC programme at lower magnitude. F: the IL-33 response is front-loaded for serum-measurable products.*

![Figure 2. Post-mortem lung, donor level. A: IL-33 by delivered labels, and endothelial IL-33 vs neutrophil elastase. B: IL-33 by pathology-verified class, and label concordance. C: the eosinophil signal is label-dependent; the neutrophil signal is robust; block-level tests inflate significance.](figures/Fig2_postmortem_tissue.png)

*Figure 2. Post-mortem lung, donor level. A: IL-33 by delivered labels, and endothelial IL-33 vs neutrophil elastase. B: IL-33 by pathology-verified class, and label concordance. C: the eosinophil signal is label-dependent; the neutrophil signal is robust; block-level tests inflate significance.*

![Figure 3. Serum proteomics. A: IL-33-inducible, AX-1177-reversible proteins are not enriched among severity markers. B: severity biology by class. C: candidate biomarkers. D: global shift by panel. E: duplicated assays. F: undelivered assays per panel.](figures/Fig3_serum_proteomics.png)

*Figure 3. Serum proteomics. A: IL-33-inducible, AX-1177-reversible proteins are not enriched among severity markers. B: severity biology by class. C: candidate biomarkers. D: global shift by panel. E: duplicated assays. F: undelivered assays per panel.*

![Figure 4. Candidate biomarkers: in vitro IL-33 inducibility / AX-1177 reversibility (HUVEC, HGMEC) vs patient serum association, with the proposed role in patients.](figures/Fig4_candidate_biomarkers.png)

*Figure 4. Candidate biomarkers: in vitro IL-33 inducibility / AX-1177 reversibility (HUVEC, HGMEC) vs patient serum association, with the proposed role in patients.*

![Figure S1. The delivered RNA-seq statistics come from one pooled model across four heterogeneous cell lines. SEs are pathological for a subset of genes, including key IL-33 targets, and the antibody-alone "hits" are artefacts.](figures/FigS1_rnaseq_model_QC.png)

*Figure S1. The delivered RNA-seq statistics come from one pooled model across four heterogeneous cell lines. SEs are pathological for a subset of genes, including key IL-33 targets, and the antibody-alone "hits" are artefacts.*
