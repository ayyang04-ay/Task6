# AX-1177 portfolio audit: deliverables

**Bottom line:** stop AX-1177 as a severe viral LRTI programme. Hold the molecule, with no development spend, for a ≤3-month, low-cost check (Gates 0–1) using data and tissue we already own. Re-admit it only if those gates pass; otherwise terminate. Full argument, defence, forward view, biomarker roles, sampling timepoints and gated plan are in the memo.

| File | What it is |
|---|---|
| `AX-1177_portfolio_audit_memo.pdf` | Committee memo (11 pages): recommendation, evidence, anticipated challenges and answers, what we would drop and why, forward view (indication, must-establish list, biomarkers and roles, sampling timepoints, gated plan with kill criteria), options considered and ruled out, data-quality audit, methods, figures |
| `AX-1177_portfolio_audit_memo.md` | Same memo in Markdown |
| `AX-1177_supporting_tables.xlsx` | 13 sheets of supporting tables (see README sheet): candidate biomarkers, gates, ruled-out options, data-quality log, serum gene/assay-level tables with in vitro bridging, post-mortem donor table and statistics, RNA-seq contrast summary, 79-gene IL-33 signature, genome-wide IL-33/AX-1177 table |
| `figures/Fig1_invitro_pharmacology.png` | AX-1177 neutralisation of the IL-33 endothelial programme; inert alone; HGMEC; kinetics |
| `figures/Fig2_postmortem_tissue.png` | Donor-level IL-33 and granulocyte IHC; label re-adjudication; pseudo-replication |
| `figures/Fig3_serum_proteomics.png` | Enrichment test; severity biology; candidate markers; global shift; duplicates; undelivered assays |
| `figures/Fig4_candidate_biomarkers.png` | Bridge from in vitro IL-33/AX-1177 effects to patient serum, with proposed roles |
| `figures/FigS1_rnaseq_model_QC.png` | Variance pathologies in the delivered pooled RNA-seq model |
| `code/` | Full analysis code. `run_all.sh` regenerates every intermediate, figure, the workbook and the memo from the raw files in `/tmp/world/filesystem` (~7 min). Working directory: `/tmp/work` |

Key analytical choices (details in memo section 8):
- Post-mortem data analysed at **donor** level; blocks are not independent.
- Serum assays ranked by **z = ln(OR)/SE**, not by OR magnitude, after collapsing 1,094 assays to 1,063 unique proteins.
- RNA-seq neutralisation quantified with **isotype-matched** contrasts and effect sizes replicated across independent sample groups, because FDR is unreliable for a subset of genes in the delivered pooled model.
