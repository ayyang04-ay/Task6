"""Figure S1: variance (SE) pathology in the delivered single pooled limma-voom model."""
import pandas as pd, numpy as np, matplotlib, warnings
matplotlib.use('Agg'); warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
exec(open('/tmp/work/genetable.py').read())
SE = (L/T).abs()
SEr = pd.read_csv('/tmp/work/se_ratio.tsv', sep='\t', index_col=0).SEratio
fig, axes = plt.subplots(1, 3, figsize=(20, 5.6)); plt.subplots_adjust(wspace=0.5)
ax = axes[0]
ax.scatter(ann.AveExpr, SEr, s=2, c='#bdbdbd', alpha=0.5, rasterized=True)
groups = {'endothelial identity':(['CD93','CDH5','VWF','PECAM1','ENG','TIE1','KDR','MMRN1'],'#2ca02c'),
          'MCF7 identity':(['TFF1','GREB1','GATA3','KRT8','KRT19','KRT7'],'#9467bd'),
          'A549 identity':(['AKR1C2','AKR1C3','AKR1B10','ALDH3A1'],'#8c564b'),
          'IL-33 targets / biomarkers':(['SELE','VCAM1','ICAM1','CXCL8','CXCL1','CCL2','PTX3','IL1RL1'],'#d62728'),
          'housekeeping':(['GAPDH'],'k')}
for k,(gs,c) in groups.items():
    es = [sym2e[g] for g in gs if g in sym2e.index]
    ax.scatter(ann.AveExpr[es], SEr[es], s=22, c=c, label=k, edgecolor='k', lw=0.3)
    for e,g in zip(es,gs): ax.annotate(g, (ann.AveExpr[e], SEr[e]), fontsize=6.5, xytext=(2,2), textcoords='offset points')
ax.set_yscale('log'); ax.axhline(3, c='r', ls='--', lw=0.8)
ax.set_xlabel('AveExpr (log2 CPM, averaged over all 114 libraries / 4 cell lines)'); ax.set_ylabel('gene SE / expected SE at same AveExpr')
ax.set_title(f'A. {int((SEr>3).sum())} genes have >3x inflated SE ({int((SEr>100).sum())} >100x)\nmostly cell-identity genes + key IL-33 targets', loc='left', fontsize=10)
ax.legend(fontsize=7, frameon=False, loc='upper left')
ax = axes[1]
for g,c in [('AKR1C2','#8c564b'),('XBP1','#1f77b4'),('NUCKS1','#ff7f0e'),('ACTB','k'),('NFKBIA','#2ca02c')]:
    e = sym2e[g]; s = SE.loc[e].sort_values()
    ax.plot(range(len(s)), s.values, marker='o', ms=3, lw=1, c=c, label=f'{g} (max/min = {s.max()/s.min():,.0f}x)')
ax.set_yscale('log'); ax.set_xlabel('26 delivered contrasts (sorted by SE)'); ax.set_ylabel('implied SE = |logFC / t|')
ax.set_title('B. For some genes the SE varies up to 10^5-fold\nbetween contrasts of the same model', loc='left', fontsize=10)
ax.legend(fontsize=7, frameon=False)
ax = axes[2]
rows=[]
for c in L.columns:
    l = L[c]; q = Q[c]
    rows.append((c, int(((q<0.05)&(l.abs()<0.2)).sum()), int(((q<0.05)&(l.abs()>=1)&(ann.AveExpr<0)).sum()), int(((q<0.05)&(l.abs()>=1)&(ann.AveExpr>0)&(SEr<3)).sum())))
r = pd.DataFrame(rows, columns=['c','tiny','lowexpr','robust']).set_index('c')
r = r.loc[[c for c in r.index if ('C47_vs' in c)]]
r.index = [i.replace('_C47_vs_',' AX-1177 vs ').replace('ISO','isotype').replace('IC119','isotype') for i in r.index]
r = r.sort_index()
yy = np.arange(len(r))
ax.barh(yy, r.tiny, color='#fdae6b', label='FDR<0.05 but |log2FC|<0.2 (variance artefact)')
ax.barh(yy, r.lowexpr, left=r.tiny, color='#9ecae1', label='FDR<0.05, |log2FC|>=1, AveExpr<0 (low-count noise)')
ax.barh(yy, r.robust, left=r.tiny+r.lowexpr, color='#d62728', label='robust')
ax.set_yticks(yy); ax.set_yticklabels(r.index, fontsize=7)
ax.set_xlabel('FDR<0.05 genes in antibody-alone contrasts')
ax.set_title('C. Antibody-alone "hits" are artefacts or noise', loc='left', fontsize=10)
ax.legend(fontsize=6.5, frameon=False, loc='upper center', bbox_to_anchor=(0.4,-0.13))
fig.suptitle('Figure S1. The delivered RNA-seq statistics come from one pooled model across 4 heterogeneous cell lines; FDR values are unreliable for a subset of genes', fontsize=11.5, x=0.01, ha='left', y=1.02)
fig.savefig('/tmp/outputs/figures/FigS1_rnaseq_model_QC.png', dpi=160, bbox_inches='tight')
print('ok')
