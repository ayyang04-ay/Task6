import pandas as pd, numpy as np
W = '/tmp/work'
cand = pd.read_csv(f'{W}/candidate_biomarkers.tsv', sep='\t')
og = pd.read_csv(f'{W}/olink_gene_level_bridge.tsv', sep='\t')
oa = pd.read_csv(f'{W}/olink_assay_level_bridge.tsv', sep='\t')
med = oa.groupby('panel_s').z.transform('median'); mad = oa.groupby('panel_s').z.transform(lambda s: 1.4826*np.median(np.abs(s-np.median(s))))
oa['z_panel_shift_adjusted'] = (oa.z-med)/mad
oa['rank_shift_adjusted'] = oa.z_panel_shift_adjusted.rank(ascending=False).astype(int)
keep = ['panel','assay','gene','OR','l95','u95','p.value','adj.p.value','rank','z','z_panel_shift_adjusted','rank_shift_adjusted','composite_endpoint_0','composite_endpoint_1','il33_class','up6','neut6','up24','neut24','hg6','hg24','c47_6','c47_24','AveExpr','SEratio']
oa2 = oa[keep].rename(columns={'up6':'HUVEC6_IL33_vs_vehicle_log2FC','neut6':'HUVEC6_AX1177_neutralisation_log2FC','up24':'HUVEC24_IL33_vs_vehicle_log2FC','neut24':'HUVEC24_AX1177_neutralisation_log2FC','hg6':'HGMEC6_AX1177_neutralisation_log2FC','hg24':'HGMEC24_AX1177_neutralisation_log2FC','c47_6':'HUVEC6_AX1177_alone_log2FC','c47_24':'HUVEC24_AX1177_alone_log2FC','AveExpr':'RNAseq_AveExpr_all114','SEratio':'RNAseq_SE_inflation','rank':'rank_of_1094'})
ogk = oa2.sort_values('p.value').drop_duplicates('gene')
ogk['n_assays_for_protein'] = ogk.gene.map(oa2.gene.value_counts())
dup = oa2[oa2.gene.duplicated(keep=False)].sort_values(['gene','rank_of_1094'])
don = pd.read_csv(f'{W}/pm_donor_table.tsv', sep='\t')
pmst = pd.read_csv(f'{W}/pm_stats_table.tsv', sep='\t')
pmc = pd.read_csv(f'{W}/pm_correlations.tsv', sep='\t')
rs = pd.read_csv(f'{W}/rnaseq_contrast_summary.tsv', sep='\t')
core = pd.read_csv(f'{W}/il33_core_signature.tsv', sep='\t')
wide = pd.read_csv(f'{W}/rnaseq_il33_wide.tsv', sep='\t')
dq = pd.read_csv(f'{W}/tables/data_quality_log.tsv', sep='\t')
gp = pd.read_csv(f'{W}/tables/gated_plan.tsv', sep='\t')
rr = pd.read_csv(f'{W}/tables/considered_ruled_out.tsv', sep='\t')
readme = pd.DataFrame([
 ('1_Candidate_biomarkers','Serum-measurable candidates: in vitro IL-33 inducibility / AX-1177 reversibility (HUVEC, HGMEC) vs prognostic association in patient serum; proposed role in patients.'),
 ('2_Gated_plan','Forward plan: gates, what is done, go / kill criteria.'),
 ('3_Considered_ruled_out','Options and claims considered, the verdict, and the data behind it.'),
 ('4_Data_quality_log','Every structural/analytical issue found in the delivered package, its impact and how it was handled.'),
 ('5_Serum_gene_level','Olink results collapsed to one row per protein (best assay), with IL-33 in vitro class and panel-shift-adjusted rank.'),
 ('6_Serum_assay_level','All 1,094 delivered assays with gene mapping (Olink names mapped to HGNC symbols), z statistic, shift-adjusted z and in vitro effects.'),
 ('7_Serum_duplicates','The 27 proteins measured on 2-4 panels (58 rows).'),
 ('8_Postmortem_donors','31 donors: delivered label, hand-curated pathology class, pathology summary, label concordance, donor-mean IHC scores, n blocks, archived tissue RNA ID.'),
 ('9_Postmortem_stats','Donor-level tests (original and pathology-verified groupings), block-level (pseudo-replicated) p for contrast, and mixed models.'),
 ('10_Postmortem_correlations','Donor-level Spearman correlations between IL-33 compartments and granulocyte markers; IL-5Ra specificity checks.'),
 ('11_RNAseq_contrast_summary','DE gene counts for all 26 delivered contrasts (FDR, effect size, artefact and robust counts).'),
 ('12_IL33_core_signature','79-gene AX-1177-reversible endothelial IL-33 signature (for scoring archived tissue RNA, Gate 1).'),
 ('13_RNAseq_IL33_wide','Genome-wide table: IL-33 effect, AX-1177 neutralisation (HUVEC/HGMEC, 6/24 h), AX-1177-alone effects, residual fraction, SE inflation.'),
 ('Notes','z = ln(OR)/SE with SE from the 95% CI (reproduces reported p). "Robust" DE = FDR<0.05, |log2FC|>=1, AveExpr>0 and SE inflation <3x. IL-33 class uses concordance across independent sample groups: IL-33 vs vehicle >=1 log2 AND AX-1177+IL-33 vs isotype+IL-33 <=-1 log2 at the same timepoint. Olink-to-gene mapping for non-standard assay names is in code/olink_map.py (e.g. ST2=IL1RL1, OPG=TNFRSF11B, TF=F3 tissue factor).'),
], columns=['Sheet','Contents'])
with pd.ExcelWriter('/tmp/outputs/AX-1177_supporting_tables.xlsx', engine='xlsxwriter') as xw:
    for name, df in [('README',readme),('1_Candidate_biomarkers',cand),('2_Gated_plan',gp),('3_Considered_ruled_out',rr),('4_Data_quality_log',dq),
                     ('5_Serum_gene_level',ogk),('6_Serum_assay_level',oa2),('7_Serum_duplicates',dup),('8_Postmortem_donors',don),('9_Postmortem_stats',pmst),
                     ('10_Postmortem_correlations',pmc),('11_RNAseq_contrast_summary',rs),('12_IL33_core_signature',core),('13_RNAseq_IL33_wide',wide)]:
        df.to_excel(xw, sheet_name=name, index=False)
        ws = xw.sheets[name]
        wrap = xw.book.add_format({'text_wrap': True, 'valign':'top'})
        for i,c in enumerate(df.columns):
            width = min(60, max(10, int(df[c].astype(str).str.len().quantile(0.9)) if len(df) else 10, len(str(c))))
            ws.set_column(i, i, width, wrap if width>=40 else None)
        ws.freeze_panes(1, 0)
print('written')
