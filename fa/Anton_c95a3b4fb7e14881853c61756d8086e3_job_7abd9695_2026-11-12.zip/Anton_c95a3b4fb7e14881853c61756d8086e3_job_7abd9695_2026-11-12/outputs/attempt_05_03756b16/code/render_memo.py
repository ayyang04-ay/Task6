# -*- coding: utf-8 -*-
"""Render the AX-1177 memo to Markdown and PDF (reportlab) from memo_content.py."""
import re, sys
sys.path.insert(0, '/tmp/outputs/code')
from memo_content import TITLE, SUBTITLE, META, S, tables
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping
from PIL import Image as PILImage

MPL = '/opt/conda/envs/chem/lib/python3.11/site-packages/matplotlib/mpl-data/fonts/ttf/'
pdfmetrics.registerFont(TTFont('DV', MPL + 'DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DV-B', MPL + 'DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DV-I', MPL + 'DejaVuSans-Oblique.ttf'))
pdfmetrics.registerFont(TTFont('DV-BI', MPL + 'DejaVuSans-BoldOblique.ttf'))
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DV-B'); addMapping('DV', 0, 1, 'DV-I'); addMapping('DV', 1, 1, 'DV-BI')

NAVY = colors.HexColor('#1f3b5a')
st = {
 'title': ParagraphStyle('title', fontName='DV-B', fontSize=17, leading=21, textColor=NAVY, spaceAfter=2),
 'subtitle': ParagraphStyle('subtitle', fontName='DV', fontSize=11.5, leading=15, textColor=NAVY, spaceAfter=6),
 'meta': ParagraphStyle('meta', fontName='DV-I', fontSize=7.8, leading=10, textColor=colors.HexColor('#444444'), spaceAfter=8),
 'h1': ParagraphStyle('h1', fontName='DV-B', fontSize=12.5, leading=16, textColor=NAVY, spaceBefore=8, spaceAfter=5),
 'h2': ParagraphStyle('h2', fontName='DV-B', fontSize=10, leading=13, textColor=NAVY, spaceBefore=6, spaceAfter=3),
 'p': ParagraphStyle('p', fontName='DV', fontSize=8.6, leading=11.6, spaceAfter=5),
 'bullet': ParagraphStyle('bullet', fontName='DV', fontSize=8.6, leading=11.6, leftIndent=12, bulletIndent=3, spaceAfter=3),
 'q': ParagraphStyle('q', fontName='DV-B', fontSize=8.6, leading=11.4, spaceBefore=4, spaceAfter=1, textColor=colors.HexColor('#7a1f1f')),
 'a': ParagraphStyle('a', fontName='DV', fontSize=8.4, leading=11.2, leftIndent=10, spaceAfter=4),
 'box': ParagraphStyle('box', fontName='DV', fontSize=9.2, leading=12.6),
 'cell': ParagraphStyle('cell', fontName='DV', fontSize=7.0, leading=8.6),
 'cellh': ParagraphStyle('cellh', fontName='DV-B', fontSize=7.2, leading=8.8, textColor=colors.white),
 'cap': ParagraphStyle('cap', fontName='DV-I', fontSize=7.6, leading=9.8, spaceAfter=10, textColor=colors.HexColor('#333333')),
}
PAGE_W, PAGE_H = A4
MARG = 1.5*cm
AVAIL_W = PAGE_W - 2*MARG
COLW = {
 'evidence': [0.04, 0.33, 0.2, 0.43],
 'establish': [0.05, 0.58, 0.37],
 'biomarkers': [0.15, 0.37, 0.16, 0.32],
 'gates': [0.07, 0.14, 0.12, 0.27, 0.22, 0.18],
 'ruled': [0.25, 0.12, 0.63],
 'dq': [0.05, 0.22, 0.45, 0.28],
}

ALLOWED = re.compile(r'<(/?)(b|i|br/?|font[^>]*|super|sub)>')
def esc(text):
    text = str(text)
    out = []; i = 0
    text = re.sub(r'&(?!(amp|lt|gt|#\d+);)', '&amp;', text)
    while i < len(text):
        if text[i] == '<':
            m = ALLOWED.match(text, i)
            if m: out.append(m.group(0)); i = m.end(); continue
            out.append('&lt;'); i += 1; continue
        if text[i] == '>':
            out.append('&gt;'); i += 1; continue
        out.append(text[i]); i += 1
    return ''.join(out)
def P(text, style): return Paragraph(esc(text), st[style])

def make_table(key, T):
    header, rows = T[key]
    data = [[P(str(h), 'cellh') for h in header]] + [[P(str(c), 'cell') for c in r] for r in rows]
    widths = [w*AVAIL_W for w in COLW[key]]
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), NAVY),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('GRID', (0,0), (-1,-1), 0.25, colors.HexColor('#b0b0b0')),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f2f5f8')]),
        ('LEFTPADDING', (0,0), (-1,-1), 3), ('RIGHTPADDING', (0,0), (-1,-1), 3),
        ('TOPPADDING', (0,0), (-1,-1), 2), ('BOTTOMPADDING', (0,0), (-1,-1), 2),
    ]))
    return t

def make_fig(path, caption):
    im = PILImage.open(path); w, h = im.size
    maxh = PAGE_H - 2*MARG - 2.5*cm
    W = AVAIL_W; H = W*h/w
    if H > maxh: H = maxh; W = H*w/h
    return KeepTogether([Image(path, width=W, height=H), Spacer(1, 3), P(caption, 'cap')])

def on_page(c, doc):
    c.saveState(); c.setFont('DV', 7); c.setFillColor(colors.HexColor('#666666'))
    c.drawString(MARG, 0.9*cm, 'AX-1177 portfolio audit | based solely on the internal AX-1177 data package | confidential')
    c.drawRightString(PAGE_W-MARG, 0.9*cm, f'page {doc.page}')
    c.restoreState()

def build_pdf(out):
    T = tables()
    doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=MARG, rightMargin=MARG, topMargin=1.4*cm, bottomMargin=1.5*cm,
                            title='AX-1177 Portfolio Audit: Recommendation', author='Portfolio analysis')
    story = [P(TITLE, 'title'), P(SUBTITLE, 'subtitle'), P(META, 'meta')]
    for blk in S:
        kind = blk[0]
        if kind == 'h1': story.append(P(blk[1], 'h1'))
        elif kind == 'h2': story.append(P(blk[1], 'h2'))
        elif kind == 'p': story.append(P(blk[1], 'p'))
        elif kind == 'bullets':
            for b in blk[1]: story.append(Paragraph(esc(b), st['bullet'], bulletText='•'))
        elif kind == 'box':
            t = Table([[P(blk[1], 'box')]], colWidths=[AVAIL_W])
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#fdf3e1')),('BOX',(0,0),(-1,-1),1.2,colors.HexColor('#c77c02')),
                                   ('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
            story += [t, Spacer(1, 6)]
        elif kind == 'qa':
            for q, a in blk[1]:
                story.append(KeepTogether([P(q, 'q'), P(a, 'a')]))
        elif kind == 'table':
            story += [make_table(blk[1], T), Spacer(1, 6)]
        elif kind == 'fig':
            story.append(make_fig(blk[1], blk[2]))
        elif kind == 'pagebreak':
            story.append(PageBreak())
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)

def md(text):
    t = text.replace('<br/><br/>', '\n\n').replace('<br/>', '  \n')
    t = re.sub(r'<b>(.*?)</b>', r'**\1**', t, flags=re.S)
    t = re.sub(r'<i>(.*?)</i>', r'*\1*', t, flags=re.S)
    t = re.sub(r'<[^>]+>', '', t)
    return t

def build_md(out):
    T = tables()
    L = [f'# {TITLE}', f'### {SUBTITLE}', '', f'*{META}*', '']
    for blk in S:
        kind = blk[0]
        if kind == 'h1': L += ['', f'## {blk[1]}', '']
        elif kind == 'h2': L += ['', f'### {blk[1]}', '']
        elif kind == 'p': L += [md(blk[1]), '']
        elif kind == 'bullets': L += [f'- {md(b)}' for b in blk[1]] + ['']
        elif kind == 'box': L += ['> ' + md(blk[1]).replace('\n\n', '\n>\n> '), '']
        elif kind == 'qa':
            for q, a in blk[1]: L += [f'**Q: {md(q)}**', '', f'A: {md(a)}', '']
        elif kind == 'table':
            header, rows = T[blk[1]]
            L.append('| ' + ' | '.join(md(str(h)) for h in header) + ' |')
            L.append('|' + '---|'*len(header))
            for r in rows: L.append('| ' + ' | '.join(md(str(c)).replace('|','/').replace('\n',' ') for c in r) + ' |')
            L.append('')
        elif kind == 'fig':
            rel = blk[1].replace('/tmp/outputs/', '')
            L += [f'![{md(blk[2])}]({rel})', '', f'*{md(blk[2])}*', '']
    open(out, 'w').write('\n'.join(L))

if __name__ == '__main__':
    build_md('/tmp/outputs/AX-1177_portfolio_audit_memo.md')
    build_pdf('/tmp/outputs/AX-1177_portfolio_audit_memo.pdf')
    print('done')
