import pandas as pd, numpy as np
d = pd.read_parquet('/tmp/work/all_contrasts.parquet')
ren = {
 'IL33_vs_Nontreated_HUVEC_6_hrs':'HUVEC6_IL33_vs_Veh','IL33_vs_Nontreated_HUVEC_24_hrs':'HUVEC24_IL33_vs_Veh',
 'Compound_47_IL33_vs_IL33_HUVEC_6hrs':'HUVEC6_C47IL33_vs_IL33','Compound_47_IL33_vs_IL33_HUVEC_24hrs':'HUVEC24_C47IL33_vs_IL33',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs':'HUVEC6_C47IL33_vs_ISOIL33','Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs':'HUVEC24_C47IL33_vs_ISOIL33',
 'Compound_47_vs_IC119_HUVEC_6hrs':'HUVEC6_C47_vs_ISO','Compound_47_vs_IC119_HUVEC_24hrs':'HUVEC24_C47_vs_ISO',
 'Compound_47_IL33_vs_IL33_HGMEC_6hrs':'HGMEC6_C47IL33_vs_IL33','Compound_47_IL33_vs_IL33_HGMEC_24hrs':'HGMEC24_C47IL33_vs_IL33',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs':'HGMEC6_C47IL33_vs_ISOIL33','Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs':'HGMEC24_C47IL33_vs_ISOIL33',
 'Compound_47_vs_IC119_HGMEC_6hrs':'HGMEC6_C47_vs_ISO','Compound_47_vs_IC119_HGMEC_24hrs':'HGMEC24_C47_vs_ISO',
}
for cl in ['A549','MCF7']:
    for t in ['6','24']:
        for v in ['IC119','DMSO','PBS']:
            ren[f'Compound_47_vs_{v}_{cl}_{t}hrs'] = f'{cl}{t}_C47_vs_{v}'
d['C'] = d.Comparison.map(ren)
assert d.C.notna().all()
ann = d.drop_duplicates('ensembl').set_index('ensembl')[['symbol','entrez','gene_name','AveExpr']]
L = d.pivot(index='ensembl', columns='C', values='logFC')
T = d.pivot(index='ensembl', columns='C', values='t')
P = d.pivot(index='ensembl', columns='C', values='P.Value')
Q = d.pivot(index='ensembl', columns='C', values='adj.P.Val')
