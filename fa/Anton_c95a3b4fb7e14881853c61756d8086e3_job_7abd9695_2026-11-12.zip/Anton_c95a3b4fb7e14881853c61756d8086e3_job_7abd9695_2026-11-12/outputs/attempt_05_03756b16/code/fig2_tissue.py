"""Figure 2: Post-mortem lung IHC re-analysed at donor level, with original and pathology-verified groupings."""
import pandas as pd, numpy as np, matplotlib, warnings
matplotlib.use('Agg'); warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
from scipy import stats
import statsmodels.formula.api as smf
df = pd.read_csv('/tmp/work/pm_blocks_curated.tsv', sep='\t')
vars_ = ['IL33_epi','IL33_endo','IL33_VSM','EPX_s','EDN_s','MBP_s','NE_s','IL5Ra_dNE_s','Tryptase_s']
don = df.groupby('Donor').agg({**{v:'mean' for v in vars_}, 'group':'first','pclass':'first'})
plt.rcParams.update({'font.size':9,'axes.titlesize':10})
orig_order = ['COVID+ pneumonia','COVID- pneumonia','COVID- non-pneumonia']
orig_lab = ['COVID+\npneumonia\n(n=16)','COVID-\npneumonia\n(n=10)','COVID-\nnon-pneumonia\n(n=5)']
ver_order = sorted(don.pclass.unique())
ver_lab = ['COVID+ &\nacute pneumonia\n(n=14)','COVID- &\nacute pneumonia/\ninfection (n=9)','no acute\npneumonia on\npathology (n=8)']
cols = {'COVID+ pneumonia':'#d62728','COVID- pneumonia':'#1f77b4','COVID- non-pneumonia':'#7f7f7f'}
vcols = dict(zip(ver_order, ['#d62728','#1f77b4','#7f7f7f']))
def strip(ax, var, by, order, labels, colmap, title, ylab):
    rng = np.random.default_rng(1)
    data = [don.loc[don[by]==k, var].dropna() for k in order]
    for i,(k,d) in enumerate(zip(order,data)):
        ax.scatter(i + rng.uniform(-0.12,0.12,len(d)), d, s=22, c=colmap[k], alpha=0.8, edgecolor='k', lw=0.3)
        ax.hlines(d.median(), i-0.25, i+0.25, color='k', lw=1.5)
    kw = stats.kruskal(*data).pvalue
    ax.set_xticks(range(len(order))); ax.set_xticklabels(labels, fontsize=7.5)
    ax.set_title(f'{title}\nKruskal-Wallis (donor-level) p={kw:.2g}', fontsize=9, loc='left')
    ax.set_ylabel(ylab, fontsize=8)
fig, axes = plt.subplots(3, 4, figsize=(17, 13.5))
plt.subplots_adjust(hspace=0.62, wspace=0.38)
# Row 1: IL-33 by original labels (3) + note
for j,(v,nm) in enumerate([('IL33_epi','IL-33, basal epithelium'),('IL33_endo','IL-33, endothelium'),('IL33_VSM','IL-33, vascular smooth muscle')]):
    strip(axes[0,j], v, 'group', orig_order, orig_lab, cols, f'A{j+1}. {nm} (original labels)', 'IHC score (donor mean of blocks)')
ax = axes[0,3]
x = don[['IL33_endo','NE_s','pclass']].dropna()
for k in ver_order:
    s = x[x.pclass==k]; ax.scatter(s.NE_s + np.random.default_rng(2).uniform(-0.05,0.05,len(s)), s.IL33_endo, c=vcols[k], s=24, edgecolor='k', lw=0.3, label=k.split(': ')[1])
r,p = stats.spearmanr(x.NE_s, x.IL33_endo)
ax.set_xlabel('neutrophil elastase score (donor mean)'); ax.set_ylabel('IL-33 endothelium score (donor mean)')
ax.set_title(f'A4. Endothelial IL-33 falls as neutrophils rise\nSpearman rho={r:.2f}, p={p:.2g} (n=31 donors)', fontsize=9, loc='left')
ax.legend(fontsize=6.5, frameon=False, loc='lower left')
# Row 2: IL-33 by verified class + endothelium block/donor
for j,(v,nm) in enumerate([('IL33_epi','IL-33, basal epithelium'),('IL33_endo','IL-33, endothelium'),('IL33_VSM','IL-33, vascular smooth muscle')]):
    strip(axes[1,j], v, 'pclass', ver_order, ver_lab, vcols, f'B{j+1}. {nm} (pathology-verified)', 'IHC score (donor mean of blocks)')
ax = axes[1,3]
# Label concordance bar
pm = pd.read_csv('/tmp/work/pm_blocks_curated.tsv', sep='\t').groupby('Donor').first()
ct = pd.crosstab(pm.group, pm.pclass).reindex(orig_order)
bottom = np.zeros(len(ct))
for k in ver_order:
    ax.barh(range(len(ct)), ct[k].values, left=bottom, color=vcols[k], edgecolor='k', lw=0.3, label=k.split(': ')[1])
    for i,v in enumerate(ct[k].values):
        if v>0: ax.text(bottom[i]+v/2, i, str(v), ha='center', va='center', color='white', fontsize=8, fontweight='bold')
    bottom += ct[k].values
ax.set_yticks(range(len(ct))); ax.set_yticklabels(['COVID+ pneu\n(n=16)','COVID- pneu\n(n=10)','COVID- non-pneu\n(n=5)'], fontsize=7.5)
ax.invert_yaxis(); ax.set_xlabel('donors')
ax.set_title('B4. Delivered label vs pathology text\n9/31 donors discordant', fontsize=9, loc='left')
ax.legend(fontsize=6.5, frameon=False, loc='upper center', bbox_to_anchor=(0.5, -0.22), ncol=1, title='pathology-verified class', title_fontsize=6.5)
ax.set_xlim(0, 17)
# Row 3: granulocytes, original vs verified; and block vs donor p
strip(axes[2,0], 'EDN_s', 'group', orig_order, orig_lab, cols, 'C1. Eosinophil EDN (original labels)', 'IHC score')
strip(axes[2,1], 'EDN_s', 'pclass', ver_order, ver_lab, vcols, 'C2. Eosinophil EDN (pathology-verified)', 'IHC score')
strip(axes[2,2], 'NE_s', 'pclass', ver_order, ver_lab, vcols, 'C3. Neutrophil elastase (pathology-verified)', 'IHC score')
ax = axes[2,3]
rows=[]
for v,nm in [('IL33_endo','IL-33 endo'),('IL33_VSM','IL-33 VSM'),('IL33_epi','IL-33 epi'),('EDN_s','EDN'),('MBP_s','MBP'),('NE_s','NE')]:
    gb = [df.loc[df.group==k, v].dropna() for k in orig_order]
    pb = stats.mannwhitneyu(pd.concat([gb[0],gb[1]]), gb[2]).pvalue
    gd = [don.loc[don.group==k, v].dropna() for k in orig_order]
    pd_ = stats.mannwhitneyu(pd.concat([gd[0],gd[1]]), gd[2]).pvalue
    rows.append((nm, pb, pd_))
yy = np.arange(len(rows))
ax.barh(yy+0.2, [-np.log10(r[1]) for r in rows], height=0.38, color='#bdbdbd', label='block-level (n=74, pseudo-replicated)')
ax.barh(yy-0.2, [-np.log10(r[2]) for r in rows], height=0.38, color='#31a354', label='donor-level (n=31)')
ax.axvline(-np.log10(0.05), c='r', ls='--', lw=0.8)
ax.set_yticks(yy); ax.set_yticklabels([r[0] for r in rows]); ax.invert_yaxis()
ax.set_xlabel('-log10 p (pneumonia vs non-pneumonia, original labels)')
ax.set_title('C4. Treating blocks as independent\ninflates significance', fontsize=9, loc='left')
ax.legend(fontsize=6.5, frameon=False, loc='upper center', bbox_to_anchor=(0.5, -0.25), ncol=1)
fig.suptitle('Figure 2. Post-mortem lung: IL-33 is constitutive in every donor, is not higher in COVID-19, and is modestly lower where acute pneumonia / neutrophils are present',
             fontsize=11.5, x=0.01, ha='left', y=0.995)
fig.savefig('/tmp/outputs/figures/Fig2_postmortem_tissue.png', dpi=160, bbox_inches='tight')
print('ok')
