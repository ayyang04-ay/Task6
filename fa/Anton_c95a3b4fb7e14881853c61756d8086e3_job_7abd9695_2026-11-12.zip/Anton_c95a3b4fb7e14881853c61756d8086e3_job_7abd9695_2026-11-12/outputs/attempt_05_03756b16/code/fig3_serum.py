"""Figure 3: Serum proteomics (Olink Target 96, n=100 hospitalised COVID-19; composite endpoint) re-analysed."""
import pandas as pd, numpy as np, matplotlib, warnings
matplotlib.use('Agg'); warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
from scipy import stats
o = pd.read_csv('/tmp/work/olink_assay_level_bridge.tsv', sep='\t')
og = o.sort_values('p.value').drop_duplicates('gene').copy()
plt.rcParams.update({'font.size':9,'axes.titlesize':10})
fig, axes = plt.subplots(2, 3, figsize=(18, 11.5))
plt.subplots_adjust(hspace=0.45, wspace=0.45)
zfdr = stats.norm.isf(o.loc[o['adj.p.value']<0.05,'p.value'].max()/2)
# A: z by IL-33 class
ax = axes[0,0]
cls = [('IL-33-induced, AX-1177-reversed','IL-33-\ninduced &\nAX-1177-\nreversed','#2ca02c'),('no concordant IL-33 effect','no\nIL-33\neffect','#9e9e9e'),
       ('IL-33-repressed, AX-1177-restored','IL-33-\nrepressed','#1f77b4'),('not in RNA-seq (not expressed/filtered)','not\nexpressed\nin cell\nlines','#bcbddc')]
data = [og.loc[og.il33_class==c,'z'].values for c,_,_ in cls]
parts = ax.violinplot(data, showmedians=True, widths=0.8)
for pc,(_,_,col) in zip(parts['bodies'], cls): pc.set_facecolor(col); pc.set_alpha(0.6)
ax.set_xticks(range(1,5)); ax.set_xticklabels([f'{l}\n(n={len(d)})' for (_,l,_),d in zip(cls,data)], fontsize=8)
ax.axhline(zfdr, c='r', ls='--', lw=0.8); ax.text(4.45, zfdr+0.1, 'FDR 5%', color='r', fontsize=7, ha='right')
ax.axhline(0, c='k', lw=0.5)
a = og[og.il33_class==cls[0][0]]; b = og[og.il33_class==cls[1][0]]
fa = (a['adj.p.value']<0.05).mean(); fb = (b['adj.p.value']<0.05).mean()
mw = stats.mannwhitneyu(a.z, b.z).pvalue
ax.set_ylabel('association with composite endpoint (z = log OR / SE)')
ax.set_title(f'A. IL-33-inducible endothelial proteins are NOT enriched\namong severity markers (FDR<5%: {100*fa:.0f}% vs {100*fb:.0f}%; MW p={mw:.2f})', loc='left', fontsize=9.5)
# B: biology classes
ax = axes[0,1]
sets = {
 'neutrophil\nactivation': ['CLEC5A','FCAR','CD177','PRTN3','IL1R2','IL18R1','RETN','MPO','CEACAM8','ARG1','LCN2','S100A12','CHI3L1','AZU1','PGLYRP1','MMP9','OLR1','TREM1','CXCL8','CSF3','LILRA5','ADGRE2','SIGLEC9','PI3'],
 'intracellular\n(cell death/leak)': ['NPM1','PXN','CALR','GSTP1','PRDX1','PRDX6','PRDX3','PRDX5','BACH1','HEXIM1','CASP8','LYN','TANK','STAMBP','SIRT2','AXIN1','EIF4EBP1','NUCB2','APBB1IP','PAG1','MAD1L1','KIFBP','CERT1','HDGF','GLRX','NADK','PPP1R2','FUS','RCOR1'],
 'interferon /\nantiviral': ['CXCL9','CXCL10','CXCL11','IFNG','IFNL1','IFNLR1','DDX58','BST2','IRF9','TRIM21','TRIM5','LAMP3','SIGLEC1','IFI30'],
 'type-2 /\neosinophil /\nmast cell': ['IL5','IL5RA','CCL11','CCL24','CCL17','FCER2','IL4R','IL13RA1','RNASE3','TPSAB1','KIT','KITLG','SIGLEC6','SIGLEC10','IL17RB'],
 'all proteins': None}
cols = ['#d62728','#8c564b','#9467bd','#ff7f0e','#9e9e9e']
data=[]; labs=[]
for (k,gs),c in zip(sets.items(), cols):
    s = og if gs is None else og[og.gene.isin(gs)]
    data.append(s.z.values); labs.append(f'{k}\n(n={len(s)})')
bp = ax.boxplot(data, patch_artist=True, showfliers=True, flierprops=dict(markersize=2))
for patch,c in zip(bp['boxes'], cols): patch.set_facecolor(c); patch.set_alpha(0.6)
for i,d in enumerate(data): ax.scatter(np.full(len(d), i+1)+np.random.default_rng(3).uniform(-0.15,0.15,len(d)), d, s=6, c='k', alpha=0.4) if len(d)<100 else None
ax.set_xticks(range(1,len(labs)+1)); ax.set_xticklabels(labs, fontsize=7.5)
ax.axhline(zfdr, c='r', ls='--', lw=0.8); ax.axhline(0, c='k', lw=0.5)
ax.set_ylabel('z (composite endpoint)')
ax.set_title('B. Severity biology = cell death/leak + neutrophils;\ntype-2 markers are null', loc='left', fontsize=9.5)
# C: candidate marker z bars
ax = axes[0,2]
cands = [('ST2','sST2 (IL1RL1)'),('PTX3','PTX3'),('IL6','IL-6'),('OPG-INFI','OPG (TNFRSF11B)'),('IL-18R1','IL-18R1'),('MCP-3','CCL7 (MCP-3)'),('CCL20','CCL20'),
         ('IL8','CXCL8 (IL-8)'),('TF','Tissue factor (F3)'),('MCP-1-INFI','CCL2 (MCP-1)'),('SELE','E-selectin (SELE)'),('PAI','PAI-1 (SERPINE1)'),('CX3CL1','CX3CL1'),('ICAM1','ICAM-1'),
         ('G-CSF','G-CSF (CSF3)'),('VCAM1','VCAM-1'),('HGF','HGF (context)'),('GDF-15','GDF-15 (context)'),('vWF','vWF (context)'),('ANGPT2','ANGPT2 (context)')]
sub = o.set_index('assay').loc[[c for c,_ in cands]]
colmap = {'IL-33-induced, AX-1177-reversed':'#2ca02c','no concordant IL-33 effect':'#9e9e9e','IL-33-repressed, AX-1177-restored':'#1f77b4','not in RNA-seq (not expressed/filtered)':'#bcbddc'}
yy = np.arange(len(cands))[::-1]
ax.barh(yy, sub.z.values, color=[colmap[c] for c in sub.il33_class])
for yv,(a_,lab) in zip(yy,cands):
    r = sub.loc[a_]
    ax.text(max(r.z,0)+0.05, yv, f"rank {int(r['rank'])}, adj p {r['adj.p.value']:.3f}", va='center', fontsize=6.5)
ax.set_yticks(yy); ax.set_yticklabels([l for _,l in cands], fontsize=7.5)
ax.axvline(zfdr, c='r', ls='--', lw=0.8); ax.axvline(o.z.median(), c='k', ls=':', lw=0.8)
ax.text(o.z.median(), len(cands)-0.2, 'median z\nof all assays', fontsize=6.5, ha='center')
ax.set_xlim(-0.2, 6.8); ax.set_xlabel('z (composite endpoint; adjusted age, sex, NEWS2)')
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color='#2ca02c', label='IL-33-inducible & AX-1177-reversible (HUVEC)'), Patch(color='#9e9e9e', label='no IL-33 effect in vitro')], fontsize=7, frameon=False, loc='upper center', bbox_to_anchor=(0.4,-0.1), ncol=1)
ax.set_title('C. Candidate biomarkers: sST2 leads; the most endothelium-\nspecific IL-33 targets (E-selectin, VCAM-1) are weak', loc='left', fontsize=9.5)
# D: global shift by panel
ax = axes[1,0]
pm = o.groupby('panel_s').agg(med=('z','median'), n=('z','size'), frac=('p.value', lambda s:(s<0.05).mean())).sort_values('med')
ax.barh(range(len(pm)), pm.med, color=['#fdae6b' if m<1 else '#e6550d' for m in pm.med])
for i,(idx,r) in enumerate(pm.iterrows()): ax.text(r.med+0.03, i, f"{100*r.frac:.0f}% p<0.05 (n={int(r.n)})", va='center', fontsize=7)
ax.set_yticks(range(len(pm))); ax.set_yticklabels([p.replace('(v.',' (v.') for p in pm.index], fontsize=7.5)
ax.set_xlabel('median z across assays in panel (null expectation = 0)')
ax.set_xlim(0, 2.6)
ax.set_title(f'D. Global positive shift: {100*(o.OR>1).mean():.0f}% of assays OR>1, {100*(o["p.value"]<0.05).mean():.0f}% p<0.05;\npanel-dependent -> technical and/or global-injury confound', loc='left', fontsize=9.5)
# E: duplicates
ax = axes[1,1]
dup = o[o.gene.duplicated(keep=False)].sort_values(['gene','rank'])
pairs=[]
for g,s in dup.groupby('gene'):
    zz = s.z.values
    for i in range(len(zz)):
        for j in range(i+1,len(zz)): pairs.append((g, zz[i], zz[j]))
pp = pd.DataFrame(pairs, columns=['gene','z1','z2'])
ax.scatter(pp.z1, pp.z2, s=18, c='#6baed6', edgecolor='k', lw=0.3)
for _,r in pp.iterrows():
    if max(r.z1,r.z2)>2.8: ax.annotate(r.gene, (r.z1,r.z2), fontsize=6.5, xytext=(3,-3), textcoords='offset points')
ax.plot([-2,5],[-2,5],'k--',lw=0.6)
rr = np.corrcoef(pp.z1, pp.z2)[0,1]
ax.set_xlabel('z, assay copy 1'); ax.set_ylabel('z, assay copy 2 (different panel)')
ax.set_title(f'E. 27 proteins are measured on 2-4 panels (58 rows; 1,063 unique)\nduplicates agree (r={rr:.2f}) but inflate hit counts (IL-6 x4 in top 30)', loc='left', fontsize=9.5)
# F: undelivered assays
ax = axes[1,2]
cnt = o.groupby('panel_s').size()
miss = (92 - cnt).sort_values()
ax.barh(range(len(miss)), miss.values, color=['#d62728' if p.startswith('Inflammation') else '#bdbdbd' for p in miss.index])
ax.set_yticks(range(len(miss))); ax.set_yticklabels([p.replace('(v.',' (v.') for p in miss.index], fontsize=7.5)
for i,v in enumerate(miss.values): ax.text(v+0.2, i, str(v), va='center', fontsize=7)
ax.set_xlabel('assays not delivered (92 per Target 96 panel minus delivered)')
ax.set_title('F. ~100 assays analysed but not delivered (BH m = 1,194 vs 1,094 rows);\nInflammation panel missing 15 incl. IL-33, TSLP, IL-4/5/13*', loc='left', fontsize=9.5)
ax.text(0.98, 0.02, '*identity of missing analytes inferred from\nvendor panel content (external reference)', transform=ax.transAxes, ha='right', va='bottom', fontsize=6.5, style='italic')
fig.suptitle('Figure 3. Serum proteomics: sST2 is the most robust prognostic marker, but the AX-1177-reversible IL-33 programme does not explain severity, and the drug target itself was not delivered',
             fontsize=11.5, x=0.01, ha='left', y=0.995)
fig.savefig('/tmp/outputs/figures/Fig3_serum_proteomics.png', dpi=160, bbox_inches='tight')
print('zfdr', zfdr, 'dup r', rr)
