import re, pandas as pd
SUFFIXES = ['-INFI','-CVDIII','-CVDII','-ONCII','-IMO','-CRE','-NEX','-ODA','-MET','-NEUI']
ALIAS = {
 # CVD II
 'ADAM-TS13':'ADAMTS13','BMP-6':'BMP6','CD40-L':'CD40LG','CTSL1':'CTSL','Dkk-1':'DKK1','FGF-21':'FGF21','FS':'FST','GDF-2':'GDF2',
 'GH':'GH1','GIF':'CBLIF','GT':'FABP6','Gal-9':'LGALS9','HAOX1':'HAO1','HB-EGF':'HBEGF','HO-1':'HMOX1','HSP 27':'HSPB1',
 'IL-17D':'IL17D','IL-1ra':'IL1RN','IL-27':'IL27','IL-4RA':'IL4R','IgG Fc receptor II-b':'FCGR2B','KIM1':'HAVCR1','LOX-1':'OLR1',
 'NEMO':'IKBKG','PAR-1':'F2R','PARP-1':'PARP1','PD-L2':'PDCD1LG2','PDGF subunit B':'PDGFB','PIgR':'PIGR','PSGL-1':'SELPLG',
 'RAGE':'AGER','TF':'F3','CD97':'ADGRE5','SCF':'KITLG','TIE2':'TEK','TM':'THBD','TRAIL-R2':'TNFRSF10B','VEGFD':'VEGFD','hOSCAR':'OSCAR','PGF':'PGF',
 # CVD III
 'AP-N':'ANPEP','BLM hydrolase':'BLMH','CASP-3':'CASP3','DLK-1':'DLK1','Ep-CAM':'EPCAM','GDF-15':'GDF15','Gal-3':'LGALS3','Gal-4':'LGALS4',
 'ICAM-2':'ICAM2','IGFBP-1':'IGFBP1','IGFBP-2':'IGFBP2','IGFBP-7':'IGFBP7','IL-17RA':'IL17RA','IL-18BP':'IL18BP','IL-1RT1':'IL1R1',
 'IL-1RT2':'IL1R2','IL-6RA':'IL6R','IL2-RA':'IL2RA','JAM-A':'F11R','LDL receptor':'LDLR','MCP-1':'CCL2','MMP-2':'MMP2','MMP-3':'MMP3',
 'MMP-9':'MMP9','NT-proBNP':'NPPB','Notch 3':'NOTCH3','OPG':'TNFRSF11B','OPN':'SPP1','PAI':'SERPINE1','PDGF subunit A':'PDGFA',
 'PECAM-1':'PECAM1','PLC':'HSPG2','PSP-D':'SFTPD','SHPS-1':'SIRPA','ST2':'IL1RL1','TLT-2':'TREML2','TNF-R1':'TNFRSF1A','TNF-R2':'TNFRSF1B',
 'TR':'TFRC','TR-AP':'ACP5','U-PAR':'PLAUR','t-PA':'PLAT','uPA':'PLAU','vWF':'VWF',
 # Cell regulation / development
 'FAM19A5':'TAFA5','MESDC2':'MESD','NOV':'CCN3','FUT3/FUT5':'FUT3',
 # Inflammation
 '4E-BP1':'EIF4EBP1','CASP-8':'CASP8','CSF-1':'CSF1','EN-RAGE':'S100A12','FGF-19':'FGF19','FGF-5':'FGF5','Flt3L':'FLT3LG',
 'IFN-gamma':'IFNG','IL-10RA':'IL10RA','IL-10RB':'IL10RB','IL-12B':'IL12B','IL-15RA':'IL15RA','IL-17A':'IL17A','IL-17C':'IL17C',
 'IL-18R1':'IL18R1','IL-20RA':'IL20RA','IL8':'CXCL8','LAP TGF-beta-1':'TGFB1','LIF-R':'LIFR','MCP-2':'CCL8','MCP-3':'CCL7',
 'MCP-4':'CCL13','MMP-1':'MMP1','MMP-10':'MMP10','NT-3':'NTF3','PD-L1':'CD274','ST1A1':'SULT1A1','TGF-alpha':'TGFA','TNFB':'LTA',
 'TRAIL':'TNFSF10','TRANCE':'TNFSF11','TWEAK':'TNFSF12','GDNF':'GDNF',
 # Neuro exploratory
 'COL4A3BP':'CERT1','KIF1BP':'KIFBP',
 # Neurology
 'ADAM 22':'ADAM22','ADAM 23':'ADAM23','Alpha-2-MRAP':'LRPAP1','BMP-4':'BMP4','CLM-1':'CD300LF','CLM-6':'CD300C','Dkk-4':'DKK4',
 'FcRL2':'FCRL2','G-CSF':'CSF3','GCP5':'GPC5','GDF-8':'MSTN','GDNFR-alpha-3':'GFRA3','GFR-alpha-1':'GFRA1','GM-CSF-R-alpha':'CSF2RA',
 'IL-5R-alpha':'IL5RA','IL12':'IL12A','JAM-B':'JAM2','LAIR-2':'LAIR2','N-CDase':'ASAH2','N2DL-2':'ULBP2','NEP':'MME','Nr-CAM':'NRCAM',
 'PDGF-R-alpha':'PDGFRA','SKR3':'ACVRL1','Siglec-9':'SIGLEC9','THY 1':'THY1','TN-R':'TNR','gal-8':'LGALS8','sFRP-3':'FRZB',
 # Oncology II
 "5'-NT":'NT5E','ADAM 8':'ADAM8','ADAM-TS 15':'ADAMTS15','CAIX':'CA9','CXL17':'CXCL17','CYR61':'CCN1','ESM-1':'ESM1','FGF-BP1':'FGFBP1',
 'FR-alpha':'FOLR1','FR-gamma':'FOLR3','Gal-1':'LGALS1','IFN-gamma-R1':'IFNGR1','MAD homolog 5':'SMAD5','MIC-A/B':'MICA','MK':'MDK',
 'MUC-16':'MUC16','MetAP 2':'METAP2','PVRL4':'NECTIN4','SYND1':'SDC1','TFPI-2':'TFPI2','TGFR-2':'TGFBR2','VEGFR-2':'KDR','VEGFR-3':'FLT4',
 'WIF-1':'WIF1','WISP-1':'CCN4','hK11':'KLK11','hK14':'KLK14','hK8':'KLK8',
 # Oncology III
 'ICAM 5':'ICAM5',
 # Organ damage
}
def base_name(a):
    b = a
    for s in SUFFIXES:
        if b.endswith(s): b = b[:-len(s)]; break
    return b
def to_gene(a):
    b = base_name(a)
    if b in ALIAS: return ALIAS[b]
    return b
def load_olink(path='/tmp/world/filesystem/AX-1177_serum_proteomics.xlsx'):
    df = pd.read_excel(path)
    df['panel_s'] = df.panel.str.replace('Olink Target 96 ','', regex=False)
    df['base'] = df.assay.map(base_name)
    df['gene'] = df.assay.map(to_gene)
    df['rank'] = range(1, len(df)+1)
    return df
