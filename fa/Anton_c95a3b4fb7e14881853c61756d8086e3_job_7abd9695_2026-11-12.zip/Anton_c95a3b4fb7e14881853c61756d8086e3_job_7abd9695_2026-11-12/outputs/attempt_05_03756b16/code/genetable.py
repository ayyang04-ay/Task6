exec(open('/tmp/work/wide.py').read())
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500)
sym2e = ann.reset_index().drop_duplicates('symbol').set_index('symbol')['ensembl']
def gtable(genes, cols):
    rows=[]
    for g in genes:
        if g not in sym2e.index:
            rows.append([g, None]+['NA']*len(cols)); continue
        e = sym2e[g]
        r=[g, round(ann.loc[e,'AveExpr'],2)]
        for c in cols:
            r.append(f'{L.loc[e,c]:+.2f}' + ('*' if Q.loc[e,c]<0.05 else ' '))
        rows.append(r)
    short=[c.replace('_IL33_vs_Veh','_IL33').replace('_C47IL33_vs_ISOIL33','_neut').replace('_C47IL33_vs_IL33','_C47IL33vIL33').replace('_C47_vs_ISO','_C47alone') for c in cols]
    return pd.DataFrame(rows, columns=['gene','AveExpr']+short)
