# -*- coding: utf-8 -*-
"""Single source of truth for the AX-1177 portfolio-audit memo (rendered to Markdown and PDF)."""
import pandas as pd
W = '/tmp/work'

TITLE = 'AX-1177 (anti-IL-33 mAb) — Portfolio Audit'
SUBTITLE = 'Recommendation, defence and forward view'
META = ('Prepared for: Portfolio Committee. Basis: the complete AX-1177 internal data package (methods annex; '
        'endothelial/epithelial RNA-seq contrasts; serum proteomics from 100 hospitalised COVID-19 patients; post-mortem lung IHC from 31 donors), '
        're-analysed from the delivered files. Every conclusion below is drawn from these data. Outside knowledge is limited to basic target biology '
        '(e.g. that sST2 is the soluble decoy form of the IL-33 receptor and that IL-33 is a nuclear alarmin) and the vendor’s published Olink panel content, which is flagged where used.')

# Each section: list of blocks. Block types: ('h1', text) ('h2', text) ('p', html) ('bullets', [html]) ('table', key) ('fig', path, caption) ('box', html) ('pagebreak',)
S = []

S += [('h1', '1. Recommendation'),
 ('box', '<b>Do not keep AX-1177 in the respiratory portfolio as a severe viral lower-respiratory-tract-infection (LRTI) programme. Stop that indication now.</b><br/><br/>'
         '<b>Hold the molecule; do not terminate it yet.</b> Run one short, low-cost check (≤ 3 months) using only data and tissue we already own, '
         'and re-admit AX-1177 to the portfolio only if it passes Gates 0–1 in Section 5.4. Otherwise terminate.<br/><br/>'
         '<b>In one line: our data validate the drug, not the disease hypothesis.</b> AX-1177 is a clean, potent IL-33 neutraliser in human endothelial cells. '
         'But none of our human data show that IL-33 is raised in, specific to, or a driver of severe viral LRTI. '
         'The direct measurement of the target in patients was made but not delivered to us.'),
 ('p', '<b>What the committee is being asked to accept.</b> We stop a programme whose central hypothesis has failed every test our own data allow: tissue, serum mechanism, and target measurement. '
       'We keep, at minimal cost (analyst time plus a targeted expression panel on 22 archived lung RNAs), a well-characterised molecule plus a ready-made biomarker kit (an sST2 enrichment marker and an endothelial PD panel). '
       'That kit can decide its fate within one quarter.'),
]

S += [('h1', '2. The case: what our data show'),
 ('table', 'evidence'),
 ('h2', '2.1 The molecule works, in the cells we tested (Figure 1)'),
 ('bullets', [
   'IL-33 (reduced form, 30 ng/mL) triggers a large endothelial inflammatory programme in HUVEC: 4,031 genes change at 6 h (FDR<0.05) and 1,836 at 24 h. '
   'The top responders are canonical NF-κB targets (NFKBIA t=44, TNFAIP3, TRAF1, RELB, BIRC3). '
   'Also induced: leukocyte adhesion molecules (E-selectin +11.2 log2, VCAM-1 +8.7, ICAM-1 +6.0), neutrophil chemokines (CXCL1/2/3/5/6/8, CCL20), GM-CSF/G-CSF, TNF, IL-1α/β, '
   'and a pro-coagulant switch (tissue factor +5.6, PAI-1 +1.7, thrombomodulin −1.0).',
   '<b>AX-1177 blocks essentially all of the IL-33-induced response at 6 h.</b> Against the isotype-matched arm (AX-1177+IL-33 vs isotype+IL-33, independent of the IL-33-alone arm), the median block is 100% (IQR 93–106%) for the 289 well-expressed induced genes. Across all 635 induced genes, including noisy low-count transcripts, it is 95–98%. '
   'At 24 h the block is 73–83% (82% for well-expressed genes). The IL-33 response itself replicates between the two independent IL-33-exposed arms (r=0.97). '
   'Glomerular microvascular endothelium (HGMEC) shows the same AX-1177-reversible programme (r=0.70 across signature genes), at ~44% of the HUVEC magnitude.',
   '<b>AX-1177 is transcriptionally inert without IL-33.</b> Across HUVEC, HGMEC, A549 and MCF7 at 6 and 24 h, it changes only 0–9 genes robustly, with no coherent pathway. '
   'The delivered "FDR hits" in these contrasts are variance artefacts (e.g. AKR1C2 log2FC 0.06 at p=10⁻⁷³) or low-count noise (Figure S1). '
   'Neither off-target biology nor endogenous IL-33 tone appears in culture.',
   'Limits: one donor per endothelial line; one dose of antibody and IL-33 (~40-fold molar excess); antibody added with IL-33 (no pre-incubation); reduced IL-33 only. '
   'The epithelial lines (A549, MCF7) never received IL-33. '
   'Potency, activity against oxidised IL-33 (the asset’s stated differentiator) and activity in lung cells are therefore <b>not demonstrated</b>.']),
 ('h2', '2.2 The disease hypothesis is not supported in human lung (Figure 2)'),
 ('bullets', [
   'IL-33 protein is constitutively abundant in basal epithelium, endothelium and vascular smooth muscle in every one of 31 elderly donors. In endothelium, 53% of blocks sit at the top of the score range.',
   '<b>It is not higher in COVID-19 or in pneumonia.</b> At donor level, IL-33 does not differ across COVID+ pneumonia (16), COVID− pneumonia (10) and non-pneumonia (5). '
   'Kruskal–Wallis p = 0.65 (epithelium), 0.11 (endothelium) and 0.16 (VSM). COVID+ donors are numerically the <i>lowest</i> in all three compartments.',
   'The only IL-33 signal is a modest <i>fall</i> in endothelial IL-33 where acute pneumonia and neutrophils are present. It tracks neutrophil elastase (ρ=−0.43, p=0.016) and is lower in pathology-verified COVID+ acute pneumonia than in lungs without pneumonia (mixed model p=0.034). '
   'COVID+ and COVID− pneumonia do not differ (p=0.34). The finding is pathogen-agnostic, and it cannot distinguish alarmin release from activation-induced loss of expression.',
   'The eosinophil "pneumonia" signal in the delivered labels (EDN/MBP, p≈0.005) is an artefact of labelling. It disappears when donors are classified from their pathology reports (EDN p=0.11). '
   '9 of 31 donor labels contradict the pathology text. IL-5Rα staining tracks neutrophil elastase (ρ=0.89), not eosinophil granule proteins (ρ≤0.20). Neutrophil infiltration is the robust tissue finding.']),
 ('h2', '2.3 Patient serum: sST2 predicts, but the IL-33 programme does not explain severity, and IL-33 itself is missing (Figure 3)'),
 ('bullets', [
   '<b>sST2 (the soluble IL-33 decoy receptor) is our most robust prognostic marker.</b> OR 3.0 per log unit (95% CI 1.8–5.0), p=1.7×10⁻⁵, adj p=0.007, rank 2 of 1,094. '
   'It is rank 1 after correcting for a panel-level global shift. Adjusted for age, sex and NEWS2.',
   '<b>The AX-1177-reversible endothelial programme is not enriched among severity markers.</b> I took the 99 serum proteins that IL-33 induces in vitro and AX-1177 reverses. '
   '17.2% are FDR-significant for the composite endpoint, versus 17.8% of the 792 proteins IL-33 does not touch (Fisher p=1.0; Mann–Whitney on z, p=0.87). '
   'Only 7 of the top 50 severity proteins are IL-33-inducible. The most endothelium-specific IL-33 products are weak or null: E-selectin p=0.02, VCAM-1 p=0.43, G-CSF p=0.23.',
   'Severity in this cohort is driven by <b>cell death/leakage and neutrophil activation</b>. Intracellular proteins have median z 3.4 (26/29 FDR-significant), neutrophil markers 2.7 (12/24), interferon markers 2.0, type-2/eosinophil/mast-cell markers 0.2 '
   '(IL-5 OR 1.00, eotaxin 1.08, tryptase 1.07).',
   '<b>The drug’s target was not delivered.</b> The delivered adjusted p-values imply Benjamini–Hochberg over 1,194 tests; only 1,094 assays were delivered. '
   'The Inflammation panel is missing 15 of its 92 analytes. By the vendor’s published panel content, those include IL-33 itself, plus TSLP, IL-4, IL-5 and IL-13. '
   'IL-33 was most likely run and dropped for being below the detection limit.']),
 ('pagebreak',),
]

S += [('h1', '3. Anticipated challenges, and the answers our data support'),
 ('qa', [
  ('“sST2 is #2 of 1,094, and #1 after adjustment. Isn’t that the IL-33 pathway driving severity?”',
   'sST2 is the decoy receptor. Injured endothelium and epithelium release it under many stimuli, and high sST2 <i>sequesters</i> IL-33 rather than signals it. '
   'In our own cells, IL-33 raises IL1RL1 only modestly and transiently in HUVEC (+1.6 log2 at 6 h, +0.4 at 24 h; not statistically resolvable in the delivered model) and not at all in glomerular endothelium. '
   'The one measurement that would connect sST2 to IL-33 is circulating IL-33, and it was run but not delivered. sST2 is the right <i>enrichment</i> marker. It is not evidence that neutralising IL-33 changes outcome.'),
  ('“AX-1177 switches off IL-6, PTX3, OPG, tissue factor and CCL20, and all of them predict severity. Doesn’t that show we can hit severity biology?”',
   'In a dish where exogenous IL-33 is the only stimulus, yes. In patients, those proteins come from many cell types responding to many signals, including the IL-1 and TNF that IL-33 itself induces (IL1A +4.6, TNF +7.9 log2 at 6 h). '
   'The fair test is whether IL-33-inducible proteins are <i>more</i> prognostic than the rest. They are not (17.2% vs 17.8%). '
   'The proteins most specific to endothelial IL-33 signalling (E-selectin, VCAM-1, G-CSF) carry little or no prognostic information.'),
  ('“Lower endothelial IL-33 in pneumonia means the alarmin is being released, i.e. the pathway is active.”',
   'That reading is compatible with our data, but so is activation-induced loss of expression, and our HUVEC data show a (non-significant) fall in IL33 mRNA after IL-33 stimulation (−0.9 log2 at 24 h). '
   'The effect is modest (about 0.6–0.8 points on a ceiling-limited score), comes from a single reader, and does not differ between COVID+ and COVID− pneumonia. '
   'It justifies measuring free IL-33. It does not justify clinical spend.'),
  ('“Absence of evidence is not evidence of absence. The tissue study is small.”',
   'Correct for small effects: 16 vs 10 donors only detects large differences. But the direction is <i>opposite</i> to the hypothesis in all three compartments, which makes a hidden large increase implausible. '
   'And the serum data independently point the same way: the IL-33-reversible programme is not enriched among severity markers.'),
  ('“The data-quality problems cut both ways. A clean re-analysis might rescue the signal.”',
   'Agreed. That is why Gate 0 is retrieval and re-analysis, at analyst-time cost only. But we should not fund clinical development on this package. '
   'Fixing the RNA-seq model would mostly sharpen the in vitro pharmacology, which is already strong. It cannot create a disease link.'),
  ('“The molecule is good. Why not simply keep it?”',
   'Molecule quality is necessary but not sufficient. A lung indication needs four facts we do not have: activity against oxidised IL-33, activity in lung cells, potency, and a therapeutic window. '
   'On the window: only co-addition was tested, and block falls from 95–100% at 6 h to 73–83% by 24 h. The hold-with-gates option preserves the asset for one quarter without development spend.'),
  ('“Why not pivot to COPD/asthma, where anti-IL-33 is better established?”',
   'Not on our data. IL-33 and eosinophil scores do not differ by COPD/asthma annotation (all p>0.1). The eosinophil signal is a labelling artefact, and serum type-2 markers are null. '
   'We have no epithelial IL-33 experiments. An airway pivot would rest entirely on external evidence and would need its own data package. It cannot be defended from this one.'),
 ]),
]

S += [('h1', '4. If we drop it: what we are dropping, and why'),
 ('p', '<b>What we are dropping.</b> A human IgG1 anti-IL-33 that does three things. (i) It neutralises reduced-IL-33 signalling in venous and glomerular endothelial cells, blocking essentially all (median 95–100%) of a ~600-gene NF-κB / adhesion / chemokine / GM-CSF / G-CSF / tissue-factor programme at 6 h. '
       '(ii) It is transcriptionally inert without IL-33 in four human cell types. (iii) It comes with a patient-measurable biomarker kit: sST2 for enrichment and an endothelial PD panel (E-selectin, OPG, tissue factor, CCL20, PTX3).'),
 ('p', '<b>What it never acquired.</b> Any human evidence that IL-33 is raised in, specific to, or causal for the target disease. Also missing: functional data on oxidised IL-33 and on lung cells, potency, and a therapeutic window.'),
 ('p', '<b>Why we drop it.</b> The viral-LRTI hypothesis failed each test our data could apply. In tissue, IL-33 is not increased and there is no virus specificity. '
       'In serum, the IL-33-reversible programme is not enriched among severity proteins. And the target measurement was not delivered. '
       'The positive signals (sST2; prognostic proteins that AX-1177 can reverse in vitro) are explained equally well by non-specific injury and neutrophil biology, which dominates severity in this cohort.'),
 ('pagebreak',),
]

S += [('h1', '5. Forward view'),
 ('h2', '5.1 What indication do our data actually point at?'),
 ('p', 'Not “viral” LRTI, and not COVID-19 specifically. To the extent our data point anywhere, they point at <b>pathogen-agnostic, endothelium- and neutrophil-driven acute lung injury '
       '(severe pneumonia / ARDS regardless of cause), enriched by high sST2</b>. Three lines of evidence converge:'),
 ('bullets', [
   '<b>In vitro:</b> IL-33’s action is an endothelial NF-κB, leukocyte-recruiting, pro-coagulant programme, and AX-1177 blocks it.',
   '<b>In tissue:</b> the only IL-33 signal (endothelial IL-33 falling as neutrophils rise) is the same in COVID+ and COVID− pneumonia.',
   '<b>In serum:</b> severity is neutrophil- and injury-driven, sST2 is the most robust prognostic marker, and several AX-1177-reversible endothelial proteins are prognostic (tissue factor, OPG, PTX3; PAI-1 borderline).']),
 ('p', 'This is a <b>hypothesis, not a validated indication</b>, but it is the only one our data support at all. '
       'A weaker secondary hypothesis is microvascular endothelial injury outside the lung: glomerular endothelium responds, though at ~44% of the HUVEC magnitude, transiently, and with no patient data. '
       'Type-2 airway disease, cardiovascular disease and COVID-specific positioning are not supported (Section 6).'),
 ('h2', '5.2 What the next studies would have to establish'),
 ('table', 'establish'),
 ('h2', '5.3 Biomarkers: which could go into patients, and in what role'),
 ('table', 'biomarkers'),
 ('p', '<b>Sampling timepoint.</b> '
       '(i) <b>In vitro: 6 h after IL-33 is the primary read-out.</b> The programme is largest then (4,031 vs 1,836 DE genes at 24 h) and AX-1177 block is most complete (95–100% vs 73–83%). 24 h is secondary, for sustained and late-wave genes (OPG, G-CSF, C3, MMP-10). '
       '(ii) <b>Patients: baseline at enrolment / hospital admission, before study drug, is the one timepoint our data validate.</b> That is where sST2, OPG, PTX3, tissue factor and IL-6 carried prognostic information, so it is the enrichment timepoint. '
       '(iii) <b>PD: sample early after dosing</b> (24 h and 72 h, plus day 7), because the IL-33 endothelial programme is front-loaded (E-selectin +11.2 at 6 h vs +4.7 at 24 h; tissue factor +5.6 vs +1.2). '
       'The exact window must come from the Gate 3 kinetic cohort, since our package contains no in vivo kinetics. '
       'The same front-loading means any future clinical study would have to dose early in the course of lung injury.'),
 ('h2', '5.4 Gated plan with kill criteria'),
 ('table', 'gates'),
 ('p', 'Gates 0–1 decide re-admission. Gates 2–3 would be the first steps of a re-admitted programme, and only after Gate 3 would a Phase 2a be considered. Its design would use sST2-high enrichment, E-selectin/OPG/tissue-factor PD endpoints, free IL-33 target engagement, and global-injury covariates.'),
 ('pagebreak',),
]

S += [('h1', '6. What I considered and ruled out'),
 ('table', 'ruled'),
 ('h1', '7. Data-quality audit of the delivered package'),
 ('p', 'Every dataset had structural or analytical defects that would mislead a naive reading. Most of them inflate positive findings. Each was handled as shown; the full log is in the workbook (sheet 4).'),
 ('table', 'dq'),
 ('pagebreak',),
]

S += [('h1', '8. Methods (summary)'),
 ('bullets', [
   '<b>RNA-seq.</b> I parsed all delivered contrasts (the two workbook sheets are identical; empty padding rows removed) and merged them with the HUVEC IL-33-vs-vehicle file, which is the same model (identical AveExpr). '
   'Neutralisation was assessed with the isotype-matched contrast (AX-1177+IL-33 vs isotype+IL-33), which shares no sample group with IL-33-vs-vehicle. '
   'Residual IL-33 effect = [(AX-1177+IL-33) − vehicle] / [IL-33 − vehicle], computed from contrast logFCs. '
   'Gene-wide SE inflation = median |logFC/t| across contrasts relative to genes of similar AveExpr. Genes >3× inflated were flagged, and effect sizes replicated across independent groups were used instead of FDR. '
   '"Robust" DE means FDR<0.05, |log2FC|≥1, AveExpr>0 and SE inflation <3×. The HGMEC IL-33 dependence was inferred from the AX-1177 × IL-33 interaction, since there is no HGMEC vehicle arm.',
   '<b>Serum proteomics.</b> I mapped Olink assay names to HGNC symbols (e.g. ST2→IL1RL1, OPG→TNFRSF11B, TF→F3 tissue factor) and collapsed 1,094 assays to 1,063 proteins. '
   'Ranking used z = ln(OR)/SE with SE from the 95% CI (this reproduces the reported p, r>0.9999). A panel-median/MAD-standardised z served as a global-shift sensitivity analysis. '
   'Bridging classes come from in vitro concordance: IL-33 vs vehicle ≥1 log2 and AX-1177 neutralisation ≤−1 log2 at the same timepoint. Enrichment was tested with Fisher’s exact and Mann–Whitney tests. '
   'The number of BH tests was back-calculated from the delivered adjusted p-values.',
   '<b>Post-mortem.</b> I propagated donor-level fields within donor, parsed ordinal scores, and ran the primary analysis at donor level (mean of blocks; Kruskal–Wallis / Mann–Whitney; Spearman). '
   'Block-level sensitivity used linear mixed models with a donor random intercept. Categories were re-adjudicated by hand from each donor’s pathology text (acute pneumonia/infection present vs absent) as a sensitivity analysis.',
   '<b>Deliverables.</b> This memo (PDF/Markdown); figures (PNG); <i>AX-1177_supporting_tables.xlsx</i> (13 sheets: candidate biomarkers, gates, ruled-out options, data-quality log, serum gene- and assay-level tables, post-mortem donor table and statistics, RNA-seq contrast summary, 79-gene IL-33 signature, genome-wide IL-33/AX-1177 table); analysis code in <i>code/</i>.']),
 ('h1', 'Figures'),
 ('fig', '/tmp/outputs/figures/Fig1_invitro_pharmacology.png', 'Figure 1. In vitro pharmacology. A–B: IL-33 effect vs AX-1177 neutralisation effect (HUVEC 6 h, 24 h); points on the dashed line are completely reversed. C: robust DE genes per contrast; AX-1177 alone is inert. D: residual IL-33 effect under AX-1177 relative to vehicle. E: HGMEC reproduces the HUVEC programme at lower magnitude. F: the IL-33 response is front-loaded for serum-measurable products.'),
 ('fig', '/tmp/outputs/figures/Fig2_postmortem_tissue.png', 'Figure 2. Post-mortem lung, donor level. A: IL-33 by delivered labels, and endothelial IL-33 vs neutrophil elastase. B: IL-33 by pathology-verified class, and label concordance. C: the eosinophil signal is label-dependent; the neutrophil signal is robust; block-level tests inflate significance.'),
 ('fig', '/tmp/outputs/figures/Fig3_serum_proteomics.png', 'Figure 3. Serum proteomics. A: IL-33-inducible, AX-1177-reversible proteins are not enriched among severity markers. B: severity biology by class. C: candidate biomarkers. D: global shift by panel. E: duplicated assays. F: undelivered assays per panel.'),
 ('fig', '/tmp/outputs/figures/Fig4_candidate_biomarkers.png', 'Figure 4. Candidate biomarkers: in vitro IL-33 inducibility / AX-1177 reversibility (HUVEC, HGMEC) vs patient serum association, with the proposed role in patients.'),
 ('fig', '/tmp/outputs/figures/FigS1_rnaseq_model_QC.png', 'Figure S1. The delivered RNA-seq statistics come from one pooled model across four heterogeneous cell lines. SEs are pathological for a subset of genes, including key IL-33 targets, and the antibody-alone "hits" are artefacts.'),
]

# ---------------- tables ----------------
def tables():
    T = {}
    T['evidence'] = (['#','Finding','Strength of evidence','Key numbers'], [
      ['1','AX-1177 neutralises reduced-IL-33 signalling in endothelium and is inert without IL-33','Strong (in vitro; one donor per line, one dose)','IL-33: 4,031 DE genes (HUVEC 6 h). AX-1177 blocks a median 95–100% of the induced response at 6 h and 73–83% at 24 h (isotype-matched). HGMEC r=0.70. AX-1177 alone: 0–9 robust genes/contrast'],
      ['2','IL-33 is constitutive in human lung and not higher in COVID-19 or pneumonia','Consistent negative (31 donors)','Donor-level KW p=0.65 / 0.11 / 0.16 (epithelium / endothelium / VSM); COVID+ numerically lowest'],
      ['3','The drug target was measured in serum but not delivered','Critical gap','BH m=1,194 vs 1,094 delivered; Inflammation panel 77/92, missing IL-33, TSLP, IL-4/5/13 (per vendor panel content)'],
      ['4','Severity is cell death + neutrophils; the AX-1177-reversible IL-33 programme does not explain it','Moderate–strong negative','IL-33-inducible proteins 17.2% vs 17.8% FDR-significant (p=1.0); intracellular z 3.4, neutrophil 2.7, type-2 0.2'],
      ['5','sST2 is the most robust prognostic marker but not evidence of IL-33 causality','Strong (prognostic); weak (mechanistic)','OR 3.0/log unit (1.8–5.0), adj p=0.007; rank 2/1,094 (1 after shift adjustment)'],
      ['6','Quality defects in every dataset, mostly inflating positives','Structural','27 duplicated proteins; 74 blocks/31 donors; 9/31 labels contradicted by pathology; 382 genes with >3× SE inflation'],
    ])
    T['establish'] = (['','Must establish','Status in our data'], [
      ['E1','Target presence: bioactive (free) IL-33 is detectable and raised in the target population at enrolment','Unknown. Assay run but not delivered (probably below detection)'],
      ['E2','Target activity in tissue: the AX-1177-reversible endothelial IL-33 programme is active in human acute lung injury, beyond generic injury','Unknown. Only indirect IHC (endothelial IL-33 loss with neutrophils)'],
      ['E3','PD specificity: the PD panel responds to IL-33, and AX-1177 does not suppress it when IL-1β/TNF drive it','Unknown. Only IL-33 was used as a stimulus'],
      ['E4','Relevant pharmacology: potency vs reduced AND oxidised IL-33; activity in lung microvascular endothelium and airway epithelium (≥3 donors); therapeutic window with delayed addition','Unknown. One dose, reduced form, co-addition, single donors, no lung cells given IL-33'],
      ['E5','Population: sST2-high identifies IL-33 pathway activity (not just severity) in a contemporary, multi-pathogen cohort','Unknown. Single-centre, pre-vaccination, COVID-only cohort'],
    ])
    T['biomarkers'] = (['Marker','What our data show','Usable in patients?','Proposed role'], [
      ['sST2 (IL1RL1)','Rank 2/1,094 (1 after shift adjustment); OR 3.0/log unit, adj p=0.007','Yes: established immunoassays','<b>Baseline prognostic enrichment / stratification.</b> Not a PD marker; not validated as predictive of AX-1177 benefit'],
      ['Free and total IL-33','Run on the Olink Inflammation panel but not delivered (likely below LOD)','Not yet: needs a high-sensitivity assay','<b>Target engagement</b> (free ↓, drug–IL-33 complex ↑ after dosing); baseline stratifier if detectable'],
      ['E-selectin','Most IL-33-inducible, AX-1177-reversible endothelial product (+11.2/−11.0 log2 HUVEC 6 h; −8.7 HGMEC); serum p=0.02','Yes','<b>Lead endothelium-restricted PD marker</b>'],
      ['OPG (TNFRSF11B)','+4.8 (6 h) and +2.4 (24 h), reversed; HGMEC −1.9; prognostic on two panels (adj p 0.014 / 0.020)','Yes','PD (sustained) + prognostic covariate'],
      ['Tissue factor (F3)','+5.6, reversed (FDR 10⁻²⁶); serum p=0.009','Yes','Exploratory PD (immunothrombosis)'],
      ['PTX3','+2.2, reversed (FDR unreliable: SE inflated); serum rank 6 (3 after shift adjustment)','Yes','Prognostic covariate; exploratory PD'],
      ['CCL20, CCL7, CX3CL1, VCAM-1, ICAM-1, G-CSF','Large IL-33 induction, AX-1177-reversed; prognostic value ranges from strong (CCL20, CCL7) to null (VCAM-1, G-CSF)','Yes','Exploratory mechanistic PD panel, not enrichment'],
      ['IL-6, CXCL8, CCL2','IL-33-inducible but made by many cells; IL-6 prognostic on 4 panels','Yes','Prognostic covariates only (standard-of-care confounded)'],
      ['HGF, GDF-15, vWF, CLEC5A, PRTN3','Strongly prognostic; not IL-33-driven in vitro','Yes','Global-injury / neutrophil covariates, needed to show any IL-33 signal is specific'],
      ['Lung IL-33 and granulocyte IHC; IL-5Rα','Post-mortem only; IL-5Rα not eosinophil-specific here','No','Translational only'],
      ['79-gene endothelial IL-33 signature','In vitro, AX-1177-reversible, sustained to 24 h, replicated in HGMEC','No (tissue/cell assays)','Gate 1 tissue scoring; in vitro potency read-out'],
    ])
    gp = pd.read_csv(f'{W}/tables/gated_plan.tsv', sep='\t')
    T['gates'] = (['Gate','Question','Time / cost','What is done','Go','Kill'], gp.values.tolist())
    rr = pd.read_csv(f'{W}/tables/considered_ruled_out.tsv', sep='\t')
    T['ruled'] = (['Option / claim','Verdict','Why (our data)'], rr.values.tolist())
    dq = pd.read_csv(f'{W}/tables/data_quality_log.tsv', sep='\t')
    T['dq'] = (['ID','Issue','Evidence','Handling'], dq[['ID','Issue','Evidence (from our re-analysis)','How handled / action']].values.tolist())
    return T
