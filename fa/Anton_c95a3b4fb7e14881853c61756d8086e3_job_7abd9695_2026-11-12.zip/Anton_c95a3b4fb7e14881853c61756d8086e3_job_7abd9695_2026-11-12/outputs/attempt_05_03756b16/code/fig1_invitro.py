"""Figure 1: In vitro pharmacology of AX-1177 (Compound_47) from the delivered limma-voom contrasts."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
exec(open('/tmp/work/genetable.py').read())   # L (logFC), T, P, Q wide tables; ann
SEr = pd.read_csv('/tmp/work/se_ratio.tsv', sep='\t', index_col=0).SEratio
sane = SEr < 3
plt.rcParams.update({'font.size':9, 'axes.titlesize':10, 'axes.labelsize':9})
fig = plt.figure(figsize=(17, 10.5))
gs = fig.add_gridspec(2, 3, hspace=0.38, wspace=0.62)
key = ['SELE','VCAM1','CSF2','CCL20','IL6','TNFRSF11B','PTX3','IL1RL1','NFKBIA']
for i,tp in enumerate(['6','24']):
    ax = fig.add_subplot(gs[0, i])
    x = L[f'HUVEC{tp}_IL33_vs_Veh']; y = L[f'HUVEC{tp}_C47IL33_vs_ISOIL33']; q = Q[f'HUVEC{tp}_IL33_vs_Veh']
    bg = ~((q<0.05)&(x.abs()>=1))
    ax.scatter(x[bg], y[bg], s=2, c='#cccccc', alpha=0.4, rasterized=True, label='other genes')
    s = (q<0.05)&(x.abs()>=1)
    ax.scatter(x[s&sane], y[s&sane], s=5, c='#1f77b4', alpha=0.6, rasterized=True, label='IL-33-regulated (FDR<0.05, |log2FC|>=1)')
    ax.scatter(x[s&~sane], y[s&~sane], s=7, c='#ff7f0e', alpha=0.8, rasterized=True, label='IL-33-regulated, inflated SE')
    lim = 12.5
    ax.plot([-lim,lim],[lim,-lim], 'k--', lw=0.8, label='complete reversal (y = -x)')
    ax.axhline(0,c='k',lw=0.4); ax.axvline(0,c='k',lw=0.4)
    for g in key:
        e = sym2e.get(g)
        if e is None: continue
        if abs(x[e])>=1.5:
            ax.annotate(g, (x[e], y[e]), fontsize=7, xytext=(3,3), textcoords='offset points')
    ax.set_xlim(-5, lim); ax.set_ylim(-lim, 5)
    ax.set_xlabel(f'IL-33red vs vehicle, HUVEC {tp} h (log2FC)')
    ax.set_ylabel('AX-1177 + IL-33 vs isotype + IL-33 (log2FC)')
    up = (q<0.05)&(x>=1)&sane
    res = ((x + L[f'HUVEC{tp}_C47IL33_vs_IL33'])/x)[up]
    ax.set_title(f'{"A" if tp=="6" else "B"}. HUVEC {tp} h: IL-33 effect vs AX-1177 effect', loc='left')
    blk_iso = (-y/x)[up].median(); upx = up & (ann.AveExpr>0); blk_x = (-y/x)[upx].median()
    ax.text(0.97, 0.97, f'IL-33-induced genes: n={up.sum()}\nmedian block by AX-1177\n(isotype-matched):\n{100*blk_iso:.0f}% all; {100*blk_x:.0f}% well-expressed (n={upx.sum()})\n({100*(1-res.median()):.0f}% as residual vs vehicle)', transform=ax.transAxes, ha='right', va='top', fontsize=7.5, bbox=dict(fc='white', ec='#999999', lw=0.5))
    if tp=='6': ax.legend(fontsize=6.5, loc='lower left', frameon=False)
# C: counts of meaningful DE genes
ax = fig.add_subplot(gs[0, 2])
def meaningful(c):
    return int(((Q[c]<0.05)&(L[c].abs()>=1)&(ann.AveExpr>0)&sane).sum())
rows = [('IL-33 vs vehicle, HUVEC 6 h','HUVEC6_IL33_vs_Veh','#1f77b4'),('IL-33 vs vehicle, HUVEC 24 h','HUVEC24_IL33_vs_Veh','#1f77b4'),
        ('AX-1177 neutralisation, HUVEC 6 h','HUVEC6_C47IL33_vs_ISOIL33','#2ca02c'),('AX-1177 neutralisation, HUVEC 24 h','HUVEC24_C47IL33_vs_ISOIL33','#2ca02c'),
        ('AX-1177 neutralisation, HGMEC 6 h','HGMEC6_C47IL33_vs_ISOIL33','#2ca02c'),('AX-1177 neutralisation, HGMEC 24 h','HGMEC24_C47IL33_vs_ISOIL33','#2ca02c')]
for cl in ['HUVEC','HGMEC','A549','MCF7']:
    for tp in ['6','24']:
        c = f'{cl}{tp}_C47_vs_ISO' if cl in ('HUVEC','HGMEC') else f'{cl}{tp}_C47_vs_IC119'
        rows.append((f'AX-1177 alone vs isotype, {cl} {tp} h', c, '#d62728'))
labs = [r[0] for r in rows]; vals = [meaningful(r[1]) for r in rows]; cols = [r[2] for r in rows]
yy = np.arange(len(rows))[::-1]
ax.barh(yy, vals, color=cols)
for yv, v in zip(yy, vals): ax.text(v+5, yv, str(v), va='center', fontsize=7)
ax.set_yticks(yy); ax.set_yticklabels(labs, fontsize=7)
ax.set_xlabel('n genes (FDR<0.05, |log2FC|>=1,\nAveExpr>0, non-inflated SE)')
ax.set_title('C. Robust DE genes per contrast', loc='left')
ax.set_xlim(0, max(vals)*1.18)
# D: residual fraction distributions
ax = fig.add_subplot(gs[1, 0])
data=[]; labels=[]
for tp in ['6','24']:
    x = L[f'HUVEC{tp}_IL33_vs_Veh']; q = Q[f'HUVEC{tp}_IL33_vs_Veh']
    for sgn,nm in [(1,'induced'),(-1,'repressed')]:
        s = (q<0.05)&(sgn*x>=1)&sane
        r = ((x + L[f'HUVEC{tp}_C47IL33_vs_IL33'])/x)[s].clip(-1,2)
        data.append(r.values); labels.append(f'{tp} h\n{nm}\n(n={s.sum()})')
bp = ax.boxplot(data, showfliers=False, patch_artist=True)
for patch,c in zip(bp['boxes'], ['#9ecae1','#fdae6b','#3182bd','#e6550d']): patch.set_facecolor(c)
ax.set_xticks(range(1,len(labels)+1)); ax.set_xticklabels(labels, fontsize=8)
ax.axhline(0, c='k', lw=0.6)
ax.set_ylabel('[(AX-1177+IL-33) - vehicle] / [IL-33 - vehicle]')
ax.set_title('D. Residual IL-33 effect under AX-1177 (HUVEC)', loc='left')
ax.text(0.02, 0.97, 'antibody and IL-33 added together\n(no pre-incubation)', transform=ax.transAxes, va='top', fontsize=7.5)
# E: HUVEC vs HGMEC neutralisation at 6h for HUVEC signature genes
ax = fig.add_subplot(gs[1, 1])
x6 = L['HUVEC6_C47IL33_vs_ISOIL33']; g6 = L['HGMEC6_C47IL33_vs_ISOIL33']; up6 = L['HUVEC6_IL33_vs_Veh']
sig = (up6>=1)&(x6<=-1)
ax.scatter(x6[~sig], g6[~sig], s=2, c='#cccccc', alpha=0.3, rasterized=True)
ax.scatter(x6[sig], g6[sig], s=5, c='#2ca02c', alpha=0.6, rasterized=True, label=f'HUVEC IL-33 signature (n={sig.sum()})')
for g in ['SELE','VCAM1','BIRC3','CSF2','CCL20','IL6','TNFRSF11B','ICAM1','IL1RL1']:
    e = sym2e[g]; ax.annotate(g, (x6[e], g6[e]), fontsize=7, xytext=(3,3), textcoords='offset points')
ax.plot([-13,3],[-13,3],'k--',lw=0.7)
ax.set_xlim(-13,3); ax.set_ylim(-13,3)
ax.set_xlabel('AX-1177 neutralisation effect, HUVEC 6 h (log2FC)')
ax.set_ylabel('AX-1177 neutralisation effect, HGMEC 6 h (log2FC)')
r = np.corrcoef(x6[sig], g6[sig])[0,1]
ax.set_title('E. Neutralisation effect: HGMEC vs HUVEC, 6 h', loc='left')
ax.text(0.03, 0.90, f'signature genes: r={r:.2f}\nHGMEC magnitude ~{100*np.median((g6/x6)[sig]):.0f}% of HUVEC\n(HGMEC has no vehicle arm)', transform=ax.transAxes, ha='left', va='top', fontsize=8, bbox=dict(fc='white', ec='#999999', lw=0.5))
ax.legend(fontsize=7, frameon=False, loc='upper left')
# F: kinetics of selected serum-measurable genes
ax = fig.add_subplot(gs[1, 2])
genes = ['SELE','VCAM1','CX3CL1','CCL20','CSF3','IL6','TNFRSF11B','F3','PTX3','IL1RL1','CXCL8','TNF','C3']
v6 = [L.loc[sym2e[g],'HUVEC6_IL33_vs_Veh'] for g in genes]; v24 = [L.loc[sym2e[g],'HUVEC24_IL33_vs_Veh'] for g in genes]
yy = np.arange(len(genes))[::-1]
ax.barh(yy+0.2, v6, height=0.38, color='#08519c', label='6 h')
ax.barh(yy-0.2, v24, height=0.38, color='#9ecae1', label='24 h')
labels = [g if g!='TNFRSF11B' else 'TNFRSF11B (OPG)' for g in genes]
labels = [l if l!='F3' else 'F3 (tissue factor)' for l in labels]
labels = [l if l!='IL1RL1' else 'IL1RL1 (ST2)' for l in labels]
ax.set_yticks(yy); ax.set_yticklabels(labels, fontsize=8)
ax.set_xlabel('IL-33red vs vehicle, HUVEC (log2FC)')
ax.axvline(0,c='k',lw=0.5)
ax.legend(frameon=False, fontsize=8)
ax.set_title('F. IL-33 induction, 6 h vs 24 h (HUVEC)', loc='left')
fig.suptitle('Figure 1. AX-1177 (Compound_47) neutralises reduced IL-33 signalling in endothelial cells and is inert without IL-33', fontsize=12, x=0.01, ha='left', y=0.995)
fig.savefig('/tmp/outputs/figures/Fig1_invitro_pharmacology.png', dpi=170, bbox_inches='tight')
print('ok')
