# -*- coding: utf-8 -*-
"""Regenerate every intermediate table used by the figures, workbook and memo, from the raw delivered files.
Run with the 'singlecell' env:  mm singlecell python prepare_intermediates.py
Raw inputs : /tmp/world/filesystem/*.xlsx
Work dir   : /tmp/work  (helper modules in this folder read from it)
"""
import os, sys, csv, re, warnings
import numpy as np, pandas as pd
warnings.filterwarnings('ignore')
RAW = '/tmp/world/filesystem'; W = '/tmp/work'
os.makedirs(W, exist_ok=True); os.makedirs(f'{W}/tables', exist_ok=True)
HERE = os.path.dirname(os.path.abspath(__file__))
for f in ['load.py','wide.py','genetable.py','olink_map.py','bridge.py','pm.py','pm_curated.py']:
    # helper modules are expected in the work dir (they use absolute /tmp/work paths)
    src = os.path.join(HERE, f)
    if os.path.abspath(src) != os.path.abspath(os.path.join(W, f)):
        open(os.path.join(W, f), 'w').write(open(src).read())
sys.path.insert(0, W)

# ---------- 1. RNA-seq: xlsx -> tsv -> parquet ----------
import openpyxl
def dump(xlsx, prefix):
    wb = openpyxl.load_workbook(xlsx, read_only=True)
    for ws in wb.worksheets:
        out = f'{W}/{prefix}{ws.title}.tsv'
        if os.path.exists(out): continue
        with open(out, 'w', newline='') as fh:
            w = csv.writer(fh, delimiter='\t')
            for row in ws.iter_rows(values_only=True):
                w.writerow(['' if v is None else v for v in row])
dump(f'{RAW}/AX-1177_rnaseq_contrasts.xlsx', 'contrasts_')
dump(f'{RAW}/AX-1177_rnaseq_huvec_il33.xlsx', 'huvec_')
from load import load_all
a, b, h6, h24 = load_all()
m = a.merge(b, on=['Comparison','ensembl'], suffixes=('_a','_b'))
assert (m.logFC_a == m.logFC_b).all(), 'the two contrast sheets differ'
pd.concat([a, h6, h24]).to_parquet(f'{W}/all_contrasts.parquet')
print('RNA-seq: sheets identical =', True, '; contrasts =', pd.concat([a,h6,h24]).Comparison.nunique())

# ---------- 2. SE inflation ----------
exec(open(f'{W}/genetable.py').read())
SE = (L/T).abs(); medSE = SE.median(axis=1)
order = ann.AveExpr.sort_values().index
exp = medSE.loc[order].rolling(501, center=True, min_periods=50).median()
ann['SEratio'] = medSE/exp.reindex(medSE.index)
ann[['symbol','AveExpr','SEratio']].to_csv(f'{W}/se_ratio.tsv', sep='\t')
SEr = ann.SEratio
print('SE inflation >3x:', int((SEr>3).sum()), ' >100x:', int((SEr>100).sum()))

# ---------- 3. RNA-seq wide table, core signature, contrast summary ----------
d = pd.DataFrame({'symbol':ann.symbol,'gene_name':ann.gene_name,'AveExpr_all114':ann.AveExpr,'SE_inflation':SEr,
  'HUVEC6_IL33_vs_Veh':L['HUVEC6_IL33_vs_Veh'],'q_HUVEC6_IL33':Q['HUVEC6_IL33_vs_Veh'],
  'HUVEC6_AX1177neut':L['HUVEC6_C47IL33_vs_ISOIL33'],'q_HUVEC6_neut':Q['HUVEC6_C47IL33_vs_ISOIL33'],
  'HUVEC24_IL33_vs_Veh':L['HUVEC24_IL33_vs_Veh'],'HUVEC24_AX1177neut':L['HUVEC24_C47IL33_vs_ISOIL33'],
  'HGMEC6_AX1177neut':L['HGMEC6_C47IL33_vs_ISOIL33'],'q_HGMEC6_neut':Q['HGMEC6_C47IL33_vs_ISOIL33'],'HGMEC24_AX1177neut':L['HGMEC24_C47IL33_vs_ISOIL33'],
  'HUVEC6_AX1177alone':L['HUVEC6_C47_vs_ISO'],'HUVEC24_AX1177alone':L['HUVEC24_C47_vs_ISO'],'HGMEC6_AX1177alone':L['HGMEC6_C47_vs_ISO']})
d['resid6_frac'] = (L['HUVEC6_IL33_vs_Veh'] + L['HUVEC6_C47IL33_vs_IL33'])/L['HUVEC6_IL33_vs_Veh']
d['resid24_frac'] = (L['HUVEC24_IL33_vs_Veh'] + L['HUVEC24_C47IL33_vs_IL33'])/L['HUVEC24_IL33_vs_Veh']
d.to_csv(f'{W}/rnaseq_il33_wide.tsv', sep='\t')
core = d[(d.HUVEC6_IL33_vs_Veh>=2)&(d.HUVEC6_AX1177neut<=-2)&(d.HGMEC6_AX1177neut<=-1)&(d.HUVEC24_IL33_vs_Veh>=1)&(d.HUVEC24_AX1177neut<=-1)
         &(d.symbol.notna())&(~d.symbol.fillna('').str.match(r'^(AC|AL|AP|LINC|MIR|RNU|SNOR|Z)\d'))&(~d.symbol.fillna('').str.contains(r'^LINC|\.'))]
core.sort_values('HUVEC6_IL33_vs_Veh', ascending=False).to_csv(f'{W}/il33_core_signature.tsv', sep='\t')
rows=[]
for c in sorted(L.columns):
    q=Q[c]; l=L[c]
    rows.append(dict(contrast=c, FDR_lt_0_05=int((q<0.05).sum()), up=int(((q<0.05)&(l>0)).sum()), down=int(((q<0.05)&(l<0)).sum()),
        FDR_and_absLFC_ge1=int(((q<0.05)&(l.abs()>=1)).sum()), FDR_but_absLFC_lt0_2=int(((q<0.05)&(l.abs()<0.2)).sum()),
        robust=int(((q<0.05)&(l.abs()>=1)&(ann.AveExpr>0)&(SEr<3)).sum())))
desc = {'IL33_vs_Veh':'IL-33red vs vehicle','C47IL33_vs_ISOIL33':'AX-1177+IL-33 vs isotype+IL-33 (neutralisation, isotype-matched)','C47IL33_vs_IL33':'AX-1177+IL-33 vs IL-33 alone',
        'C47_vs_ISO':'AX-1177 vs isotype (no IL-33)','C47_vs_IC119':'AX-1177 vs isotype (no IL-33)','C47_vs_DMSO':'AX-1177 vs DMSO','C47_vs_PBS':'AX-1177 vs PBS'}
cs = pd.DataFrame(rows)
cs['description'] = cs.contrast.map(lambda c: next((v for k,v in desc.items() if c.endswith(k)), ''))
cs.to_csv(f'{W}/rnaseq_contrast_summary.tsv', sep='\t', index=False)
for tp in ['6','24']:
    x = L[f'HUVEC{tp}_IL33_vs_Veh']; qq = Q[f'HUVEC{tp}_IL33_vs_Veh']; B = L[f'HUVEC{tp}_C47IL33_vs_ISOIL33']; A = L[f'HUVEC{tp}_C47IL33_vs_IL33']
    s = (qq<0.05)&(x>=1)&(SEr<3); sx = s&(ann.AveExpr>0)
    print(f'HUVEC {tp}h: induced n={s.sum()} block iso-matched median {100*(-B/x)[s].median():.0f}% (well-expressed n={sx.sum()}: {100*(-B/x)[sx].median():.0f}%); residual-vs-vehicle block {100*(1-((x+A)/x)[s].median()):.0f}%')
print('core signature genes:', len(core))

# ---------- 4. Serum proteomics bridge ----------
exec(open(f'{W}/bridge.py').read())
o.to_csv(f'{W}/olink_assay_level_bridge.tsv', sep='\t', index=False)
og = o.sort_values('p.value').drop_duplicates('gene').copy()
og['sig_fdr'] = og['adj.p.value']<0.05; og['sig_nom'] = og['p.value']<0.05
og.to_csv(f'{W}/olink_gene_level_bridge.tsv', sep='\t', index=False)
from scipy import stats
ia = og[og.il33_class=='IL-33-induced, AX-1177-reversed']; ib = og[og.il33_class=='no concordant IL-33 effect']
print(f"serum: unique proteins {len(og)}; IL-33-inducible {len(ia)} FDR frac {(ia['adj.p.value']<0.05).mean():.3f} vs {(ib['adj.p.value']<0.05).mean():.3f}; MW p={stats.mannwhitneyu(ia.z, ib.z).pvalue:.2f}")
ratio = (o['adj.p.value']/stats.false_discovery_control(o['p.value'])).iloc[0]
print(f'serum: implied BH m = {1094*ratio:.0f}')

# ---------- 5. Post-mortem ----------
from pm import load_pm
from pm_curated import CURATED
import statsmodels.formula.api as smf
df = load_pm()
df['path_pneu'] = df.Donor.map(lambda k: CURATED[k][0]); df['pattern'] = df.Donor.map(lambda k: CURATED[k][1])
df['covid'] = df.Category.str.contains('COVID pos')
df['pclass'] = np.where(df.covid & df.path_pneu, 'A: COVID+ & acute pneumonia', np.where(~df.covid & df.path_pneu, 'B: COVID- & acute pneumonia/infection', 'C: no acute pneumonia on pathology'))
df.to_csv(f'{W}/pm_blocks_curated.tsv', sep='\t', index=False)
vars_ = ['IL33_epi','IL33_endo','IL33_VSM','EPX_s','EDN_s','MBP_s','BASO_2D7_s','IL5Ra_dNE_s','NE_s','IL5Ra_dTrypt_s','Tryptase_s','HE_eos_Y']
nice = {'IL33_epi':'IL-33 basal epithelium','IL33_endo':'IL-33 endothelium','IL33_VSM':'IL-33 vascular smooth muscle','EPX_s':'EPX (eosinophil)','EDN_s':'EDN (eosinophil)','MBP_s':'MBP (eosinophil)','BASO_2D7_s':'2D7 (basophil)','IL5Ra_dNE_s':'IL-5Ra (duplex w NE)','NE_s':'Neutrophil elastase','IL5Ra_dTrypt_s':'IL-5Ra (duplex w tryptase)','Tryptase_s':'Tryptase (mast cell)','HE_eos_Y':'H&E eosinophils apparent (fraction of blocks)'}
don = df.groupby('Donor').agg({**{v:'mean' for v in vars_}, 'group':'first','pclass':'first','pattern':'first','Age':'first','Sex':'first','SARS':'first','Notes_donor':'first','Block':'size'}).rename(columns={'Block':'n_blocks'})
don['tissue_RNA_id'] = df[df.TissueRNA.notna()].groupby('Donor').TissueRNA.first()
don['pathology_summary'] = [CURATED[k][2] for k in don.index]
don['label_concordant_with_pathology'] = [('yes' if ((g!='COVID- non-pneumonia') == CURATED[k][0]) else 'NO') for k,g in zip(don.index, don.group)]
don.to_csv(f'{W}/pm_donor_table.tsv', sep='\t')
don.to_csv(f'{W}/pm_donor_curated2.tsv', sep='\t')
orig = ['COVID+ pneumonia','COVID- pneumonia','COVID- non-pneumonia']; ver = sorted(don.pclass.unique())
rows=[]
for v in vars_:
    g = [don.loc[don.group==k, v].dropna() for k in orig]; gv = [don.loc[don.pclass==k, v].dropna() for k in ver]; gb = [df.loc[df.group==k, v].dropna() for k in orig]
    r = dict(variable=nice[v])
    for k,x_ in zip(orig,g): r[f'{k} median (donors)'] = round(x_.median(),2)
    r['KW p, original labels (donor)'] = stats.kruskal(*g).pvalue
    r['COVID+ vs COVID- pneumonia p (donor)'] = stats.mannwhitneyu(g[0],g[1]).pvalue
    r['pneumonia vs non-pneumonia p (donor)'] = stats.mannwhitneyu(pd.concat([g[0],g[1]]), g[2]).pvalue
    r['pneumonia vs non-pneumonia p (BLOCK, pseudo-replicated)'] = stats.mannwhitneyu(pd.concat([gb[0],gb[1]]), gb[2]).pvalue
    for k,x_ in zip(ver,gv): r[f'{k} median'] = round(x_.median(),2)
    r['KW p, pathology-verified (donor)'] = stats.kruskal(*gv).pvalue
    r['COVID+ acute pneu vs no pneu p (donor)'] = stats.mannwhitneyu(gv[0],gv[2]).pvalue
    r['COVID+ vs COVID- acute pneu p (donor)'] = stats.mannwhitneyu(gv[0],gv[1]).pvalue
    xx = df[['Donor','pclass',v]].dropna().rename(columns={v:'y'}); xx['pcl'] = xx.pclass.str[0]
    mm_ = smf.mixedlm('y ~ C(pcl, Treatment("C"))', xx, groups=xx['Donor']).fit(reml=True)
    r['mixed model (block, donor RE): COVID+ acute pneu vs no pneu, est'] = round(mm_.params['C(pcl, Treatment("C"))[T.A]'],2)
    r['mixed model p'] = mm_.pvalues['C(pcl, Treatment("C"))[T.A]']
    rows.append(r)
pd.DataFrame(rows).to_csv(f'{W}/pm_stats_table.tsv', sep='\t', index=False)
cor=[]
for a_ in ['IL33_epi','IL33_endo','IL33_VSM']:
    for b_ in ['EPX_s','EDN_s','MBP_s','NE_s','IL5Ra_dNE_s','Tryptase_s']:
        y = don[[a_,b_]].dropna(); rr_,pp_ = stats.spearmanr(y[a_],y[b_]); cor.append(dict(a=nice[a_], b=nice[b_], rho=round(rr_,2), p=pp_, n=len(y)))
for a_,b_ in [('IL5Ra_dNE_s','NE_s'),('IL5Ra_dNE_s','EPX_s'),('IL5Ra_dNE_s','EDN_s'),('IL5Ra_dNE_s','MBP_s'),('IL5Ra_dNE_s','IL5Ra_dTrypt_s'),('EPX_s','EDN_s')]:
    y = don[[a_,b_]].dropna(); rr_,pp_ = stats.spearmanr(y[a_],y[b_]); cor.append(dict(a=nice[a_], b=nice[b_], rho=round(rr_,2), p=pp_, n=len(y)))
pd.DataFrame(cor).to_csv(f'{W}/pm_correlations.tsv', sep='\t', index=False)
print('post-mortem: donors', len(don), 'blocks', len(df), 'label-discordant', int((don.label_concordant_with_pathology=='NO').sum()))
print('done')
