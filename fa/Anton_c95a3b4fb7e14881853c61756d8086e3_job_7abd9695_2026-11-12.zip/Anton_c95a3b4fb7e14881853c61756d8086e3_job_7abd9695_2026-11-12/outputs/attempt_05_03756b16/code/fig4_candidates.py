"""Figure 4 + Table: candidate biomarkers bridging in vitro IL-33/AX-1177 pharmacology to patient serum."""
import pandas as pd, numpy as np, matplotlib, warnings
matplotlib.use('Agg'); warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
o = pd.read_csv('/tmp/work/olink_assay_level_bridge.tsv', sep='\t')
med = o.groupby('panel_s').z.transform('median'); mad = o.groupby('panel_s').z.transform(lambda s: 1.4826*np.median(np.abs(s-np.median(s))))
o['z_shift'] = (o.z-med)/mad
o['rank_shift'] = o.z_shift.rank(ascending=False).astype(int)
wide = pd.read_csv('/tmp/work/rnaseq_il33_wide.tsv', sep='\t', index_col=0)
cands = [
 ('sST2','ST2','IL1RL1','Baseline prognostic ENRICHMENT / stratification','Yes - clinical immunoassays exist'),
 ('PTX3','PTX3','PTX3','Prognostic covariate; exploratory PD','Yes'),
 ('OPG','OPG-INFI','TNFRSF11B','Exploratory PD (sustained IL-33 response) + prognostic','Yes'),
 ('IL-6','IL6','IL6','Prognostic covariate only (non-specific; SoC-confounded)','Yes'),
 ('CCL20','CCL20','CCL20','Exploratory PD','Yes'),
 ('CCL7 (MCP-3)','MCP-3','CCL7','Exploratory PD','Yes'),
 ('CXCL8 (IL-8)','IL8','CXCL8','Exploratory PD (non-specific)','Yes'),
 ('Tissue factor','TF','F3','Exploratory PD (immunothrombosis)','Yes'),
 ('CCL2 (MCP-1)','MCP-1-INFI','CCL2','Exploratory PD (non-specific)','Yes'),
 ('E-selectin','SELE','SELE','Lead endothelium-restricted PD marker','Yes'),
 ('PAI-1','PAI','SERPINE1','Exploratory PD (fibrinolysis)','Yes'),
 ('CX3CL1','CX3CL1','CX3CL1','Exploratory PD','Yes'),
 ('ICAM-1','ICAM1','ICAM1','Mechanistic PD only','Yes'),
 ('VCAM-1','VCAM1','VCAM1','Mechanistic PD only (not prognostic)','Yes'),
 ('G-CSF','G-CSF','CSF3','Mechanistic PD only (not prognostic)','Yes'),
 ('IL-18R1','IL-18R1','IL18R1','Not recommended (leukocyte-derived in serum)','Yes'),
 ('HGF','HGF','HGF','Global-injury COVARIATE (not IL-33-driven)','Yes'),
 ('GDF-15','GDF-15','GDF15','Global-injury COVARIATE','Yes'),
 ('vWF','vWF','VWF','Endothelial-injury COVARIATE (not IL-33-driven)','Yes'),
 ('CLEC5A','CLEC5A','CLEC5A','Neutrophil-activation COVARIATE','Yes'),
]
rows=[]
for lab, assay, gene, role, pt in cands:
    r = o[o.assay==assay].iloc[0]
    e = r.ensembl
    w = wide.loc[e] if isinstance(e,str) and e in wide.index else None
    rows.append(dict(marker=lab, olink_assay=assay, panel=r.panel_s, gene=gene,
        OR_per_log_unit=round(r.OR,2), CI95=f'{r.l95:.2f}-{r.u95:.2f}', p=r['p.value'], adj_p=r['adj.p.value'], rank_of_1094=int(r['rank']), z=round(r.z,2), shift_adj_rank=int(r.rank_shift),
        n_panels=int((o.gene==gene).sum()),
        HUVEC_IL33_6h=None if w is None else round(w.HUVEC6_IL33_vs_Veh,2), HUVEC_AX1177_6h=None if w is None else round(w.HUVEC6_AX1177neut,2),
        HUVEC_IL33_24h=None if w is None else round(w.HUVEC24_IL33_vs_Veh,2), HUVEC_AX1177_24h=None if w is None else round(w.HUVEC24_AX1177neut,2),
        HGMEC_AX1177_6h=None if w is None else round(w.HGMEC6_AX1177neut,2), RNAseq_SE_inflation=None if w is None else round(w.SE_inflation,1),
        il33_class=r.il33_class, proposed_role=role, usable_in_patients=pt))
t = pd.DataFrame(rows)
t.to_csv('/tmp/work/candidate_biomarkers.tsv', sep='\t', index=False)
pd.set_option('display.width',300); pd.set_option('display.max_columns',40)
print(t.drop(columns=['proposed_role','usable_in_patients']).to_string(index=False))
# Heatmap
cols = ['HUVEC_IL33_6h','HUVEC_AX1177_6h','HUVEC_IL33_24h','HUVEC_AX1177_24h','HGMEC_AX1177_6h']
M = t.set_index('marker')[cols].astype(float)
fig = plt.figure(figsize=(15.5, 8.8))
gs = fig.add_gridspec(1, 3, width_ratios=[5, 1.6, 6.2], wspace=0.08)
ax = fig.add_subplot(gs[0,0])
im = ax.imshow(M.values, cmap='RdBu_r', vmin=-10, vmax=10, aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        v = M.values[i,j]; ax.text(j, i, f'{v:+.1f}', ha='center', va='center', fontsize=7.5, color='white' if abs(v)>6 else 'black')
ax.set_xticks(range(len(cols))); ax.set_xticklabels(['IL-33 vs\nvehicle\nHUVEC 6 h','AX-1177\nneutralisation\nHUVEC 6 h','IL-33 vs\nvehicle\nHUVEC 24 h','AX-1177\nneutralisation\nHUVEC 24 h','AX-1177\nneutralisation\nHGMEC 6 h'], fontsize=7.5)
ax.set_yticks(range(M.shape[0])); ax.set_yticklabels([f'{m} \u2020' if (f is not None and f>3) else m for m,f in zip(M.index, t.RNAseq_SE_inflation)], fontsize=8.5)
ax.xaxis.tick_top()
pos = ax.get_position()
cax = fig.add_axes([pos.x0, pos.y0-0.06, pos.width, 0.018])
cb = fig.colorbar(im, cax=cax, orientation='horizontal'); cb.set_label('log2 fold change (in vitro)', fontsize=8)
ax.set_title('In vitro (delivered contrasts)', fontsize=10, loc='left', pad=48)
ax2 = fig.add_subplot(gs[0,1], sharey=ax)
z = t.z.values
ax2.barh(range(len(z)), z, color=['#2ca02c' if c.startswith('IL-33-induced') else '#9e9e9e' for c in t.il33_class])
ax2.axvline(2.67, c='r', ls='--', lw=0.8); ax2.axvline(o.z.median(), c='k', ls=':', lw=0.8)
ax2.set_xlim(0,5); ax2.set_xlabel('serum z\n(composite endpoint)', fontsize=8)
plt.setp(ax2.get_yticklabels(), visible=False)
ax2.set_title('Patients', fontsize=10, loc='left', pad=48)
ax3 = fig.add_subplot(gs[0,2]); ax3.axis('off')
ax3.set_ylim(M.shape[0]-0.5, -0.5)
for i,r in t.iterrows():
    ax3.text(0.0, i, f"rank {r.rank_of_1094} (shift-adj {r.shift_adj_rank}); x{r.n_panels} panel{'s' if r.n_panels>1 else ''}", va='center', fontsize=7.3, color='#555555')
    ax3.text(0.42, i, r.proposed_role, va='center', fontsize=7.6, fontweight='bold' if ('ENRICH' in r.proposed_role or 'Lead' in r.proposed_role) else 'normal')
ax3.text(0.0, -0.9, 'serum ranking (of 1,094 assays)', fontsize=8.5, fontweight='bold'); ax3.text(0.42, -0.9, 'proposed role in patients', fontsize=8.5, fontweight='bold')
fig.suptitle('Figure 4. Candidate biomarkers: in vitro IL-33 inducibility / AX-1177 reversibility vs prognostic value in patient serum', fontsize=11.5, x=0.01, ha='left', y=1.04)
fig.text(0.01, -0.035, '\u2020 gene-wide SE inflated >3x in the delivered pooled model (FDR uninformative; effect replicated across independent sample groups). Red dashed line: FDR 5% threshold; dotted: median z of all assays.', fontsize=7.5)
fig.savefig('/tmp/outputs/figures/Fig4_candidate_biomarkers.png', dpi=170, bbox_inches='tight')
print('ok')
