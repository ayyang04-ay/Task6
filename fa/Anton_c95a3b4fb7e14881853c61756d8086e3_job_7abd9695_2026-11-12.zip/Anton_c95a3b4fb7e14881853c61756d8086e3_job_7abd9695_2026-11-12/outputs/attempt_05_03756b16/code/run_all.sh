#!/bin/bash
# Reproduce all intermediates, figures, the workbook and the memo from the raw delivered files.
# Requires the micromamba envs 'singlecell' (analysis/figures) and 'chem' (xlsx + PDF), via the `mm` wrapper.
set -euo pipefail
cd "$(dirname "$0")"
mm singlecell python prepare_intermediates.py     # raw xlsx -> /tmp/work intermediates (RNA-seq parse ~3 min)
mm singlecell python dq_log.py                    # data-quality log, gated plan, ruled-out table
mm singlecell python fig1_invitro.py
mm singlecell python fig2_tissue.py
mm singlecell python fig3_serum.py
mm singlecell python fig4_candidates.py           # also writes /tmp/work/candidate_biomarkers.tsv
mm singlecell python figS1_rnaseq_qc.py
mm chem python build_workbook.py
mm chem python render_memo.py
echo "all outputs regenerated"
