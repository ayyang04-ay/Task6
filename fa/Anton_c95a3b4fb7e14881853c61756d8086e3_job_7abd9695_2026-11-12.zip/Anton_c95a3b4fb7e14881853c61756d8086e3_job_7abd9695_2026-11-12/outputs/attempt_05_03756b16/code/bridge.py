import sys; sys.path.insert(0,'/tmp/work')
exec(open('/tmp/work/genetable.py').read())
from olink_map import *
import numpy as np, pandas as pd
o = load_olink()
# z statistic from CI (scale-free)
o['logOR'] = np.log(o.OR); o['se'] = (np.log(o.u95)-np.log(o.l95))/(2*1.959964)
o['z'] = o.logOR/o.se
# map to rnaseq
sym2e_all = ann.reset_index().drop_duplicates('symbol').set_index('symbol')['ensembl']
def find_e(r):
    for cand in [r.gene, r.base]:
        if cand in sym2e_all.index: return sym2e_all[cand]
    return None
o['ensembl'] = o.apply(find_e, axis=1)
cols = {'HUVEC6_IL33_vs_Veh':'up6','HUVEC6_C47IL33_vs_ISOIL33':'neut6','HUVEC24_IL33_vs_Veh':'up24','HUVEC24_C47IL33_vs_ISOIL33':'neut24',
        'HGMEC6_C47IL33_vs_ISOIL33':'hg6','HGMEC24_C47IL33_vs_ISOIL33':'hg24','HUVEC6_C47_vs_ISO':'c47_6','HUVEC24_C47_vs_ISO':'c47_24'}
for c,n in cols.items():
    o[n] = o.ensembl.map(L[c])
    o['q_'+n] = o.ensembl.map(Q[c])
o['AveExpr'] = o.ensembl.map(ann.AveExpr)
o['SEratio'] = o.ensembl.map((L/T).abs().median(axis=1) / (L/T).abs().median(axis=1).loc[ann.AveExpr.sort_values().index].rolling(501,center=True,min_periods=50).median().reindex(L.index))
def il33_class(r, thr=1.0):
    if pd.isna(r.ensembl): return 'not in RNA-seq (not expressed/filtered)'
    i6 = (r.up6>=thr) and (r.neut6<=-thr); i24 = (r.up24>=thr) and (r.neut24<=-thr)
    d6 = (r.up6<=-thr) and (r.neut6>=thr); d24 = (r.up24<=-thr) and (r.neut24>=thr)
    if i6 or i24: return 'IL-33-induced, AX-1177-reversed'
    if d6 or d24: return 'IL-33-repressed, AX-1177-restored'
    return 'no concordant IL-33 effect'
o['il33_class'] = o.apply(il33_class, axis=1)
