import pandas as pd, numpy as np, re
def parse_score(v):
    if v is None or (isinstance(v,float) and np.isnan(v)): return np.nan
    s = str(v).strip()
    if s.upper() in ('ND',''): return np.nan
    m = re.match(r'^(\d+(\.\d+)?)\+?$', s)
    if m: return float(m.group(1))
    return np.nan
def load_pm(path='/tmp/world/filesystem/AX-1177_postmortem_lung.xlsx'):
    df = pd.read_excel(path)
    short = ['SampleID','Block','TissueRNA','DonorNum','Lobe','Category','Race','Sex','Age','SARS','Pathology','HE_eos','EPX','EDN','MBP','BASO_2D7','IL5Ra_dNE','NE','IL5Ra_dTrypt','Tryptase','EPX_num','NE_num','Trypt_num','IL33_epi','IL33_endo','IL33_VSM','Notes']
    df.columns = short
    df = df[df.Block.notna()].copy()
    df['Donor'] = df.SampleID.astype(int)
    for c in ['Category','Race','Sex','Age','SARS','Pathology']:
        df[c] = df.groupby('Donor')[c].transform(lambda s: s.ffill().bfill())
    for c in ['EPX','EDN','MBP','BASO_2D7','IL5Ra_dNE','NE','IL5Ra_dTrypt','Tryptase']:
        df[c+'_s'] = df[c].map(parse_score)
    for c in ['EPX_num','NE_num','Trypt_num']:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    df['Notes_donor'] = df.groupby('Donor').Notes.transform(lambda s: ', '.join(sorted(set(x.strip() for v in s.dropna() for x in str(v).split(',')))))
    df['group'] = df.Category.map({'COVID pos pneumonia':'COVID+ pneumonia','COVID neg pneumonia':'COVID- pneumonia','COVID neg non-pneumonia':'COVID- non-pneumonia'})
    df['HE_eos_Y'] = (df.HE_eos.astype(str).str.strip().str.upper()=='Y').astype(float)
    return df
