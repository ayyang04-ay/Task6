import pandas as pd, numpy as np
def load_all():
    a = pd.read_csv('/tmp/work/contrasts_6h.tsv', sep='\t', low_memory=False)
    a = a[a.Comparison.notna() & (a.Comparison!='')]
    b = pd.read_csv('/tmp/work/contrasts_24h.tsv', sep='\t', low_memory=False)
    h6 = pd.read_csv('/tmp/work/huvec_IL33_vs_Vehicle_HUVEC_6_hrs.tsv', sep='\t')
    h24 = pd.read_csv('/tmp/work/huvec_IL33_vs_Vehicle_HUVEC_24_hrs.tsv', sep='\t')
    return a,b,h6,h24
