"""Serum proteomics: protein-level collapse, global shift, IL-33 pathway assays, bridge test vs in vitro IL-33 program, candidate biomarker table."""
import pandas as pd, numpy as np
from scipy import stats
CACHE='/tmp/work'; OUT='/tmp/outputs/tables'
p = pd.read_pickle(f'{CACHE}/prot.pkl'); W, ann = pd.read_pickle(f'{CACHE}/wide.pkl'); L, Q, SE = W['logFC'], W['adj.P.Val'], W['SE']
a = pd.read_pickle(f'{CACHE}/sig_annot.pkl')
print('assays', len(p), '| unique proteins', p.base.nunique(), '| OR>1: %.1f%%' % (100*(p.OR>1).mean()), '| p<0.05: %d (%.0f expected) of which OR>1: %.1f%%' % ((p['p.value']<0.05).sum(), 0.05*len(p), 100*(p.loc[p['p.value']<0.05,'OR']>1).mean()))
print('delivered q<0.05: %d assays / %d unique proteins' % ((p['adj.p.value']<0.05).sum(), p.loc[p['adj.p.value']<0.05,'base'].nunique()))
prot = p.groupby('base').agg(n_assays=('assay','size'), assays=('assay', lambda s: ', '.join(s)), panels=('panel_short', lambda s: ', '.join(s)),
                             mean_z=('z','mean'), best_p=('p.value','min'), best_q=('adj.p.value','min'), sym=('sym','first'), in_rnaseq=('in_rnaseq','first'))
prot['rank_by_z'] = prot.mean_z.rank(ascending=False).astype(int)
sig_sym = a.groupby('symbol')[['SIG_UP_HUVEC','SIG_DN_HUVEC','SIG_UP_HGMEC','SIG_UP_BOTH']].any()
prot = prot.join(sig_sym, on='sym')
for c in ['SIG_UP_HUVEC','SIG_DN_HUVEC','SIG_UP_HGMEC','SIG_UP_BOTH']: prot[c] = prot[c].fillna(False).astype(bool)
prot.sort_values('rank_by_z').to_csv(f'{OUT}/serum_protein_level_dedup.csv')
print('median protein z %.2f; sST2 z %.2f rank %d/%d' % (prot.mean_z.median(), prot.loc['ST2','mean_z'], prot.loc['ST2','rank_by_z'], len(prot)))
# bridge test (universe = proteins whose gene is in the RNA-seq universe)
u = prot[prot.in_rnaseq.astype(bool)]
rows=[]
for s in ['SIG_UP_HUVEC','SIG_UP_HGMEC','SIG_UP_BOTH','SIG_DN_HUVEC']:
    x = u.loc[u[s],'mean_z']; y = u.loc[~u[s],'mean_z']
    rows.append(dict(signature=s, n_in_serum=len(x), median_z_signature=round(x.median(),2), median_z_other=round(y.median(),2), MWU_p=stats.mannwhitneyu(x,y).pvalue,
                     frac_z_gt_1p96_signature=round((x>1.96).mean(),2), frac_z_gt_1p96_other=round((y>1.96).mean(),2)))
bt = pd.DataFrame(rows); bt.to_csv(f'{OUT}/serum_bridge_enrichment_test.csv', index=False); print(bt.to_string())
b = u[['mean_z','best_p','assays','SIG_UP_HUVEC','SIG_DN_HUVEC','SIG_UP_HGMEC','SIG_UP_BOTH']].rename(columns={'mean_z':'z'}); b.to_pickle(f'{CACHE}/bridge.pkl')
# IL-33 pathway / type-2 / endothelial assays
sel = ['ST2','IL-1RT1','IL-1RT2','IL-1ra','IL1RL2','IL-18R1','IL18','IL-18BP','IL5','IL-5R-alpha','CCL11','CCL24','IL-4RA','IL13RA1','PTX3','vWF','ANGPT2','FLT1','SELE','ICAM1','VCAM1','TM','PAI','U-PAR','HGF','IL6']
p[p.base.isin(sel)].sort_values('p.value')[['assay','panel_short','OR','l95','u95','p.value','adj.p.value','composite_endpoint_0','composite_endpoint_1']].to_csv(f'{OUT}/serum_selected_axes.csv', index=False)
# candidate biomarker table
sym2ens = ann.reset_index().drop_duplicates('symbol').set_index('symbol').ensembl
def fmt(e, c):
    if e is None or pd.isna(e): return 'n/a'
    q = Q.loc[e,c]; star = '***' if q<0.001 else ('**' if q<0.01 else ('*' if q<0.05 else ' ns'))
    return f'{L.loc[e,c]:+.1f}{star}' + (' [SE>2: unreliable]' if SE.loc[e,c]>2 else '')
cands = [('sST2','IL1RL1',['ST2']),('IL-6','IL6',['IL6','IL6-ONCII','IL6-CVDII','IL6-IMO']),('CCL20','CCL20',['CCL20']),('MCP-3 (CCL7)','CCL7',['MCP-3']),
 ('OPG (TNFRSF11B)','TNFRSF11B',['OPG-INFI','OPG-CVDIII']),('IL-18R1','IL18R1',['IL-18R1']),('CSF-1 (M-CSF)','CSF1',['CSF-1']),('IL-1beta','IL1B',['IL1B']),
 ('uPA (PLAU)','PLAU',['uPA-INFI','uPA-CVDIII']),('IL-15','IL15',['IL15']),('PAI-1 (SERPINE1)','SERPINE1',['PAI']),('CX3CL1','CX3CL1',['CX3CL1']),('G-CSF (CSF3)','CSF3',['G-CSF']),
 ('CXCL10','CXCL10',['CXCL10']),('CXCL5','CXCL5',['CXCL5']),('CXCL6','CXCL6',['CXCL6']),('TNF','TNF',['TNF']),('MMP-10','MMP10',['MMP-10']),('ICAM-1','ICAM1',['ICAM1']),
 ('Thrombomodulin','THBD',['TM']),('Tissue factor (F3)','F3',[]),('GM-CSF (CSF2)','CSF2',[]),
 ('PTX3','PTX3',['PTX3']),('E-selectin','SELE',['SELE']),('VCAM-1','VCAM1',['VCAM1']),('IL-8 (CXCL8)','CXCL8',['IL8']),('MCP-1 (CCL2)','CCL2',['MCP-1-INFI','MCP-1-CVDIII']),
 ('HGF','HGF',['HGF','HGF-ONCII']),('vWF','VWF',['vWF']),('ANGPT2','ANGPT2',['ANGPT2'])]
rows=[]
for name, sym, assays in cands:
    e = sym2ens.get(sym)
    r = dict(marker=name, gene=sym)
    for c,lab in [('IL33vVeh_HUVEC_6','IL-33 vs veh HUVEC 6h'),('IL33vVeh_HUVEC_24','IL-33 vs veh HUVEC 24h'),('NeutIso_HUVEC_6','AX-1177 effect HUVEC 6h'),('NeutIso_HUVEC_24','AX-1177 effect HUVEC 24h'),('NeutIso_HGMEC_6','AX-1177 effect HGMEC 6h'),('NeutIso_HGMEC_24','AX-1177 effect HGMEC 24h')]:
        r[lab] = fmt(e, c)
    s = p[p.assay.isin(assays)]
    if len(s):
        bb = s.sort_values('p.value').iloc[0]
        r.update({'serum OR per log unit (95% CI), best assay': f"{bb.OR:.2f} ({bb.l95:.2f}-{bb.u95:.2f})", 'serum p': f"{bb['p.value']:.1e}", 'serum q (as delivered)': round(bb['adj.p.value'],3), 'n assays (panels)': len(s)})
    else: r['serum OR per log unit (95% CI), best assay'] = 'not in delivered panel'
    rows.append(r)
pd.DataFrame(rows).to_csv(f'{OUT}/biomarker_candidates_evidence.csv', index=False)
print(pd.DataFrame(rows)[['marker','IL-33 vs veh HUVEC 6h','AX-1177 effect HGMEC 6h','serum q (as delivered)']].to_string())
