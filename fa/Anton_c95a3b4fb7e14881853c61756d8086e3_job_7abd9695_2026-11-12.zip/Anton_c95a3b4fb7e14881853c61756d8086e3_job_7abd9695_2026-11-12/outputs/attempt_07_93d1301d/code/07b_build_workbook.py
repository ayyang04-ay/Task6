import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
T = '/tmp/outputs/tables'; OUT = '/tmp/outputs/AX-1177_supporting_tables.xlsx'
roles = {
 'sST2':'Prognostic enrichment / stratification at enrolment (pre-dose). Not PD; predictive value to be tested as a pre-specified interaction.',
 'IL-6':'7-plex IL-33 endothelial response panel: exploratory PD (pre-dose, 6h, 24h, D3, D7); prognostic covariate. Not for selection.',
 'CCL20':'7-plex PD panel (exploratory PD).','MCP-3 (CCL7)':'7-plex PD panel (exploratory PD).','OPG (TNFRSF11B)':'7-plex PD panel (exploratory PD).',
 'IL-18R1':'7-plex PD panel (exploratory PD).','CSF-1 (M-CSF)':'7-plex PD panel (exploratory PD).','IL-1beta':'7-plex PD panel (exploratory PD).',
 'uPA (PLAU)':'Procoagulant/fibrinolytic PD module (exploratory).','PAI-1 (SERPINE1)':'Procoagulant PD module (exploratory); plasma.',
 'Thrombomodulin':'Procoagulant PD module (exploratory; IL-33 represses, AX-1177 restores in vitro).','Tissue factor (F3)':'Procoagulant PD module: measure TF activity in plasma (not on delivered panels).',
 'GM-CSF (CSF2)':'In vitro PD read-out (largest, most robust IL-33 response); not on delivered serum panels.',
 'PTX3':'Prognostic covariate only; IL-33 link not established in our cells.','E-selectin':'Prognostic covariate only; IL-33 link not established (SE>2).',
 'VCAM-1':'Not recommended (no serum association; IL-33 link not established).','IL-8 (CXCL8)':'Prognostic covariate only; IL-33 link not established (SE>2).',
 'MCP-1 (CCL2)':'Prognostic covariate only; IL-33 link not established (SE>2).','HGF':'Prognostic covariate only (top serum hit; not IL-33-regulated in our cells).',
 'vWF':'Prognostic covariate (endothelial injury); not IL-33-linked in our data.','ANGPT2':'Prognostic covariate (endothelial injury); not IL-33-regulated in our cells.',
}
bc = pd.read_csv(f'{T}/biomarker_candidates_evidence.csv'); bc['proposed_role'] = bc.marker.map(roles).fillna('In vitro IL-33 read-out; weak/no serum association - not prioritised for patients.')
readme = pd.DataFrame({'item':[
 'Purpose','Data basis','Sheet 1','Sheet 2','Sheet 3','Sheet 4','Sheet 5','Sheet 6','Sheet 7','Sheet 8','Sheet 9','Sheet 10','Sheet 11','Sheet 12','Sheet 13','Conventions','Code'],
 'description':[
 'Supporting tables for the AX-1177 portfolio audit memo (AX-1177_portfolio_audit_memo.md/.pdf).',
 'Only the five delivered AX-1177 files (methods annex, two RNA-seq workbooks, serum proteomics, post-mortem IHC). All cells read, including hidden rows/columns.',
 '1_Data_integrity_log: 19 issues found in the delivered files, with impact on conclusions and recommended action.',
 '2_InVitro_DE_burden: per-contrast counts of FDR<0.05 genes, robust genes, negligible-magnitude and low-expression hits.',
 '3_InVitro_reversal: regression of AX-1177 effect on the HUVEC IL-33 program; % reversal; isotype-control check.',
 '4_IL33_signature_genes: genes induced/repressed by IL-33 in HUVEC and opposed by AX-1177 (HUVEC and/or HGMEC), with log2FC/FDR.',
 '5_Hallmark_GSEA: fgsea NES/padj (MSigDB Hallmark) for IL-33, neutralisation and antibody-alone contrasts.',
 '6_Serum_protein_level: 1,064 unique proteins (duplicates across panels collapsed), mean Wald z, rank, in vitro signature flags.',
 '7_Serum_bridge_test: are IL-33-driven endothelial proteins more outcome-associated than other proteins? (No.)',
 '8_Serum_selected_axes: IL-33/IL-1 family, type-2, endothelial and coagulation assays as delivered (with CIs).',
 '9_Biomarker_candidates: in vitro IL-33 response, AX-1177 effect, serum association and proposed role for each candidate marker.',
 '10_PM_donor_level: post-mortem data aggregated to donor level, with pathology re-read (acute pneumonia, DAD, thromboemboli) and curation notes.',
 '11_PM_group_comparisons: donor-level vs (invalid) block-level group tests for IL-33 and cell markers.',
 '12_PM_path_verified: comparisons using pathology-verified groups (exploratory).',
 '13_PM_IL33_vs_cells: donor-level Spearman correlations of IL-33 with eosinophil / neutrophil / mast-cell / basophil markers.',
 'FDR = Benjamini-Hochberg. Robust RNA-seq gene = FDR<0.05, |log2FC|>1, AveExpr>0, SE<1. NeutIso = AX-1177+IL-33 vs isotype+IL-33. IL33vVeh = IL-33 vs vehicle ("Nontreated"). Ab_v_X = AX-1177 alone vs X. Wald z = ln(OR)/SE with SE from CI width.',
 'code/01-07 (Python, singlecell env; R for fgsea). Re-run from the raw files.']})
sheets = [('README', readme), ('1_Data_integrity_log', pd.read_csv(f'{T}/data_integrity_log.csv')), ('2_InVitro_DE_burden', pd.read_csv(f'{T}/invitro_DE_burden_per_contrast.csv')),
          ('3_InVitro_reversal', pd.read_csv(f'{T}/invitro_reversal_summary.csv')), ('4_IL33_signature_genes', pd.read_csv(f'{T}/invitro_IL33_endothelial_signature_genes.csv')),
          ('5_Hallmark_GSEA', pd.read_csv(f'{T}/invitro_fgsea_hallmark.csv')), ('6_Serum_protein_level', pd.read_csv(f'{T}/serum_protein_level_dedup.csv')),
          ('7_Serum_bridge_test', pd.read_csv(f'{T}/serum_bridge_enrichment_test.csv')), ('8_Serum_selected_axes', pd.read_csv(f'{T}/serum_selected_axes.csv')),
          ('9_Biomarker_candidates', bc), ('10_PM_donor_level', pd.read_csv(f'{T}/postmortem_donor_level_curated.csv')),
          ('11_PM_group_comparisons', pd.read_csv(f'{T}/postmortem_group_comparisons_donor_vs_block.csv')), ('12_PM_path_verified', pd.read_csv(f'{T}/postmortem_pathology_verified_comparisons.csv')),
          ('13_PM_IL33_vs_cells', pd.read_csv(f'{T}/postmortem_IL33_vs_cell_markers_spearman.csv'))]
with pd.ExcelWriter(OUT, engine='openpyxl') as xw:
    for name, df in sheets: df.to_excel(xw, sheet_name=name, index=False)
wb = load_workbook(OUT)
for ws in wb.worksheets:
    for c in ws[1]: c.font = Font(bold=True); c.fill = PatternFill('solid', fgColor='DDEBF7'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'A2'
    for col in ws.columns:
        L = max(len(str(c.value)) if c.value is not None else 0 for c in col[:200])
        ws.column_dimensions[col[0].column_letter].width = min(max(10, L*0.9), 70)
    if ws.title in ('README','1_Data_integrity_log','9_Biomarker_candidates'):
        for row in ws.iter_rows(min_row=2):
            for c in row: c.alignment = Alignment(wrap_text=True, vertical='top')
wb.save(OUT); print('workbook written:', OUT, [s[0] for s in sheets])
