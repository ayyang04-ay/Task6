"""Post-mortem lung IHC: donor-level aggregation, label-vs-pathology curation, group comparisons, correlations."""
import pandas as pd, numpy as np, sys, os
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from pm_curation import CUR
CACHE='/tmp/work'; OUT='/tmp/outputs/tables'
d = pd.read_pickle(f'{CACHE}/pm_blocks.pkl')
feat = ['IL33_epi','IL33_endo','IL33_vsm','EPX_s','EDN_s','MBP_s','BASO_2D7_s','IL5Ra_NEdx_s','NE_s','IL5Ra_TRdx_s','TRYP_s']
don = d.groupby('SID').agg({**{f:'mean' for f in feat}, 'grp':'first','Age':'first','Sex':'first','Block':'size','Notes':'first'}).rename(columns={'Block':'n_blocks'})
cur = pd.DataFrame(CUR).T; don = don.join(cur)
for c in ['acute_pneu','DAD','TE']: don[c] = don[c].astype(int)
don['covid'] = don.grp.str.startswith('COVID+').astype(int)
don['series'] = d.groupby('SID').Block.first().str[:8]
don.to_pickle(f'{CACHE}/pm_donors_cur.pkl')
order = ['COVID+ pneumonia','COVID- pneumonia','COVID- non-pneumonia']
rows=[]
for f in feat:
    g = [don.loc[don.grp==x, f].dropna() for x in order]; gb = [d.loc[d.grp==x, f].dropna() for x in order]
    rows.append(dict(feature=f, **{f'median {x} (donors)': round(v.median(),2) for x,v in zip(order,g)},
                     KW_p_donor_level=round(stats.kruskal(*g).pvalue,3), KW_p_block_level_NAIVE=round(stats.kruskal(*gb).pvalue,4),
                     p_COVIDpos_vs_COVIDneg_pneumonia=round(stats.mannwhitneyu(g[0],g[1]).pvalue,3),
                     p_any_pneumonia_label_vs_nonpneumonia=round(stats.mannwhitneyu(pd.concat([g[0],g[1]]),g[2]).pvalue,3)))
gc = pd.DataFrame(rows); gc.to_csv(f'{OUT}/postmortem_group_comparisons_donor_vs_block.csv', index=False); print(gc.to_string())
c = don['covid']
def cmp(ma, mb, label):
    r = dict(comparison=label, n=f'{int(ma.sum())} vs {int(mb.sum())}')
    for f in ['IL33_epi','IL33_endo','IL33_vsm','NE_s','IL5Ra_NEdx_s','EDN_s']:
        x = don.loc[ma,f].dropna(); y = don.loc[mb,f].dropna(); r[f] = f'{x.median():.2f} vs {y.median():.2f} (p={stats.mannwhitneyu(x,y).pvalue:.2f})'
    return r
pc = pd.DataFrame([cmp(don.DAD==1, don.DAD==0, 'DAD/ALI vs no DAD'),
                   cmp((c==1)&(don.DAD==1), (c==0)&(don.acute_pneu==1), 'COVID+ with DAD vs COVID- with documented acute pneumonia'),
                   cmp((don.acute_pneu+don.DAD)>0, (don.acute_pneu+don.DAD)==0, 'any acute pneumonia/DAD vs none documented'),
                   cmp(c==1, (c==0)&(don.acute_pneu==0), 'COVID+ (all) vs COVID- without documented pneumonia')])
pc.to_csv(f'{OUT}/postmortem_pathology_verified_comparisons.csv', index=False); print(pc.to_string())
rows=[]
for f in ['IL33_epi','IL33_endo','IL33_vsm']:
    for g in ['EPX_s','EDN_s','MBP_s','BASO_2D7_s','NE_s','IL5Ra_NEdx_s','TRYP_s']:
        rho, pv = stats.spearmanr(don[f], don[g], nan_policy='omit'); rows.append(dict(IL33=f, marker=g, spearman_rho=round(rho,2), p=round(pv,3)))
pd.DataFrame(rows).to_csv(f'{OUT}/postmortem_IL33_vs_cell_markers_spearman.csv', index=False)
notes = don.Notes.fillna('')
for k in ['COPD','Asthma']:
    m = notes.str.contains(k)
    print(k, {f: f'{don.loc[m,f].median():.2f} vs {don.loc[~m,f].median():.2f} p={stats.mannwhitneyu(don.loc[m,f].dropna(), don.loc[~m,f].dropna()).pvalue:.2f}' for f in ['IL33_epi','IL33_endo','IL33_vsm']})
print(pd.crosstab(don.grp, don.series)); print(don.groupby('series')[['MBP_s','EDN_s','NE_s','IL33_endo']].median().round(2))
out = don.drop(columns=['covid']).rename(columns={'grp':'delivered_group','note':'pathology_curation_note'})
out.to_csv(f'{OUT}/postmortem_donor_level_curated.csv')
