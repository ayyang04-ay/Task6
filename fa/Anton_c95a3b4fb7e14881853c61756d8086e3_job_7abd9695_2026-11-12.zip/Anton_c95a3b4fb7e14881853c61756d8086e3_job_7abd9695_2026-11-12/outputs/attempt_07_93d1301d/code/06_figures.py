"""Figures for the AX-1177 portfolio audit memo. Reads cached intermediates written by 01-05 scripts (in /tmp/work)."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
W, ann = pd.read_pickle('/tmp/work/wide.pkl'); L, Q, SE, T = W['logFC'], W['adj.P.Val'], W['SE'], W['t']
ann = ann.reindex(L.index)
sym2ens = ann.reset_index().drop_duplicates('symbol').set_index('symbol').ensembl
plt.rcParams.update({'font.size': 8, 'axes.titlesize': 9, 'axes.labelsize': 8})

# ---------------- Figure 1: in vitro pharmacology ----------------
fig, axs = plt.subplots(2, 3, figsize=(13, 8.2))
label_genes = ['CSF2','CCL20','TRAF1','TNFAIP3','NFKBIA','F3','IL6','CXCL2','CSF3','THBD','OCLN','CX3CL1','C3']
unreliable = ['SELE','VCAM1','CXCL8','CXCL1','CCL2','PTX3','IL1RL1']
def panel(ax, tp_x, ycol, title, hgmec=False):
    resp = (Q[f'IL33vVeh_HUVEC_{tp_x}']<0.05)&(L[f'IL33vVeh_HUVEC_{tp_x}'].abs()>1)&(ann.AveExpr>0)&(SE[f'IL33vVeh_HUVEC_{tp_x}']<1)
    x = L.loc[resp, f'IL33vVeh_HUVEC_{tp_x}']; y = L.loc[resp, ycol]
    sig = (Q.loc[resp, ycol]<0.05) & (np.sign(y)!=np.sign(x))
    ax.scatter(x[~sig], y[~sig], s=6, c='#bbbbbb', lw=0, label='not significantly opposed')
    ax.scatter(x[sig], y[sig], s=6, c='#1f77b4', lw=0, label='significantly opposed by AX-1177 (FDR<0.05)')
    lim = max(abs(x).max(), abs(y).max())*1.05
    ax.plot([-lim, lim], [lim, -lim], ls='--', c='k', lw=0.7, label='complete reversal (y = -x)')
    s = stats.linregress(x, y)
    xx = np.linspace(-lim, lim, 10); ax.plot(xx, s.intercept + s.slope*xx, c='#d62728', lw=1, label='linear fit')
    rev = -y/x
    for g in label_genes:
        e = sym2ens.get(g)
        if e is not None and resp.get(e, False):
            ax.annotate(g, (x[e], y[e]), fontsize=6.5, xytext=(3,2), textcoords='offset points')
    for g in unreliable:
        e = sym2ens.get(g)
        if e is not None:
            ax.scatter(L.loc[e, f'IL33vVeh_HUVEC_{tp_x}'], L.loc[e, ycol], s=22, facecolors='none', edgecolors='#d62728', lw=0.8)
            if g in ('SELE','VCAM1','CXCL8','CXCL1'):
                ax.annotate(g+'*', (L.loc[e, f'IL33vVeh_HUVEC_{tp_x}'], L.loc[e, ycol]), fontsize=6, color='#d62728', xytext=(4,-8), textcoords='offset points')
    ax.axhline(0, c='grey', lw=0.4); ax.axvline(0, c='grey', lw=0.4)
    if hgmec:
        txt = f'{resp.sum()} HUVEC IL-33-responsive genes\nslope {s.slope:.2f}, r {s.rvalue:.2f}\n{sig.sum()} significantly opposed in HGMEC\n(HGMEC IL-33 vs vehicle not measured)'
    else:
        txt = f'{resp.sum()} robust IL-33-responsive genes\nslope {s.slope:.2f}, r {s.rvalue:.2f}\nmedian reversal {100*np.median(rev):.0f}%\n{sig.sum()}/{resp.sum()} significantly reversed'
    ax.text(0.03, 0.03, txt, transform=ax.transAxes, fontsize=6.8, va='bottom', ha='left', bbox=dict(fc='white', ec='#cccccc', lw=0.5))
    ax.set_title(title)
    ax.set_xlabel(f'IL-33red vs vehicle, HUVEC {tp_x}h (log2FC)'); ax.set_ylabel('AX-1177+IL-33 vs isotype+IL-33 (log2FC)')
    ax.legend(fontsize=5.5, loc='upper right', frameon=False)
panel(axs[0,0], '6', 'NeutIso_HUVEC_6', 'A. HUVEC 6h: AX-1177 reverses the IL-33 program')
panel(axs[0,1], '24', 'NeutIso_HUVEC_24', 'B. HUVEC 24h')
panel(axs[1,0], '6', 'NeutIso_HGMEC_6', 'D. Glomerular endothelium (HGMEC) 6h', hgmec=True)
panel(axs[1,1], '6', 'NeutIso_HGMEC_24', 'E. Glomerular endothelium (HGMEC) 24h', hgmec=True)
# C: DEG counts
ax = axs[0,2]
order = ['IL33vVeh_HUVEC_6','IL33vVeh_HUVEC_24','NeutIso_HUVEC_6','NeutIso_HUVEC_24','NeutIso_HGMEC_6','NeutIso_HGMEC_24',
         'Ab_v_IC119_HUVEC_6','Ab_v_IC119_HUVEC_24','Ab_v_IC119_HGMEC_6','Ab_v_IC119_HGMEC_24','Ab_v_IC119_A549_6','Ab_v_IC119_A549_24','Ab_v_IC119_MCF7_6','Ab_v_IC119_MCF7_24']
n_all = [(Q[c]<0.05).sum() for c in order]
n_rob = [((Q[c]<0.05)&(L[c].abs()>1)&(ann.AveExpr>0)&(SE[c]<1)).sum() for c in order]
yy = np.arange(len(order))[::-1]
ax.barh(yy, n_all, color='#c6dbef', label='FDR<0.05 (all)')
ax.barh(yy, n_rob, color='#08519c', label='FDR<0.05, |log2FC|>1, expressed')
labels = ['IL-33 vs veh HUVEC 6h','IL-33 vs veh HUVEC 24h','AX-1177 neutral. HUVEC 6h','AX-1177 neutral. HUVEC 24h','AX-1177 neutral. HGMEC 6h','AX-1177 neutral. HGMEC 24h',
          'AX-1177 alone HUVEC 6h','AX-1177 alone HUVEC 24h','AX-1177 alone HGMEC 6h','AX-1177 alone HGMEC 24h','AX-1177 alone A549 6h','AX-1177 alone A549 24h','AX-1177 alone MCF7 6h','AX-1177 alone MCF7 24h']
ax.set_yticks(yy); ax.set_yticklabels(labels, fontsize=6.5); ax.set_xscale('symlog', linthresh=10); ax.set_xlabel('number of genes (symlog)')
for yv, a_, r_ in zip(yy, n_all, n_rob): ax.text(max(a_,1)*1.1, yv, f'{a_} / {r_}', va='center', fontsize=6)
ax.set_title('C. Differential expression burden per contrast\n(antibody alone vs isotype: no coherent signal)'); ax.legend(fontsize=6, loc='lower right', frameon=False)
ax.set_xlim(0, 30000)
# F: hallmark NES heatmap
gs = pd.read_csv('/tmp/work/fgsea_hallmark.tsv', sep='\t')
sel = ['HALLMARK_TNFA_SIGNALING_VIA_NFKB','HALLMARK_INFLAMMATORY_RESPONSE','HALLMARK_IL6_JAK_STAT3_SIGNALING','HALLMARK_INTERFERON_GAMMA_RESPONSE','HALLMARK_COMPLEMENT','HALLMARK_COAGULATION','HALLMARK_APOPTOSIS','HALLMARK_E2F_TARGETS','HALLMARK_MYC_TARGETS_V1','HALLMARK_OXIDATIVE_PHOSPHORYLATION']
cols = ['IL33vVeh_HUVEC_6','IL33vVeh_HUVEC_24','NeutIso_HUVEC_6','NeutIso_HUVEC_24','NeutIso_HGMEC_6','NeutIso_HGMEC_24','Ab_v_IC119_HUVEC_6','Ab_v_IC119_HGMEC_6','Ab_v_IC119_A549_24','Ab_v_IC119_MCF7_24']
M = gs[gs.pathway.isin(sel)].pivot(index='pathway', columns='contrast', values='NES').reindex(index=sel, columns=cols)
P = gs[gs.pathway.isin(sel)].pivot(index='pathway', columns='contrast', values='padj').reindex(index=sel, columns=cols)
ax = axs[1,2]
im = ax.imshow(M.values, cmap='RdBu_r', vmin=-3.5, vmax=3.5, aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        p = P.values[i,j]; s = '***' if p<0.001 else ('**' if p<0.01 else ('*' if p<0.05 else ''))
        ax.text(j, i, s, ha='center', va='center', fontsize=6)
ax.set_yticks(range(len(sel))); ax.set_yticklabels([s.replace('HALLMARK_','').replace('_',' ').lower() for s in sel], fontsize=6.5)
ax.set_xticks(range(len(cols))); ax.set_xticklabels(['IL33 HUVEC 6h','IL33 HUVEC 24h','Neut HUVEC 6h','Neut HUVEC 24h','Neut HGMEC 6h','Neut HGMEC 24h','Ab HUVEC 6h','Ab HGMEC 6h','Ab A549 24h','Ab MCF7 24h'], rotation=60, ha='right', fontsize=6.5)
plt.colorbar(im, ax=ax, fraction=0.04, label='NES (fgsea, Hallmark)')
ax.set_title('F. Pathways: IL-33 induces NF-kB/inflammatory/coagulation;\nAX-1177 mirrors it (Neut = AX-1177+IL-33 vs isotype+IL-33)')
fig.text(0.01, 0.004, '* red open circles = canonical activation genes whose large log2FC is NOT statistically supported (gene-level SE > 2 log2 units in every contrast): SELE, VCAM1, CXCL8, CXCL1, CCL2, PTX3, IL1RL1 (sST2).\nRobust = FDR<0.05, |log2FC|>1, AveExpr>0, SE<1. Panels D-E plot HGMEC neutralization against the HUVEC IL-33 response because the HGMEC design has no vehicle arm. Panel C labels: all FDR<0.05 / robust.', fontsize=6.5)
plt.tight_layout(rect=[0,0.03,1,1])
plt.savefig('/tmp/outputs/figures/Fig1_invitro_pharmacology.png', dpi=180); plt.close()

# ---------------- Figure 2: serum proteomics ----------------
prot = pd.read_pickle('/tmp/work/prot.pkl'); bridge = pd.read_pickle('/tmp/work/bridge.pkl')
pl = prot.groupby('base').agg(z=('z','mean'), p=('p.value','min'))
fig, axs = plt.subplots(1, 3, figsize=(14, 5.6), gridspec_kw={'width_ratios':[1.1,0.8,1.4]})
ax = axs[0]
ax.hist(pl.z, bins=50, color='#9ecae1', edgecolor='white', density=True, label=f'{len(pl)} unique proteins')
xx = np.linspace(-4,5,200); ax.plot(xx, stats.norm.pdf(xx), c='k', lw=1, ls='--', label='expected if no association (N(0,1))')
for nm, col in [('ST2','#d62728'),('HGF','#555555'),('IL6','#2ca02c')]:
    ax.axvline(pl.loc[nm,'z'], c=col, lw=1.2); ax.text(pl.loc[nm,'z'], ax.get_ylim()[1]*0.9 if nm=='ST2' else ax.get_ylim()[1]*0.7, ' '+('sST2' if nm=='ST2' else nm), color=col, fontsize=7)
ax.axvline(pl.z.median(), c='#08519c', lw=1, ls=':'); ax.text(pl.z.median(), 0.02, f' median z = {pl.z.median():.2f}', color='#08519c', fontsize=7)
ax.set_xlabel('Wald z (log OR / SE), adjusted for age, sex, NEWS2'); ax.set_ylabel('density')
ax.set_title(f'A. Proteome-wide shift with severity: {100*(prot.OR>1).mean():.0f}% of assays OR>1\nsST2 ranks 2nd of {len(pl)} unique proteins (99.8th pct)')
ax.legend(fontsize=6.5, frameon=False, loc='upper left')
ax = axs[1]
g1 = bridge.loc[bridge.SIG_UP_HUVEC, 'z']; g0 = bridge.loc[~bridge.SIG_UP_HUVEC, 'z']
bp = ax.boxplot([g0, g1], widths=0.5, showfliers=False)
rng = np.random.default_rng(0)
ax.scatter(1+rng.uniform(-0.15,0.15,len(g0)), g0, s=3, c='#aaaaaa'); ax.scatter(2+rng.uniform(-0.15,0.15,len(g1)), g1, s=8, c='#1f77b4')
u = stats.mannwhitneyu(g1, g0)
ax.set_xticks([1,2]); ax.set_xticklabels([f'other proteins\n(n={len(g0)})', f'IL-33-induced, AX-1177-\nreversible in HUVEC (n={len(g1)})'], fontsize=7)
ax.set_ylabel('Wald z for severe outcome'); ax.set_title(f'B. Bridge test: IL-33 endothelial program is\nNOT enriched among outcome-linked proteins (MWU p={u.pvalue:.2f})')
ax = axs[2]
cand = [('sST2 (ST2)','ST2','grey'),('IL-6','IL6','blue'),('CCL20','CCL20','blue'),('MCP-3/CCL7','MCP-3','blue'),('OPG','OPG-INFI','blue'),('IL-18R1','IL-18R1','blue'),('CSF-1','CSF-1','blue'),('IL-1beta','IL1B','blue'),
        ('uPA','uPA-INFI','lightblue'),('PAI-1','PAI','lightblue'),('CX3CL1','CX3CL1','lightblue'),('G-CSF','G-CSF','lightblue'),('CXCL10','CXCL10','lightblue'),('CXCL6','CXCL6','lightblue'),
        ('PTX3','PTX3','grey'),('E-selectin','SELE','grey'),('IL-8','IL8','grey'),('MCP-1','MCP-1-INFI','grey'),('VCAM-1','VCAM1','grey'),('HGF','HGF','black'),('vWF','vWF','black'),('ANGPT2','ANGPT2','black'),
        ('IL-5','IL5-IMO','purple'),('eotaxin-1/CCL11','CCL11-INFI','purple'),('CCL24','CCL24','purple')]
colmap = {'blue':'#08519c','lightblue':'#6baed6','grey':'#d62728','black':'#333333','purple':'#7b3294'}
for i,(nm, a, c) in enumerate(cand):
    r = prot[prot.assay==a].iloc[0]; y = len(cand)-i
    ax.plot([r.l95, r.u95], [y,y], c=colmap[c], lw=1.2); ax.scatter(r.OR, y, c=colmap[c], s=14, zorder=3)
    ax.text(2e3, y, f"q={r['adj.p.value']:.3f}", va='center', fontsize=6)
ax.set_yticks([len(cand)-i for i in range(len(cand))]); ax.set_yticklabels([c[0] for c in cand], fontsize=6.5)
ax.set_xscale('log'); ax.axvline(1, c='k', lw=0.6); ax.set_xlim(0.1, 1e4); ax.set_xlabel('OR per log unit (95% CI) for ICU/IMV/death by day 30')
ax.set_title('C. Candidate markers: serum association vs in vitro IL-33 evidence\n(OR per log unit is not comparable across proteins; compare q / direction)')
from matplotlib.lines import Line2D
hand = [Line2D([0],[0],color=colmap['blue'],lw=2,label='IL-33-induced & AX-1177-reversed (HUVEC+HGMEC), serum q<0.05'),
        Line2D([0],[0],color=colmap['lightblue'],lw=2,label='IL-33-induced & reversed in vitro, serum n.s./weaker'),
        Line2D([0],[0],color=colmap['grey'],lw=2,label='serum-associated, in vitro IL-33 response NOT established (SE>2)'),
        Line2D([0],[0],color=colmap['black'],lw=2,label='serum-associated, not IL-33-responsive in vitro'),
        Line2D([0],[0],color=colmap['purple'],lw=2,label='type-2 markers')]
ax.legend(handles=hand, fontsize=6, loc='upper center', bbox_to_anchor=(0.45, -0.13), ncol=2, frameon=False)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/Fig2_serum_proteomics.png', dpi=180); plt.close()

# ---------------- Figure 3: post-mortem ----------------
don = pd.read_pickle('/tmp/work/pm_donors_cur.pkl'); blk = pd.read_pickle('/tmp/work/pm_blocks.pkl')
order = ['COVID+ pneumonia','COVID- pneumonia','COVID- non-pneumonia']
def path_cat(r):
    if r.DAD==1: return 'DAD / acute lung injury'
    if r.acute_pneu==1: return 'acute pneumonia, no DAD'
    return 'no acute pneumonia\ndocumented'
don['path_cat'] = don.apply(path_cat, axis=1)
porder = ['DAD / acute lung injury','acute pneumonia, no DAD','no acute pneumonia\ndocumented']
plabels = ['DAD /\nacute lung\ninjury','acute\npneumonia,\nno DAD','no acute\npneumonia\ndocumented']
fig, axs = plt.subplots(1, 4, figsize=(15.5, 4.6), gridspec_kw={'width_ratios':[1,1,1,0.9]})
rng = np.random.default_rng(1)
for k,(f, nm) in enumerate([('IL33_endo','IL-33, endothelium'),('IL33_epi','IL-33, basal epithelium'),('IL33_vsm','IL-33, vascular smooth muscle')]):
    ax = axs[k]
    for i,g in enumerate(order):
        sub = don[don.grp==g]
        ax.scatter(i+rng.uniform(-0.18,0.18,len(sub)), sub[f], s=10+6*sub.n_blocks, alpha=0.7, c=['#d62728','#1f77b4','#2ca02c'][i], edgecolors='k', lw=0.3)
        ax.hlines(sub[f].median(), i-0.25, i+0.25, color='k', lw=1.5)
    p_d = stats.kruskal(*[don.loc[don.grp==g, f].dropna() for g in order]).pvalue
    p_b = stats.kruskal(*[blk.loc[blk.grp==g, f].dropna() for g in order]).pvalue
    ax.set_xticks(range(3)); ax.set_xticklabels(['COVID+\n"pneumonia"\n(16 donors/49 blocks)','COVID-\n"pneumonia"\n(10/15)','COVID-\n"non-pneumonia"\n(5/10)'], fontsize=6.5)
    ax.set_ylim(-0.3, 6); ax.set_ylabel('semi-quantitative score (as delivered)')
    ax.set_title(f'{"ABC"[k]}. {nm}\ndonor-level KW p={p_d:.2f}  |  naive block-level p={p_b:.3f}')
ax = axs[3]
ct = pd.crosstab(don.grp, don.path_cat).reindex(index=order, columns=porder).fillna(0).astype(int)
im = ax.imshow(ct.values, cmap='Greys', vmin=0, vmax=12)
for i in range(ct.shape[0]):
    for j in range(ct.shape[1]):
        ax.text(j, i, ct.values[i,j], ha='center', va='center', color='white' if ct.values[i,j]>6 else 'k', fontsize=10)
ax.set_xticks(range(3)); ax.set_xticklabels(plabels, fontsize=6.5); ax.set_yticks(range(3)); ax.set_yticklabels(['COVID+\n"pneumonia"','COVID-\n"pneumonia"','COVID-\n"non-pneumonia"'], fontsize=7)
ax.set_xlabel('autopsy diagnosis\n(re-read of delivered pathology text)', fontsize=7); ax.set_title('D. Delivered labels vs\ndocumented lung pathology (donors)')
fig.text(0.01, 0.01, 'Dot size = number of histology blocks per donor (3 COVID+ donors contribute 8 blocks each). Bars = donor medians. Endothelial scores sit at/near the scale ceiling in all groups.', fontsize=6.5)
plt.tight_layout(rect=[0,0.03,1,1]); plt.savefig('/tmp/outputs/figures/Fig3_postmortem_IL33.png', dpi=180); plt.close()
print('figures written')
