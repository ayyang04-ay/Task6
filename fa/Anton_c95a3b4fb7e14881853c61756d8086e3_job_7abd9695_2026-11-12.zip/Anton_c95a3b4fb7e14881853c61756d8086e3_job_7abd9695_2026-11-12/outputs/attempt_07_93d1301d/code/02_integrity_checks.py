"""Data-integrity checks across all four workbooks. Prints findings; see Data_integrity_log sheet in the supporting workbook."""
import pandas as pd, numpy as np, openpyxl
from scipy import stats, optimize
from statsmodels.stats.multitest import multipletests
RAW = '/tmp/world/filesystem'; CACHE = '/tmp/work'
# 1 hidden rows/columns
for f in ['AX-1177_postmortem_lung.xlsx','AX-1177_serum_proteomics.xlsx']:
    ws = openpyxl.load_workbook(f'{RAW}/{f}').active
    hc = [(c, d.min, d.max) for c, d in ws.column_dimensions.items() if d.hidden]
    hr = [r for r, d in ws.row_dimensions.items() if d.hidden]
    print(f, '| hidden column groups (letter,min,max):', hc, '| hidden rows:', hr)
# 2 the two contrast sheets
a = pd.read_pickle(f'{CACHE}/contrasts_6h.pkl'); b = pd.read_pickle(f'{CACHE}/contrasts_24h.pkl')
m = a.merge(b, on=['Comparison','ensembl'], suffixes=('_a','_b'))
print('6h vs 24h sheet: same row set:', len(m)==len(a)==len(b), '; identical values:', all(np.allclose(m[c+'_a'], m[c+'_b'], equal_nan=True) for c in ['logFC','t','P.Value','adj.P.Val','AveExpr','B']),
      '; contrasts per sheet:', a.Comparison.nunique(), b.Comparison.nunique())
allc = pd.read_pickle(f'{CACHE}/all_contrasts.pkl')
print('AveExpr identical across contrasts for every gene:', (allc.groupby('ensembl').AveExpr.nunique()==1).all())
ok = []
for comp, d in allc.groupby('Comparison'):
    ok.append(np.allclose(multipletests(d['P.Value'], method='fdr_bh')[1], d['adj.P.Val'], rtol=1e-8))
print('RNA-seq BH reproduces within each contrast:', all(ok))
sub = allc[(allc.t.abs()>2)&(allc.t.abs()<5)].groupby('ensembl').head(1).sample(5000, random_state=2)
dfi = [np.exp(optimize.brentq(lambda l: 2*stats.t.sf(abs(t), np.exp(l)) - p, np.log(0.5), np.log(1e7))) for t,p in zip(sub.t, sub['P.Value'])]
print('implied limma df.total: min %.2f, median %.2f  -> residual df = 75 (annex implies 114-38 = 76)' % (np.min(dfi), np.median(dfi)))
se = (allc.logFC/allc.t).abs(); g = allc.assign(se=se).groupby('symbol').se.median()
print('genes with SE>2 log2 units in every contrast (examples):', [x for x in ['SELE','VCAM1','CXCL8','CXCL1','CCL2','PTX3','IL1RL1','VWF','CDH5','PECAM1','ESM1'] if g.get(x,0)>2])
for f in ['IL33_vs_Vehicle_HUVEC_6_hrs','IL33_vs_Vehicle_HUVEC_24_hrs']:
    h = pd.read_pickle(f'{CACHE}/huvec_{f}.pkl')
    print(f, ': sorted by logFC:', h.logFC.is_monotonic_decreasing, '; non-significant among top-20 by logFC:', list(h.head(20).loc[h.head(20)['adj.P.Val']>=0.05,'symbol']), '; contrast label:', h.Comparison.iloc[0])
# 3 proteomics
p = pd.read_pickle(f'{CACHE}/prot.pkl')
pw = 2*stats.norm.sf(np.abs(p.z)); print('proteomics p consistent with CI (max |log10 dev|): %.1e' % np.max(np.abs(np.log10(p['p.value'])-np.log10(pw))))
print('proteomics BH over delivered 1094 reproduces:', np.allclose(multipletests(p['p.value'], method='fdr_bh')[1], p['adj.p.value'], rtol=1e-6),
      '; implied number of tests from top row: %.1f' % (p['adj.p.value'].iloc[0]/p['p.value'].iloc[0]))
M = 1194; R = p['p.value']*M/p['adj.p.value']; exact = np.abs(R-np.round(R))<1e-6
miss = (np.round(R[exact]).astype(int) - (np.arange(1,len(p)+1)[exact]))
print('assays missing from delivery but counted in BH: %d; of which ranked within the delivered q<0.05 region: %d' % (M-len(p), int(miss[p['adj.p.value'][exact]<0.05].max())))
print('assays per panel:', p.panel_short.value_counts().to_dict())
print('proteins on >1 panel:', p[p.duplicated('base', keep=False)].base.nunique(), '; unique proteins:', p.base.nunique())
for c in ['composite_endpoint_0','composite_endpoint_1']:
    v = p[c][p[c]>0]; print(c, 'smallest non-zero value = 1/%.0f' % (1/v.min()), '; max', round(p[c].max(),3))
# 4 post-mortem
d = pd.read_pickle(f'{CACHE}/pm_blocks.pkl')
print('post-mortem: donors', d.SID.nunique(), 'blocks', len(d), '; blocks per donor max', d.groupby('SID').size().max(), '; donors with 8 blocks:', list(d.groupby('SID').size()[lambda s: s==8].index))
for a_, b_ in [('EPX_s','EPX_num'),('NE_s','NE_num'),('TRYP_s','TRYP_num')]:
    exp = np.where(d[a_]==0, 0, d[a_]+0.5); print(f'{b_} = grade + 0.5 (0 kept as 0):', bool((np.isclose(exp, d[b_]) | (d[a_].isna() & d[b_].isna())).all()))
print('max IL-33 score (0-5 scale):', d[['IL33_epi','IL33_endo','IL33_vsm']].max().max(), '; SARS-CoV-2 status missing for donors:', list(d.groupby('SID').CoV.first()[lambda s: s.isna()].index))
