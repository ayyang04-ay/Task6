# fgsea (Hallmark, msigdbr) on limma moderated t statistics exported by 03_invitro.py
suppressMessages({library(fgsea); library(data.table); library(msigdbr)})
x <- fread("/tmp/work/t_for_gsea.tsv"); x <- x[!duplicated(symbol)]
h <- msigdbr(species="Homo sapiens", category="H"); H <- split(h$gene_symbol, h$gs_name)
res <- rbindlist(lapply(grep("^t_", names(x), value=TRUE), function(cn){
  st <- x[[cn]]; names(st) <- x$symbol; st <- st[is.finite(st)]; set.seed(1)
  r <- fgseaMultilevel(H, st, minSize=15, maxSize=500, eps=0); r$contrast <- sub("^t_","",cn); r[, .(contrast, pathway, NES, padj, size)]}))
fwrite(res, "/tmp/work/fgsea_hallmark.tsv", sep="\t"); fwrite(res, "/tmp/outputs/tables/invitro_fgsea_hallmark.csv")
cat("fgsea done:", nrow(res), "rows\n")
