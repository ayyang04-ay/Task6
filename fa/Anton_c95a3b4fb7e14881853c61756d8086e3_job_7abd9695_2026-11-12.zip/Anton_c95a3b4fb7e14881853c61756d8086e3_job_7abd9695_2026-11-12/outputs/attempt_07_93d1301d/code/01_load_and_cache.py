"""Load the four delivered workbooks (as-is, including hidden rows/columns) and cache them.
Run in the `singlecell` env:  mm singlecell python 01_load_and_cache.py   (takes ~4 min: the contrasts workbook is 123 MB)"""
import pandas as pd, numpy as np, openpyxl, os
RAW = '/tmp/world/filesystem'; CACHE = '/tmp/work'; os.makedirs(CACHE, exist_ok=True)
if not os.path.exists(f'{CACHE}/contrasts_6h.pkl'):
    for sh in ['6h', '24h']:
        pd.read_excel(f'{RAW}/AX-1177_rnaseq_contrasts.xlsx', sheet_name=sh).to_pickle(f'{CACHE}/contrasts_{sh}.pkl')
    for sh in ['IL33_vs_Vehicle_HUVEC_6_hrs', 'IL33_vs_Vehicle_HUVEC_24_hrs']:
        pd.read_excel(f'{RAW}/AX-1177_rnaseq_huvec_il33.xlsx', sheet_name=sh).to_pickle(f'{CACHE}/huvec_{sh}.pkl')
a = pd.read_pickle(f'{CACHE}/contrasts_6h.pkl')
h6 = pd.read_pickle(f'{CACHE}/huvec_IL33_vs_Vehicle_HUVEC_6_hrs.pkl'); h24 = pd.read_pickle(f'{CACHE}/huvec_IL33_vs_Vehicle_HUVEC_24_hrs.pkl')
allc = pd.concat([a, h6, h24], ignore_index=True); allc.to_pickle(f'{CACHE}/all_contrasts.pkl')
short = {'IL33_vs_Nontreated_HUVEC_6_hrs':'IL33vVeh_HUVEC_6','IL33_vs_Nontreated_HUVEC_24_hrs':'IL33vVeh_HUVEC_24'}
for cl in ['HUVEC','HGMEC']:
    for tp in ['6','24']:
        short[f'Compound_47_IL33_vs_IL33_IC119_{cl}_{tp}hrs'] = f'NeutIso_{cl}_{tp}'
        short[f'Compound_47_IL33_vs_IL33_{cl}_{tp}hrs'] = f'Neut_{cl}_{tp}'
for c in allc.Comparison.unique():
    short.setdefault(c, c.replace('Compound_47_vs_','Ab_v_').replace('hrs',''))
allc['c'] = allc.Comparison.map(short); allc['SE'] = (allc.logFC/allc.t).abs()
W = {k: allc.pivot(index='ensembl', columns='c', values=k) for k in ['logFC','t','adj.P.Val','P.Value','SE']}
ann = allc.drop_duplicates('ensembl').set_index('ensembl')[['symbol','AveExpr','gene_name']].reindex(W['logFC'].index)
pd.to_pickle((W, ann), f'{CACHE}/wide.pkl')
# proteomics
df = pd.read_excel(f'{RAW}/AX-1177_serum_proteomics.xlsx')
df['panel_short'] = df.panel.str.replace('Olink Target 96 ','').str.replace(r'\(v\.\d+\)','',regex=True).str.strip()
df['rank'] = np.arange(1, len(df)+1)
df['base'] = df.assay.str.replace(r'-(INFI|ONCII|ONCIII|CVDII|CVDIII|IMO|CRE|DEV|MET|NEX|NEU|ODA|CM|CMET)$','',regex=True)
df['se'] = (np.log(df.u95)-np.log(df.l95))/(2*1.959964); df['z'] = np.log(df.OR)/df.se
import sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from olink_map import to_sym
df['sym'] = df.base.map(to_sym); df['in_rnaseq'] = df.sym.isin(set(ann.symbol.dropna()))
df.to_pickle(f'{CACHE}/prot.pkl')
# post-mortem (read every cell incl. hidden columns; forward-fill merged donor-level fields)
import re
wb = openpyxl.load_workbook(f'{RAW}/AX-1177_postmortem_lung.xlsx', data_only=True); ws = wb.active
rows = [[ws.cell(r,c).value for c in range(1,28)] for r in range(2, ws.max_row+1) if ws.cell(r,2).value is not None]
cols = ['SID','Block','RNA','SID2','Lobe','Dx','Race','Sex','Age','CoV','Path','HE_eos','EPX','EDN','MBP','BASO_2D7','IL5Ra_NEdx','NE','IL5Ra_TRdx','TRYP','EPX_num','NE_num','TRYP_num','IL33_epi','IL33_endo','IL33_vsm','Notes']
d = pd.DataFrame(rows, columns=cols); d['SID'] = d.SID.astype(str).str.strip()
for c in ['Dx','Race','Sex','Age','CoV','Path']:
    d[c] = d.groupby('SID')[c].transform(lambda s: s.ffill().bfill())
d['Notes'] = d.groupby('SID')['Notes'].transform(lambda s: s.dropna().iloc[0] if s.notna().any() else None)
def score(v):
    if v is None: return np.nan
    if isinstance(v,(int,float)): return float(v)
    m = re.match(r'^(\d)\+?$', str(v).strip()); return float(m.group(1)) if m else np.nan
for c in ['EPX','EDN','MBP','BASO_2D7','IL5Ra_NEdx','NE','IL5Ra_TRdx','TRYP']: d[c+'_s'] = d[c].map(score)
for c in ['EPX_num','NE_num','TRYP_num','IL33_epi','IL33_endo','IL33_vsm']:
    d[c] = d[c].map(lambda v: np.nan if (v is None or isinstance(v,str)) else float(v))
d['grp'] = d.Dx.map({'COVID pos pneumonia':'COVID+ pneumonia','COVID neg pneumonia':'COVID- pneumonia','COVID neg non-pneumonia':'COVID- non-pneumonia'})
d.to_pickle(f'{CACHE}/pm_blocks.pkl')
print('cached:', allc.shape, df.shape, d.shape)
