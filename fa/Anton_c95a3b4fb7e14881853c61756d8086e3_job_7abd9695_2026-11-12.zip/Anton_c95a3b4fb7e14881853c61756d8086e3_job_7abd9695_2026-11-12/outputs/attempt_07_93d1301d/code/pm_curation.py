# Manual curation of each donor from the autopsy diagnosis text (column K) -- see pathology text dump
# acute_pneu: acute pneumonia/bronchopneumonia/acute pneumonitis documented in lungs
# DAD: diffuse alveolar damage / hyaline membranes / 'acute lung injury' documented
# TE: pulmonary (thrombo)emboli documented
CUR = {
 # COVID+ "pneumonia"
 '2035': dict(acute_pneu=1, DAD=0, TE=1, note='acute bronchopneumonia + multifocal pulmonary emboli'),
 '2044': dict(acute_pneu=1, DAD=1, TE=0, note='ALI with multifocal DAD + hyaline membranes; focal BP; emphysema; fibrosis; herpetic tracheitis'),
 '2045': dict(acute_pneu=1, DAD=0, TE=0, note='acute BP with haemorrhage; organizing pneumonia'),
 '2049': dict(acute_pneu=1, DAD=1, TE=0, note='ALI with DAD + hyaline membranes consistent with COVID-19; BP'),
 '2040': dict(acute_pneu=0, DAD=1, TE=1, note='DAD (exudative/proliferative/fibrotic) + arterial thromboemboli'),
 '2043': dict(acute_pneu=1, DAD=1, TE=0, note='BP with Aspergillus; early ALI with focal DAD'),
 '2067': dict(acute_pneu=0, DAD=0, TE=0, note='NO acute pneumonia: mild chronic NSIP-like pneumonitis, emphysema'),
 '2072': dict(acute_pneu=1, DAD=1, TE=0, note='early ALI with hyaline membranes; BP RLL'),
 '2073': dict(acute_pneu=1, DAD=0, TE=0, note='acute BP bilateral'),
 '2075': dict(acute_pneu=1, DAD=0, TE=0, note='focal acute and organizing pneumonia; suspected amyloidosis'),
 '2101': dict(acute_pneu=0, DAD=0, TE=0, note='NO acute pneumonia: chronic interstitial inflammation, possible aspiration'),
 '2105': dict(acute_pneu=1, DAD=0, TE=0, note='acute pneumonitis bilateral'),
 '2108': dict(acute_pneu=1, DAD=1, TE=0, note='organizing DAD consistent with SARS-CoV-2 pneumonia'),
 '2110': dict(acute_pneu=1, DAD=1, TE=0, note='consolidation + acute lung injury bilateral'),
 '2113': dict(acute_pneu=1, DAD=0, TE=1, note='acute BP + thromboembolus'),
 '2060': dict(acute_pneu=1, DAD=0, TE=1, note='acute BP + PA thromboemboli; emphysema'),
 # COVID- "pneumonia"
 '1130': dict(acute_pneu=1, DAD=0, TE=0, note='acute BP'),
 '1138': dict(acute_pneu=1, DAD=0, TE=0, note='acute BP with haemorrhage'),
 '1149': dict(acute_pneu=1, DAD=0, TE=0, note='acute BP'),
 '1159': dict(acute_pneu=1, DAD=0, TE=0, note='acute BP'),
 '1165': dict(acute_pneu=1, DAD=0, TE=0, note='acute BP'),
 '1910': dict(acute_pneu=1, DAD=0, TE=0, note='severe acute BP'),
 '1905': dict(acute_pneu=0, DAD=0, TE=0, note='NO pneumonia documented (emphysema); SARS-CoV-2 status blank'),
 '1970': dict(acute_pneu=0, DAD=0, TE=0, note='NO lung findings documented'),
 '1968': dict(acute_pneu=0, DAD=0, TE=0, note='NO pneumonia: possible aspirated material, emphysema, mucus plugging'),
 '1961': dict(acute_pneu=0, DAD=0, TE=0, note='NO pneumonia: pleural plaques/blebs'),
 # COVID- "non-pneumonia"
 '1861': dict(acute_pneu=0, DAD=0, TE=0, note='pulmonary fibrosis, emphysema, acute bronchitis'),
 '1944': dict(acute_pneu=1, DAD=0, TE=0, note='systemic coccidioidomycosis involving lung (fungal lung infection)'),
 '1956': dict(acute_pneu=1, DAD=0, TE=0, note='acute pneumonitis + haemorrhage, necrosis (no hyaline membranes)'),
 '1965': dict(acute_pneu=0, DAD=0, TE=0, note='severe IPF with bronchiectasis'),
 '1976': dict(acute_pneu=1, DAD=0, TE=0, note='acute and organizing pneumonia RLL; DIPNECH'),
}
