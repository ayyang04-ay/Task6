"""In vitro RNA-seq: DEG burden, IL-33 program, AX-1177 reversal, HGMEC, antibody-alone, isotype control quality. Writes tables to /tmp/outputs/tables."""
import pandas as pd, numpy as np
from scipy import stats
CACHE='/tmp/work'; OUT='/tmp/outputs/tables'
W, ann = pd.read_pickle(f'{CACHE}/wide.pkl'); L, Q, SE, T = W['logFC'], W['adj.P.Val'], W['SE'], W['t']
ae = ann.AveExpr
# 1 DEG burden per contrast
rows=[]
for c in L.columns:
    s = Q[c]<0.05
    rows.append(dict(contrast=c, FDR05=int(s.sum()), up=int((s&(L[c]>0)).sum()), down=int((s&(L[c]<0)).sum()),
                     FDR05_absLFC1_expressed=int((s&(L[c].abs()>1)&(ae>0)).sum()),
                     FDR05_absLFC1_expressed_SElt1=int((s&(L[c].abs()>1)&(ae>0)&(SE[c]<1)).sum()),
                     FDR05_absLFC_lt0p25=int((s&(L[c].abs()<0.25)).sum()), FDR05_AveExpr_lt0=int((s&(ae<0)).sum())))
burden = pd.DataFrame(rows).sort_values('contrast'); burden.to_csv(f'{OUT}/invitro_DE_burden_per_contrast.csv', index=False)
# 2 reversal
rev_rows=[]
def robust(tp): return (Q[f'IL33vVeh_HUVEC_{tp}']<0.05)&(L[f'IL33vVeh_HUVEC_{tp}'].abs()>1)&(ae>0)&(SE[f'IL33vVeh_HUVEC_{tp}']<1)
for tp in ['6','24']:
    r = robust(tp); x = L.loc[r, f'IL33vVeh_HUVEC_{tp}']
    for ycol in [f'NeutIso_HUVEC_{tp}', f'NeutIso_HGMEC_6', f'NeutIso_HGMEC_24', f'Neut_HUVEC_{tp}', f'Ab_v_IC119_HUVEC_{tp}', f'Ab_v_IC119_HGMEC_{tp}']:
        y = L.loc[r, ycol]; s = stats.linregress(x, y); opp = (Q.loc[r, ycol]<0.05)&(np.sign(y)!=np.sign(x))
        rev_rows.append(dict(x=f'IL33vVeh_HUVEC_{tp}', y=ycol, n_genes=int(r.sum()), slope=round(s.slope,3), r=round(s.rvalue,3), p=s.pvalue,
                             median_pct_reversal=round(100*np.median(-y/x),1) if ycol.startswith('NeutIso_HUVEC') else None,
                             n_significantly_opposed=int(opp.sum())))
    iso = L[f'Neut_HUVEC_{tp}'] - L[f'NeutIso_HUVEC_{tp}']      # = (IL33+IC119) - IL33
    s = stats.linregress(x, iso[r]); rev_rows.append(dict(x=f'IL33vVeh_HUVEC_{tp}', y=f'derived: (IL33+IC119) - IL33, HUVEC {tp}h', n_genes=int(r.sum()), slope=round(s.slope,3), r=round(s.rvalue,3), p=s.pvalue))
    isoG = L[f'Neut_HGMEC_{tp}'] - L[f'NeutIso_HGMEC_{tp}']
    s = stats.linregress(x, isoG[r]); rev_rows.append(dict(x=f'IL33vVeh_HUVEC_{tp}', y=f'derived: (IL33+IC119) - IL33, HGMEC {tp}h', n_genes=int(r.sum()), slope=round(s.slope,3), r=round(s.rvalue,3), p=s.pvalue))
rev = pd.DataFrame(rev_rows); rev.to_csv(f'{OUT}/invitro_reversal_summary.csv', index=False)
# 3 per-gene signature table (IL-33 induced/repressed in HUVEC & opposed by AX-1177)
a = ann.copy()
for tp in ['6','24']:
    a[f'ind_{tp}'] = (Q[f'IL33vVeh_HUVEC_{tp}']<0.05)&(L[f'IL33vVeh_HUVEC_{tp}']>1)
    a[f'rev_{tp}'] = (Q[f'NeutIso_HUVEC_{tp}']<0.05)&(L[f'NeutIso_HUVEC_{tp}']<0)
    a[f'rep_{tp}'] = (Q[f'IL33vVeh_HUVEC_{tp}']<0.05)&(L[f'IL33vVeh_HUVEC_{tp}']<-1)
    a[f'res_{tp}'] = (Q[f'NeutIso_HUVEC_{tp}']<0.05)&(L[f'NeutIso_HUVEC_{tp}']>0)
    a[f'hg_{tp}'] = (Q[f'NeutIso_HGMEC_{tp}']<0.05)&(L[f'NeutIso_HGMEC_{tp}']<-1)
a['SIG_UP_HUVEC'] = (a.ind_6&a.rev_6)|(a.ind_24&a.rev_24)
a['SIG_DN_HUVEC'] = (a.rep_6&a.res_6)|(a.rep_24&a.res_24)
a['SIG_UP_HGMEC'] = a.hg_6|a.hg_24
a['SIG_UP_BOTH'] = a.SIG_UP_HUVEC & a.SIG_UP_HGMEC
a.to_pickle(f'{CACHE}/sig_annot.pkl')
cols = ['IL33vVeh_HUVEC_6','IL33vVeh_HUVEC_24','NeutIso_HUVEC_6','NeutIso_HUVEC_24','NeutIso_HGMEC_6','NeutIso_HGMEC_24','Ab_v_IC119_HUVEC_6','Ab_v_IC119_HGMEC_6']
sig = a[a.SIG_UP_HUVEC|a.SIG_DN_HUVEC|a.SIG_UP_HGMEC][['symbol','gene_name','AveExpr','SIG_UP_HUVEC','SIG_DN_HUVEC','SIG_UP_HGMEC','SIG_UP_BOTH']]
sig = sig.join(L[cols].round(3).add_prefix('log2FC_')).join(Q[cols].add_prefix('FDR_')).join(SE['IL33vVeh_HUVEC_6'].round(3).rename('SE_IL33vVeh_HUVEC_6'))
sig.sort_values('log2FC_IL33vVeh_HUVEC_6', ascending=False).to_csv(f'{OUT}/invitro_IL33_endothelial_signature_genes.csv')
print(burden.to_string()); print(rev.to_string())
print('signature sizes:', a[['SIG_UP_HUVEC','SIG_DN_HUVEC','SIG_UP_HGMEC','SIG_UP_BOTH']].sum().to_dict())
# 4 export t-stats for GSEA
out = pd.DataFrame({'symbol':ann.symbol, 'AveExpr':ae})
for c in ['IL33vVeh_HUVEC_6','IL33vVeh_HUVEC_24','NeutIso_HUVEC_6','NeutIso_HUVEC_24','NeutIso_HGMEC_6','NeutIso_HGMEC_24','Ab_v_IC119_HUVEC_6','Ab_v_IC119_HUVEC_24','Ab_v_IC119_HGMEC_6','Ab_v_IC119_HGMEC_24','Ab_v_IC119_A549_6','Ab_v_IC119_A549_24','Ab_v_IC119_MCF7_6','Ab_v_IC119_MCF7_24']:
    out['t_'+c] = T[c]
out.dropna(subset=['symbol']).to_csv(f'{CACHE}/t_for_gsea.tsv', sep='\t')
# molar ratio of the neutralisation experiment (from annex)
il33_nM = 30e-9/18100*1e9*1e3 ; ab_nM = 10e-6/146000*1e9*1e3
print(f'IL-33red {il33_nM:.2f} nM; AX-1177 {ab_nM:.1f} nM; molar excess {ab_nM/il33_nM:.0f}:1 (IgG bivalent: {2*ab_nM/il33_nM:.0f}:1 binding sites)')
