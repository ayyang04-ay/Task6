import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, textwrap
from matplotlib.patches import FancyBboxPatch
FIG_W, FIG_H = 15, 5.0
fig, ax = plt.subplots(figsize=(FIG_W, FIG_H)); ax.set_xlim(0, 100); ax.set_ylim(0, 60); ax.axis('off')
pt_per_unit = FIG_H*72/60
stages = [
 (0.5, 21, 'STAGE 0 | weeks 0-8\nData we already own', '#deebf7',
  ['Retrieve the 100 Olink assays counted in the BH correction but absent from the delivery (incl. IL-33; ~4 of them at q<0.05)',
   'Obtain patient-level NPX + clinical data (n=100; 44 events); re-fit at protein level; confirm the log scale',
   'Test incremental prognostic value of sST2 over age/sex/NEWS2 AND over IL-6 + HGF (dAUC, calibration, bootstrap cut-point)',
   'Re-fit RNA-seq per cell line from archived counts; add IL-33 vs isotype contrast for HGMEC; reconcile residual df (75 vs 76)',
   'Blinded second-reader IHC re-score at donor level; re-group donors by documented pathology']),
 (22.7, 8.2, 'GATE A', '#fdd0a2', ['GO if sST2 keeps independent value after IL-6 + HGF, and/or the IL-33 assay is informative', 'KILL if neither (cost to date: no new wet-lab spend)']),
 (32.0, 21, 'STAGE 1 | months 2-8\nDecisive human-sample + cell work', '#deebf7',
  ['High-sensitivity IL-33 (reduced / oxidised / total) and IL-33:sST2 complex in the 100 banked enrolment sera',
   'Patient-serum transfer: enrolment sera (sST2-high vs -low) on primary LUNG microvascular endothelium (>=3 donors) +/- AX-1177 vs isotype; 6 h read-out of the IL-33 panel',
   'Lung microvascular endothelium + primary airway epithelium: IL-33red AND IL-33ox, dose-response (IC50/IC90), 1-3-6-24 h, TNF / IL-1b comparators',
   'Protein read-outs: IL-6, CCL20, CCL7, OPG, CSF-1, IL-1b, tissue-factor activity, PAI-1']),
 (54.2, 8.2, 'GATE B', '#fdd0a2', ['GO if IL-33 is detectable and tracks outcome or sST2 AND AX-1177 blunts activation driven by patient serum', 'KILL if IL-33 is undetectable or unrelated AND no AX-1177 effect on patient sera']),
 (63.5, 17.5, 'STAGE 2 | months 8-18\nTranslational package', '#deebf7',
  ['External validation cohort spanning COVID-19, influenza/RSV and bacterial CAP (enrolment sera; same endpoint)',
   'In vivo viral pneumonia model (AX-1177 species cross-reactivity to be confirmed; not in our data)',
   'Clinical-grade assays: sST2 cut-point; total IL-33 target-engagement assay; PD panel']),
 (82.2, 17.3, 'GATE C -> Phase 1b/2a', '#c7e9c0',
  ['Hospitalised pneumonia, not on IMV, enrolled at admission; stratified by admission sST2',
   'Primary endpoint mirrors our cohort: ICU / IMV / death by day 30',
   'Samples: pre-dose at enrolment; 6 h and 24 h post-dose; day 3; day 7'])]
for x, w, title, col, lines in stages:
    ax.add_patch(FancyBboxPatch((x, 12.0), w, 42.5, boxstyle='round,pad=0.3', fc=col, ec='#555555', lw=0.8))
    ax.text(x+0.5, 53.5, title, va='top', ha='left', fontsize=8.5, weight='bold')
    fs = 6.9 if w > 10 else 6.6
    chars = int(w/100*FIG_W*72 / (fs*0.66))
    y = 46.5
    for l in lines:
        t = textwrap.fill(l, chars - (3 if w > 10 else 6), break_long_words=False, break_on_hyphens=False)
        ax.text(x+0.5, y, u'\u2022 ' + t.replace('\n', '\n   '), va='top', ha='left', fontsize=fs, linespacing=1.25)
        nlines = t.count('\n') + 1
        y -= nlines*fs*1.25*1.22/pt_per_unit + 1.3
ax.set_title('AX-1177: proposed gated de-risking plan (each gate is a keep/kill decision; cheapest and most decisive tests first)', fontsize=10.5, weight='bold')
plt.savefig('/tmp/outputs/figures/Fig4_gated_plan.png', dpi=170, bbox_inches='tight'); print('ok')
