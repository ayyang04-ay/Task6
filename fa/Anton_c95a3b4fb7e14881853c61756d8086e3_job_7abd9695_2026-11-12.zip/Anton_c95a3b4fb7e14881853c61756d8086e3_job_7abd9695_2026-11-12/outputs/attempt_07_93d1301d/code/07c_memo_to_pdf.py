"""Render the Markdown memo to PDF with reportlab (DejaVu fonts for Unicode). Run in the `core` env."""
import re, os, matplotlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, ListFlowable, ListItem
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping
F = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
pdfmetrics.registerFont(TTFont('DV', f'{F}/DejaVuSans.ttf')); pdfmetrics.registerFont(TTFont('DV-B', f'{F}/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DV-I', f'{F}/DejaVuSans-Oblique.ttf')); pdfmetrics.registerFont(TTFont('DV-BI', f'{F}/DejaVuSans-BoldOblique.ttf'))
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DV-B'); addMapping('DV', 0, 1, 'DV-I'); addMapping('DV', 1, 1, 'DV-BI')
ss = getSampleStyleSheet()
body = ParagraphStyle('b', parent=ss['Normal'], fontName='DV', fontSize=8.6, leading=11.2, spaceAfter=3)
h1 = ParagraphStyle('h1', parent=body, fontName='DV-B', fontSize=14, leading=17, spaceAfter=6, textColor=colors.HexColor('#08306b'))
h2 = ParagraphStyle('h2', parent=body, fontName='DV-B', fontSize=11.2, leading=14, spaceBefore=8, spaceAfter=4, textColor=colors.HexColor('#08519c'))
h3 = ParagraphStyle('h3', parent=body, fontName='DV-B', fontSize=9.6, leading=12, spaceBefore=6, spaceAfter=3, textColor=colors.HexColor('#2171b5'))
cell = ParagraphStyle('c', parent=body, fontSize=7.2, leading=8.9, spaceAfter=0)
cellh = ParagraphStyle('ch', parent=cell, fontName='DV-B')
def inline(s):
    s = s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    s = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', s)
    s = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'<i>\1</i>', s)
    s = re.sub(r'`(.+?)`', r'<font face="DV" color="#444444">\1</font>', s)
    return s
md = open('/tmp/outputs/AX-1177_portfolio_audit_memo.md', encoding='utf8').read().split('\n')
story = []; i = 0; W = A4[0] - 30*mm
def flush_list(items, ordered):
    if not items: return
    if ordered:
        lf = ListFlowable([ListItem(Paragraph(inline(t), body), leftIndent=12) for t in items], bulletType='1', bulletFormat='%s.', leftIndent=14, bulletFontName='DV', bulletFontSize=8)
    else:
        lf = ListFlowable([ListItem(Paragraph(inline(t), body), leftIndent=10) for t in items], bulletType='bullet', start='\u2022', leftIndent=12, bulletFontName='DV', bulletFontSize=7.5)
    story.append(lf)
while i < len(md):
    line = md[i]
    if line.startswith('# '): story.append(Paragraph(inline(line[2:]), h1)); i += 1; continue
    if line.startswith('## '): story.append(Paragraph(inline(line[3:]), h2)); i += 1; continue
    if line.startswith('### '): story.append(Paragraph(inline(line[4:]), h3)); i += 1; continue
    if line.strip() == '---': story.append(Spacer(1, 4)); i += 1; continue
    if line.startswith('|'):
        rows = []
        while i < len(md) and md[i].startswith('|'):
            r = [c.strip() for c in md[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r':?-{2,}:?', c) for c in r): rows.append(r)
            i += 1
        ncol = len(rows[0]); lens = [max(len(r[j]) if j < len(r) else 0 for r in rows) for j in range(ncol)]
        lens = [min(max(l, 8), 120) for l in lens]; tot = sum(lens); cw = [W*l/tot for l in lens]
        data = [[Paragraph(inline(c), cellh if k == 0 else cell) for c in r] for k, r in enumerate(rows)]
        t = Table(data, colWidths=cw, repeatRows=1)
        t.setStyle(TableStyle([('GRID', (0,0), (-1,-1), 0.3, colors.HexColor('#9ecae1')), ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#deebf7')),
                               ('VALIGN', (0,0), (-1,-1), 'TOP'), ('LEFTPADDING', (0,0), (-1,-1), 3), ('RIGHTPADDING', (0,0), (-1,-1), 3)]))
        story.append(t); story.append(Spacer(1, 5)); continue
    m = re.match(r'^(\s*)(- |\d+\. )(.*)$', line)
    if m:
        # collect a (possibly nested, 2 levels) list block
        block = []
        while i < len(md):
            mm_ = re.match(r'^(\s*)(- |\d+\. )(.*)$', md[i])
            if mm_:
                block.append([len(mm_.group(1)), mm_.group(2)[0].isdigit(), mm_.group(3)]); i += 1
            elif md[i].startswith('   ') and md[i].strip() and block:
                block[-1][2] += ' ' + md[i].strip(); i += 1
            else: break
        def build(items, level_indent):
            out = []; k = 0
            while k < len(items):
                ind, ordered, text = items[k]; k += 1
                kids = []
                while k < len(items) and items[k][0] > ind: kids.append(items[k]); k += 1
                content = [Paragraph(inline(text), body)]
                if kids:
                    kid_ordered = kids[0][1]
                    content.append(ListFlowable([ListItem(x, leftIndent=10) for x in build(kids, level_indent+1)],
                                   bulletType='1' if kid_ordered else 'bullet', bulletFormat='%s.' if kid_ordered else None,
                                   start=None if kid_ordered else '\u2013', leftIndent=12, bulletFontName='DV', bulletFontSize=7.5))
                out.append(content)
            return out
        top_ordered = block[0][1]
        items = build(block, 0)
        lf = ListFlowable([ListItem(x, leftIndent=12) for x in items], bulletType='1' if top_ordered else 'bullet',
                          bulletFormat='%s.' if top_ordered else None, start=None if top_ordered else '\u2022', leftIndent=14, bulletFontName='DV', bulletFontSize=8)
        story.append(lf); continue
    if line.strip() == '': i += 1; continue
    para = [line]; i += 1
    while i < len(md) and md[i].strip() and not re.match(r'^(#|\||- |\d+\. |---)', md[i]): para.append(md[i]); i += 1
    story.append(Paragraph(inline(' '.join(para)), body))
story.append(PageBreak()); story.append(Paragraph('Figures', h1))
caps = {'Fig1_invitro_pharmacology.png': 'Figure 1. In vitro pharmacology. A-B: AX-1177 reverses the IL-33red program in HUVEC (6 h, 24 h). C: differential-expression burden per contrast (antibody alone produces no coherent signal). D-E: the same program is opposed in glomerular endothelium (HGMEC) at 6 h but weakly at 24 h (no HGMEC vehicle arm). F: Hallmark pathways. Red open circles: canonical activation genes whose large fold changes are not statistically supported.',
        'Fig2_serum_proteomics.png': 'Figure 2. Serum proteomics (n = 100 hospitalised COVID-19; ICU / IMV / death by day 30). A: proteome-wide shift with severity; sST2 ranks 2nd of 1,064 proteins. B: the in vitro IL-33 endothelial program is not enriched among outcome-linked proteins. C: candidate markers, coloured by the strength of in vitro IL-33 evidence.',
        'Fig3_postmortem_IL33.png': 'Figure 3. Post-mortem lung IL-33 IHC at donor level (dot size = blocks per donor). No COVID-19-specific increase; block-level tests overstate differences. D: delivered group labels vs documented pathology.',
        'Fig4_gated_plan.png': 'Figure 4. Proposed gated de-risking plan with keep/kill gates.'}
for f, cap in caps.items():
    p = f'/tmp/outputs/figures/{f}'
    from PIL import Image as PI
    w, h = PI.open(p).size; iw = W; ih = iw*h/w
    if ih > 230*mm: ih = 230*mm; iw = ih*w/h
    story.append(Image(p, width=iw, height=ih)); story.append(Paragraph(inline(cap), ParagraphStyle('cap', parent=body, fontSize=7.6, leading=9.5, textColor=colors.HexColor('#333333'))))
    story.append(Spacer(1, 8))
def footer(c, d):
    c.saveState(); c.setFont('DV', 7); c.setFillColor(colors.grey)
    c.drawString(15*mm, 8*mm, 'AX-1177 portfolio audit - grounded in delivered AX-1177 data only'); c.drawRightString(A4[0]-15*mm, 8*mm, f'page {d.page}'); c.restoreState()
doc = SimpleDocTemplate('/tmp/outputs/AX-1177_portfolio_audit_memo.pdf', pagesize=A4, leftMargin=15*mm, rightMargin=15*mm, topMargin=14*mm, bottomMargin=14*mm,
                        title='AX-1177 portfolio audit memo', author='Portfolio analysis')
doc.build(story, onFirstPage=footer, onLaterPages=footer); print('pdf written')
