# AX-1177 portfolio audit: deliverables

| File | What it is |
|---|---|
| `AX-1177_portfolio_audit_memo.pdf` / `.md` | Committee memo: recommendation (keep, re-scoped and gated), evidence, defence, data-integrity findings, forward view (indication, must-establish studies with go/kill criteria, biomarker roles, sampling timepoint, staged plan), what would be dropped, and what was considered and ruled out. Figures are appended to the PDF. |
| `AX-1177_supporting_tables.xlsx` | 14 sheets: README, data-integrity log (19 items), in vitro DE burden, reversal analysis, IL-33 endothelial signature genes, Hallmark GSEA, serum protein-level table (duplicates collapsed), bridge test, selected serum axes, biomarker candidates with proposed roles, post-mortem donor-level table (with pathology re-read), group comparisons (donor vs block level), pathology-verified comparisons, IL-33 vs cell-marker correlations. |
| `figures/Fig1_invitro_pharmacology.png` | AX-1177 reversal of the IL-33 program (HUVEC 6/24 h, HGMEC 6/24 h), DE burden, Hallmark pathways. |
| `figures/Fig2_serum_proteomics.png` | Proteome-wide severity shift; sST2 rank; bridge test; candidate markers. |
| `figures/Fig3_postmortem_IL33.png` | Donor-level lung IL-33 IHC; donor vs block-level p-values; labels vs documented pathology. |
| `figures/Fig4_gated_plan.png` | Gated de-risking plan with keep/kill gates. |
| `tables/*.csv` | The same tables as CSV. |
| `code/` | Reproducible pipeline: 01 load/cache, 02 integrity checks, 03 in vitro, 04 fgsea (R), 05 serum, 05b post-mortem, 06/06b figures, 07a-c integrity log, workbook, PDF. Also `olink_map.py` (Olink name to HGNC) and `pm_curation.py` (per-donor pathology re-read). Python scripts run in the `singlecell` env (07c in `core`). Raw inputs are read from /tmp/world/filesystem. |
