import pandas as pd, numpy as np
from scipy import stats
allc = pd.read_pickle('/tmp/work/allc.pkl')
# 1. AveExpr constant per gene across all contrasts?
g = allc.groupby('ensembl')['AveExpr'].agg(['min','max','nunique','count'])
g['range'] = g['max']-g['min']
print('genes:', len(g), 'count per gene:', g['count'].value_counts().to_dict())
print('genes with AveExpr range>1e-6:', (g.range>1e-6).sum())
print(g.sort_values('range', ascending=False).head(20))
# 2. annotation consistent per gene?
for c in ['symbol','entrez','gene_name']:
    n = allc.groupby('ensembl')[c].nunique(dropna=False)
    print(c, 'genes with >1 distinct value:', (n>1).sum())
