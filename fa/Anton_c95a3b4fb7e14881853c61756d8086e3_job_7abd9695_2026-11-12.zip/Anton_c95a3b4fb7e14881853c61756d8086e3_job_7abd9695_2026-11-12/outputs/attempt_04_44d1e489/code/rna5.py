import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',400)
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
for tp, tpl in [('6','6_hrs'),('24','24_hrs')]:
    LV = W[f'IL33_vs_Nontreated_HUVEC_{tpl}']; qLV = Q[f'IL33_vs_Nontreated_HUVEC_{tpl}']
    LCL = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']; LCLI = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    LIL = LCL-LCLI
    d = pd.DataFrame({'sym':ann.symbol,'AveExpr':ann.AveExpr,'L_V':LV,'q':qLV,'LC_L':LCL,'LC_LI':LCLI,'LI_L':LIL,'LC_V':LV+LCL,'LI_V':LV+LIL})
    dn = d[(d.q<0.05)&(d.L_V<-1)].sort_values('L_V')
    print(f'==== {tp}h DOWN genes: n={len(dn)}')
    print(dn.head(40).round(2).to_string())
    # classify: "isotype-reversed" = LI_V near 0
    dn['iso_reversed'] = (dn.LI_V.abs() < 0.5*dn.L_V.abs())
    print('fraction of down genes where isotype also restores (|LI-V|<0.5|L-V|):', dn.iso_reversed.mean().round(3))
    up = d[(d.q<0.05)&(d.L_V>1)]
    up_iso = (up.LI_V.abs() < 0.5*up.L_V.abs())
    print('fraction of UP genes where isotype restores:', up_iso.mean().round(3))
    print('AveExpr of down genes median', dn.AveExpr.median(), ' up genes median', up.AveExpr.median())
