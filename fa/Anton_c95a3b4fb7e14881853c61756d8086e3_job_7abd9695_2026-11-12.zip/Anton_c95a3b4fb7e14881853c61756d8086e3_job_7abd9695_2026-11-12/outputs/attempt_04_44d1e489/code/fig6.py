import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
core = pd.read_pickle('/tmp/work/core.pkl')
sym2ens = ann.reset_index().dropna(subset=['symbol']).drop_duplicates('symbol').set_index('symbol').ensembl
genes = ['CSF2','CCL20','CXCL6','CSF3','IL6','TNFRSF11B','ICAM1','F3','C3','CXCL10','MX2','SELE','CXCL8']
labels = {'CSF2':'CSF2\n(GM-CSF)','CSF3':'CSF3\n(G-CSF)','TNFRSF11B':'TNFRSF11B\n(OPG)','F3':'F3\n(TF)','SELE':'SELE*','CXCL8':'CXCL8*'}
fig = plt.figure(figsize=(17,9))
gs = fig.add_gridspec(2,3, width_ratios=[1,1,0.75])
for row,(tp,tpl) in enumerate([('6','6_hrs'),('24','24_hrs')]):
    ax = fig.add_subplot(gs[row,0:2])
    LV = W[f'IL33_vs_Nontreated_HUVEC_{tpl}']; LCL = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']; LCLI = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    e = [sym2ens[g] for g in genes]
    L = LV[e].values; LI = (LV+LCL-LCLI)[e].values; LC = (LV+LCL)[e].values
    x = np.arange(len(genes)); w=0.27
    ax.bar(x-w, L, w, color='#c0392b', label='IL-33red')
    ax.bar(x, LI, w, color='#f1948a', label='IL-33red + isotype IC119')
    ax.bar(x+w, LC, w, color='#2c3e50', label='IL-33red + AX-1177')
    ax.axhline(0,c='k',lw=0.6)
    for i in range(len(genes)):
        inh = -LCL[e[i]]/LV[e[i]]*100
        ax.text(x[i]+w, max(LC[i],0)+0.25, f'{inh:.0f}%', ha='center', fontsize=7.5, color='#2c3e50')
    ax.set_xticks(x); ax.set_xticklabels([labels.get(g,g) for g in genes], fontsize=8.5)
    ax.set_ylabel(f'log2FC vs vehicle, HUVEC {tp} h'); ax.set_ylim(-2.2, 12.5)
    ax.set_title(f'{tp} h: response to IL-33 and % inhibition by AX-1177 (numbers above dark bars)', fontsize=10)
    if row==0: ax.legend(fontsize=8, loc='upper right')
# HGMEC panel
ax = fig.add_subplot(gs[0,2])
d, cu, cd = core['6']
xh = W['Compound_47_IL33_vs_IL33_HUVEC_6hrs'][cu]; yh = W['Compound_47_IL33_vs_IL33_HGMEC_6hrs'][cu]
ax.scatter(xh, yh, s=10, c='#c0392b', alpha=0.7, lw=0)
ax.plot([-13,1],[-13,1], ls='--', c='k', lw=0.7); ax.axhline(0,c='k',lw=0.5); ax.axvline(0,c='k',lw=0.5)
r = stats.spearmanr(xh,yh).statistic
ax.set_xlabel('AX-1177 effect in HUVEC 6 h (log2FC)'); ax.set_ylabel('AX-1177 effect in HGMEC 6 h (log2FC)')
ax.set_title(f'Glomerular microvascular EC (HGMEC): same genes reversed\n(core HUVEC genes, rho = {r:.2f}; 59% FDR<0.05 in HGMEC at 6 h, 17% at 24 h)\nNo HGMEC vehicle arm, so IL-33 effect size there is unknown', fontsize=8.5)
ax = fig.add_subplot(gs[1,2])
for tp,col in [('6','#c0392b'),('24','#2c3e50')]:
    tpl = tp+'_hrs'
    LV = W[f'IL33_vs_Nontreated_HUVEC_{tpl}']; LCL = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']; qq = Q[f'IL33_vs_Nontreated_HUVEC_{tpl}']
    sel = (qq<0.05)&(LV>1)
    inh = (-LCL/LV*100)[sel].clip(-50,200)
    ax.hist(inh, bins=np.arange(-50,205,10), histtype='step', lw=2, color=col, density=True, label=f'{tp} h (n={sel.sum()}, median {inh.median():.0f}%)')
ax.axvline(100, c='grey', ls=':', lw=1)
ax.set_xlabel('% inhibition of IL-33-induced genes by AX-1177'); ax.set_ylabel('density'); ax.legend(fontsize=8)
ax.set_title('Neutralisation is near-complete at 6 h and partial at 24 h\n(interferon-stimulated genes such as CXCL10, MX2 escape)', fontsize=9)
fig.suptitle('Figure 6. Time course of IL-33 activity and AX-1177 neutralisation (antibody added together with IL-33, no pre-incubation; single concentration)', fontsize=12)
fig.text(0.01,-0.01,'*SELE and CXCL8 log2FCs are valid group-mean differences, but their delivered P values are not (Figure 2). Group means are derived from contrasts of the same fitted model: IL-33+AX-1177 vs vehicle = (IL-33 vs vehicle) + (IL-33+AX-1177 vs IL-33).', fontsize=8, va='top')
plt.tight_layout()
plt.savefig('/tmp/outputs/figures/fig6_timecourse_and_markers.png', dpi=170, bbox_inches='tight')
print('ok')
