import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',400)
prot = pd.read_csv('/tmp/work/proteomics_mapped.csv')
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl')
core = pd.read_pickle('/tmp/work/core.pkl')
sym2ens = ann.reset_index().dropna(subset=['symbol']).drop_duplicates('symbol').set_index('symbol').ensembl
# collapse proteomics duplicates: keep the assay with the smallest p per base (report also n panels)
prot = prot.sort_values('p.value')
pu = prot.drop_duplicates('base').copy()
pu['n_panels'] = pu.base.map(prot.base.value_counts())
pu = pu[pu.rna_sym.notna()].copy()
pu['ens'] = pu.rna_sym.map(sym2ens)
for tp,tpl in [('6','6_hrs'),('24','24_hrs')]:
    pu[f'LV_{tp}'] = pu.ens.map(W[f'IL33_vs_Nontreated_HUVEC_{tpl}']); pu[f'qLV_{tp}'] = pu.ens.map(Q[f'IL33_vs_Nontreated_HUVEC_{tpl}'])
    pu[f'LCL_{tp}'] = pu.ens.map(W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']); pu[f'qLCL_{tp}'] = pu.ens.map(Q[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs'])
    d, cu, cd = core[tp]
    pu[f'coreUP_{tp}'] = pu.ens.map(cu).fillna(False).astype(bool)
    pu[f'coreDN_{tp}'] = pu.ens.map(cd).fillna(False).astype(bool)
pu['coreUP_any'] = pu.coreUP_6 | pu.coreUP_24
pu['sev_q05'] = (pu['adj.p.value']<0.05) & (pu.OR>1)
pu['sev_p05'] = (pu['p.value']<0.05) & (pu.OR>1)
pu['z'] = stats.norm.isf(pu['p.value']/2)*np.sign(np.log(pu.OR))
print('unique mapped proteins:', len(pu), '; core-UP (6h or 24h) proteins:', pu.coreUP_any.sum())
for flag in ['coreUP_6','coreUP_24','coreUP_any']:
    for sev in ['sev_q05','sev_p05']:
        tab = pd.crosstab(pu[flag], pu[sev])
        orr, p = stats.fisher_exact(tab.values)
        print(f'{flag} x {sev}: table={tab.values.tolist()} OR={orr:.2f} p={p:.3g}; frac severe among core={pu.loc[pu[flag],sev].mean():.2f} vs others={pu.loc[~pu[flag],sev].mean():.2f}')
    u = stats.mannwhitneyu(pu.loc[pu[flag],'z'], pu.loc[~pu[flag],'z'], alternative='greater')
    print(f'   signed-z Mann-Whitney (core>others): p={u.pvalue:.3g}; median z core={pu.loc[pu[flag],"z"].median():.2f} others={pu.loc[~pu[flag],"z"].median():.2f}')
cols = ['base','rna_sym','n_panels','OR','l95','u95','p.value','adj.p.value','LV_6','qLV_6','LCL_6','LV_24','qLV_24','LCL_24','coreUP_6','coreUP_24']
print(pu[pu.coreUP_any].sort_values('p.value')[cols].round(4).to_string(index=False))
pu.to_pickle('/tmp/work/bridge.pkl')
