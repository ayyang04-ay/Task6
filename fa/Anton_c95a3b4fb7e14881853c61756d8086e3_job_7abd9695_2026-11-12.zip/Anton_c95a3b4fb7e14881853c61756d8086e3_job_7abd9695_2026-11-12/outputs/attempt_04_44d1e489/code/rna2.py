import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',400)
allc = pd.read_pickle('/tmp/work/allc2.pkl')
cons = [c for c in allc.Comparison.unique() if c.startswith('Compound_47_vs_')]
for c in cons:
    d = allc[(allc.Comparison==c)&(allc['adj.P.Val']<0.05)].sort_values('P.Value')
    print('=====', c, len(d))
    print(d[['symbol','logFC','AveExpr','t','P.Value','adj.P.Val','SE']].head(25).to_string(index=False))
