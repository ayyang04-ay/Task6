import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
don = pd.read_pickle('/tmp/work/pm_donor2.pkl').reset_index()
df = pd.read_pickle('/tmp/work/pm.pkl')
for v in ['IL33_epi','IL33_endo','IL33_vsmc','EPX_o','EDN_o','MBP_o']:
    df[v] = pd.to_numeric(df[v], errors='coerce')
don['covid'] = don.SARS2=='pos'
order = ['COVID+ acute lung injury/pneumonia','COVID+ no acute pneumonia','COVID- acute pneumonia','COVID- no acute pneumonia']
short = {'COVID+ acute lung injury/pneumonia':'COVID+\nacute LI/pna','COVID+ no acute pneumonia':'COVID+\nno acute pna','COVID- acute pneumonia':'COVID-\nacute pna','COVID- no acute pneumonia':'COVID-\nno acute pna'}
cols = {'COVID+ acute lung injury/pneumonia':'#c0392b','COVID+ no acute pneumonia':'#e6b0aa','COVID- acute pneumonia':'#2e86c1','COVID- no acute pneumonia':'#aed6f1'}
fig, axes = plt.subplots(2,3, figsize=(16,9.5))
rng = np.random.default_rng(1)
def strip(ax, v, title):
    for i,g in enumerate(order):
        vals = don.loc[don.group_path==g, v].dropna().values
        ax.scatter(i+rng.uniform(-0.15,0.15,len(vals)), vals, c=cols[g], s=45, edgecolors='k', lw=0.4)
        if len(vals): ax.plot([i-0.25,i+0.25],[np.median(vals)]*2, c='k', lw=2)
    ax.set_xticks(range(4)); ax.set_xticklabels([short[g] for g in order], fontsize=8)
    a = don.loc[don.covid, v].dropna(); b = don.loc[~don.covid, v].dropna()
    p = stats.mannwhitneyu(a,b).pvalue
    pb = stats.mannwhitneyu(df.loc[df.SARS2_donor=='pos', v].dropna(), df.loc[df.SARS2_donor!='pos', v].dropna()).pvalue
    ax.set_title(f'{title}\nCOVID+ vs COVID- (donors): p = {p:.3f}   [naive block-level p = {pb:.3f}]', fontsize=9)
    ax.set_ylim(-0.3, 5.9); ax.axhline(5, ls=':', c='grey', lw=0.8); ax.text(3.3, 5.05, 'documented max (5)', fontsize=7, color='grey', ha='right')
strip(axes[0,0], 'IL33_endo', 'IL-33, endothelial cells (donor median of blocks)')
strip(axes[0,1], 'IL33_vsmc', 'IL-33, vascular smooth muscle')
strip(axes[0,2], 'IL33_epi', 'IL-33, bronchial/bronchiolar basal epithelium')
ax = axes[1,0]
for cv,col,lab in [(True,'#c0392b','COVID+'),(False,'#2e86c1','COVID-')]:
    d = don[don.covid==cv]
    ax.scatter(d.Age, d.IL33_endo + rng.uniform(-0.05,0.05,len(d)), c=col, s=45, edgecolors='k', lw=0.4, label=lab)
r,p = stats.spearmanr(don.Age, don.IL33_endo)
ax.set_xlabel('age at death (years)'); ax.set_ylabel('IL-33 endothelial score')
ax.set_title(f'Endothelial IL-33 tracks age (Spearman rho = {r:.2f}, p = {p:.3f});\nCOVID effect after age adjustment: p = 0.10 (rank regression)', fontsize=9); ax.legend(fontsize=8)
ax = axes[1,1]
for j,(v,lab) in enumerate([('EPX_o','EPX'),('EDN_o','EDN'),('MBP_o','MBP')]):
    for k,(cv,col) in enumerate([(True,'#c0392b'),(False,'#2e86c1')]):
        vals = don.loc[don.covid==cv, v].dropna().values
        xpos = j*1.0 + (k-0.5)*0.35
        ax.scatter(xpos+rng.uniform(-0.08,0.08,len(vals)), vals, c=col, s=30, edgecolors='k', lw=0.3)
        ax.plot([xpos-0.12,xpos+0.12],[np.median(vals)]*2,c='k',lw=2)
    pp = stats.mannwhitneyu(don.loc[don.covid, v].dropna(), don.loc[~don.covid, v].dropna()).pvalue
    ax.text(j, 3.8, f'p={pp:.2f}', ha='center', fontsize=8)
ax.set_xticks([0,1,2]); ax.set_xticklabels(['EPX','EDN','MBP']); ax.set_ylim(-0.3,4.2)
ax.set_title('Eosinophil granule proteins (IHC, donor medians)\nred = COVID+ (n=16), blue = COVID- (n=15): no COVID-specific eosinophilia', fontsize=9)
ax = axes[1,2]; ax.axis('off')
txt = ("Data-quality flags (post-mortem file)\n\n"
 "- 74 blocks from 31 donors; 3 COVID+ donors supply 24 of 49\n  COVID+ blocks -> analyse per donor, not per block.\n"
 "- Disease labels vs pathology text: 4/10 'COVID-neg pneumonia'\n  donors have no pneumonia recorded; 2/5 'non-pneumonia'\n  controls have pneumonia/pneumonitis; 1 control has pulmonary\n  coccidioidomycosis; 2/16 COVID+ lack acute pneumonia;\n  1 donor has no SARS-CoV-2 result.\n"
 "- IL-33 scores reach 5.5 on a documented 0-5 scale; numeric\n  columns use an undocumented transform (1+ -> 1.5 ... 5+ -> 5.5).\n"
 "- Epithelial/endothelial IL-33 identical across all blocks in\n  ~half of multi-block donors; endothelial IL-33 near ceiling\n  in controls. Single reader, semi-quantitative.\n"
 "- Elderly (64-98 y), all white, heavy CV/COPD comorbidity;\n  end-stage tissue only.\n\n"
 "Groups above are re-derived from the pathology text\n(LI = lung injury/DAD; pna = pneumonia).")
ax.text(0, 1, txt, va='top', fontsize=8.5, family='monospace')
fig.suptitle('Figure 5. Post-mortem lung: IL-33 is constitutive in epithelium and endothelium and is not increased in COVID-19; no COVID-specific eosinophilia', fontsize=12)
plt.tight_layout()
plt.savefig('/tmp/outputs/figures/fig5_postmortem_lung.png', dpi=170, bbox_inches='tight')
print('ok')
