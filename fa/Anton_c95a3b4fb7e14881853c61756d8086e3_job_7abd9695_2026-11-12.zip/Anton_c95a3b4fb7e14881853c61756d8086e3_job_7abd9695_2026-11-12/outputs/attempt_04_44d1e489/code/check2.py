import pandas as pd, numpy as np
from scipy import stats, optimize
allc = pd.read_pickle('/tmp/work/allc.pkl')
# implied df: solve 2*t.sf(|t|, df) = P
sub = allc[(allc.t.abs()>0.5)&(allc.t.abs()<8)].sample(20000, random_state=1)
def implied_df(t,p):
    f = lambda lg: 2*stats.t.sf(abs(t), np.exp(lg)) - p
    try:
        return np.exp(optimize.brentq(f, np.log(0.5), np.log(1e6)))
    except Exception:
        return np.nan
sub['df_impl'] = [implied_df(t,p) for t,p in zip(sub.t, sub['P.Value'])]
print(sub.df_impl.describe())
print(sub.df_impl.round(1).value_counts().head(20))
print(sub.groupby('Comparison').df_impl.median())
