import pandas as pd, numpy as np, sys
sys.path.insert(0,'/tmp/work')
from olinkmap import M, ALT
pd.set_option('display.width',250); pd.set_option('display.max_rows',400)
prot = pd.read_csv('/tmp/work/proteomics_base.csv')
ann = pd.read_pickle('/tmp/work/ann.pkl')
syms = set(ann.symbol.dropna())
prot['gene'] = prot.base.map(lambda b: M.get(b, b))
def resolve(g):
    if g in syms: return g
    for a in ALT.get(g, []):
        if a in syms: return a
    return None
prot['rna_sym'] = prot.gene.map(resolve)
print('mapped to RNA symbol:', prot.rna_sym.notna().sum(), '/', len(prot), '; unique bases mapped:', prot[prot.rna_sym.notna()].base.nunique(), '/', prot.base.nunique())
print('unmapped:', sorted(prot[prot.rna_sym.isna()].base.unique()))
prot.to_csv('/tmp/work/proteomics_mapped.csv', index=False)
