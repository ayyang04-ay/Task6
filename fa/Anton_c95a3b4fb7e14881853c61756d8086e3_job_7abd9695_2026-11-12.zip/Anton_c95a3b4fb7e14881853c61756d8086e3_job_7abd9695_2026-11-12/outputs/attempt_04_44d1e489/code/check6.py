import pandas as pd, numpy as np
allc = pd.read_pickle('/tmp/work/allc2.pkl')
pd.set_option('display.width',250)
endo = allc[allc.Comparison.str.contains('HUVEC|HGMEC|Nontreated')]
g = endo.groupby(['ensembl','symbol'], dropna=False).agg(medSE=('absSE','median'), AveExpr=('AveExpr','first'),
      maxabsFC=('logFC', lambda x: x.abs().max())).reset_index()
print(g.medSE.describe(percentiles=[.5,.9,.99,.999]))
print('n genes medSE>2:', (g.medSE>2).sum(), ' >3:', (g.medSE>3).sum(), ' >5:', (g.medSE>5).sum())
print(g.sort_values('medSE', ascending=False).head(40).to_string(index=False))
# relationship between SE and AveExpr
g['bin'] = pd.cut(g.AveExpr, [-10,-4,-3,-2,-1,0,1,2,4,6,8,20])
print(g.groupby('bin').medSE.describe())
