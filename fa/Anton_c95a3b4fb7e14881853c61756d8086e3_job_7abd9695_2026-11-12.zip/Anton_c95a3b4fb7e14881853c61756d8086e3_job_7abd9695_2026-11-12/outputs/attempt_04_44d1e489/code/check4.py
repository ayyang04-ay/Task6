import pandas as pd, numpy as np
allc = pd.read_pickle('/tmp/work/allc2.pkl')
pd.set_option('display.width',250)
genes = ['SELE','VCAM1','CXCL8','CXCL1','ICAM1','CSF2','IL6','IL1RL1','IL33','IL1RAP','MYD88']
for g in genes:
    d = allc[allc.symbol==g]
    d = d[d.Comparison.str.contains('HUVEC|Nontreated')]
    print('====', g)
    print(d[['Comparison','logFC','AveExpr','t','P.Value','adj.P.Val','B','SE']].to_string(index=False))
