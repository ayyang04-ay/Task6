import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',400)
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl'); SE = pd.read_pickle('/tmp/work/SEw.pkl')
out = {}
for tp, tpl in [('6','6_hrs'),('24','24_hrs')]:
    LV = W[f'IL33_vs_Nontreated_HUVEC_{tpl}']; qLV = Q[f'IL33_vs_Nontreated_HUVEC_{tpl}']
    LCL = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']; qLCL = Q[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']
    LCLI = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']; qLCLI = Q[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    LIL = LCL-LCLI
    core_up = (qLV<0.05)&(LV>1)&(qLCL<0.05)&(LCL<0)&(qLCLI<0.05)&(LCLI<0)&(LIL.abs()<0.5*LV.abs())
    core_dn = (qLV<0.05)&(LV<-1)&(qLCL<0.05)&(LCL>0)&(qLCLI<0.05)&(LCLI>0)&(LIL.abs()<0.5*LV.abs())
    print(f'HUVEC {tp}h core UP: {core_up.sum()}  core DOWN: {core_dn.sum()}')
    d = pd.DataFrame({'sym':ann.symbol,'AveExpr':ann.AveExpr,'L_V':LV,'qLV':qLV,'LC_L':LCL,'LC_LI':LCLI,'LI_L':LIL,'pct_inh':-LCL/LV*100,
                      'HGMEC_LC_L':W[f'Compound_47_IL33_vs_IL33_HGMEC_{tp}hrs'],'HGMEC_q':Q[f'Compound_47_IL33_vs_IL33_HGMEC_{tp}hrs'],
                      'HGMEC_LC_LI':W[f'Compound_47_IL33_vs_IL33_IC119_HGMEC_{tp}hrs']})
    out[tp] = (d, core_up, core_dn)
    print(d[core_up].sort_values('L_V', ascending=False).head(60).round(2).to_string())
    print('core DOWN genes:'); print(d[core_dn].sort_values('L_V').head(30).round(2).to_string())
pd.to_pickle(out, '/tmp/work/core.pkl')
