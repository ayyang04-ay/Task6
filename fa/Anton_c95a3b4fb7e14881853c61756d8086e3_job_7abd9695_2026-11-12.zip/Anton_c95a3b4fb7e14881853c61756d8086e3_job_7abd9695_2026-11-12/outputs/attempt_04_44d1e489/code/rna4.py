import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',400)
allc = pd.read_pickle('/tmp/work/allc2.pkl')
W = allc.pivot(index='ensembl', columns='Comparison', values='logFC')
T = allc.pivot(index='ensembl', columns='Comparison', values='t')
Q = allc.pivot(index='ensembl', columns='Comparison', values='adj.P.Val')
SE = allc.pivot(index='ensembl', columns='Comparison', values='absSE')
ann = allc.drop_duplicates('ensembl').set_index('ensembl')[['symbol','AveExpr','gene_name']]
W.to_pickle('/tmp/work/W.pkl'); T.to_pickle('/tmp/work/T.pkl'); Q.to_pickle('/tmp/work/Q.pkl'); SE.to_pickle('/tmp/work/SEw.pkl'); ann.to_pickle('/tmp/work/ann.pkl')
for tp, tpl in [('6','6_hrs'),('24','24_hrs')]:
    LV = W[f'IL33_vs_Nontreated_HUVEC_{tpl}']; qLV = Q[f'IL33_vs_Nontreated_HUVEC_{tpl}']
    LCL = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']; LCLI = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    LIL = LCL - LCLI   # isotype effect on IL-33 response: (LI - L)
    LCV = LV + LCL     # residual response with AX-1177
    LIV = LV + LIL     # IL-33 + isotype vs vehicle
    sel = (qLV<0.05)&(LV.abs()>1)
    up = sel&(LV>0); dn = sel&(LV<0)
    print(f'==== HUVEC {tp}h: IL-33 responsive genes (FDR<.05,|lfc|>1): {sel.sum()} (up {up.sum()}, down {dn.sum()})')
    for name, s in [('up',up),('down',dn),('all',sel)]:
        x = LV[s]; y = LCL[s]; yi = LCLI[s]
        slope = np.polyfit(x, y, 1)[0]; slope_i = np.polyfit(x, yi, 1)[0]
        r = stats.pearsonr(x,y)[0]
        inh = (-y/x*100)
        inh_i = (-yi/(x+LIL[s])*100)
        print(f'  {name}: slope(LC-L ~ L-V)={slope:.3f}, r={r:.3f}; slope(LC-LI ~ L-V)={slope_i:.3f}; median %inhibition vs IL33={inh.median():.1f}% (IQR {inh.quantile(.25):.1f}-{inh.quantile(.75):.1f}); vs IL33+IC119={inh_i.median():.1f}%')
        print(f'     residual |LC-V| median={LCV[s].abs().median():.3f}; isotype effect |LI-L| median={LIL[s].abs().median():.3f}; corr(LI-L, L-V)={stats.pearsonr(x, LIL[s])[0]:.3f}; slope(LI-L ~ L-V)={np.polyfit(x, LIL[s],1)[0]:.3f}')
    # fraction of responsive genes significantly reversed
    qLCL = Q[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']
    rev = sel & (qLCL<0.05) & (np.sign(LCL)==-np.sign(LV))
    print(f'  responsive genes significantly reversed by AX-1177 (FDR<.05 opposite sign): {rev.sum()} / {sel.sum()} ({rev.sum()/sel.sum()*100:.1f}%)')
    # genes significantly reversed with >=80% inhibition
    inh_all = -LCL/LV*100
    print('  %inhibition distribution among responsive:', inh_all[sel].describe(percentiles=[.05,.1,.25,.5,.75,.9,.95]).round(1).to_dict())
