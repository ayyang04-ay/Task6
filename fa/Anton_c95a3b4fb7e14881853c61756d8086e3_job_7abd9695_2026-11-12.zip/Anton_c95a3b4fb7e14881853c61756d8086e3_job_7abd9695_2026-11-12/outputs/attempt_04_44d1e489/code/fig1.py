import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from adjustText import adjust_text
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl'); SE = pd.read_pickle('/tmp/work/SEw.pkl')
core = pd.read_pickle('/tmp/work/core.pkl')
endo_cols = [c for c in SE.columns if ('HUVEC' in c or 'HGMEC' in c)]
medSE = SE[endo_cols].median(axis=1)
infl = medSE>3
lab = {'CSF2':'CSF2 (GM-CSF)','CCL20':'CCL20','CXCL6':'CXCL6','CSF3':'CSF3 (G-CSF)','IL6':'IL6','TNFRSF11B':'TNFRSF11B (OPG)','ICAM1':'ICAM1','F3':'F3 (tissue factor)','CX3CL1':'CX3CL1','TNF':'TNF','CXCL10':'CXCL10','SELE':'SELE*','VCAM1':'VCAM1*','CXCL8':'CXCL8*','CXCL1':'CXCL1*','C3':'C3','MX2':'MX2'}
sym2ens = ann.reset_index().dropna(subset=['symbol']).drop_duplicates('symbol').set_index('symbol').ensembl
fig, axes = plt.subplots(1,3, figsize=(19,6.3))
def panel(ax, tp, tpl, mode):
    d, cu, cd = core[tp]
    LV = W[f'IL33_vs_Nontreated_HUVEC_{tpl}']
    LCL = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']; LCLI = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    y = LCL if mode=='ab' else (LCL-LCLI)
    qq = Q[f'IL33_vs_Nontreated_HUVEC_{tpl}']
    ru = (qq<0.05)&(LV>1)&~infl; rd = (qq<0.05)&(LV<-1)&~infl
    other = ~(ru|rd|infl)
    ax.scatter(LV[other], y[other], s=3, c='#c8c8c8', alpha=0.5, lw=0, label='other genes', rasterized=True)
    ax.scatter(LV[rd], y[rd], s=9, c='#3b6fb6', alpha=0.7, lw=0, label=f'IL-33-repressed (FDR<0.05, log2FC<-1; n={rd.sum()})')
    ax.scatter(LV[ru], y[ru], s=9, c='#c0392b', alpha=0.7, lw=0, label=f'IL-33-induced (FDR<0.05, log2FC>1; n={ru.sum()})')
    sel_inf = infl & (LV.abs()>2)
    ax.scatter(LV[sel_inf], y[sel_inf], s=40, facecolors='none', edgecolors='#8e44ad', lw=1.2, marker='^', label='inflated-variance genes* (P uninformative)')
    lim = 13
    ax.plot([-lim,lim],[lim,-lim], ls='--', c='k', lw=0.8)
    ax.axhline(0,c='k',lw=0.5); ax.axvline(0,c='k',lw=0.5)
    up = (LV>1)&(Q[f'IL33_vs_Nontreated_HUVEC_{tpl}']<0.05)
    s_up = np.polyfit(LV[up], y[up], 1)[0]
    texts=[]
    for s,l in lab.items():
        if s in sym2ens and sym2ens[s] in LV.index:
            e = sym2ens[s]
            if abs(LV[e])>2:
                texts.append(ax.text(LV[e], y[e], l, fontsize=8))
    adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='grey', lw=0.5))
    ax.set_xlim(-6, 12.5); ax.set_ylim(-13, 6)
    ax.set_xlabel(f'IL-33red vs vehicle, HUVEC {tp} h (log2FC)')
    if mode=='ab':
        ax.set_ylabel('(IL-33red + AX-1177) vs IL-33red (log2FC)')
        ax.set_title(f'AX-1177 reverses the IL-33 response, {tp} h\nslope (IL-33-induced genes) = {s_up:.2f}; dashed line = complete reversal', fontsize=10)
    else:
        ax.set_ylabel('(IL-33red + isotype IC119) vs IL-33red (log2FC)')
        dn = (LV<-1)&(Q[f'IL33_vs_Nontreated_HUVEC_{tpl}']<0.05)
        s_dn = np.polyfit(LV[dn], y[dn], 1)[0]
        ax.set_title(f'Isotype has no effect on IL-33-induced genes (slope {s_up:.2f}), {tp} h\nbut also "reverses" IL-33-repressed genes (slope {s_dn:.2f}): not IL-33 biology', fontsize=10)
    ax.legend(fontsize=7, loc='lower left')
panel(axes[0],'6','6_hrs','ab'); panel(axes[1],'6','6_hrs','iso'); panel(axes[2],'24','24_hrs','ab')
fig.suptitle('Figure 1. AX-1177 (Compound_47, 10 µg/mL) neutralises reduced IL-33 (30 ng/mL) signalling in HUVEC; isotype IC119 does not', fontsize=12, y=1.0)
fig.text(0.01,-0.03,'*SELE, VCAM1, CXCL8, CXCL1 (and IL1RL1) have gene-wise SEs of 4 to >1,000 log2 units in the delivered single pooled model, so their P values are not interpretable; their log2FCs (group-mean differences) are.\n'
         'Most IL-33-repressed genes are low-count lncRNAs/pseudogenes that the isotype also restores, so they are an artefact of the IL-33-alone group, not IL-33 signalling. Only the induced programme is used downstream.\nSource: AX-1177_rnaseq_huvec_il33.xlsx (IL-33 vs vehicle) and AX-1177_rnaseq_contrasts.xlsx (AX-1177/isotype contrasts); isotype effect = (IL33+AX-1177 vs IL33) - (IL33+AX-1177 vs IL33+IC119).', fontsize=8, va='top')
plt.tight_layout()
plt.savefig('/tmp/outputs/figures/fig1_invitro_neutralisation.png', dpi=170, bbox_inches='tight')
print('ok')
