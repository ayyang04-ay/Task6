# Convert the delivered Excel files to CSV (run in an env with pandas+openpyxl, e.g. `mm singlecell python`).
import pandas as pd, os
IN = '/tmp/world/filesystem'; OUT = '/tmp/work'; os.makedirs(OUT, exist_ok=True)
xl = pd.ExcelFile(f'{IN}/AX-1177_rnaseq_contrasts.xlsx', engine='openpyxl')
for s in xl.sheet_names:            # sheets '6h' and '24h' (each actually holds all 24 contrasts)
    xl.parse(s).to_csv(f'{OUT}/contrasts_{s}.csv', index=False)
xl = pd.ExcelFile(f'{IN}/AX-1177_rnaseq_huvec_il33.xlsx', engine='openpyxl')
for s in xl.sheet_names:
    xl.parse(s).to_csv(f'{OUT}/huvec_{s}.csv', index=False)
pd.read_excel(f'{IN}/AX-1177_serum_proteomics.xlsx').to_csv(f'{OUT}/proteomics.csv', index=False)
pd.read_excel(f'{IN}/AX-1177_postmortem_lung.xlsx').to_csv(f'{OUT}/postmortem.csv', index=False)
# proteomics: strip panel suffixes to get one key per protein
p = pd.read_csv(f'{OUT}/proteomics.csv')
sfx = ['INFI','CVDII','ONCII','CRE','IMO','CVDIII','ODA','MET','NEX','NEUI','DEV','CM','ONCIII','NEU']
p['base'] = p.assay.str.replace(r'-(?:' + '|'.join(sfx) + r')$', '', regex=True)
p.to_csv(f'{OUT}/proteomics_base.csv', index=False)
print('converted')
