import pandas as pd, numpy as np
from scipy import stats
pu = pd.read_pickle('/tmp/work/bridge.pkl')
SE = pd.read_pickle('/tmp/work/SEw.pkl')
pu['SE6'] = pu.ens.map(SE['IL33_vs_Nontreated_HUVEC_6_hrs'])
ok = pu.SE6<2  # exclude inflated-variance genes
for tp in ['6','24']:
    for sub,name in [(pu.index==pu.index,'all'),(ok,'SE<2')]:
        d = pu[sub]
        r,pv = stats.spearmanr(d[f'LV_{tp}'], d.z)
        r2,pv2 = stats.spearmanr(-d[f'LCL_{tp}'], d.z)
        print(f'{tp}h {name:5s} n={len(d)}: Spearman(IL33 logFC, serum z)={r:+.3f} p={pv:.2g}; Spearman(AX-1177 reversal, serum z)={r2:+.3f} p={pv2:.2g}')
# restrict to strongly induced genes: does induction magnitude predict severity?
d = pu[(pu.qLV_6<0.05)&(pu.LV_6>1)]
print('among IL33-induced (n=%d): Spearman(logFC, z)=%.3f p=%.2g' % ((len(d),)+stats.spearmanr(d.LV_6, d.z)))
# permutation-based enrichment with size-matched random sets for core_any vs q<0.05
rng = np.random.default_rng(0)
obs = pu.loc[pu.coreUP_any,'sev_q05'].mean()
k = pu.coreUP_any.sum()
null = [pu.sev_q05.sample(k, random_state=int(s)).mean() for s in rng.integers(0,1e9,5000)]
print(f'core-UP frac severe (q<0.05) = {obs:.3f}; null mean={np.mean(null):.3f}; perm p(>=obs)={np.mean(np.array(null)>=obs):.3f}')
