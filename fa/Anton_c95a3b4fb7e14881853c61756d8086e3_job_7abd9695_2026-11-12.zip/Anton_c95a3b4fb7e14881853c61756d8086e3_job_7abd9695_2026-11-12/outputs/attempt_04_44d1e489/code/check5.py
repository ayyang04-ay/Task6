import pandas as pd, numpy as np
allc = pd.read_pickle('/tmp/work/allc2.pkl')
pd.set_option('display.width',250)
genes = ['SELE','CXCL1','IL1RL1','CSF2']
for g in genes:
    d = allc[allc.symbol==g]
    print('====', g)
    print(d[['Comparison','logFC','t','P.Value','adj.P.Val','SE']].to_string(index=False))
