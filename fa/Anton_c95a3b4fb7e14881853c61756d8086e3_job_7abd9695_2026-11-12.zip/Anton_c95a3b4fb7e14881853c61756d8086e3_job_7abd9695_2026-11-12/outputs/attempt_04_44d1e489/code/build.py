import pandas as pd, numpy as np
a = pd.read_csv('/tmp/work/contrasts_6h.csv', dtype={'entrez':str})
h6 = pd.read_csv('/tmp/work/huvec_IL33_vs_Vehicle_HUVEC_6_hrs.csv', dtype={'entrez':str})
h24 = pd.read_csv('/tmp/work/huvec_IL33_vs_Vehicle_HUVEC_24_hrs.csv', dtype={'entrez':str})
h6['src']='huvec_file'; h24['src']='huvec_file'; a['src']='contrasts_file'
allc = pd.concat([a,h6,h24], ignore_index=True)
allc.to_pickle('/tmp/work/allc.pkl')
print(allc.shape, allc.Comparison.nunique())
