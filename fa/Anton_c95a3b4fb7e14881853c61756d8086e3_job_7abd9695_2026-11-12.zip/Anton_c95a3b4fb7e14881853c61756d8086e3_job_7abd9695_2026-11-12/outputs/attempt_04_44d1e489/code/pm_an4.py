import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',300)
df = pd.read_pickle('/tmp/work/pm.pkl')
for v in ['EPX_o','EDN_o','MBP_o','2D7_o','NE_dIL5Ra_o','Try_dIL5Ra_o','IL5Ra_dNE_o','IL33_epi','IL33_endo','IL33_vsmc']:
    df[v] = pd.to_numeric(df[v], errors='coerce')
df['covid'] = (df.SARS2_donor=='pos').astype(int)
print('=== naive BLOCK-level tests (pseudo-replicated) vs donor-level')
don = pd.read_pickle('/tmp/work/pm_donor2.pkl')
don['covid'] = (don.SARS2=='pos').astype(int)
for v in ['IL33_epi','IL33_endo','IL33_vsmc','EDN_o','2D7_o','NE_dIL5Ra_o']:
    a = df.loc[df.covid==1, v].dropna(); b = df.loc[df.covid==0, v].dropna()
    pb = stats.mannwhitneyu(a,b).pvalue
    ad = don.loc[don.covid==1, v].dropna(); bd = don.loc[don.covid==0, v].dropna()
    pdn = stats.mannwhitneyu(ad,bd).pvalue
    # mixed model with donor random intercept (treating score as continuous, sensitivity only)
    d = df[['SampleID','covid',v]].dropna().rename(columns={v:'y'})
    try:
        m = smf.mixedlm('y ~ covid', d, groups=d.SampleID).fit(reml=True)
        pm = m.pvalues['covid']; coef = m.params['covid']
    except Exception as e:
        pm = np.nan; coef=np.nan
    print(f'{v:12s} blocks n={len(a)}+{len(b)} p={pb:.4f} | donors n={len(ad)}+{len(bd)} p={pdn:.4f} | mixed-model coef={coef:.2f} p={pm:.4f}')
# ICC of blocks within donors
print('=== within-donor (between-block) variability, donors with >=2 blocks')
for v in ['IL33_epi','IL33_endo','IL33_vsmc','EPX_o','NE_dIL5Ra_o']:
    d = df[['SampleID',v]].dropna()
    d = d[d.SampleID.map(d.SampleID.value_counts())>=2]
    m = smf.mixedlm(f'{v} ~ 1', d, groups=d.SampleID).fit(reml=True)
    vb = float(m.cov_re.iloc[0,0]); vw = m.scale
    print(f'{v:12s} ICC={vb/(vb+vw):.2f} (between-donor var {vb:.2f}, within-donor var {vw:.2f}); mean |range| within donor={d.groupby("SampleID")[v].agg(lambda x: x.max()-x.min()).mean():.2f}')
print('=== IL-33 by COPD/emphysema (donor level)')
for grp in ['COPD','Asthma','COPD_or_emph','emphysema']:
    for v in ['IL33_epi','IL33_endo','IL33_vsmc']:
        a = don.loc[don[grp], v].dropna(); b = don.loc[~don[grp], v].dropna()
        print(f'{grp:13s} {v:10s} yes med={a.median():.2f} (n={len(a)}) no med={b.median():.2f} (n={len(b)}) p={stats.mannwhitneyu(a,b).pvalue:.3f}')
print('=== IL-33 vs eosinophil/neutrophil/mast correlations (donor level, Spearman)')
for x in ['IL33_epi','IL33_endo','IL33_vsmc']:
    for y in ['EPX_o','EDN_o','MBP_o','2D7_o','NE_dIL5Ra_o','Try_dIL5Ra_o','IL5Ra_dNE_o','Age']:
        d = don[[x,y]].dropna()
        r,p = stats.spearmanr(d[x], d[y])
        print(f'{x:10s} ~ {y:13s} rho={r:+.2f} p={p:.3f} n={len(d)}')
