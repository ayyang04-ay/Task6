import pandas as pd, numpy as np
df = pd.read_csv('/tmp/work/postmortem.csv')
short = ['SampleID','Block','TissueRNA','Unn3','Lobe','DiseaseCat','Race','Gender','Age','SARS2','Pathology','HE_eos','EPX','EDN','MBP','2D7','IL5Ra_dNE','NE_dIL5Ra','IL5Ra_dTry','Try_dIL5Ra','EPX_num','NE_num','Try_num','IL33_epi','IL33_endo','IL33_vsmc','Notes']
df.columns = short
df = df[df.SampleID.notna()].copy()
df['SampleID'] = df.SampleID.astype(int)
print('Unn3==SampleID:', (df.Unn3==df.SampleID).all())
# forward-fill donor-level fields within donor from the first block
first = df.groupby('SampleID').head(1).set_index('SampleID')
for c in ['DiseaseCat','Race','Gender','Age','SARS2']:
    df[c+'_donor'] = df.SampleID.map(first[c])
# Notes: union across blocks
notes = df.groupby('SampleID').Notes.apply(lambda s: '; '.join(sorted(set(s.dropna()))) )
df['Notes_donor'] = df.SampleID.map(notes)
# blocks per donor
print(df.groupby('SampleID').size().value_counts().sort_index())
# parse ordinal columns
def parse(x):
    if pd.isna(x): return np.nan
    s = str(x).strip()
    if s.upper()=='ND': return np.nan
    s = s.replace('+','').strip()
    try: return float(s)
    except: return 'BAD:'+str(x)
ordcols = ['EPX','EDN','MBP','2D7','IL5Ra_dNE','NE_dIL5Ra','IL5Ra_dTry','Try_dIL5Ra']
for c in ordcols:
    df[c+'_o'] = df[c].map(parse)
    bad = df[c+'_o'].astype(str).str.startswith('BAD')
    if bad.any(): print('BAD', c, df.loc[bad, c].tolist())
# unique raw values
for c in ordcols+['EPX_num','NE_num','Try_num','IL33_epi','IL33_endo','IL33_vsmc','HE_eos']:
    print(c, sorted(df[c].astype(str).unique()))
df.to_pickle('/tmp/work/pm.pkl')
