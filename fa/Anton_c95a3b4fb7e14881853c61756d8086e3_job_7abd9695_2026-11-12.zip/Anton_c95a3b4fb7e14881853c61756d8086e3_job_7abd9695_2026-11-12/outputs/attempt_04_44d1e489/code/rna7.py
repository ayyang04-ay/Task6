import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',200)
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl'); SE = pd.read_pickle('/tmp/work/SEw.pkl')
rows=[]
for tp,tpl in [('6','6_hrs'),('24','24_hrs')]:
    LV = W[f'IL33_vs_Nontreated_HUVEC_{tpl}']; q = Q[f'IL33_vs_Nontreated_HUVEC_{tpl}']
    LCL = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']; LCLI = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    se = SE[f'IL33_vs_Nontreated_HUVEC_{tpl}']
    # robust = well measured (SE<1) & expressed reasonably
    sel = (q<0.01)&(LV>2)&(se<1)
    d = pd.DataFrame({'sym':ann.symbol,'AveExpr':ann.AveExpr,'L_V':LV,'LC_L':LCL,'LC_V':LV+LCL,'pct_inh':-LCL/LV*100,'LI_V':LV+LCL-LCLI})[sel]
    print(f'== HUVEC {tp}h robust IL-33-induced genes (q<0.01, lfc>2, SE<1): n={len(d)}; median inhibition {d.pct_inh.median():.1f}%; n with <50% inhibition: {(d.pct_inh<50).sum()}; n with residual LC_V>1: {(d.LC_V>1).sum()}')
    print(d[(d.pct_inh<60)].sort_values('LC_V', ascending=False).round(2).head(25).to_string())
