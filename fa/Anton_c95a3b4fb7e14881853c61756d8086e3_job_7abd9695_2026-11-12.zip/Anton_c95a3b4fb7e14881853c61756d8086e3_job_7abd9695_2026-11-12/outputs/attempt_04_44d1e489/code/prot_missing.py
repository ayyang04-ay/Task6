import pandas as pd, numpy as np
p = pd.read_pickle('/tmp/work/prot_qc.pkl').sort_values('p.value').reset_index(drop=True)
m = 1194
p['drank'] = np.arange(1, len(p)+1)
p['r_impl'] = p['p.value']*m/p['adj.p.value']
p['is_anchor'] = (p.r_impl - p.r_impl.round()).abs() < 1e-3
anc = p[p.is_anchor].copy()
anc['r_full'] = anc.r_impl.round().astype(int)
anc['n_missing_before'] = anc.r_full - anc.drank
print('anchors:', len(anc))
print(anc[['assay','p.value','adj.p.value','drank','r_full','n_missing_before']].to_string(index=False, max_rows=120))
print('----')
for thr in [0.0005, 0.001, 0.005, 0.01, 0.05, 0.1, 0.2, 0.5, 1.0]:
    a = anc[anc['p.value']<=thr]
    if len(a):
        last = a.iloc[-1]
        print(f'p<={thr}: missing assays with p below ~{last["p.value"]:.4g}: {int(last.n_missing_before)}  (delivered with p<=thr: {(p["p.value"]<=thr).sum()})')
# where exactly do the first missing ones fall
prev = 0
for _,r in anc.iterrows():
    if r.n_missing_before>prev:
        lo = p[p.drank==r.drank-1]['p.value'].values
        print(f'missing assay #{prev+1}..{int(r.n_missing_before)}: p between {lo[0] if len(lo) else 0:.3g} and {r["p.value"]:.3g} (adj ~{r["adj.p.value"]:.3f})')
        prev = int(r.n_missing_before)
    if prev>=6: break
