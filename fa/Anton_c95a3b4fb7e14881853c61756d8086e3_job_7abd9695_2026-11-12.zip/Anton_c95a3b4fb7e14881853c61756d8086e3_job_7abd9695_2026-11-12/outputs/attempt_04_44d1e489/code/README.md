# AX-1177 audit: analysis code

All scripts read the delivered files from `/tmp/world/filesystem` (via `00_convert_inputs.py`) and write intermediates to `/tmp/work`.
Environments: `mm singlecell python` (pandas, scipy, statsmodels, matplotlib, adjustText, openpyxl); `mm renv Rscript` (msigdbr); `mm core python` (reportlab, for the PDF).

Run order:
1. `00_convert_inputs.py`: Excel to CSV; protein keys without panel suffixes.
2. `build.py`: stack all 26 RNA-seq contrasts (24 from the contrasts workbook + 2 from the HUVEC IL-33 workbook).
3. Integrity checks: `check1.py` (AveExpr/annotation constant per gene), `check2.py` (t to P implied df = 85.1), `check3.py`–`check6.py` (SE = |logFC/t|; inflated/deflated SEs; the genes affected).
4. In vitro pharmacology: `rna1.py` (DE counts), `rna2.py`/`rna3.py` (antibody-alone hits and their non-replication), `rna4.py`/`rna5.py` (reversal and isotype analysis; repressed-gene artefact), `rna6.py` (core AX-1177-reversible programme), `rna7.py` (incomplete reversal at 24 h), `rna8.py` (HGMEC).
5. Pathways: `msig.R` exports MSigDB Hallmark/Reactome; then `ora.py` (core programme) and `ora2.py` (serum severity proteins).
6. Proteomics: `olinkmap.py` + `bridge1.py` (Olink to HGNC mapping); `prot_qc.py` (Wald/CI/BH checks); `prot_missing.py` (BH back-calculation m = 1,194; withheld-assay reconstruction).
7. Bridge: `bridge2.py` (Fisher/Mann-Whitney), `bridge3.py` (global correlation, permutation), plus the sensitivity analyses in the memo.
8. Post-mortem: `pm_prep.py` (parse, donor-field propagation), `pm_an1.py`–`pm_an5.py` (donor-level summaries, pathology-text label audit, block vs donor vs mixed models, age adjustment), `misc1.py`.
9. Outputs: `fig1.py`–`fig6.py`, `tables.py` + `excel.py` + `fixxl.py` (supporting workbook), `md2pdf.py` (memo PDF).
