import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from adjustText import adjust_text
from scipy import stats
pu = pd.read_pickle('/tmp/work/bridge.pkl')
SE = pd.read_pickle('/tmp/work/SEw.pkl')
fig, ax = plt.subplots(1,2, figsize=(15,6.2), gridspec_kw={'width_ratios':[2.2,1]})
a = ax[0]
x = pu.LV_6; y = pu.z
c = pu.coreUP_any
a.scatter(x[~c], y[~c], s=10, c='#b0bec5', lw=0, label=f'other Olink proteins (n={(~c).sum()})')
a.scatter(x[c], y[c], s=36, c='#c0392b', lw=0, label=f'IL-33-induced & AX-1177-reversed (n={c.sum()})')
thr_z = stats.norm.isf(0.0076/2)
a.axhline(thr_z, ls='--', c='k', lw=0.7); a.text(-3.8, thr_z+0.1, 'serum FDR 0.05', fontsize=8)
a.axhline(0, c='k', lw=0.5); a.axvline(0, c='k', lw=0.5)
texts=[]
for b in ['OPG','CCL20','IL6','IL-18R1','MCP-3','CSF-1','IL1B','G-CSF','CXCL6','CX3CL1','TNF','CXCL10','CXCL5','TNFRSF9','ICAM1','CCL5','KYNU','ST2','SELE','IL8','VCAM1']:
    r = pu[pu.base==b]
    if len(r):
        r=r.iloc[0]; texts.append(a.text(r.LV_6, r.z, b.replace('ST2','sST2*').replace('SELE','SELE*').replace('IL8','IL8*').replace('VCAM1','VCAM1*'), fontsize=8, color='#c0392b' if r.coreUP_any else '#37474f'))
adjust_text(texts, ax=a, arrowprops=dict(arrowstyle='-', color='grey', lw=0.4))
rho, pr = stats.spearmanr(x, y)
a.set_xlabel('IL-33red vs vehicle in HUVEC, 6 h (log2FC of the encoding gene)')
a.set_ylabel('serum association with severe outcome (signed z)')
a.set_title(f'In vitro IL-33 induction vs. clinical severity association (912 proteins mapped to genes)\nglobal Spearman rho = {rho:.2f} (p = {pr:.1g}); weak, directionally consistent', fontsize=10)
a.legend(fontsize=8, loc='lower right')
b = ax[1]
frac_core = pu.loc[c,'sev_q05'].mean(); frac_bg = pu.loc[~c,'sev_q05'].mean()
rng = np.random.default_rng(0); k=c.sum()
null = np.array([pu.sev_q05.sample(k, random_state=int(s)).mean() for s in rng.integers(0,1e9,5000)])
b.hist(null, bins=np.arange(0,0.45,0.0149), color='#cfd8dc', label='random protein sets of the same size')
b.axvline(frac_core, c='#c0392b', lw=2, label=f'IL-33 programme: {frac_core*100:.0f}%')
b.axvline(frac_bg, c='#37474f', lw=1.2, ls='--', label=f'all other proteins: {frac_bg*100:.0f}%')
tab = pd.crosstab(pu.coreUP_any, pu.sev_q05).values
orr, pf = stats.fisher_exact(tab)
b.set_title(f'Is the IL-33 programme over-represented among\nseverity-associated proteins?  No (Fisher OR {orr:.2f}, p = {pf:.2f};\npermutation p = {np.mean(null>=frac_core):.2f})', fontsize=10)
b.set_xlabel('fraction of proteins with FDR<0.05 for severity'); b.set_ylabel('count (5,000 permutations)')
b.legend(fontsize=8)
fig.text(0.01,-0.03,'*sST2, SELE, IL8 (CXCL8), VCAM1: encoding genes have inflated SEs in the delivered RNA-seq model (Figure 2), so they cannot be classified as "core", although their IL-33 log2FCs are large (SELE 11.2, CXCL8 8.2, VCAM1 8.7).\n'
         'Interpretation: severity-associated serum proteins include a few IL-33-inducible endothelial products (IL-6, OPG, CCL20, IL-18R1), but the programme as a whole is not preferentially linked to outcome; the clinical signal is not IL-33-specific.', fontsize=8, va='top')
fig.suptitle('Figure 4. Translational bridge: does the AX-1177-reversible endothelial IL-33 programme track with severity in patients?', fontsize=12)
plt.tight_layout()
plt.savefig('/tmp/outputs/figures/fig4_translational_bridge.png', dpi=170, bbox_inches='tight')
print('ok', orr, pf)
