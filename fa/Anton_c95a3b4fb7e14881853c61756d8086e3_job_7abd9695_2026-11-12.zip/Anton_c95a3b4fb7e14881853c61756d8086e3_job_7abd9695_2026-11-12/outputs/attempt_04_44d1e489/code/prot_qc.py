import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250); pd.set_option('display.max_rows',100)
p = pd.read_csv('/tmp/work/proteomics_mapped.csv')
lo, hi, b = np.log(p.l95), np.log(p.u95), np.log(p.OR)
p['mid_dev'] = (lo+hi)/2 - b
p['se'] = (hi-lo)/(2*1.959964)
p['p_wald'] = 2*stats.norm.sf(np.abs(b/p.se))
p['p_ratio'] = p.p_wald/p['p.value']
print('CI midpoint deviation (log scale): max abs', p.mid_dev.abs().max().round(4), '; n >0.01:', (p.mid_dev.abs()>0.01).sum())
print('Wald p vs reported p: ratio quantiles', p.p_ratio.quantile([0,.01,.5,.99,1]).round(3).to_dict())
bad = p[(np.log10(p.p_wald)-np.log10(p['p.value'])).abs()>0.3]
print('n rows with |log10 p_wald - log10 p| > 0.3:', len(bad))
print(bad[['panel','assay','OR','l95','u95','p.value','p_wald','adj.p.value']].head(20).to_string())
# BH recompute
bh = multipletests(p['p.value'], method='fdr_bh')[1]
p['bh_re'] = bh
print('BH recompute: max abs diff', np.abs(p.bh_re - p['adj.p.value']).max())
# significance consistency: CI excludes 1 <-> p<0.05
inc = ((p.l95>1)|(p.u95<1)) != (p['p.value']<0.05)
print('CI-excludes-1 vs p<0.05 inconsistencies:', inc.sum())
print(p.loc[inc, ['assay','OR','l95','u95','p.value','p_wald']].head(20).to_string())
# direction
print('n OR<1 with q<0.05:', ((p.OR<1)&(p['adj.p.value']<0.05)).sum(), '; n OR>1 with q<0.05:', ((p.OR>1)&(p['adj.p.value']<0.05)).sum())
print('OR distribution:', p.OR.describe().round(2).to_dict())
print('fraction OR>1 overall:', (p.OR>1).mean().round(3))
# extreme CIs
print(p.sort_values('u95', ascending=False)[['assay','OR','l95','u95','p.value','composite_endpoint_0','composite_endpoint_1']].head(15).to_string())
p.to_pickle('/tmp/work/prot_qc.pkl')
