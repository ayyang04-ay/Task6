import pandas as pd, numpy as np
from scipy import stats
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl'); SE = pd.read_pickle('/tmp/work/SEw.pkl')
core = pd.read_pickle('/tmp/work/core.pkl')
for tp in ['6','24']:
    d, cu, cd = core[tp]
    x = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs'][cu]; y = W[f'Compound_47_IL33_vs_IL33_HGMEC_{tp}hrs'][cu]
    qy = Q[f'Compound_47_IL33_vs_IL33_HGMEC_{tp}hrs'][cu]
    r = stats.spearmanr(x,y)
    slope = np.polyfit(x,y,1)[0]
    print(f'{tp}h core-UP genes n={cu.sum()}: HGMEC reversal vs HUVEC reversal Spearman={r.statistic:.2f}; slope={slope:.2f}; HGMEC significantly reversed (q<0.05, same dir): {((qy<0.05)&(y<0)).sum()} ({((qy<0.05)&(y<0)).mean()*100:.0f}%)')
    # genome-wide
    xa = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']; ya = W[f'Compound_47_IL33_vs_IL33_HGMEC_{tp}hrs']
    print(f'    genome-wide Spearman HUVEC vs HGMEC reversal: {stats.spearmanr(xa,ya).statistic:.2f}')
    # top HGMEC reversed genes
    tophg = pd.DataFrame({'sym':ann.symbol,'HGMEC_LC_L':W[f'Compound_47_IL33_vs_IL33_HGMEC_{tp}hrs'],'q':Q[f'Compound_47_IL33_vs_IL33_HGMEC_{tp}hrs'],'HUVEC_LC_L':x.reindex(ann.index), 'HUVEC_L_V':d.L_V})
    print(tophg[(tophg.q<0.05)].sort_values('HGMEC_LC_L').head(20).round(2).to_string())
