import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from adjustText import adjust_text
p = pd.read_csv('/tmp/work/proteomics_mapped.csv')
bridge = pd.read_pickle('/tmp/work/bridge.pkl')
coreset = set(bridge.loc[bridge.coreUP_any,'base'])
p = p.sort_values('p.value'); npan = p.base.value_counts()
u = p.drop_duplicates('base').copy(); u['n_panels'] = u.base.map(npan)
thr = p.loc[p['adj.p.value']<0.05,'p.value'].max()
cats = {
 'IL-33 receptor axis (sST2)': (['ST2'], '#000000','*',180),
 'Type-2 / eosinophil / mast cell': (['IL5','CCL11','CCL17','CCL24','TPSAB1','KIT','IL-5R-alpha','RNASE3','IL-4RA','IL13RA1'], '#27ae60','s',45),
 'Endothelial activation / injury': (['vWF','ANGPT2','SELE','VCAM1','ICAM1','ESM-1','CDH5','PECAM-1','SELP','TM','PAI','ANGPT1','TIE2'], '#16a085','D',45),
 'Neutrophil degranulation': (['PRTN3','CD177','LCN2','EN-RAGE','MPO','AZU1','DEFA1','CEACAM8'], '#e67e22','o',40),
}
fig, ax = plt.subplots(figsize=(11.5,7.2))
x = np.log(u.OR); y = -np.log10(u['p.value'])
ax.scatter(x, y, s=8, c='#cfd8dc', lw=0, label=f'all proteins (n={len(u)} unique; {int((npan>1).sum())} measured on >1 panel)')
core_m = u.base.isin(coreset)
ax.scatter(x[core_m], y[core_m], s=40, facecolors='none', edgecolors='#c0392b', lw=1.2, label=f'IL-33-induced & AX-1177-reversed in HUVEC (n={core_m.sum()})')
texts=[]
for name,(lst,col,mk,sz) in cats.items():
    m = u.base.isin(lst)
    ax.scatter(x[m], y[m], s=sz, c=col, marker=mk, lw=0, label=name, zorder=3)
    for _,r in u[m].iterrows():
        texts.append(ax.text(np.log(r.OR), -np.log10(r['p.value']), r.base.replace('vWF','VWF').replace('ST2','sST2'), fontsize=8, color=col))
for b in ['OPG','CCL20','IL6','IL-18R1','G-CSF','CXCL6','CX3CL1','TNF','CXCL10','CXCL5','HGF','PTX3','IL8']:
    r = u[u.base==b].iloc[0]
    col = '#c0392b' if b in coreset else '#34495e'
    texts.append(ax.text(np.log(r.OR), -np.log10(r['p.value']), b+(' (x%d panels)'%r.n_panels if r.n_panels>1 else ''), fontsize=8, color=col))
adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='grey', lw=0.4))
ax.axhline(-np.log10(thr), c='k', ls='--', lw=0.8); ax.text(2.8, -np.log10(thr)+0.08, 'FDR 0.05 (as delivered)', fontsize=8)
ax.axvline(0, c='k', lw=0.6)
ax.set_xlabel('ln(OR) per log unit of protein, adjusted for age, sex, NEWS2 (as delivered)')
ax.set_ylabel('-log10 P')
ax.set_xlim(-2.5, 5); ax.legend(fontsize=8, loc='upper left', framealpha=0.9)
ax.set_title('Figure 3. Serum proteins at enrolment vs ICU/IMV/death within 30 days (100 hospitalised COVID-19 patients, 44 events)', fontsize=11)
fig.text(0.01,-0.02, f'{(u.OR>1).mean()*100:.0f}% of proteins have OR>1 and {(u["adj.p.value"]<0.05).sum()} unique proteins pass FDR 0.05: sicker patients have more of almost everything. sST2 ranks #2 of 1,094 assays.\n'
 'Classical type-2 mediators (IL-5, eotaxin-1/-2, TARC, tryptase, KIT) are null. Per-log-unit ORs are not comparable across proteins (scale-dependent). IL-33 itself is not in the delivery.\n'
 'Duplicate assays across panels collapsed to the most significant one per protein (all duplicates are concordant). Source: AX-1177_serum_proteomics.xlsx.', fontsize=8, va='top')
plt.tight_layout()
plt.savefig('/tmp/outputs/figures/fig3_serum_severity_landscape.png', dpi=170, bbox_inches='tight')
print('ok', thr)
