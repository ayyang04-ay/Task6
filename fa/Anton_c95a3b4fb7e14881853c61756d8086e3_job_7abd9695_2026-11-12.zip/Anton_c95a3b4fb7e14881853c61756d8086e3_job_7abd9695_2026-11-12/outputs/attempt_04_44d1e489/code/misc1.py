import pandas as pd, numpy as np, re
from scipy import stats
pd.set_option('display.width',250)
don = pd.read_pickle('/tmp/work/pm_donor2.pkl')
F = pd.read_pickle('/tmp/work/pm_flags2.pkl')
don = don.join(F[['PE_thrombo']])
print('=== IL-33 by DAD/ALI and thrombosis (donor level)')
for flag in ['DAD_ALI','PE_thrombo']:
    for v in ['IL33_endo','IL33_vsmc','IL33_epi']:
        a = don.loc[don[flag]==True, v].dropna(); b = don.loc[don[flag]==False, v].dropna()
        print(f'{flag:10s} {v:10s} yes med={a.median():.2f} n={len(a)} | no med={b.median():.2f} n={len(b)} | p={stats.mannwhitneyu(a,b).pvalue:.3f}')
p = pd.read_csv('/tmp/work/proteomics_mapped.csv')
print('=== IL-1 family receptors/decoys & neutrophil markers in serum')
for a in ['ST2','IL-1RT2','IL-1RT1','IL-1ra','IL-18R1','IL-18BP','IL1B','IL18-INFI','IL18-CVDII','IL1RL2','MPO','AZU1','CD177','PRTN3','CEACAM8','LCN2','MMP-9','EN-RAGE','PGLYRP1','DEFA1','CXCL1-INFI','CXCL5','CXCL6','G-CSF','IL8','OSM','HGF','PTX3','TNF-R1','TNF-R2','GDF-15','AGER','RAGE','EGFR','AREG-ONCII','TGF-alpha-INFI','HB-EGF','BTC','EREG']:
    r = p[p.assay==a]
    if len(r): r=r.iloc[0]; print(f'{a:15s} OR={r.OR:6.2f} ({r.l95:.2f}-{r.u95:.2f}) p={r["p.value"]:.2g} q={r["adj.p.value"]:.2g}')
    else: print(a, 'not present')
# rank of ST2 among all
p = p.sort_values('p.value').reset_index(drop=True)
print('ST2 rank by p:', p.index[p.assay=='ST2'][0]+1, 'of', len(p))
print('n q<0.05:', (p['adj.p.value']<0.05).sum(), '; unique proteins q<0.05:', p[p['adj.p.value']<0.05].base.nunique())
