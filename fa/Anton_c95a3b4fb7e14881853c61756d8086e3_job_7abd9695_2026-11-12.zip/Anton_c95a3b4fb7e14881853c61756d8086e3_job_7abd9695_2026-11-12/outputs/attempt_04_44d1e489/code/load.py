import pandas as pd, numpy as np
def load(s):
    return pd.read_csv(f'/tmp/work/contrasts_{s}.csv', dtype={'entrez':str})
