import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from adjustText import adjust_text
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl'); SE = pd.read_pickle('/tmp/work/SEw.pkl')
allc = pd.read_pickle('/tmp/work/allc2.pkl')
P = allc.pivot(index='ensembl', columns='Comparison', values='P.Value')
endo_cols = [c for c in SE.columns if ('HUVEC' in c or 'HGMEC' in c)]
medSE = SE[endo_cols].median(axis=1)
sym2ens = ann.reset_index().dropna(subset=['symbol']).drop_duplicates('symbol').set_index('symbol').ensembl
fig, ax = plt.subplots(1,2, figsize=(15,5.6))
a = ax[0]
bins = np.logspace(-2, 4.5, 80)
a.hist(medSE, bins=bins, color='#7f8c8d')
a.set_xscale('log'); a.set_yscale('log')
a.axvline(3, c='#c0392b', ls='--', lw=1)
a.text(3.3, 120, f'{(medSE>3).sum()} genes with median SE > 3 log2 units\n(typical gene: median SE {medSE.median():.2f})', color='#c0392b', fontsize=9)
texts=[]
yoff = {'SELE':2.2,'VCAM1':6,'IL1RL1':16,'CXCL8':2.2,'CXCL1':6,'CDH5':2.2,'VWF':2.2,'CD93':2.2,'ESM1':2.2,'PTGS2':2.2,'KRT8':6}
for s in ['SELE','VCAM1','CXCL8','CXCL1','IL1RL1','CDH5','VWF','CD93','ESM1','PTGS2','KRT8']:
    e = sym2ens[s]; x = medSE[e]
    a.plot([x],[1.5],'v',c='#8e44ad'); a.text(x, yoff[s], s, fontsize=7.5, rotation=90, ha='center', va='bottom')
a.set_xlabel('gene-wise median |logFC / t| across endothelial contrasts (log2 units)')
a.set_ylabel('number of genes')
a.set_title('Single pooled limma fit (114 libraries, 4 cell types):\nimplausibly large SEs for cell-type identity and key IL-33 target genes', fontsize=10)
b = ax[1]
LV = W['IL33_vs_Nontreated_HUVEC_6_hrs']; pv = P['IL33_vs_Nontreated_HUVEC_6_hrs']
infl = medSE>3
b.scatter(LV[~infl], -np.log10(pv[~infl]), s=3, c='#bdc3c7', lw=0, rasterized=True, label='genes with plausible SE')
b.scatter(LV[infl], -np.log10(pv[infl]), s=22, c='#8e44ad', lw=0, label='inflated-SE genes (median SE > 3)')
texts=[]
for s in ['SELE','VCAM1','CXCL8','CXCL1','IL1RL1','CSF2','CCL20','CXCL6','IL6','TNFRSF11B','ICAM1']:
    e = sym2ens[s]; texts.append(b.text(LV[e], -np.log10(pv[e]), s + (' (OPG)' if s=='TNFRSF11B' else ''), fontsize=8))
adjust_text(texts, ax=b, arrowprops=dict(arrowstyle='-', color='grey', lw=0.5))
b.set_xlabel('IL-33red vs vehicle, HUVEC 6 h (log2FC)'); b.set_ylabel('-log10 P (as delivered)')
b.set_title('Canonical endothelial-activation genes show very large IL-33 effects\nbut non-significant P values because of the pooled variance, not the biology', fontsize=10)
b.legend(fontsize=8, loc='upper left')
fig.text(0.01,-0.04,'SE was derived per row as |logFC/t|. A log2 SE of ~9 (SELE) or ~1,100 (CXCL1) cannot occur on voom log-CPM data with n=3 per group; they are consistent with residual variance pooled across endothelial cells and epithelial cancer lines in one model (annex section 5), and are not interpretable either way.\n'
         'Remedy: refit endothelial cells separately from the archived count matrices (annex section 5) before any claim about SELE, VCAM1, CXCL8, CXCL1 or IL1RL1 (ST2).', fontsize=8, va='top')
fig.suptitle('Figure 2. Data-integrity issue in the delivered RNA-seq statistics', fontsize=12)
plt.tight_layout()
plt.savefig('/tmp/outputs/figures/fig2_rnaseq_variance_inflation.png', dpi=170, bbox_inches='tight')
print('ok')
