import pandas as pd, numpy as np, re
from scipy import stats
from statsmodels.stats.multitest import multipletests
W = pd.read_pickle('/tmp/work/W.pkl'); Q = pd.read_pickle('/tmp/work/Q.pkl'); ann = pd.read_pickle('/tmp/work/ann.pkl'); SE = pd.read_pickle('/tmp/work/SEw.pkl')
core = pd.read_pickle('/tmp/work/core.pkl')
endo_cols = [c for c in SE.columns if ('HUVEC' in c or 'HGMEC' in c)]
medSE = SE[endo_cols].median(axis=1)
# ---------- core signature table
rows = pd.DataFrame({'ensembl':ann.index,'symbol':ann.symbol.values,'gene_name':ann.gene_name.values,'AveExpr_all114':ann.AveExpr.values}).set_index('ensembl')
for tp,tpl in [('6','6_hrs'),('24','24_hrs')]:
    LV = W[f'IL33_vs_Nontreated_HUVEC_{tpl}']; LCL = W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']; LCLI = W[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    rows[f'HUVEC_{tp}h_IL33_vs_vehicle_log2FC'] = LV; rows[f'HUVEC_{tp}h_IL33_vs_vehicle_FDR'] = Q[f'IL33_vs_Nontreated_HUVEC_{tpl}']
    rows[f'HUVEC_{tp}h_AX1177+IL33_vs_IL33_log2FC'] = LCL; rows[f'HUVEC_{tp}h_AX1177+IL33_vs_IL33_FDR'] = Q[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs']
    rows[f'HUVEC_{tp}h_AX1177+IL33_vs_IL33+isotype_log2FC'] = LCLI; rows[f'HUVEC_{tp}h_AX1177+IL33_vs_IL33+isotype_FDR'] = Q[f'Compound_47_IL33_vs_IL33_IC119_HUVEC_{tp}hrs']
    rows[f'HUVEC_{tp}h_isotype_effect_log2FC'] = LCL-LCLI
    rows[f'HUVEC_{tp}h_pct_inhibition'] = -LCL/LV*100
    rows[f'HGMEC_{tp}h_AX1177+IL33_vs_IL33_log2FC'] = W[f'Compound_47_IL33_vs_IL33_HGMEC_{tp}hrs']; rows[f'HGMEC_{tp}h_AX1177+IL33_vs_IL33_FDR'] = Q[f'Compound_47_IL33_vs_IL33_HGMEC_{tp}hrs']
    d,cu,cd = core[tp]
    rows[f'core_{tp}h'] = np.where(cu,'induced',np.where(cd,'repressed',''))
rows['median_SE_endothelial_contrasts'] = medSE
rows['flag_inflated_variance_P_uninformative'] = medSE>3
sig = rows[(rows.core_6h!='')|(rows.core_24h!='')|((rows.flag_inflated_variance_P_uninformative)&((rows['HUVEC_6h_IL33_vs_vehicle_log2FC'].abs()>2)|(rows['HUVEC_24h_IL33_vs_vehicle_log2FC'].abs()>2)))].copy()
sig = sig.sort_values('HUVEC_6h_IL33_vs_vehicle_log2FC', ascending=False).reset_index()
# ---------- proteomics annotated
p = pd.read_csv('/tmp/work/proteomics_mapped.csv')
bridge = pd.read_pickle('/tmp/work/bridge.pkl').set_index('base')
p['n_panels_for_protein'] = p.base.map(p.base.value_counts())
p['BH_recomputed_over_1094_delivered'] = multipletests(p['p.value'], method='fdr_bh')[1]
sym2ens = ann.reset_index().dropna(subset=['symbol']).drop_duplicates('symbol').set_index('symbol').ensembl
p['ens'] = p.rna_sym.map(sym2ens)
for tp,tpl in [('6','6_hrs'),('24','24_hrs')]:
    p[f'HUVEC_{tp}h_IL33_log2FC'] = p.ens.map(W[f'IL33_vs_Nontreated_HUVEC_{tpl}']); p[f'HUVEC_{tp}h_IL33_FDR'] = p.ens.map(Q[f'IL33_vs_Nontreated_HUVEC_{tpl}'])
    p[f'HUVEC_{tp}h_AX1177_effect_log2FC'] = p.ens.map(W[f'Compound_47_IL33_vs_IL33_HUVEC_{tp}hrs'])
p['encoding_gene_in_core_IL33_programme'] = p.base.map(bridge.coreUP_any).fillna(False)
p['encoding_gene_inflated_variance'] = p.ens.map(medSE>3).fillna(False)
cat = {}
for b in ['ST2']: cat[b]='IL-33 receptor axis'
for b in ['IL5','CCL11','CCL17','CCL24','TPSAB1','KIT','IL-5R-alpha','RNASE3','IL-4RA','IL13RA1']: cat[b]='type-2/eosinophil/mast'
for b in ['vWF','ANGPT2','SELE','VCAM1','ICAM1','ESM-1','CDH5','PECAM-1','SELP','TM','PAI','ANGPT1','TIE2','OPG']: cat[b]='endothelial activation/injury'
for b in ['PRTN3','CD177','LCN2','EN-RAGE','MPO','AZU1','DEFA1','CEACAM8']: cat[b]='neutrophil'
for b in ['IL-1RT2','IL-1RT1','IL-1ra','IL-18R1','IL-18BP','IL1B','IL18','IL1RL2']: cat[b]='IL-1 family'
p['category'] = p.base.map(cat).fillna('')
pcols = ['panel','assay','base','gene','n_panels_for_protein','category','OR','l95','u95','p.value','adj.p.value','BH_recomputed_over_1094_delivered','composite_endpoint_0','composite_endpoint_1',
         'HUVEC_6h_IL33_log2FC','HUVEC_6h_IL33_FDR','HUVEC_6h_AX1177_effect_log2FC','HUVEC_24h_IL33_log2FC','HUVEC_24h_IL33_FDR','HUVEC_24h_AX1177_effect_log2FC','encoding_gene_in_core_IL33_programme','encoding_gene_inflated_variance']
pout = p[pcols].rename(columns={'base':'protein (panel suffix removed)','gene':'HGNC gene (mapped)','adj.p.value':'adj.p.value (as delivered; implies m=1194)','composite_endpoint_0':'composite_endpoint_0 (undocumented; k/56)','composite_endpoint_1':'composite_endpoint_1 (undocumented; k/44)'}).sort_values('p.value')
# ---------- withheld reconstruction
q = p.sort_values('p.value').reset_index(drop=True); m=1194
q['delivered_rank']=np.arange(1,len(q)+1); q['implied_rank_in_1194']=q['p.value']*m/q['adj.p.value']
anc = q[(q.implied_rank_in_1194-q.implied_rank_in_1194.round()).abs()<1e-3].copy()
anc['implied_rank_in_1194']=anc.implied_rank_in_1194.round().astype(int)
anc['n_undelivered_assays_with_smaller_p'] = anc.implied_rank_in_1194-anc.delivered_rank
wh = anc[['assay','p.value','adj.p.value','delivered_rank','implied_rank_in_1194','n_undelivered_assays_with_smaller_p']]
# ---------- postmortem donor
don = pd.read_pickle('/tmp/work/pm_donor2.pkl').reset_index()
F = pd.read_pickle('/tmp/work/pm_flags2.pkl')
don = don.merge(F[['DiseaseCat','acute_pna','DAD_ALI','PE_thrombo','fungal','path_snip']].reset_index(), on='SampleID', how='left', suffixes=('','_F'))
def verdict(r):
    if r.DiseaseCat=='COVID neg pneumonia' and not (r.acute_pna or r.DAD_ALI): return 'DISCORDANT: labelled pneumonia, none in pathology'
    if r.DiseaseCat=='COVID neg non-pneumonia' and (r.acute_pna): return 'DISCORDANT: labelled non-pneumonia, pneumonia/pneumonitis in pathology'
    if r.DiseaseCat=='COVID pos pneumonia' and not (r.acute_pna or r.DAD_ALI): return 'DISCORDANT: labelled pneumonia, no acute pneumonia in pathology'
    if r.fungal and r.DiseaseCat!='COVID pos pneumonia': return 'NOTE: pulmonary fungal infection in control'
    return 'concordant'
don['label_audit'] = don.apply(verdict, axis=1)
don.loc[don.SARS2.isna(),'label_audit'] = don.loc[don.SARS2.isna(),'label_audit'] + '; SARS-CoV-2 result missing'
dcols = ['SampleID','DiseaseCat','SARS2','Age','Gender','nblocks','Notes','group_path','label_audit','acute_pna','DAD_ALI','PE_thrombo','IL33_epi','IL33_endo','IL33_vsmc','EPX_o','EDN_o','MBP_o','2D7_o','NE_dIL5Ra_o','Try_dIL5Ra_o','IL5Ra_dNE_o','HE_eos_y','path_snip']
dout = don[dcols].rename(columns={'DiseaseCat':'disease_category_as_delivered','SARS2':'SARS-CoV-2_as_delivered','group_path':'group_rederived_from_pathology','acute_pna':'acute_pneumonia_in_pathology','DAD_ALI':'DAD_or_acute_lung_injury_in_pathology','PE_thrombo':'thrombo-embolism_in_pathology','HE_eos_y':'H&E_eos_fraction_of_blocks','path_snip':'pathology_text_first_130_chars','EPX_o':'EPX_donor_median','EDN_o':'EDN_donor_median','MBP_o':'MBP_donor_median','2D7_o':'2D7_basophil_donor_median','NE_dIL5Ra_o':'neutrophil_elastase_donor_median','Try_dIL5Ra_o':'tryptase_donor_median','IL5Ra_dNE_o':'IL5Ra_donor_median','IL33_epi':'IL33_basal_epithelium_donor_median','IL33_endo':'IL33_endothelium_donor_median','IL33_vsmc':'IL33_VSMC_donor_median'})
pd.to_pickle({'sig':sig,'pout':pout,'wh':wh,'dout':dout}, '/tmp/work/tables.pkl')
print(len(sig), len(pout), len(wh), len(dout)); print(dout.label_audit.value_counts())
