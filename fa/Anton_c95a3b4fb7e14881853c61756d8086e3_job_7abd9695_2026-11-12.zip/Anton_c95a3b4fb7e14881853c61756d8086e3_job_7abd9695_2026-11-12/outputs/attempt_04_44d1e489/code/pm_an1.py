import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',300); pd.set_option('display.max_columns',40)
df = pd.read_pickle('/tmp/work/pm.pkl')
df['group'] = df.DiseaseCat_donor.map({'COVID pos pneumonia':'C+pna','COVID neg pneumonia':'C-pna','COVID neg non-pneumonia':'C-nonpna'})
print(df.groupby('group').SampleID.nunique(), df.groupby('group').size())
print(df.groupby(['group','SampleID']).size().unstack(0).fillna(0).astype(int).T.to_string())
vars_ = ['EPX_o','EDN_o','MBP_o','2D7_o','IL5Ra_dNE_o','NE_dIL5Ra_o','IL5Ra_dTry_o','Try_dIL5Ra_o','IL33_epi','IL33_endo','IL33_vsmc']
for v in vars_: df[v] = pd.to_numeric(df[v], errors='coerce')
df['HE_eos_y'] = (df.HE_eos=='Y').astype(float)
vars_ += ['HE_eos_y']
don = df.groupby(['SampleID','group'])[vars_].median().reset_index()
don_mean = df.groupby(['SampleID','group'])[vars_].mean().reset_index()
don = don.merge(df.groupby('SampleID').agg(Age=('Age_donor','first'),Gender=('Gender_donor','first'),SARS2=('SARS2_donor','first'),Notes=('Notes_donor','first'),nblocks=('Block','size')).reset_index(), on='SampleID')
don.to_pickle('/tmp/work/pm_donor.pkl')
print(don.to_string())
# group summaries
print(don.groupby('group')[vars_].median().T.to_string())
print(don.groupby('group')[['Age']].describe())
