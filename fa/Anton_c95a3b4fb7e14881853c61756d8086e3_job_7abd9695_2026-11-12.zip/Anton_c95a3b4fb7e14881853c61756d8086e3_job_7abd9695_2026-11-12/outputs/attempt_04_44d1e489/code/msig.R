suppressMessages(library(msigdbr))
print(packageVersion("msigdbr"))
h <- tryCatch(msigdbr(species = "Homo sapiens", category = "H"), error=function(e) {print(e); NULL})
if (is.null(h)) h <- tryCatch(msigdbr(species = "Homo sapiens", collection = "H"), error=function(e) {print(e); NULL})
print(dim(h))
write.csv(h[, c("gs_name","gene_symbol")], "/tmp/work/hallmark.csv", row.names=FALSE)
r <- tryCatch(msigdbr(species = "Homo sapiens", category = "C2", subcategory = "CP:REACTOME"), error=function(e) {print(e); NULL})
if (!is.null(r)) { print(dim(r)); write.csv(r[, c("gs_name","gene_symbol")], "/tmp/work/reactome.csv", row.names=FALSE) }
