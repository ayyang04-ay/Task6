import pandas as pd, numpy as np, itertools
pd.set_option('display.width',250); pd.set_option('display.max_rows',400)
allc = pd.read_pickle('/tmp/work/allc2.pkl')
cons = [c for c in allc.Comparison.unique() if c.startswith('Compound_47_vs_')]
hits = {c: set(allc[(allc.Comparison==c)&(allc['adj.P.Val']<0.05)].ensembl) for c in cons}
sym = allc.drop_duplicates('ensembl').set_index('ensembl').symbol
# count how many contrasts each gene is hit in
from collections import Counter
cnt = Counter(g for c in cons for g in hits[c])
print('genes hit in >=2 antibody-alone contrasts:', sum(1 for g,v in cnt.items() if v>=2))
multi = sorted([(v, sym.get(g), g, [c for c in cons if g in hits[c]]) for g,v in cnt.items() if v>=2], reverse=True)
for m in multi[:60]: print(m[0], m[1], m[2], m[3])
# Independent replication: same cell line & comparator, across timepoints
print('--- replication across timepoints (independent sample sets)')
for cl in ['HUVEC','HGMEC','A549','MCF7']:
    for comp in ['IC119','PBS','DMSO']:
        a = f'Compound_47_vs_{comp}_{cl}_6hrs'; b = f'Compound_47_vs_{comp}_{cl}_24hrs'
        if a in hits and b in hits:
            ov = hits[a]&hits[b]
            print(cl, comp, len(hits[a]), len(hits[b]), 'overlap', len(ov), [sym.get(g) for g in ov])
print('--- replication across cell lines at same time vs IC119')
for t in ['6hrs','24hrs']:
    sets = {cl: hits[f'Compound_47_vs_IC119_{cl}_{t}'] for cl in ['HUVEC','HGMEC','A549','MCF7']}
    for a,b in itertools.combinations(sets,2):
        ov = sets[a]&sets[b]
        print(t, a, b, len(ov), [sym.get(g) for g in ov])
