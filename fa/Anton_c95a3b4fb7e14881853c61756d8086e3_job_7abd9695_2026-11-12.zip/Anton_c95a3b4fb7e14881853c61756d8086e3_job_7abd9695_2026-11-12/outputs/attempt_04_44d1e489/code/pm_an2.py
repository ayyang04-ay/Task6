import pandas as pd, numpy as np, re
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',140); pd.set_option('display.max_rows',200)
df = pd.read_pickle('/tmp/work/pm.pkl')
path = df.groupby('SampleID').Pathology.apply(lambda s: ' '.join(s.dropna()))
def flags(t):
    tl = t.lower()
    return pd.Series({
      'pna_path': bool(re.search(r'pneumonia|bronchpneumonia|pneumonitis|consolidation', tl)),
      'acute_pna': bool(re.search(r'acute (broncho)?pneumonia|acute bronchpneumonia|bronchopneumonia|acute pneumonitis|organizing pneumonia|consolidation', tl)),
      'DAD_ALI': bool(re.search(r'diffuse alveolar damage|hyalin|acute lung injury', tl)),
      'fibrosis': bool(re.search(r'fibrosis', tl)) and bool(re.search(r'pulmonary fibrosis|lungs showing diffuse fibrosis|interstitial', tl)),
      'emphysema': 'emphysema' in tl,
      'PE_thrombo': bool(re.search(r'embol|thrombo', tl)),
      'fungal': bool(re.search(r'aspergill|coccidio', tl)),
      'path_len': len(t)})
F = path.apply(flags)
first = df.groupby('SampleID').head(1).set_index('SampleID')
F['DiseaseCat'] = first.DiseaseCat; F['SARS2'] = first.SARS2; F['Notes'] = df.groupby('SampleID').Notes_donor.first()
F['nblocks'] = df.groupby('SampleID').size()
F['path_snip'] = path.str.replace(r'\s+',' ',regex=True).str.slice(0,130)
print(F.sort_values('DiseaseCat').to_string())
F.to_pickle('/tmp/work/pm_flags.pkl')
