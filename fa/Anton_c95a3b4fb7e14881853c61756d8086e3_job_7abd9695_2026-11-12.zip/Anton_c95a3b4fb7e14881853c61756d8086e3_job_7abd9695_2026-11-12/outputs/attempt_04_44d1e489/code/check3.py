import pandas as pd, numpy as np
from scipy import stats
allc = pd.read_pickle('/tmp/work/allc.pkl')
allc['SE'] = allc.logFC/allc.t
allc['absSE'] = allc.SE.abs()
# sign consistency
print('sign mismatch logFC vs t:', (np.sign(allc.logFC)!=np.sign(allc.t)).sum())
# per gene median SE
med = allc.groupby('ensembl').absSE.median().rename('medSE')
allc = allc.join(med, on='ensembl')
allc['SEratio'] = allc.absSE/allc.medSE
print(allc.SEratio.describe(percentiles=[.001,.01,.05,.5,.95,.99,.999]))
# per contrast distribution of SE ratio
q = allc.groupby('Comparison').SEratio.quantile([0.01,0.5,0.99]).unstack()
q['n_gt3'] = allc.groupby('Comparison').apply(lambda d: (d.SEratio>3).sum())
q['n_gt10'] = allc.groupby('Comparison').apply(lambda d: (d.SEratio>10).sum())
q['n_lt0.3'] = allc.groupby('Comparison').apply(lambda d: (d.SEratio<0.3).sum())
print(q.to_string())
allc.to_pickle('/tmp/work/allc2.pkl')
