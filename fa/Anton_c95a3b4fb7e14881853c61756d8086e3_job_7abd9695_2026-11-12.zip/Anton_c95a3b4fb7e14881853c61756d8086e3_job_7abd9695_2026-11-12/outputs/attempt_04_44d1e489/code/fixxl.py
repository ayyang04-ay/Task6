import openpyxl
wb = openpyxl.load_workbook('/tmp/outputs/AX-1177_supporting_tables.xlsx')
ws = wb['3_Considered_and_ruled_out']
for row in ws.iter_rows(min_row=2):
    if row[0].value and str(row[0].value).startswith('Reposition to cardiovascular'):
        row[2].value = 'NT-proBNP not FDR-significant (p = 0.050 and 0.17 on two panels, q >= 0.15); troponin I p = 0.11; no cardiac data.'
        print('fixed')
wb.save('/tmp/outputs/AX-1177_supporting_tables.xlsx')
