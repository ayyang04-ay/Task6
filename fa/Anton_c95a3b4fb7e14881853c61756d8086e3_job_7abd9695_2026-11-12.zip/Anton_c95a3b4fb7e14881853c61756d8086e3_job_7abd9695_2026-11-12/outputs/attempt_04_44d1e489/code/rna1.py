import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_rows',200)
allc = pd.read_pickle('/tmp/work/allc2.pkl')
# number of DE genes per contrast
def nde(d, fdr=0.05, lfc=1):
    up = ((d['adj.P.Val']<fdr)&(d.logFC>lfc)).sum(); dn=((d['adj.P.Val']<fdr)&(d.logFC<-lfc)).sum()
    any_ = (d['adj.P.Val']<fdr).sum()
    return pd.Series({'FDR<.05':any_, 'up(|lfc|>1)':up, 'down(|lfc|>1)':dn, 'minP':d['P.Value'].min(), 'n_rawP<0.001':(d['P.Value']<0.001).sum()})
res = allc.groupby('Comparison').apply(nde, include_groups=False)
print(res.to_string())
