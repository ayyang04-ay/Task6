import pandas as pd, numpy as np, re
from scipy import stats
pd.set_option('display.width',300); pd.set_option('display.max_rows',200)
df = pd.read_pickle('/tmp/work/pm.pkl'); F = pd.read_pickle('/tmp/work/pm_flags.pkl')
don = pd.read_pickle('/tmp/work/pm_donor.pkl').set_index('SampleID')
path = df.groupby('SampleID').Pathology.apply(lambda s: ' '.join(s.dropna()).lower())
F['DAD_ALI'] = path.map(lambda t: bool(re.search(r'diffuse alveolar damage|(?<!no )hyalin[e]? membranes|acute lung injury', t)))
F.loc[[1956],'DAD_ALI'] = False
# pathology-verified regroup
def regroup(sid):
    r = F.loc[sid]
    cov = r.SARS2=='pos'
    acute = r.acute_pna or r.DAD_ALI or sid in (2040,2108)
    if cov and acute: return 'COVID+ acute lung injury/pneumonia'
    if cov: return 'COVID+ no acute pneumonia'
    if acute: return 'COVID- acute pneumonia'
    return 'COVID- no acute pneumonia'
F['group_path'] = [regroup(s) for s in F.index]
print(F[['DiseaseCat','SARS2','acute_pna','DAD_ALI','group_path']].sort_values('group_path').to_string())
print(pd.crosstab(F.DiseaseCat, F.group_path))
F.to_pickle('/tmp/work/pm_flags2.pkl')
don = don.join(F[['group_path','DAD_ALI','acute_pna','emphysema']])
don['COPD'] = don.Notes.fillna('').str.contains('COPD'); don['Asthma'] = don.Notes.fillna('').str.contains('Asthma')
don['COPD_or_emph'] = don.COPD | don.emphysema
don.to_pickle('/tmp/work/pm_donor2.pkl')
vars_ = ['IL33_epi','IL33_endo','IL33_vsmc','EPX_o','EDN_o','MBP_o','2D7_o','NE_dIL5Ra_o','Try_dIL5Ra_o','IL5Ra_dNE_o']
def kw(groupcol):
    rows=[]
    for v in vars_:
        gs = [g[v].dropna().values for _,g in don.groupby(groupcol)]
        H,p = stats.kruskal(*gs)
        rows.append([v]+[f'{np.median(x):.2f} (n={len(x)})' for x in gs]+[p])
    cols = ['var']+[str(k) for k,_ in don.groupby(groupcol)]+['KW_p']
    return pd.DataFrame(rows, columns=cols)
print('=== Original labels (donor-level medians; Kruskal-Wallis)')
print(kw('group').to_string(index=False))
print('=== Pathology-verified labels')
print(kw('group_path').to_string(index=False))
# Pairwise COVID+ vs COVID- (all) Mann-Whitney, donor level
don['covid'] = don.SARS2=='pos'
print('=== COVID+ vs all COVID- donors (Mann-Whitney, donor level)')
for v in vars_:
    a = don.loc[don.covid, v].dropna(); b = don.loc[~don.covid, v].dropna()
    u = stats.mannwhitneyu(a,b)
    # Cliff's delta
    cd = (np.sign(a.values[:,None]-b.values[None,:])).mean()
    print(f'{v:14s} COVID+ med={a.median():.2f} (n={len(a)}) COVID- med={b.median():.2f} (n={len(b)}) p={u.pvalue:.3f} cliff_delta={cd:.2f}')
