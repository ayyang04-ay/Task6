import pandas as pd, numpy as np
T = pd.read_pickle('/tmp/work/tables.pkl')
readme = pd.DataFrame({'sheet':[
 '1_Data_integrity_log','2_Biomarker_candidates','3_Considered_and_ruled_out','4_Gated_plan','5_Core_IL33_signature',
 '6_Serum_proteomics_annotated','7_Withheld_assay_reconstruction','8_Postmortem_donor_level'],
 'content':[
 'Every data problem found in the four delivered files, with evidence, impact on conclusions and remedy.',
 'Candidate biomarkers, evidence from our data, proposed role (patient selection / PD / TE / research-only) and readiness.',
 'Hypotheses and positions evaluated and why they were ruled out or deprioritised.',
 'Stage-gated next steps with activities, sampling timepoints, readouts and go/no-go criteria.',
 'AX-1177-reversible IL-33 programme in HUVEC (6 h and 24 h), with isotype effect, % inhibition, HGMEC reversal and inflated-variance flag. Includes genes with very large IL-33 effects but uninformative P values.',
 'All 1,094 delivered Olink assays with de-duplication keys, recomputed BH, mapped gene, and the in vitro IL-33 response/AX-1177 reversal of the encoding gene.',
 'Back-calculation of the BH adjustment (m = 1,194) locating the 100 analysed-but-undelivered assays in the p-value ranking.',
 'Donor-level (not block-level) summary of the post-mortem file, with labels re-derived from the pathology text and a label audit.'],
})
integ = pd.DataFrame([
 ['RNA-seq','R1','Single limma/voom model pooled across HUVEC, HGMEC, A549 and MCF7 (annex section 5) gives implausible gene-wise SEs (SE = |logFC/t|).',
  '121 genes have median SE > 3 log2 units in endothelial contrasts (typical gene 0.34). SELE ~8.9, VCAM1 ~7.0, CXCL8 ~4.1, IL1RL1/ST2 ~8.3, CXCL1 ~1,100, CDH5 ~930, CD93 ~16,500.',
  'P/FDR uninformative for these genes, which include the canonical adhesion molecules, CXCL8 and ST2. Their log2FCs are valid group-mean differences (e.g., SELE +11.2 with IL-33 at 6 h, -10.9 with AX-1177).',
  'Refit endothelial cells separately from the archived count matrices; report per-cell-line dispersion.'],
 ['RNA-seq','R2','Implausibly small SEs in individual contrasts create spurious hits.',
  'AKR1C2 t = 169 for log2FC 0.11 (A549, 24 h); NCL t = -26.6 for log2FC -0.12 (MCF7, 6 h); DYNC1H1 t = -16.1 (HUVEC 24 h).',
  'Some antibody-alone "hits" are artefacts. None of the antibody-alone hits replicate across timepoints or cell lines (0-1 genes overlapping, chance level).',
  'Same refit; use a minimum-fold-change test (limma TREAT).'],
 ['RNA-seq','R3','Sheets named "6h" and "24h" in AX-1177_rnaseq_contrasts.xlsx each contain all 24 contrasts at both timepoints (identical values, different row order); the "6h" sheet dimension tag reports 1,048,576 rows (Excel maximum).',
  'Each sheet holds 629,040 rows = 24 contrasts x 26,210 genes; (contrast, gene) values identical between sheets.',
  'No data loss detected, but sheet names invite timepoint mis-citation.','Re-export one sheet per contrast with checksums.'],
 ['RNA-seq','R4','Reference arm label mismatch: comparison column says "IL33_vs_Nontreated", sheet names and annex say "Vehicle".',
  'AX-1177_rnaseq_huvec_il33.xlsx, both sheets.','Ambiguity about the reference arm for the headline IL-33 response.','Confirm Nontreated = Vehicle arm (annex section 3).'],
 ['RNA-seq','R5','HGMEC has no vehicle/unstimulated arm and no IL-33 vs control contrast.',
  'Only Compound_47 vs IC119, Compound_47+IL33 vs IL33 and vs IL33+IC119 delivered for HGMEC.','IL-33 effect size and % inhibition in HGMEC cannot be estimated; only the reversal direction can.','Add vehicle and IL-33 vs isotype contrasts.'],
 ['RNA-seq','R6','Epithelial lines never received IL-33; MCF7 is a breast line; DMSO is not a vehicle for an IgG.',
  'Annex section 3, epithelial arms: PBS, DMSO, IC119, Compound_47 only.','No evidence on epithelial IL-33 neutralisation; epithelial contrasts address antibody-alone effects only.','Primary bronchial epithelial cells (ALI) +/- IL-33 (reduced and oxidised) +/- virus.'],
 ['RNA-seq','R7','Single donor per primary endothelial cell (HUVEC P2, HGMEC P5); n = 3 are culture replicates.','Annex section 2.','Donor-to-donor variability unknown; generalisation limited.','At least 3 donors; lung microvascular endothelium.'],
 ['RNA-seq','R8','Single antibody concentration, concurrent addition (no pre-incubation), reduced IL-33 only.',
  '10 ug/mL IgG (~68 nM) vs 30 ng/mL IL-33 (~1.66 nM): ~41-fold molar excess.','No potency (IC50/IC90) to support dose projection; oxidised IL-33 (the claimed dual-form differentiator) untested; therapeutic window (antibody after IL-33) untested.','Dose-response, pre/co/post-addition, oxidised IL-33.'],
 ['RNA-seq','R9','The "IL-33-repressed" genes are not IL-33 biology.',
  'Isotype also restores them (slope -0.80 at 6 h); dominated by low-count lncRNAs/pseudogenes with log2FC near -3.','The "4,031 DE genes" headline overstates the biology; only the induced programme (427 core genes at 6 h, 140 at 24 h) is attributable to IL-33.','Report the core induced programme; filter low counts within endothelial libraries.'],
 ['RNA-seq','R10','Annotation gaps.','entrez/gene_name missing for renamed genes (CXCL8, ACKR1, CAVIN1).','Cosmetic.','Update annotation.'],
 ['Serum proteomics','P1','100 analysed assays were not delivered.',
  'Reported adj. p values imply BH over m = 1,194 tests (exact from HGF, rank 1), vs 1,094 delivered. Reconstructed ranks place >=3 undelivered assays at FDR < 0.05 (p ~0.0003, ~0.0011, ~0.0055) and ~15 at p < 0.05. IL-33, an Inflammation-panel analyte, is absent, as are IL-4, IL-13, TSLP, IL-1a.',
  'Evidence base incomplete; the target ligand is missing; possible selective delivery.','Obtain all 1,194 results with NPX, LOD and missingness; document the QC filter.'],
 ['Serum proteomics','P2','Annex states BH was applied "across all assays in the delivery".','Contradicted by P1.','Documentation error.','Correct annex.'],
 ['Serum proteomics','P3','Duplicate proteins across panels are counted separately.','27 proteins on >1 panel (58 rows), e.g., IL-6 x4, HGF x2, OPG x2; 178 FDR-significant rows = 169 unique proteins. Duplicates are concordant (a reassuring QC signal).','Hit counts inflated.','Collapse per protein before counting.'],
 ['Serum proteomics','P4','"Per log unit" ORs: log base unspecified; Olink NPX is already log2; ORs not comparable across proteins.','E.g., CSF-1 OR 90 (4.2-1,933).','Do not rank markers by OR magnitude.','Report per-SD standardised ORs.'],
 ['Serum proteomics','P5','Undocumented columns composite_endpoint_0/1.','Values are k/56 and k/44 (56 non-events, 44 events); likely fraction below LOD per outcome group (max 9%).','Interpretation relies on inference.','Document.'],
 ['Serum proteomics','P6','Design limits.','Single centre, pre-vaccination, COVID-19 only, one timepoint (enrolment), n = 100 (44 events); not adjusted for renal function, days from symptom onset or treatment; 82% of proteins have OR > 1.','Associations are prognostic and largely non-specific; transfer to current-era or non-COVID viral pneumonia is untested.','Replicate in contemporary, multi-virus cohorts; adjust for eGFR and symptom duration.'],
 ['Post-mortem','M1','Pseudo-replication: blocks are not independent.','74 blocks from 31 donors; 3 COVID+ donors contribute 24 of 49 COVID+ blocks. Block-level tests give EDN p = 0.0006 and endothelial IL-33 p = 0.017 vs donor-level p = 0.13 and 0.075.','Block-level results overstate evidence.','Analyse per donor (or mixed models with donor random effect).'],
 ['Post-mortem','M2','Donor-level fields recorded only on the first block; some notes sit on later blocks.','E.g., COPD recorded on 2040-1B; bronchitis on 2045-1B.','Naive filtering drops information.','Propagate donor fields; one donor table.'],
 ['Post-mortem','M3','Disease labels discordant with pathology text.','4/10 "COVID neg pneumonia" donors have no pneumonia recorded (1905, 1961, 1968, 1970; 1905 also lacks a SARS-CoV-2 result); 2/5 "non-pneumonia" controls have pneumonia/pneumonitis (1956, 1976); control 1944 has pulmonary coccidioidomycosis; 2/16 COVID+ lack acute pneumonia (2067 with 8 blocks, 2101).','Group comparisons are contaminated.','Re-adjudicate categories with the pathologists.'],
 ['Post-mortem','M4','Score integrity.','IL-33 scores up to 5.5 on a documented 0-5 scale; numeric columns use an undocumented transform (1+ -> 1.5 ... 5+ -> 5.5); epithelial/endothelial IL-33 identical across all blocks in about half of multi-block donors; endothelial IL-33 at ceiling in most controls; single reader; ND entries; trailing spaces.','Treat as ordinal only; limited sensitivity to detect differences.','Second blinded reader, quantitative digital pathology, documented scoring rules.'],
 ['Post-mortem','M5','Cohort and confounding.','Age 64-98, all white, heavy cardiovascular and COPD comorbidity; end-stage tissue only; no time-from-onset. Vascular IL-33 correlates with age (rho = 0.57, p = 0.001). RNA IDs for 22 blocks but no RNA delivered.','Age confounds vascular IL-33; end-stage tissue does not represent the treatment window.','Age-adjusted analysis; request tissue RNA; earlier-stage tissue if obtainable.'],
], columns=['dataset','id','issue','evidence','impact_on_conclusions','remedy'])
biom = pd.DataFrame([
 ['sST2 (soluble IL1RL1)','serum','#2 of 1,094 assays: OR 3.02 (1.83-5.01) per log unit, q = 0.0075, adjusted for age, sex, NEWS2; IL-33 decoy receptor; non-specific (the IL-1-family receptors IL-1R2 and IL-18R1 are also prognostic).','PATIENTS: prognostic enrichment/stratification at enrolment (pre-dose). NOT a PD marker, and NOT proof of IL-33 activity.','Clinical-grade ST2 immunoassays exist (external). Cut-off must be derived from our raw data and validated in an independent cohort.'],
 ['OPG (TNFRSF11B)','serum','IL-33 induces +4.8 (6 h) / +2.4 (24 h) log2 in HUVEC; AX-1177 reverses 100% / 114%; serum OR 6.8 (q = 0.014) and 4.4 (q = 0.020) on two panels.','PATIENTS: exploratory PD/response marker (baseline, 24 h, day 3) plus prognostic covariate.','Needs bridging to a clinical immunoassay; not IL-33-specific (other NF-kB stimuli induce it).'],
 ['CCL20','serum','IL-33 +9.2 / +5.6 log2; AX-1177 reverses 106% / 102%; serum OR 1.83, q = 0.020.','PATIENTS: exploratory PD marker.','As above.'],
 ['IL-6','serum','IL-33 +5.8 / +2.8 log2; reversed 102% / 102%; serum OR 2.1-2.3 on four panels, q <= 0.019.','PATIENTS: exploratory PD marker, with caveats.','Least specific (also driven by IL-1, TNF and virus); confounded by tocilizumab/dexamethasone use.'],
 ['IL-18R1','serum','IL-33 +3.6 / +1.2 log2 (q = 1e-20 at 6 h); reversed; serum OR 6.07, q = 0.018.','PATIENTS: exploratory PD marker (secondary).','Biology of the soluble form unclear.'],
 ['Free IL-33, total (drug-bound) IL-33, IL-33:sST2 complexes','serum (+ nasal/BAL where feasible)','Not in our delivery: IL-33 is missing from the Olink data (withheld or undetectable).','PATIENTS: target engagement (total IL-33 accumulation) and mechanism confirmation; selection only if detectable pre-dose.','Must be developed: drug-tolerant, high-sensitivity assays. This is the critical gap.'],
 ['E-selectin (SELE), PTX3, IL-8 (CXCL8)','serum','Very large in vitro IL-33 effects reversed by AX-1177 (SELE +11.2, CXCL8 +8.2, PTX3 +2.2 log2), but delivered RNA-seq P values are invalid (Figure 2); serum SELE p = 0.022 (q = 0.09), PTX3 q = 0.012, IL-8 q = 0.023.','PATIENTS (later): candidate PD markers once the per-cell-type refit confirms them.','Pending refit.'],
 ['vWF, ANGPT2','serum','Prognostic (q = 0.050, 0.052) but not IL-33 transcriptional targets in HUVEC (granule-stored; log2FC about 0).','PATIENTS: endotheliopathy stratification only; not PD for AX-1177.','Clinical assays exist.'],
 ['GM-CSF (CSF2), G-CSF (CSF3), CXCL6, CX3CL1, TNF, CXCL10','cell supernatant / transcript','Strongest, cleanest in vitro markers (e.g., CSF2 +10.3 log2, 119% reversal), but not prognostic in serum (G-CSF, CXCL6, CX3CL1, TNF, CXCL10 null) or not measured (GM-CSF).','NOT for patients now: in vitro potency/bioassay and ex vivo PD (e.g., whole-blood or endothelial stimulation) readouts.','Ready for in vitro use.'],
 ['Type-2/eosinophil markers (IL-5, eotaxins, TARC, tryptase, ECP); tissue EPX/EDN/MBP','serum / tissue','Null in serum and tissue (donor level).','None.','Ruled out.'],
 ['Lung IL-33 IHC','tissue','Constitutive in epithelium and endothelium; not increased in COVID-19; ceiling effects.','Research only (no patient role).','Not feasible as a patient biomarker.'],
], columns=['marker','matrix','evidence_in_our_data','proposed_role','readiness_and_caveats'])
ruled = pd.DataFrame([
 ['Continue in "severe lower respiratory viral infection" as framed','Ruled out as framed','Only SARS-CoV-2 patient data (pre-vaccination, single centre); IL-33 ligand not measured; lung IL-33 not increased; the AX-1177-reversible programme is not enriched among severity proteins (OR 1.16, p = 0.62).'],
 ['Type-2 / eosinophilic mechanism (IL-33 -> ILC2 -> IL-5/IL-13 -> eosinophils) in viral LRTI','Ruled out','Serum IL-5 OR 1.00; eotaxin-1/-2, TARC, tryptase, KIT null; tissue EPX/EDN/MBP not different by COVID status at donor level (p = 0.43/0.13/0.56); IL-33 does not correlate with eosinophils.'],
 ['Reposition to COPD/asthma on the strength of our data','Not supported','No epithelial IL-33 pharmacology (epithelial lines never received IL-33); tissue IL-33 not associated with COPD/asthma notes (p = 0.22-0.94). External clinical activity in COPD exists but is not our data.'],
 ['Reposition to glomerular/renal vascular disease (HGMEC)','Not supported','Only an in vitro reversal in one-donor HGMEC (59% of core genes at 6 h, 17% at 24 h, no vehicle arm); no patient data.'],
 ['Reposition to cardiovascular disease (sST2 is a heart-failure marker)','Not supported','NT-proBNP and troponin I not associated (p = 0.05-0.17 and 0.11); no cardiac data.'],
 ['Use sST2 as evidence of IL-33 activity or as a PD marker','Ruled out','sST2 is a decoy induced by many stimuli; it rises together with other IL-1-family receptors (IL-1R2 q = 0.018, IL-18R1 q = 0.018); the drug is not expected to lower it.'],
 ['AX-1177 intrinsic or off-target transcriptional activity','Ruled out (favourable)','14-73 FDR hits per antibody-alone contrast, but 0-1 genes replicate across independent timepoints or cell lines; hits are low-count noise or SE artefacts.'],
 ['Isotype/Fc effects explaining the neutralisation','Ruled out','Isotype has no effect on IL-33-induced genes (slope 0.01 at 6 h).'],
 ['"About 4,000 DE genes" as the IL-33 effect size','Ruled out','IL-33-repressed genes are reversed by isotype too (artefact); the attributable programme is 427 induced genes at 6 h.'],
 ['Block-level post-mortem statistics','Ruled out','Pseudo-replication; donor-level and age-adjusted analyses remove the apparent effects.'],
 ['Ranking serum biomarkers by OR magnitude','Ruled out','Per-log-unit ORs are scale-dependent (CSF-1 OR 90).'],
 ['HGF (top serum hit) or vWF/ANGPT2 as IL-33 PD markers','Ruled out','Not IL-33-responsive in HUVEC (HGF +0.5 log2, ns; ANGPT2 +0.09; vWF -0.08).'],
 ['GM-CSF/G-CSF/CXCL6/CX3CL1/TNF/CXCL10 as patient markers','Deprioritised','Best in vitro markers, but not prognostic in serum or not measured; keep for in vitro/ex vivo potency assays.'],
 ['Drop the asset outright now','Not recommended','The molecule performs well in vitro; the decisive disease-linkage evidence can be obtained quickly and cheaply from samples and data we already own.'],
], columns=['option_or_hypothesis','verdict','basis_in_our_data'])
plan = pd.DataFrame([
 ['Gate 1 (0-4 months): close the evidence gaps with in-house material','1a Obtain all 1,194 Olink results (incl. IL-33), NPX, LOD and missingness; re-analyse per protein with per-SD ORs, adding eGFR and days from onset.\n1b Measure free IL-33, total IL-33 and IL-33:sST2 complexes in the 100 biobanked enrolment sera (high-sensitivity assay).\n1c Refit the RNA-seq per cell type from the archived counts.\n1d Re-adjudicate post-mortem categories; blinded second reader; donor-level, age-adjusted re-analysis; request the 22 tissue-RNA samples.',
  'Enrolment serum (pre-treatment): the only timepoint at which our associations exist.',
  'GO if IL-33 (free or complexed) is detectable in a meaningful fraction of patients AND is associated with the composite outcome beyond NEWS2 and sST2 AND correlates with an IL-33 endothelial score (OPG + CCL20 + IL-6, plus SELE/PTX3 if confirmed by the refit). NO-GO (drop/out-license) if IL-33 is undetectable or unrelated to outcome and to the endothelial score.'],
 ['Gate 2 (4-10 months): pharmacology that supports a dose and the differentiation claim','2a Primary human lung microvascular EC, >=3 donors: reduced AND oxidised IL-33; 8-point AX-1177 dose-response (IC50/IC90); pre-incubation vs concurrent vs delayed addition (1, 3, 6 h after IL-33).\n2b Specificity arms: IL-1b, TNF, poly(I:C)/IFN-b and virus-conditioned epithelial medium, to define the IL-33-specific component; anti-ST2 comparator.\n2c Primary bronchial epithelium (ALI) +/- influenza/RSV/SARS-CoV-2 +/- AX-1177: IL-33 release (reduced/oxidised), and transfer of conditioned medium to endothelium.',
  'Transcripts at 6 h (primary, maximally reversible); secreted proteins at 24 h.',
  'GO if IC90 is achievable at projected lung-interstitial exposure; AX-1177 neutralises oxidised as well as reduced IL-33; virus-induced epithelial IL-33 activates endothelium in an AX-1177-reversible way; and a delayed-addition window exists. NO-GO if activity collapses when the antibody is added after IL-33.'],
 ['Gate 3 (10-18 months): in vivo proof of concept and safety','Viral pneumonia model with a cross-reactive/surrogate anti-IL-33: vascular leak, lung injury, survival; viral load and antiviral T-cell responses (safety); prophylactic vs delayed dosing.',
  'Early (within 24-48 h of infection) and delayed dosing arms.',
  'GO to IND-enabling only with efficacy on lung injury without impaired viral control. Otherwise drop/out-license.'],
 ['Clinical design if gates pass (for planning only)','Hospitalised viral pneumonia, early (<=48-72 h of oxygen requirement), enriched for high sST2 at enrolment; multi-virus.',
  'Baseline (pre-dose) for enrichment; 24 h, day 3 and day 7 for PD (OPG, CCL20, IL-6) and TE (total IL-33).',
  'Primary: ICU/IMV/death by day 30 (as in our cohort); PD: fall in OPG/CCL20/IL-6 vs placebo; TE: rise in total IL-33.'],
], columns=['gate','activities','sampling_timepoint','go_no_go_criteria'])
with pd.ExcelWriter('/tmp/outputs/AX-1177_supporting_tables.xlsx', engine='openpyxl') as xw:
    readme.to_excel(xw, sheet_name='README', index=False)
    integ.to_excel(xw, sheet_name='1_Data_integrity_log', index=False)
    biom.to_excel(xw, sheet_name='2_Biomarker_candidates', index=False)
    ruled.to_excel(xw, sheet_name='3_Considered_and_ruled_out', index=False)
    plan.to_excel(xw, sheet_name='4_Gated_plan', index=False)
    T['sig'].to_excel(xw, sheet_name='5_Core_IL33_signature', index=False)
    T['pout'].to_excel(xw, sheet_name='6_Serum_proteomics_annotated', index=False)
    T['wh'].to_excel(xw, sheet_name='7_Withheld_assay_reconstruction', index=False)
    T['dout'].to_excel(xw, sheet_name='8_Postmortem_donor_level', index=False)
# formatting
import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
wb = openpyxl.load_workbook('/tmp/outputs/AX-1177_supporting_tables.xlsx')
for ws in wb.worksheets:
    for c in ws[1]:
        c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='2C3E50'); c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'A2'
    textual = ws.title in ('README','1_Data_integrity_log','2_Biomarker_candidates','3_Considered_and_ruled_out','4_Gated_plan')
    for col in ws.columns:
        letter = col[0].column_letter
        maxlen = max((len(str(c.value)) if c.value is not None else 0) for c in col[:200])
        ws.column_dimensions[letter].width = min(70 if textual else 28, max(10, maxlen*0.9))
        if textual:
            for c in col[1:]: c.alignment = Alignment(wrap_text=True, vertical='top')
wb.save('/tmp/outputs/AX-1177_supporting_tables.xlsx')
print('saved')
