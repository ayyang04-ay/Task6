import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',80)
H = pd.read_csv('/tmp/work/hallmark.csv')
pu = pd.read_pickle('/tmp/work/bridge.pkl')
universe = set(pu.rna_sym)
sev = set(pu.loc[pu.sev_q05,'rna_sym'])
res=[]
for name,g in H.groupby('gs_name').gene_symbol:
    s = set(g)&universe
    if len(s)<5: continue
    k=len(sev&s); M=len(universe); n=len(s); N=len(sev)
    p = stats.hypergeom.sf(k-1,M,n,N)
    res.append((name,k,n,N,(k/N)/(n/M) if N else np.nan,p,','.join(sorted(sev&s))[:80]))
df = pd.DataFrame(res, columns=['set','k','n_in_olink','N_sev','fold','p','genes']); df['q']=multipletests(df.p,method='fdr_bh')[1]
print('universe (mapped Olink):', len(universe), ' severe q<0.05 (mapped):', len(sev))
print(df.sort_values('p').head(12).round(4).to_string(index=False))
