import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',60)
H = pd.read_csv('/tmp/work/hallmark.csv'); R = pd.read_csv('/tmp/work/reactome.csv')
ann = pd.read_pickle('/tmp/work/ann.pkl'); core = pd.read_pickle('/tmp/work/core.pkl')
universe = set(ann.symbol.dropna())
def ora(genes, gs, universe, minsize=10):
    genes = set(genes)&universe
    res=[]
    for name, g in gs.groupby('gs_name').gene_symbol:
        s = set(g)&universe
        if len(s)<minsize: continue
        k = len(genes&s)
        if k==0: continue
        M=len(universe); n=len(s); N=len(genes)
        p = stats.hypergeom.sf(k-1, M, n, N)
        res.append((name, k, n, N, k/(N*n/M), p, ','.join(sorted(genes&s))[:90]))
    df = pd.DataFrame(res, columns=['set','k','setsize','N','fold','p','genes'])
    df['q'] = multipletests(df.p, method='fdr_bh')[1]
    return df.sort_values('p')
for tp in ['6','24']:
    d, cu, cd = core[tp]
    up = ann.symbol[cu].dropna(); dn = ann.symbol[cd].dropna()
    print(f'===== {tp}h core UP (n={len(up)}) HALLMARK'); print(ora(up, H, universe).head(10).round(4).to_string(index=False))
    print(f'===== {tp}h core DOWN (n={len(dn)}) HALLMARK'); print(ora(dn, H, universe).head(6).round(4).to_string(index=False))
    print(f'===== {tp}h core UP REACTOME'); print(ora(up, R, universe).head(10).round(4).to_string(index=False))
