import re, os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether, HRFlowable
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping
FD = '/opt/conda/envs/core/lib/python3.11/site-packages/matplotlib/mpl-data/fonts/ttf/'
pdfmetrics.registerFont(TTFont('DV', FD+'DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DV-B', FD+'DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DV-I', FD+'DejaVuSans-Oblique.ttf'))
pdfmetrics.registerFont(TTFont('DV-BI', FD+'DejaVuSans-BoldOblique.ttf'))
pdfmetrics.registerFont(TTFont('DVM', FD+'DejaVuSansMono.ttf'))
addMapping('DV',0,0,'DV'); addMapping('DV',1,0,'DV-B'); addMapping('DV',0,1,'DV-I'); addMapping('DV',1,1,'DV-BI')
ss = getSampleStyleSheet()
base = ParagraphStyle('base', parent=ss['Normal'], fontName='DV', fontSize=9, leading=12.2, spaceAfter=3)
h1 = ParagraphStyle('h1', parent=base, fontName='DV-B', fontSize=15, leading=19, spaceAfter=8, textColor=colors.HexColor('#1b2631'))
h2 = ParagraphStyle('h2', parent=base, fontName='DV-B', fontSize=12, leading=15, spaceBefore=9, spaceAfter=5, textColor=colors.HexColor('#1f618d'))
h3 = ParagraphStyle('h3', parent=base, fontName='DV-B', fontSize=10, leading=13, spaceBefore=6, spaceAfter=3, textColor=colors.HexColor('#1b2631'))
cell = ParagraphStyle('cell', parent=base, fontSize=7.6, leading=9.6, spaceAfter=0)
cellb = ParagraphStyle('cellb', parent=cell, fontName='DV-B', textColor=colors.white)
bul = ParagraphStyle('bul', parent=base, leftIndent=12, bulletIndent=2)
bul2 = ParagraphStyle('bul2', parent=base, leftIndent=24, bulletIndent=14)
cap = ParagraphStyle('cap', parent=base, fontSize=8, leading=10, textColor=colors.HexColor('#555555'))
def inline(t):
    t = t.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    t = re.sub(r'`([^`]+)`', r'<font face="DVM" size="8">\1</font>', t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?![\*\w])', r'<i>\1</i>', t)
    return t
def parse_table(lines, width):
    rows = [ [c.strip() for c in l.strip().strip('|').split('|')] for l in lines if not re.match(r'^\s*\|?\s*:?-{2,}', l.strip().strip('|').split('|')[0] if l.strip() else '') ]
    rows = [r for r in rows if not all(re.fullmatch(r':?-{2,}:?', c) or c=='' for c in r)]
    ncol = max(len(r) for r in rows)
    header = not all(c=='' for c in rows[0])
    if not header: rows = rows[1:]
    data = []
    for i,r in enumerate(rows):
        r = r + ['']*(ncol-len(r))
        st = cellb if (i==0 and header) else cell
        data.append([Paragraph(inline(c), st) for c in r])
    # column widths proportional to content length (capped)
    lens = [max(len(rows[i][j]) if j < len(rows[i]) else 0 for i in range(len(rows))) for j in range(ncol)]
    lens = [min(max(l,8),90) for l in lens]
    tot = sum(lens); cw = [width*l/tot for l in lens]
    t = Table(data, colWidths=cw, repeatRows=1 if header else 0)
    hdr_bg = colors.HexColor('#2c3e50') if header else colors.white
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),hdr_bg),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('GRID',(0,0),(-1,-1),0.3,colors.HexColor('#b0b7bd')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white, colors.HexColor('#f4f6f7')]),
        ('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2)]))
    return t
def build(md_path, pdf_path, figs):
    doc = SimpleDocTemplate(pdf_path, pagesize=A4, leftMargin=1.6*cm, rightMargin=1.6*cm, topMargin=1.5*cm, bottomMargin=1.5*cm,
                            title='AX-1177 portfolio audit: recommendation and forward view', author='Portfolio analysis')
    W = A4[0]-3.2*cm
    story=[]; lines = open(md_path).read().split('\n'); i=0; para=[]
    def flush():
        nonlocal para
        if para: story.append(Paragraph(inline(' '.join(para)), base)); para=[]
    while i < len(lines):
        l = lines[i]
        if l.strip().startswith('|'):
            flush(); tl=[]
            while i < len(lines) and lines[i].strip().startswith('|'):
                tl.append(lines[i]); i+=1
            story.append(parse_table(tl, W)); story.append(Spacer(1,5)); continue
        if l.startswith('# '): flush(); story.append(Paragraph(inline(l[2:]), h1))
        elif l.startswith('## '): flush(); story.append(Paragraph(inline(l[3:]), h2))
        elif l.startswith('### '): flush(); story.append(Paragraph(inline(l[4:]), h3))
        elif l.strip()=='---': flush(); story.append(HRFlowable(width='100%', thickness=0.6, color=colors.HexColor('#95a5a6'), spaceBefore=4, spaceAfter=4))
        elif re.match(r'^\s{2,}- ', l): flush(); story.append(Paragraph(inline(l.strip()[2:]), bul2, bulletText='–'))
        elif re.match(r'^- ', l): flush(); story.append(Paragraph(inline(l[2:]), bul, bulletText='•'))
        elif re.match(r'^\s{2,}\d+\. ', l): flush(); m = re.match(r'^\s*(\d+)\. (.*)', l); story.append(Paragraph(inline(m.group(2)), bul2, bulletText=m.group(1)+'.'))
        elif re.match(r'^\d+\. ', l): flush(); m = re.match(r'^(\d+)\. (.*)', l); story.append(Paragraph(inline(m.group(2)), bul, bulletText=m.group(1)+'.'))
        elif l.strip()=='' : flush()
        else: para.append(l.strip())
        i+=1
    flush()
    story.append(PageBreak()); story.append(Paragraph('Figures', h1))
    for fpath, caption in figs:
        from PIL import Image as PI
        im = PI.open(fpath); w,h = im.size
        iw = W; ih = iw*h/w
        if ih > 23*cm: ih = 23*cm; iw = ih*w/h
        story.append(KeepTogether([Image(fpath, width=iw, height=ih), Paragraph(inline(caption), cap), Spacer(1,10)]))
    def onpage(c, d):
        c.saveState(); c.setFont('DV',7); c.setFillColor(colors.HexColor('#7f8c8d'))
        c.drawString(1.6*cm, 0.9*cm, 'AX-1177 portfolio audit: based solely on the delivered AX-1177 data files')
        c.drawRightString(A4[0]-1.6*cm, 0.9*cm, f'page {d.page}'); c.restoreState()
    doc.build(story, onFirstPage=onpage, onLaterPages=onpage)
if __name__=='__main__':
    F='/tmp/outputs/figures/'
    figs=[(F+'fig1_invitro_neutralisation.png','Figure 1. AX-1177 neutralises reduced IL-33 signalling in HUVEC; isotype does not. The IL-33-repressed set is an artefact of the IL-33-alone arm.'),
          (F+'fig2_rnaseq_variance_inflation.png','Figure 2. Delivered RNA-seq statistics: implausible gene-wise SEs from the single pooled model make P values uninformative for SELE, VCAM1, CXCL8, CXCL1, ST2 and others.'),
          (F+'fig3_serum_severity_landscape.png','Figure 3. Serum proteins at enrolment vs composite outcome (100 COVID-19 patients). sST2 #2 of 1,094; type-2 mediators null.'),
          (F+'fig4_translational_bridge.png','Figure 4. The AX-1177-reversible IL-33 programme is not over-represented among severity-associated serum proteins.'),
          (F+'fig5_postmortem_lung.png','Figure 5. Post-mortem lung (donor level): IL-33 not increased in COVID-19; no COVID-specific eosinophilia; data-quality flags.'),
          (F+'fig6_timecourse_and_markers.png','Figure 6. Time course: near-complete neutralisation at 6 h, partial at 24 h (interferon-stimulated genes escape); HGMEC reverses the same genes.')]
    build('/tmp/outputs/AX-1177_committee_memo.md','/tmp/outputs/AX-1177_committee_memo.pdf', figs)
    print('pdf ok')
