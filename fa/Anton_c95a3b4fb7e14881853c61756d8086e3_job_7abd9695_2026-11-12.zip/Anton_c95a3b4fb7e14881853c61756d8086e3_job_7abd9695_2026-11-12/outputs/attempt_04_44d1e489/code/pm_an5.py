import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.miscmodels.ordinal_model import OrderedModel
don = pd.read_pickle('/tmp/work/pm_donor2.pkl').reset_index()
don['covid'] = (don.SARS2=='pos').astype(int)
don['acute'] = don.group_path.isin(['COVID+ acute lung injury/pneumonia','COVID- acute pneumonia']).astype(int)
don['age10'] = don.Age/10
don['male'] = (don.Gender=='M').astype(int)
print(don.groupby('covid').Age.describe())
for v in ['IL33_endo','IL33_vsmc','IL33_epi','EDN_o']:
    d = don[[v,'covid','age10','acute','male','NE_dIL5Ra_o']].dropna().copy()
    d['r'] = d[v].rank()
    m1 = smf.ols('r ~ covid', d).fit(); m2 = smf.ols('r ~ covid + age10', d).fit(); m3 = smf.ols('r ~ covid + age10 + acute', d).fit()
    print(f'{v}: rank-OLS covid coef p: unadj={m1.pvalues.covid:.3f}; +age={m2.pvalues.covid:.3f} (age p={m2.pvalues.age10:.3f}); +age+acute={m3.pvalues.covid:.3f} (acute p={m3.pvalues.acute:.3f})')
    # ordinal logistic (proportional odds) on donor medians, rounded to categories
    try:
        cats = pd.Categorical(d[v].round(2), ordered=True)
        om = OrderedModel(cats.codes, d[['covid','age10']], distr='logit').fit(method='bfgs', disp=False)
        print(f'    ordinal logit: covid OR={np.exp(om.params["covid"]):.2f} p={om.pvalues["covid"]:.3f}; age(10y) OR={np.exp(om.params["age10"]):.2f} p={om.pvalues["age10"]:.3f}')
    except Exception as e:
        print('   ordinal failed', e)
