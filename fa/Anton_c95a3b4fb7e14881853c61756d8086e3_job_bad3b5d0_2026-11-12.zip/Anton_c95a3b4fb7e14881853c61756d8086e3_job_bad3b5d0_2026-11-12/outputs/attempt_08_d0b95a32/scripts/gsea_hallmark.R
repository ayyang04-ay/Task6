#!/usr/bin/env Rscript
# AX-1177 portfolio audit - Hallmark gene-set enrichment of the delivered contrasts (fgsea, MSigDB via msigdbr 7.5.1).
# Run after analysis_pipeline.py:  Rscript gsea_hallmark.R <output dir>
# Ranking statistic: delivered moderated t; for rows whose implied SE is not credible (>1.5 or <0.02) the empirical-null t
# (endothelial contrasts) or 0 (epithelial contrasts) is substituted - see analysis_pipeline.py.
args <- commandArgs(trailingOnly=TRUE); out <- ifelse(length(args) >= 1, args[1], "/tmp/outputs")
if (dir.exists("/opt/refdbs/rlib")) .libPaths(c("/opt/refdbs/rlib", .libPaths()))
suppressMessages({library(msigdbr); library(fgsea); library(data.table)})
set.seed(1)
d <- fread(file.path(out, "intermediate", "rank_stats.csv"))
d <- d[order(-AveExpr)][!duplicated(symbol)]
H <- as.data.table(msigdbr(species="Homo sapiens", category="H")); sets <- split(H$gene_symbol, H$gs_name)
res <- rbindlist(lapply(grep("^t_", names(d), value=TRUE), function(tc) {
  st <- d[[tc]]; names(st) <- d$symbol; st <- sort(st[is.finite(st)], decreasing=TRUE)
  fg <- fgseaMultilevel(sets, st, minSize=15, maxSize=500, eps=0)
  fg[, contrast := sub("^t_", "", tc)]; fg[, leadingEdge := sapply(leadingEdge, function(x) paste(head(x, 15), collapse=","))]; fg }))
fwrite(res[, .(contrast, pathway, NES, pval, padj, size, leadingEdge)][order(contrast, pval)], file.path(out, "tables", "gsea_hallmark.csv"))
# median log2 fold change of each Hallmark set in each contrast (effect size behind the enrichment scores)
lc <- grep("^lfc_", names(d), value=TRUE)
med <- rbindlist(lapply(names(sets), function(s) { x <- d[symbol %in% sets[[s]]]; data.table(pathway=s, n_genes=nrow(x), t(sapply(lc, function(k) round(median(x[[k]], na.rm=TRUE), 3)))) }))
setnames(med, lc, sub("^lfc_", "", lc)); fwrite(med, file.path(out, "tables", "hallmark_median_log2FC.csv"))
print(dcast(res[pathway %in% c("HALLMARK_TNFA_SIGNALING_VIA_NFKB","HALLMARK_INFLAMMATORY_RESPONSE","HALLMARK_INTERFERON_GAMMA_RESPONSE","HALLMARK_IL6_JAK_STAT3_SIGNALING","HALLMARK_COMPLEMENT","HALLMARK_COAGULATION","HALLMARK_MYC_TARGETS_V1","HALLMARK_OXIDATIVE_PHOSPHORYLATION")], pathway ~ contrast, value.var="NES")[, lapply(.SD, function(x) if (is.numeric(x)) round(x, 2) else x)])
