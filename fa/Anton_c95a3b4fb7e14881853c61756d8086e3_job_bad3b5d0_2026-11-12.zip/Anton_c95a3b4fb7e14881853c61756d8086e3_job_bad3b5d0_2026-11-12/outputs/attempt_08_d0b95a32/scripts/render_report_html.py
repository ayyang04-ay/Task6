#!/usr/bin/env python
"""Render the markdown report to a single self-contained HTML file (figures embedded)."""
import sys, os, re, base64, markdown
out = sys.argv[1] if len(sys.argv) > 1 else '/tmp/outputs'
md = open(os.path.join(out, 'AX-1177_portfolio_audit_report.md'), encoding='utf-8').read()
html = markdown.markdown(md, extensions=['tables', 'fenced_code', 'sane_lists'])
def embed(m):
    path = os.path.join(out, m.group(1))
    b64 = base64.b64encode(open(path, 'rb').read()).decode()
    return f'src="data:image/png;base64,{b64}"'
html = re.sub(r'src="(figures/[^"]+\.png)"', embed, html)
css = """
body{font-family:-apple-system,'Segoe UI',Helvetica,Arial,sans-serif;max-width:1050px;margin:2em auto;padding:0 1.2em;line-height:1.5;color:#1a1a1a;font-size:15px}
h1{font-size:1.7em;border-bottom:2px solid #333;padding-bottom:.3em} h2{font-size:1.3em;margin-top:1.8em;border-bottom:1px solid #bbb;padding-bottom:.2em} h3{font-size:1.08em;margin-top:1.4em}
table{border-collapse:collapse;margin:1em 0;font-size:.9em;width:100%} th,td{border:1px solid #c8c8c8;padding:5px 8px;text-align:left;vertical-align:top} th{background:#f0f0f0}
img{max-width:100%;height:auto;margin:.6em 0;border:1px solid #ddd} code{background:#f4f4f4;padding:1px 4px;border-radius:3px;font-size:.92em}
"""
page = f'<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>AX-1177 portfolio audit</title><style>{css}</style></head><body>{html}</body></html>'
open(os.path.join(out, 'AX-1177_portfolio_audit_report.html'), 'w', encoding='utf-8').write(page)
print('written', os.path.join(out, 'AX-1177_portfolio_audit_report.html'), round(len(page) / 1e6, 2), 'MB')
