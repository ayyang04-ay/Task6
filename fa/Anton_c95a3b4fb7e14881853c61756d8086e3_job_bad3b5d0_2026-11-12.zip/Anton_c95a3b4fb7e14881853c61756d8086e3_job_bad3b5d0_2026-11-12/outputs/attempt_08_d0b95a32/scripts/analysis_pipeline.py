#!/usr/bin/env python
"""AX-1177 portfolio audit - reproducible analysis of the four delivered files.
Run:  python analysis_pipeline.py  <dir with delivered files>  <output dir>
Python >=3.10 with pandas, numpy, scipy, statsmodels, openpyxl.
Writes key_numbers.json, an Excel workbook of supporting tables, and intermediate pickles used by the figure scripts."""
import sys, os, json, re, warnings
import numpy as np, pandas as pd, openpyxl
from scipy import stats, optimize
from statsmodels.stats.multitest import multipletests
import statsmodels.api as sm
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from olink_map import alias
warnings.filterwarnings('ignore')
IN = sys.argv[1] if len(sys.argv) > 1 else '/tmp/world/filesystem'
OUT = sys.argv[2] if len(sys.argv) > 2 else '/tmp/outputs'
WORK = os.path.join(OUT, 'intermediate'); os.makedirs(WORK, exist_ok=True); os.makedirs(os.path.join(OUT, 'tables'), exist_ok=True)
K = {}   # key numbers quoted in the report

# =====================================================================================================
# 1. RNA-seq contrast tables
# =====================================================================================================
def read_sheet(ws):
    it = ws.iter_rows(values_only=True); hdr = next(it)
    d = pd.DataFrame(list(it), columns=hdr); return d[d['Comparison'].notna()].copy()
wb = openpyxl.load_workbook(os.path.join(IN, 'AX-1177_rnaseq_huvec_il33.xlsx'), read_only=True)
huv = pd.concat([read_sheet(ws) for ws in wb.worksheets], ignore_index=True)
wb = openpyxl.load_workbook(os.path.join(IN, 'AX-1177_rnaseq_contrasts.xlsx'), read_only=True)
sheets = {ws.title: read_sheet(ws) for ws in wb.worksheets}
s6, s24 = sheets['6h'], sheets['24h']
m = s6.merge(s24, on=['Comparison', 'ensembl'], suffixes=('_a', '_b'))
K['rnaseq_contrast_tabs_identical'] = bool(len(m) == len(s6) == len(s24) and all(np.allclose(m[c + '_a'], m[c + '_b']) for c in ['logFC', 't', 'P.Value', 'adj.P.Val', 'B']))
K['rnaseq_rows_per_tab'] = int(len(s6)); K['rnaseq_contrasts_per_tab'] = int(s6['Comparison'].nunique()); K['rnaseq_genes'] = int(s6['ensembl'].nunique())
allc = pd.concat([huv, s6], ignore_index=True)
short = {
 'IL33_vs_Nontreated_HUVEC_6_hrs': 'HUV6_IL33vVeh', 'IL33_vs_Nontreated_HUVEC_24_hrs': 'HUV24_IL33vVeh',
 'Compound_47_vs_IC119_HUVEC_6hrs': 'HUV6_AbvIso', 'Compound_47_vs_IC119_HUVEC_24hrs': 'HUV24_AbvIso',
 'Compound_47_vs_IC119_HGMEC_6hrs': 'HGM6_AbvIso', 'Compound_47_vs_IC119_HGMEC_24hrs': 'HGM24_AbvIso',
 'Compound_47_IL33_vs_IL33_HUVEC_6hrs': 'HUV6_AbIL33vIL33', 'Compound_47_IL33_vs_IL33_HUVEC_24hrs': 'HUV24_AbIL33vIL33',
 'Compound_47_IL33_vs_IL33_HGMEC_6hrs': 'HGM6_AbIL33vIL33', 'Compound_47_IL33_vs_IL33_HGMEC_24hrs': 'HGM24_AbIL33vIL33',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs': 'HUV6_AbIL33vIsoIL33', 'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs': 'HUV24_AbIL33vIsoIL33',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs': 'HGM6_AbIL33vIsoIL33', 'Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs': 'HGM24_AbIL33vIsoIL33',
 'Compound_47_vs_IC119_A549_6hrs': 'A549_6_AbvIso', 'Compound_47_vs_IC119_A549_24hrs': 'A549_24_AbvIso',
 'Compound_47_vs_IC119_MCF7_6hrs': 'MCF7_6_AbvIso', 'Compound_47_vs_IC119_MCF7_24hrs': 'MCF7_24_AbvIso',
 'Compound_47_vs_DMSO_A549_6hrs': 'A549_6_AbvDMSO', 'Compound_47_vs_DMSO_A549_24hrs': 'A549_24_AbvDMSO',
 'Compound_47_vs_DMSO_MCF7_6hrs': 'MCF7_6_AbvDMSO', 'Compound_47_vs_DMSO_MCF7_24hrs': 'MCF7_24_AbvDMSO',
 'Compound_47_vs_PBS_A549_6hrs': 'A549_6_AbvPBS', 'Compound_47_vs_PBS_A549_24hrs': 'A549_24_AbvPBS',
 'Compound_47_vs_PBS_MCF7_6hrs': 'MCF7_6_AbvPBS', 'Compound_47_vs_PBS_MCF7_24hrs': 'MCF7_24_AbvPBS'}
allc['c'] = allc['Comparison'].map(short); assert allc['c'].notna().all()
allc['absSE'] = (allc['logFC'] / allc['t']).abs()
ann = allc.drop_duplicates('ensembl').set_index('ensembl')[['symbol', 'entrez', 'gene_name', 'AveExpr']]
piv = lambda v: allc.pivot(index='ensembl', columns='c', values=v)[list(short.values())]
L, T, P, Q, S = piv('logFC'), piv('t'), piv('P.Value'), piv('adj.P.Val'), piv('absSE')
pd.to_pickle(dict(L=L, T=T, P=P, Q=Q, S=S, ann=ann, short=short), os.path.join(WORK, 'rna_mats.pkl'))
endo = [c for c in L.columns if c[:3] in ('HUV', 'HGM')]
nullc = [c for c in L.columns if 'AbvIso' in c or 'AbvPBS' in c or 'AbvDMSO' in c]
sym2ens = ann.reset_index().sort_values('AveExpr', ascending=False).drop_duplicates('symbol').set_index('symbol')['ensembl']

# ---- 1a. QC of the delivered statistics
K['BH_within_contrast_reproduced'] = bool(all(np.allclose(multipletests(P[c].values, method='fdr_bh')[1], Q[c].values) for c in L.columns))
K['n_FDR5'] = {c: int((Q[c] < 0.05).sum()) for c in L.columns}
K['rows_total'] = int(S.size); K['rows_impliedSE_gt1.5'] = int((S > 1.5).sum().sum()); K['rows_impliedSE_lt0.02'] = int((S < 0.02).sum().sum())
K['impliedSE_median'] = float(np.nanmedian(S.values)); K['impliedSE_p99'] = float(np.nanpercentile(S.values, 99)); K['impliedSE_max'] = float(np.nanmax(S.values)); K['impliedSE_min'] = float(np.nanmin(S.values))
K['genes_SE_gt1.5_all_endothelial_contrasts'] = int((S[endo] > 1.5).all(axis=1).sum()); K['genes_SE_gt1.5_any_endothelial_contrast'] = int((S[endo] > 1.5).any(axis=1).sum())
def dfree(t, p):
    try: return optimize.brentq(lambda d: stats.t.logsf(abs(t), d) + np.log(2) - np.log(p), 2, 1e5)
    except Exception: return np.nan
ii = allc[(allc['P.Value'] > 1e-300) & (allc['t'].abs() > 2.5)].groupby('ensembl')['t'].apply(lambda s: s.abs().idxmax())
dfs = np.array([dfree(t, p) for t, p in zip(allc.loc[ii.values, 't'], allc.loc[ii.values, 'P.Value'])])
K['df_total_min_max'] = [float(np.nanmin(dfs)), float(np.nanmax(dfs))]
K['null_contrast_tail'] = {c: {'n_FDR5': int((Q[c] < 0.05).sum()), 'n_p_lt_1e-4': int((P[c] < 1e-4).sum()), 'expected_p_lt_1e-4': round(len(P) * 1e-4, 1)} for c in nullc}
lowexp = ann['AveExpr'] < 1
K['null_endothelial_p1e-4_lowexpr_fraction'] = float(sum(((P[c] < 1e-4) & lowexp).sum() for c in nullc[:4]) / sum((P[c] < 1e-4).sum() for c in nullc[:4]))
sig_null = (Q[nullc] < 0.05)
K['null_genes_sig_in_>=2_contrasts'] = int((sig_null.sum(axis=1) >= 2).sum())
ex = {}
for g, c in [('AKR1C2', 'A549_24_AbvPBS'), ('DCBLD2', 'A549_6_AbvIso'), ('SELE', 'HUV6_IL33vVeh'), ('VCAM1', 'HUV6_IL33vVeh'), ('CXCL8', 'HUV6_IL33vVeh'), ('CXCL1', 'HUV6_IL33vVeh'), ('CCL2', 'HUV6_IL33vVeh'), ('PTX3', 'HUV6_IL33vVeh'), ('IL1RL1', 'HUV6_IL33vVeh'), ('ICAM1', 'HUV6_IL33vVeh'), ('PTGS2', 'HUV6_IL33vVeh')]:
    e = sym2ens[g]; ex[f'{g}|{c}'] = dict(log2FC=float(L.loc[e, c]), t=float(T.loc[e, c]), P=float(P.loc[e, c]), adjP=float(Q.loc[e, c]), impliedSE=float(S.loc[e, c]))
K['example_rows'] = ex

# ---- 1b. empirical null from 8 endothelial contrasts that should be null (antibody alone; isotype+IL-33 vs IL-33)
null = pd.DataFrame({'HUV6_AbvIso': L['HUV6_AbvIso'], 'HUV24_AbvIso': L['HUV24_AbvIso'], 'HGM6_AbvIso': L['HGM6_AbvIso'], 'HGM24_AbvIso': L['HGM24_AbvIso'],
                     'HUV6_IsoIL33vIL33': L['HUV6_AbIL33vIL33'] - L['HUV6_AbIL33vIsoIL33'], 'HUV24_IsoIL33vIL33': L['HUV24_AbIL33vIL33'] - L['HUV24_AbIL33vIsoIL33'],
                     'HGM6_IsoIL33vIL33': L['HGM6_AbIL33vIL33'] - L['HGM6_AbIL33vIsoIL33'], 'HGM24_IsoIL33vIL33': L['HGM24_AbIL33vIL33'] - L['HGM24_AbIL33vIsoIL33']})
emp_se = np.sqrt((null ** 2).mean(axis=1))
mod_se = S[['HUV6_IL33vVeh', 'HUV24_IL33vVeh', 'HUV6_AbIL33vIsoIL33', 'HUV24_AbIL33vIsoIL33']].median(axis=1)
ok = (mod_se < 1.5) & (mod_se > 0.02)
K['empSE_vs_modelSE_normal_genes'] = dict(n=int(ok.sum()), median_ratio=float((emp_se / mod_se)[ok].median()), spearman=float(stats.spearmanr(emp_se[ok], mod_se[ok])[0]),
                                          spearman_t=float(stats.spearmanr(T.loc[ok, 'HUV6_IL33vVeh'], (L['HUV6_IL33vVeh'] / emp_se)[ok])[0]))
# zero-count ties: identical logFC shared by >=20 genes in a contrast
tie = pd.DataFrame({c: L[c].round(9).isin(set(L[c].round(9).value_counts().loc[lambda s: s >= 20].index)) for c in endo}); ntie = tie.sum(axis=1)
pd.to_pickle(dict(null=null, emp_se=emp_se, ntie=ntie), os.path.join(WORK, 'rna_empirical.pkl'))
def robust(col): return (L[col].abs() >= 1) & ((L[col] / emp_se).abs() >= 5) & (ntie < 10)
rob = {6: robust('HUV6_IL33vVeh'), 24: robust('HUV24_IL33vVeh')}
pd.to_pickle(rob, os.path.join(WORK, 'robust_sets.pkl'))

# ---- 1c. IL-33 response and AX-1177 reversal
R = {}
for tp in (6, 24):
    a, b, c_, ab = L[f'HUV{tp}_IL33vVeh'], L[f'HUV{tp}_AbIL33vIsoIL33'], L[f'HUV{tp}_AbIL33vIL33'], L[f'HUV{tp}_AbvIso']
    r = rob[tp]; rb, rc = (-b / a)[r], (-c_ / a)[r]
    R[f'HUVEC_{tp}h'] = dict(n_model_FDR5=int((Q[f'HUV{tp}_IL33vVeh'] < 0.05).sum()), n_model_FDR5_lfc1=int(((Q[f'HUV{tp}_IL33vVeh'] < 0.05) & (a.abs() >= 1)).sum()),
        n_robust=int(r.sum()), n_up=int((r & (a > 0)).sum()), n_down=int((r & (a < 0)).sum()), n_robust_with_unreliable_model_P=int((r & (S[f'HUV{tp}_IL33vVeh'] > 1.5)).sum()),
        n_reversed_ge50pct_both_comparators=int(((rb >= .5) & (rc >= .5)).sum()), frac_reversed=float(((rb >= .5) & (rc >= .5)).mean()),
        median_reversal_vs_isoIL33=float(rb.median()), IQR_vs_isoIL33=[float(rb.quantile(.25)), float(rb.quantile(.75))], median_reversal_vs_IL33=float(rc.median()), IQR_vs_IL33=[float(rc.quantile(.25)), float(rc.quantile(.75))],
        pearson_r_vs_isoIL33=float(stats.pearsonr(a[r], b[r])[0]), slope_vs_isoIL33=float(np.polyfit(a[r], b[r], 1)[0]), r_antibody_alone=float(stats.pearsonr(a[r], ab[r])[0]), median_abs_lfc_antibody_alone=float(ab[r].abs().median()))
a6, a24, r6 = L['HUV6_IL33vVeh'], L['HUV24_IL33vVeh'], rob[6]
for tp in (6, 24):
    hb, hc, hab = L[f'HGM{tp}_AbIL33vIsoIL33'], L[f'HGM{tp}_AbIL33vIL33'], L[f'HGM{tp}_AbvIso']
    conc = r6 & (np.sign(hb) != np.sign(a6)) & (np.sign(hc) != np.sign(a6))
    R[f'HGMEC_{tp}h_vs_HUVEC6h_signature'] = dict(n=int(r6.sum()), n_reversal_direction_both=int(conc.sum()), frac=float(conc.sum() / r6.sum()), n_and_abs_lfc_ge0p5=int((conc & (hb.abs() >= .5)).sum()), frac_ge0p5=float((conc & (hb.abs() >= .5)).sum() / r6.sum()),
        pearson_r=float(stats.pearsonr(a6[r6], hb[r6])[0]), slope=float(np.polyfit(a6[r6], hb[r6], 1)[0]), r_antibody_alone=float(stats.pearsonr(a6[r6], hab[r6])[0]), n_model_FDR5=int((Q[f'HGM{tp}_AbIL33vIsoIL33'] < .05).sum()))
up = r6 & (a6 > 0)
R['time_course'] = dict(slope_24h_on_6h=float(np.polyfit(a6[r6], a24[r6], 1)[0]), median_ratio_24_over_6_induced=float((a24 / a6)[up].median()), frac_retaining_ge50pct=float(((a24 / a6)[up] >= .5).mean()), frac_retaining_ge80pct=float(((a24 / a6)[up] >= .8).mean()), frac_higher_at_24h=float(((a24 / a6)[up] > 1).mean()))
# the same question on the delivered statistics only (no empirical null): IL-33 genes at FDR<5% and >=2-fold whose implied SE is credible (<0.3) in both contrasts
for tp in (6, 24):
    a, b = L[f'HUV{tp}_IL33vVeh'], L[f'HUV{tp}_AbIL33vIsoIL33']; dd = (Q[f'HUV{tp}_IL33vVeh'] < .05) & (a.abs() >= 1); gd = dd & (S[f'HUV{tp}_IL33vVeh'] < .3) & (S[f'HUV{tp}_AbIL33vIsoIL33'] < .3); rv = (-b / a)[gd]
    R[f'HUVEC_{tp}h_delivered_statistics_only'] = dict(n_FDR5_2fold=int(dd.sum()), n_also_FDR5_opposite_direction_with_AX1177=int((dd & (Q[f'HUV{tp}_AbIL33vIsoIL33'] < .05) & (np.sign(b) != np.sign(a))).sum()),
        n_also_FDR5_same_direction=int((dd & (Q[f'HUV{tp}_AbIL33vIsoIL33'] < .05) & (np.sign(b) == np.sign(a))).sum()), n_well_measured=int(gd.sum()), median_reversal_well_measured=float(rv.median()), IQR=[float(rv.quantile(.25)), float(rv.quantile(.75))], frac_reversed_ge50pct=float((rv >= .5).mean()))
K['reversal'] = R
def gene(g):
    e = sym2ens[g]; return {c: round(float(L.loc[e, c]), 2) for c in ['HUV6_IL33vVeh', 'HUV6_AbIL33vIsoIL33', 'HUV6_AbIL33vIL33', 'HUV24_IL33vVeh', 'HUV24_AbIL33vIsoIL33', 'HGM6_AbIL33vIsoIL33', 'HGM24_AbIL33vIsoIL33', 'HUV6_AbvIso', 'HGM6_AbvIso']} | {'empirical_SE': round(float(emp_se[e]), 3), 'empirical_t_6h': round(float(L.loc[e, 'HUV6_IL33vVeh'] / emp_se[e]), 1), 'model_adjP_6h': float(Q.loc[e, 'HUV6_IL33vVeh']), 'implied_SE_6h': round(float(S.loc[e, 'HUV6_IL33vVeh']), 2)}
K['genes'] = {g: gene(g) for g in ['SELE', 'VCAM1', 'ICAM1', 'CXCL8', 'CXCL1', 'CXCL2', 'CXCL3', 'CXCL5', 'CXCL6', 'CCL2', 'CCL7', 'CCL20', 'CX3CL1', 'CXCL10', 'CCL5', 'CSF1', 'CSF2', 'CSF3', 'IL6', 'LIF', 'IL1A', 'IL1B', 'TNF', 'TNFRSF11B', 'PTX3', 'IL1RL1', 'IL18R1', 'CTSS', 'F3', 'THBD', 'SERPINE1', 'PLAU', 'NOS3', 'IL33', 'C3', 'KYNU', 'CCL26', 'IL4', 'TSLP', 'POSTN', 'NFKBIA', 'TRAF1', 'AREG']}
K['type2_genes_absent_from_filtered_table'] = [g for g in ['IL5', 'IL13', 'IL9', 'IL25', 'CCL11', 'CCL24', 'CCL17', 'CCL22', 'CCL13'] if g not in sym2ens.index]
# antibody alone: reproducibility
rep = {}
for c1, c2 in [('HUV6_AbvIso', 'HUV24_AbvIso'), ('HGM6_AbvIso', 'HGM24_AbvIso'), ('A549_6_AbvIso', 'A549_24_AbvIso'), ('MCF7_6_AbvIso', 'MCF7_24_AbvIso'), ('HUV6_AbvIso', 'HGM6_AbvIso')]:
    s = Q[c1] < .05; rep[f'{c1}->{c2}'] = dict(n_sig=int(s.sum()), sign_concordance=float((np.sign(L.loc[s, c1]) == np.sign(L.loc[s, c2])).mean()), n_replicated_p05_same_sign=int(((P.loc[s, c2] < .05) & (np.sign(L.loc[s, c1]) == np.sign(L.loc[s, c2]))).sum()))
K['antibody_alone_replication'] = rep
# recurrence of antibody-alone 'hits' across the 8 independent cell-line x time groups (contrasts within a group share the antibody arm)
grp_of = lambda c: c.split('_')[0] if c[:3] in ('HUV', 'HGM') else '_'.join(c.split('_')[:2])
byg = pd.DataFrame({g_: (Q[[c for c in nullc if grp_of(c) == g_]] < .05).any(axis=1) for g_ in sorted({grp_of(c) for c in nullc})}); ng = byg.sum(axis=1); pg = byg.mean()
import itertools
K['antibody_alone_recurrence'] = dict(independent_groups=int(byg.shape[1]), genes_sig_in_ge1_group=int((ng >= 1).sum()), genes_sig_in_ge2_groups=int((ng >= 2).sum()), genes_sig_in_ge3_groups=int((ng >= 3).sum()),
                                      expected_ge2_by_chance=round(float(sum(pg[a_] * pg[b_] for a_, b_ in itertools.combinations(pg.index, 2)) * len(L)), 1))
K['stoichiometry'] = dict(antibody_nM=round(10e-3 / 146000 * 1e9, 1), IL33_nM=round(30e-6 / 18100 * 1e9, 2), molar_excess=round((10e-3 / 146000) / (30e-6 / 18100), 1), binding_site_excess=round(2 * (10e-3 / 146000) / (30e-6 / 18100), 1))   # 10 ug/mL IgG (146 kDa) vs 30 ng/mL IL-33 (18.1 kDa)

# =====================================================================================================
# 2. Serum proteomics
# =====================================================================================================
wb = openpyxl.load_workbook(os.path.join(IN, 'AX-1177_serum_proteomics.xlsx')); ws = wb.worksheets[0]
rows = list(ws.iter_rows(values_only=True)); ser = pd.DataFrame(rows[1:], columns=rows[0])
ser['excel_row'] = np.arange(2, len(ser) + 2); ser['row_hidden'] = [bool(ws.row_dimensions[r].hidden) for r in ser['excel_row']]
ser['ce0'] = pd.to_numeric(ser['composite_endpoint_0']); ser['ce1'] = pd.to_numeric(ser['composite_endpoint_1'])
ser['panel_s'] = ser['panel'].str.replace('Olink Target 96 ', '').str.replace(r'\(v\.\d+\)', '', regex=True)
suf = r'-(INFI|CVDII|CVDIII|ONCII|IMO|CRE|NEUI|NEX|ODA|MET)$'
ser['gene'] = ser['assay'].str.replace(suf, '', regex=True).str.strip().map(lambda b: alias.get(b, b))
ser['z'] = np.log(ser['OR']) / ((np.log(ser['u95']) - np.log(ser['l95'])) / (2 * 1.959964))
mtests = ser['adj.p.value'].iloc[0] / ser['p.value'].iloc[0]
K['serum'] = dict(rows=int(len(ser)), unique_proteins=int(ser.gene.nunique()), proteins_on_multiple_panels=int((ser.gene.value_counts() > 1).sum()), rows_for_those=int(ser.gene.isin(ser.gene.value_counts().loc[lambda s: s > 1].index).sum()),
    BH_denominator_implied=round(float(mtests), 1), rows_FDR5_delivered=int((ser['adj.p.value'] < .05).sum()), proteins_FDR5=int(ser.loc[ser['adj.p.value'] < .05, 'gene'].nunique()), rows_FDR5_if_readjusted_over_delivered=int((multipletests(ser['p.value'], method='fdr_bh')[1] < .05).sum()),
    rows_FDR5_with_OR_gt1=int(((ser['adj.p.value'] < .05) & (ser.OR > 1)).sum()), frac_rows_OR_gt1=float((ser.OR > 1).mean()), rows_p05=int((ser['p.value'] < .05).sum()), bonferroni_hits=ser.loc[ser['p.value'] < .05 / round(mtests), 'assay'].tolist(),
    hidden_rows=ser.loc[ser.row_hidden, 'assay'].tolist(), hidden_columns=[k for k, v in ws.column_dimensions.items() if v.hidden], IL33_row_present=bool(ser.assay.str.contains(r'IL-?33', case=False).any()),
    inflammation_panel_rows=int((ser.panel_s == 'Inflammation').sum()), endpoint_denominators_implied=[56, 44] if np.allclose(ser.ce0 * 56, np.round(ser.ce0 * 56)) and np.allclose(ser.ce1 * 44, np.round(ser.ce1 * 44)) else None, max_ce=[float(ser.ce0.max()), float(ser.ce1.max())])
# Where do the tested-but-not-delivered assays fall? BH adj.p_i = min_{j>=i} p_j*m/rank_j, so a row whose p*m/adj.p is an integer is its own
# minimiser and reveals its true rank among all 1,194 tests; true rank minus delivered rank = number of withheld assays with smaller P.
mB = int(round(mtests)); imp = ser['p.value'] * mB / ser['adj.p.value']; anc = ser[np.abs(imp - np.round(imp)) < 1e-6].copy(); anc['true_rank'] = np.round(imp[anc.index]).astype(int)
anc['missing_before'] = anc['true_rank'] - (anc['excel_row'] - 1); assert anc['missing_before'].is_monotonic_increasing
wl = []; pm, pp = 0, 0.0
for _, r_ in anc.iterrows():
    wl += [(pp, r_['p.value'], int(r_['true_rank']) - 1)] * int(r_['missing_before'] - pm); pm, pp = r_['missing_before'], r_['p.value']
pthr = ser.loc[ser['adj.p.value'] < .05, 'p.value'].max()
K['serum_withheld_assays'] = dict(n_withheld=mB - len(ser), n_localised=len(wl), n_with_P_below_FDR5_threshold=int(sum(hi <= pthr for lo, hi, _ in wl)), n_with_P_lt_0p05=int(sum(hi < .05 for lo, hi, _ in wl)),
                                  smallest=dict(P_between=[float(wl[0][0]), float(wl[0][1])], rank_at_most=int(wl[0][2])), FDR5_intervals=[[float(lo), float(hi)] for lo, hi, _ in wl if hi <= pthr])
def srow(a):
    r = ser[ser.assay == a].iloc[0]; return dict(OR=round(float(r.OR), 2), l95=round(float(r.l95), 2), u95=round(float(r.u95), 2), p=float(r['p.value']), adjP=float(r['adj.p.value']), z=round(float(r.z), 2), rank=int(r.excel_row - 1))
K['serum_rows'] = {a: srow(a) for a in ['ST2', 'HGF', 'IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO', 'IL8', 'CCL20', 'MCP-3', 'OPG-INFI', 'OPG-CVDIII', 'PTX3', 'CSF-1', 'IL-18R1', 'CTSS', 'MCP-1-INFI', 'MCP-1-CVDIII', 'TF', 'SELE', 'ICAM1', 'VCAM1', 'CX3CL1', 'G-CSF', 'CXCL1-INFI', 'CXCL5', 'CXCL6', 'IL5-IMO', 'CCL11-INFI', 'CCL11-IMO', 'CCL24', 'CCL17', 'IL-5R-alpha', 'RNASE3', 'TPSAB1', 'FCER2', 'IL-4RA', 'AREG-ONCII', 'AREG-IMO', 'vWF', 'ANGPT2', 'PAI', 'TM', 'RAGE', 'KIM1-CVDII', 'OSM', 'TNF', 'KYNU']}
# join with RNA-seq and test enrichment of the IL-33 endothelial signature among outcome-associated proteins
ser['ensembl'] = ser['gene'].map(sym2ens)
g = ser.groupby('gene').agg(z=('z', 'mean'), min_adjp=('adj.p.value', 'min'), ensembl=('ensembl', 'first')).reset_index(); g = g[g.ensembl.notna()].copy()
g['a6'] = g.ensembl.map(L['HUV6_IL33vVeh']); g['b6'] = g.ensembl.map(L['HUV6_AbIL33vIsoIL33']); g['et'] = g.ensembl.map(L['HUV6_IL33vVeh'] / emp_se); g['etb'] = g.ensembl.map(L['HUV6_AbIL33vIsoIL33'] / emp_se)
g['sig'] = g.min_adjp < .05; g['induced_reversed'] = (g.a6 >= 1) & (g.et >= 4) & (g.etb <= -4)
x, rest = g[g.induced_reversed], g[~g.induced_reversed]
tab = np.array([[x.sig.sum(), (~x.sig).sum()], [rest.sig.sum(), (~rest.sig).sum()]]); t2 = sm.stats.Table2x2(tab)
K['serum_enrichment'] = dict(proteins_with_RNA=int(len(g)), n_induced_reversed=int(len(x)), n_sig_in_set=int(x.sig.sum()), frac_in_set=float(x.sig.mean()), n_sig_rest=int(rest.sig.sum()), n_rest=int(len(rest)), frac_rest=float(rest.sig.mean()),
    OR=float(t2.oddsratio), CI=[float(v) for v in t2.oddsratio_confint()], fisher_p=float(stats.fisher_exact(tab)[1]), mannwhitney_p=float(stats.mannwhitneyu(x.z, rest.z).pvalue), spearman_lfc_vs_z_within_set=[float(v) for v in stats.spearmanr(x.a6, x.z)], overlap_genes=sorted(x[x.sig].gene))
# post hoc: how many of the strongest prognostic proteins (all 1,063, ranked by mean z) belong to the IL-33 endothelial set?
allp = ser.groupby('gene').agg(z=('z', 'mean')).reset_index().sort_values('z', ascending=False).reset_index(drop=True); allp['ind'] = allp.gene.isin(set(x.gene))
K['serum_topN_posthoc'] = {f'top{n_}': dict(n_in_set=int(allp.ind.iloc[:n_].sum()), expected=round(n_ * allp.ind.sum() / len(allp), 2), hypergeom_p=float(stats.hypergeom.sf(allp.ind.iloc[:n_].sum() - 1, len(allp), int(allp.ind.sum()), n_)), genes=list(allp.gene[:n_][allp.ind.iloc[:n_]])) for n_ in (10, 20, 25, 50, 100)}
ser.to_pickle(os.path.join(WORK, 'serum.pkl')); g.to_pickle(os.path.join(WORK, 'serum_gene_level.pkl'))

# =====================================================================================================
# 3. Post-mortem lung IHC
# =====================================================================================================
wb = openpyxl.load_workbook(os.path.join(IN, 'AX-1177_postmortem_lung.xlsx')); ws = wb.worksheets[0]
hdr = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]; hdr[3] = 'SampleID_dup'; hdr[27] = 'blank'
lung = pd.DataFrame([[ws.cell(r, c).value for c in range(1, ws.max_column + 1)] for r in range(2, ws.max_row + 1)], columns=hdr); lung = lung[lung['Histology Block ID'].notna()].copy()
K['lung_hidden_columns'] = [hdr[openpyxl.utils.column_index_from_string(k) - 1] for k, v in ws.column_dimensions.items() if v.hidden]
lung['donor'] = lung['Sample ID'].astype(str).str.strip()
def num(v):
    if v is None: return np.nan
    if isinstance(v, str):
        v = v.strip()
        if v in ('N/A', 'ND', ''): return np.nan
        if v.startswith('='): return float(eval(v[1:]))      # one cell is an Excel formula: =(2+4.5)/2
        return float(v.replace('+', ''))
    return float(v)
ren = {'IL-33, bronchial and bronchiolar basal epithelial cells': 'IL33_epi', 'IL-33, endothelial cells': 'IL33_endo', 'IL-33, vascular smooth muscle cells': 'IL33_vsmc', 'EPX IHC [0 (none)- 5 (severe)]': 'EPX', 'EDN IHC [0 (none) - 5 (severe)]': 'EDN', 'MBP IHC [0 (none) - 5 (severe)]': 'MBP', '2D7 IHC [0 (none) - 5 (severe)]': 'B2D7',
       'IL-5Ra (from duplex w NE)  [0 (none) - 5 (severe)]': 'IL5Ra_NE', 'Neutrophil elastase (from duplex w IL5Ra) [0 (none) - 5 (severe)]': 'NE', 'IL-5Ra (from duplex w tryptase)  [0 (none) - 5 (severe)]': 'IL5Ra_TRY', 'Tryptase (from duplex w IL5Ra) [0 (none) - 5 (severe)]': 'TRY'}
mk = list(ren.values())
for k, v in ren.items(): lung[v] = lung[k].map(num)
for c in ['Disease Category', 'Gender', 'Age', 'SARS-Cov-2 ']: lung[c] = lung.groupby('donor')[c].transform(lambda s: s.ffill().bfill())
lung['grp'] = lung['Disease Category'].map({'COVID neg pneumonia': 'NEG_PNA', 'COVID pos pneumonia': 'POS_PNA', 'COVID neg non-pneumonia': 'NEG_NONPNA'})
don = lung.groupby('donor').agg(grp=('grp', 'first'), n_blocks=('donor', 'size'), age=('Age', 'first'), sex=('Gender', 'first'), **{m_: (m_, 'mean') for m_ in mk}).reset_index()
# manual read of the autopsy text (see report section on lung tissue)
acute = dict.fromkeys(['1130', '1138', '1149', '1159', '1165', '1910', '2035', '2044', '2045', '2049', '2040', '2043', '2072', '2073', '2075', '2105', '2108', '2110', '2113', '2060', '1944', '1956', '1976'], 1)
don['acute_pneumonia_in_text'] = don.donor.map(acute).fillna(0).astype(int); don['covid'] = (don.grp == 'POS_PNA').astype(int)
G = lambda m_, g_: don.loc[don.grp == g_, m_].dropna()
LT = {}
for m_ in mk:
    pos, negp, non = G(m_, 'POS_PNA'), G(m_, 'NEG_PNA'), G(m_, 'NEG_NONPNA'); allneg = pd.concat([negp, non])
    blk_pos, blk_neg = lung.loc[lung.grp == 'POS_PNA', m_].dropna(), lung.loc[lung.grp != 'POS_PNA', m_].dropna()
    LT[m_] = dict(mean_POS=round(float(pos.mean()), 2), mean_NEG_PNA=round(float(negp.mean()), 2), mean_NEG_NONPNA=round(float(non.mean()), 2), KW_p=float(stats.kruskal(pos, negp, non).pvalue), MW_p_POS_vs_NEG_PNA=float(stats.mannwhitneyu(pos, negp).pvalue),
                  MW_p_POS_vs_allNEG=float(stats.mannwhitneyu(pos, allneg).pvalue), naive_block_level_MW_p_POS_vs_allNEG=float(stats.mannwhitneyu(blk_pos, blk_neg).pvalue),
                  MW_p_pathology_pneumonia_vs_none=float(stats.mannwhitneyu(don.loc[don.acute_pneumonia_in_text == 1, m_].dropna(), don.loc[don.acute_pneumonia_in_text == 0, m_].dropna()).pvalue))
rngb = np.random.default_rng(11)
for m_ in mk:     # donor-level bootstrap CI for COVID+ minus COVID- pneumonia
    a_, b_ = G(m_, 'POS_PNA').values, G(m_, 'NEG_PNA').values; bs = np.array([rngb.choice(a_, len(a_)).mean() - rngb.choice(b_, len(b_)).mean() for _ in range(20000)])
    LT[m_]['diff_POS_minus_NEG_PNA'] = round(float(a_.mean() - b_.mean()), 2); LT[m_]['diff_CI95_bootstrap'] = [round(float(v), 2) for v in np.percentile(bs, [2.5, 97.5])]
import statsmodels.formula.api as smf
fit = smf.ols('IL33_endo ~ covid + age + C(sex)', data=don).fit()
K['lung'] = dict(blocks=int(len(lung)), donors=int(len(don)), donors_by_group=don.grp.value_counts().to_dict(), blocks_by_group=lung.grp.value_counts().to_dict(), blocks_per_donor=don.n_blocks.value_counts().sort_index().to_dict(),
    age_range=[float(don.age.min()), float(don.age.max())], tests=LT, endothelium_blocks_at_top_score=int((lung.IL33_endo == 5.5).sum()), donors_all_blocks_top=int((don.IL33_endo == 5.5).sum()),
    compartment_means=dict(endo=round(float(don.IL33_endo.mean()), 2), epi=round(float(don.IL33_epi.mean()), 2), vsmc=round(float(don.IL33_vsmc.mean()), 2)), wilcoxon_endo_vs_epi=float(stats.wilcoxon(don.IL33_endo, don.IL33_epi).pvalue),
    donors_endo_ge_epi=int((don.IL33_endo >= don.IL33_epi).sum()), spearman_IL33endo_NE=[float(v) for v in stats.spearmanr(don.IL33_endo, don.NE)], spearman_IL5Ra_NE=[float(v) for v in stats.spearmanr(don.IL5Ra_NE, don.NE)], spearman_IL5Ra_EPX=[float(v) for v in stats.spearmanr(don.IL5Ra_NE, don.EPX)],
    spearman_IL33endo_age=[float(v) for v in stats.spearmanr(don.IL33_endo, don.age)], ols_IL33endo_covid_adj_age_sex=dict(beta=float(fit.params['covid']), p=float(fit.pvalues['covid'])),
    acute_pneumonia_in_text_by_group=pd.crosstab(don.grp, don.acute_pneumonia_in_text).to_dict(), tissue_RNA_ids=int(lung['Tissue RNA'].notna().sum()))

# ---- extra lung annotations from a manual read of the autopsy text, and sensitivity analyses
dadset = ['2044', '2049', '2040', '2043', '2072', '2108', '2110']; thromb = ['2035', '2040', '2113', '2060']
don['DAD_or_ALI_in_text'] = don.donor.isin(dadset).astype(int); don['pulmonary_thromboemboli_in_text'] = don.donor.isin(thromb).astype(int)
notes = lung.groupby('donor')['Notes - Approved lung conditions'].apply(lambda s: '; '.join([x for x in s if x])); don['notes'] = don.donor.map(notes).fillna('')
label_unsupported = ['1905', '1970', '1968', '1961', '2067', '2101', '1944', '1956', '1976']; don['label_not_matched_by_text'] = don.donor.isin(label_unsupported).astype(int)
sub = don[don.acute_pneumonia_in_text == 1]
K['lung']['sensitivity_pathology_confirmed_pneumonia'] = {m_: dict(n_pos=int((sub.covid == 1).sum()), n_neg=int((sub.covid == 0).sum()), mean_pos=round(float(sub.loc[sub.covid == 1, m_].mean()), 2), mean_neg=round(float(sub.loc[sub.covid == 0, m_].mean()), 2),
                                                     MW_p=float(stats.mannwhitneyu(sub.loc[sub.covid == 1, m_].dropna(), sub.loc[sub.covid == 0, m_].dropna()).pvalue)) for m_ in mk}
K['lung']['thromboemboli_POS_vs_allNEG'] = dict(pos='4/16', neg='0/15', fisher_p=float(stats.fisher_exact([[4, 12], [0, 15]])[1])); K['lung']['DAD_ALI_POS_vs_allNEG'] = dict(pos='7/16', neg='0/15', fisher_p=float(stats.fisher_exact([[7, 9], [0, 15]])[1]))
K['lung']['three_8block_donors_share_of_COVIDpos_blocks'] = '24/49'
don['COPD_or_asthma_noted'] = don.notes.str.contains('COPD|Asthma').astype(int)
K['lung']['COPD_or_asthma_noted_vs_not'] = dict(n_yes=int(don.COPD_or_asthma_noted.sum()), **{m_: round(float(stats.mannwhitneyu(don.loc[don.COPD_or_asthma_noted == 1, m_].dropna(), don.loc[don.COPD_or_asthma_noted == 0, m_].dropna()).pvalue), 3) for m_ in ['IL33_epi', 'IL33_endo', 'IL33_vsmc', 'EPX', 'EDN', 'MBP']})
lung.to_pickle(os.path.join(WORK, 'lung_blocks.pkl')); don.to_pickle(os.path.join(WORK, 'lung_donors.pkl'))

# =====================================================================================================
# 4. Cross-dataset tables
# =====================================================================================================
rc = ['HUV6_IL33vVeh', 'HUV6_AbIL33vIsoIL33', 'HUV24_IL33vVeh', 'HUV24_AbIL33vIsoIL33', 'HGM6_AbIL33vIsoIL33', 'HGM24_AbIL33vIsoIL33']
sj = ser.join(L[rc].add_prefix('lfc_'), on='ensembl').join(Q[['HUV6_IL33vVeh']].add_prefix('q_'), on='ensembl').join(S[['HUV6_IL33vVeh']].add_prefix('se_'), on='ensembl').join(ann[['AveExpr']], on='ensembl')
cls = g.set_index('gene').apply(lambda r: 'induced & AX-1177-reversed' if r.induced_reversed else ('unchanged (|log2FC|<0.3)' if abs(r.a6) < .3 else 'other'), axis=1)
sj['endothelial_IL33_class'] = sj.gene.map(cls).fillna('gene not in RNA-seq table'); sj.to_pickle(os.path.join(WORK, 'serum_x_rna.pkl'))
g['cls'] = g.gene.map(cls); g.to_pickle(os.path.join(WORK, 'serum_gene_level.pkl'))

ROLE = {
 'IL1RL1': ('sST2', 'Patients: baseline stratification / prognostic enrichment (primary use). Exploratory PD only.', 'Strongest axis-specific clinical signal (2nd of 1,094 assays; survives Bonferroni). IL1RL1 mRNA is IL-33-inducible and AX-1177-reversed in HUVEC (delivered P unreliable; empirical t 17.7) but not in HGMEC; transient. Decoy receptor: prognostic, not proof of pathway activity.'),
 'IL6': ('IL-6', 'Patients: PD / disease-activity (on-treatment change vs placebo).', '4 concordant serum assays; large in vitro window; reversed in both cell types. Not IL-33-specific.'),
 'CXCL8': ('IL-8', 'Patients: PD / disease-activity.', 'Delivered RNA-seq P unreliable (implied SE 4.1); empirical t 34.8; sustained at 24 h.'),
 'CCL20': ('CCL20', 'Patients: PD / disease-activity.', 'Largest dynamic range of the serum-validated set; sustained; reversed in HGMEC.'),
 'CCL7': ('MCP-3', 'Patients: PD (exploratory).', 'Near detection floor in vitro: reversal estimate imprecise; transient.'),
 'TNFRSF11B': ('OPG', 'Patients: PD / disease-activity.', '2 concordant serum assays; reversed in both cell types at 6 h.'),
 'PTX3': ('PTX3', 'Patients: PD / endothelial-injury marker.', 'Serum OR 11.6 with wide CI. Delivered RNA-seq P unreliable (implied SE 10.9); empirical t 26; transient in vitro.'),
 'CSF1': ('M-CSF', 'Patients: PD (exploratory).', 'Serum OR CI extremely wide (4-1,933): narrow NPX range; rank by z, not OR.'),
 'IL18R1': ('IL-18R1', 'Patients: PD (exploratory).', 'Shed receptor; induced and reversed in both cell types.'),
 'CTSS': ('Cathepsin S', 'Patients: PD (exploratory).', 'The only protein that passes every delivered test: induced at 6 and 24 h, reversed in HUVEC and HGMEC at both times, and FDR < 5% in serum. Modest fold change (4.4x); serum OR CI wide.'),
 'CCL2': ('MCP-1', 'Patients: exploratory PD.', 'Serum FDR 0.051-0.054 on two panels. Delivered RNA-seq P unreliable; empirical t 40.'),
 'F3': ('Tissue factor', 'Patients: exploratory PD / thrombo-inflammation read-out.', 'Serum FDR 0.051; ~50-fold induction at 6 h, transient; pulmonary thrombo-emboli recorded in 4/16 COVID+ autopsies.'),
 'SELE': ('Soluble E-selectin', 'In vitro: primary potency read-out. Patients: exploratory PD with endothelial specificity.', 'Largest in vitro effect (+11.2 log2), reversed in both cell types, persists at 24 h. Serum OR 2.08, FDR 0.09. Delivered RNA-seq P = 0.21 is a model artefact.'),
 'PLAU': ('uPA', 'Patients: exploratory PD.', 'Serum FDR 0.066.'),
 'CSF3': ('G-CSF', 'In vitro / ex vivo potency read-out; patients: exploratory PD only.', 'Sustained at 24 h, both cell types. No prognostic signal in serum (OR 1.25, P = 0.23).'),
 'CXCL6': ('CXCL6', 'In vitro / ex vivo potency read-out; patients: exploratory PD only.', 'Most sustained large effect (+7.5 log2 at 24 h). Serum OR 1.02.'),
 'CXCL1': ('CXCL1', 'In vitro / ex vivo potency read-out; patients: exploratory PD only.', 'Delivered RNA-seq P = 0.99 is a model artefact (implied SE 1,155). Serum n.s. on two panels.'),
 'CXCL5': ('CXCL5', 'In vitro / ex vivo potency read-out; patients: exploratory PD only.', 'Most persistent in HGMEC at 24 h.'),
 'CX3CL1': ('Fractalkine', 'In vitro potency read-out.', 'Transient.'),
 'CXCL10': ('CXCL10', 'In vitro read-out (late / secondary wave).', 'Partly secondary (interferon-like) response.'),
 'VCAM1': ('Soluble VCAM-1', 'In vitro: primary potency read-out. Patients: exploratory.', 'Strongest HGMEC effect (-11.7 log2). Serum n.s. Delivered RNA-seq P unreliable.'),
 'ICAM1': ('Soluble ICAM-1', 'In vitro: primary potency read-out. Patients: exploratory.', 'Serum n.s. (OR 1.67). Delivered RNA-seq P unreliable.'),
 'CCL5': ('RANTES', 'In vitro late read-out (24 h).', 'Still strongly AX-1177-sensitive in HGMEC at 24 h (-4.6 log2).'),
 'KYNU': ('Kynureninase', 'In vitro read-out (sustained).', ''),
 'TNFRSF9': ('Soluble 4-1BB', 'In vitro read-out.', ''),
 'MMP10': ('MMP-10', 'In vitro read-out (sustained).', 'HUVEC only.'),
 'C1QTNF1': ('C1QTNF1', 'In vitro read-out (sustained).', ''),
 'CSF2': ('GM-CSF', 'In vitro / ex vivo potency read-out. Patients: needs an assay (absent from delivered serum table).', 'Largest sustained effect (+10.3 -> +8.1 log2); reversed in both cell types.'),
 'CXCL2': ('CXCL2', 'In vitro read-out.', 'Not in delivered serum table.'), 'CXCL3': ('CXCL3', 'In vitro read-out.', 'Not in delivered serum table.'),
 'IL1A': ('IL-1alpha', 'In vitro read-out.', 'Not in delivered serum table.'), 'LIF': ('LIF', 'In vitro read-out.', 'Not in delivered serum table.'),
 'C3': ('Complement C3', 'In vitro late read-out (rises 6 -> 24 h).', 'Not in delivered serum table.'), 'EBI3': ('EBI3', 'In vitro read-out.', 'Not in delivered serum table.'),
 'THBD': ('Thrombomodulin', 'In vitro functional read-out (loss of anticoagulant phenotype).', 'Repressed by IL-33, restored by AX-1177.'),
 'NOS3': ('eNOS', 'In vitro functional read-out (endothelial dysfunction).', 'Repressed at 6 and 24 h; delivered adj.P 0.53, empirical t -8.'),
 'TNF': ('TNF', 'In vitro early read-out only (6 h).', 'Fully transient (gone by 24 h); serum n.s.'),
 'IL1B': ('IL-1beta', 'Patients: PD (exploratory).', 'Serum FDR 0.046. Significant on delivered statistics in HUVEC at 6 and 24 h and HGMEC at 6 h; one noisy antibody-alone contrast inflates its empirical SE (1.1).'),
 'IL33': ('IL-33', 'Patients: target engagement (free / total IL-33, IL-33:sST2 complex) - ASSAY GAP.', 'No IL-33 row in delivered serum table. IL33 mRNA falls at 24 h of IL-33 stimulation (-0.89 log2; restored by AX-1177).'),
 'SERPINE1': ('PAI-1', 'Exploratory.', 'Serum P = 0.048, FDR 0.15.'), 'SDC4': ('Syndecan-4', 'In vitro read-out.', ''), 'IL32': ('IL-32', 'In vitro read-out (sustained, both cell types).', ''),
 'AREG': ('Amphiregulin', 'Not supported as an IL-33 PD marker by the in vitro data.', 'Serum FDR 0.03-0.045, but not IL-33-induced at 6 h in endothelium (+1.7 log2 only at 24 h, noisy).')}
rows_ = []
for gname, (prot, role_, note_) in ROLE.items():
    e = sym2ens[gname]; a_, b_ = L.loc[e, 'HUV6_IL33vVeh'], L.loc[e, 'HUV6_AbIL33vIsoIL33']; s_ = ser[ser.gene == gname].sort_values('p.value')
    r_ = dict(protein=prot, gene=gname, proposed_role=role_, HUVEC_IL33_6h_log2FC=a_, HUVEC_reversal_6h_log2FC=b_, pct_reversed_6h=100 * (-b_ / a_), HUVEC_IL33_24h_log2FC=L.loc[e, 'HUV24_IL33vVeh'], HUVEC_reversal_24h_log2FC=L.loc[e, 'HUV24_AbIL33vIsoIL33'],
              ratio_24h_over_6h=L.loc[e, 'HUV24_IL33vVeh'] / a_, HGMEC_reversal_6h_log2FC=L.loc[e, 'HGM6_AbIL33vIsoIL33'], HGMEC_reversal_24h_log2FC=L.loc[e, 'HGM24_AbIL33vIsoIL33'], AX1177_alone_HUVEC_6h=L.loc[e, 'HUV6_AbvIso'], AX1177_alone_HGMEC_6h=L.loc[e, 'HGM6_AbvIso'],
              model_adjP_6h=Q.loc[e, 'HUV6_IL33vVeh'], model_SE_6h=S.loc[e, 'HUV6_IL33vVeh'], model_stat_unreliable=bool(S.loc[e, 'HUV6_IL33vVeh'] > 1.5), empirical_SE=emp_se[e], empirical_t_6h=a_ / emp_se[e])
    if len(s_): r_.update(serum_assays='; '.join(s_.assay), serum_n_assays=len(s_), serum_OR=s_.iloc[0]['OR'], serum_l95=s_.iloc[0]['l95'], serum_u95=s_.iloc[0]['u95'], serum_p=s_.iloc[0]['p.value'], serum_adjP=s_.iloc[0]['adj.p.value'], serum_z=s_['z'].mean())
    else: r_.update(serum_assays='not in delivered serum table', serum_n_assays=0)
    r_['notes'] = note_; rows_.append(r_)
bm = pd.DataFrame(rows_); bm.to_pickle(os.path.join(WORK, 'biomarker_table.pkl'))

# markers that pass on the DELIVERED statistics alone: induced >=2-fold at 6 h and 24 h in HUVEC and reversed by AX-1177 (vs isotype + IL-33) in HUVEC and HGMEC, all at FDR < 5%
upc = ['HUV6_IL33vVeh', 'HUV24_IL33vVeh']; dnc = ['HUV6_AbIL33vIsoIL33', 'HUV24_AbIL33vIsoIL33', 'HGM6_AbIL33vIsoIL33', 'HGM24_AbIL33vIsoIL33']
six = (Q[upc + dnc] < .05).all(axis=1) & (L[upc] >= 1).all(axis=1) & (L[dnc] <= -.5).all(axis=1); five = (Q[upc + dnc[:3]] < .05).all(axis=1) & (L[upc] >= 1).all(axis=1) & (L[dnc[:3]] <= -.5).all(axis=1)
sgene = ser.groupby('gene')['adj.p.value'].min()
K['markers_passing_delivered_statistics'] = dict(six_contrasts=sorted(ann.loc[six, 'symbol']), six_contrasts_in_serum_table=sorted(set(ann.loc[six, 'symbol']) & set(sgene.index)), six_contrasts_and_serum_FDR5=sorted(set(ann.loc[six, 'symbol']) & set(sgene[sgene < .05].index)),
    five_contrasts_n=int(five.sum()), five_contrasts_in_serum_table=sorted(set(ann.loc[five, 'symbol']) & set(sgene.index)), five_contrasts_and_serum_FDR5=sorted(set(ann.loc[five, 'symbol']) & set(sgene[sgene < .05].index)))

# rank statistics for gene-set analysis (model t; empirical t substituted where the model SE is not credible)
rk = pd.DataFrame({'symbol': ann['symbol'], 'AveExpr': ann['AveExpr']})
for c in ['HUV6_IL33vVeh', 'HUV24_IL33vVeh', 'HUV6_AbIL33vIsoIL33', 'HUV24_AbIL33vIsoIL33', 'HGM6_AbIL33vIsoIL33', 'HGM24_AbIL33vIsoIL33', 'HUV6_AbvIso', 'HUV24_AbvIso', 'HGM6_AbvIso', 'HGM24_AbvIso', 'A549_6_AbvIso', 'A549_24_AbvIso', 'MCF7_6_AbvIso', 'MCF7_24_AbvIso']:
    fl = (S[c] > 1.5) | (S[c] < 0.02); h = T[c].copy(); h[fl] = (L[c] / emp_se)[fl] if c[:3] in ('HUV', 'HGM') else 0.0; rk['t_' + c] = h; rk['lfc_' + c] = L[c]
for c in ['HUV24_AbIL33vIL33', 'HGM6_AbIL33vIL33', 'HGM24_AbIL33vIL33']: rk['lfc_' + c] = L[c]
rk.to_csv(os.path.join(WORK, 'rank_stats.csv'))

# =====================================================================================================
# 5. Supporting-tables workbook
# =====================================================================================================
full = {v: k for k, v in short.items()}
t_contrast = pd.DataFrame([dict(contrast_as_delivered=full[c], n_FDR5=int((Q[c] < .05).sum()), n_FDR5_up=int(((Q[c] < .05) & (L[c] > 0)).sum()), n_FDR5_down=int(((Q[c] < .05) & (L[c] < 0)).sum()), n_FDR5_and_abs_log2FC_ge1=int(((Q[c] < .05) & (L[c].abs() >= 1)).sum()),
                                n_FDR5_but_abs_log2FC_lt0p3=int(((Q[c] < .05) & (L[c].abs() < .3)).sum()), n_abs_log2FC_gt3_but_FDR_ge5=int(((L[c].abs() > 3) & (Q[c] >= .05)).sum()), n_rows_implied_SE_gt1p5=int((S[c] > 1.5).sum()), n_rows_implied_SE_lt0p02=int((S[c] < .02).sum()), n_P_lt_1e4=int((P[c] < 1e-4).sum())) for c in L.columns])
nice = {'HUV6_IL33vVeh': 'HUVEC_6h_IL33_vs_vehicle', 'HUV6_AbIL33vIL33': 'HUVEC_6h_AX1177+IL33_vs_IL33', 'HUV6_AbIL33vIsoIL33': 'HUVEC_6h_AX1177+IL33_vs_iso+IL33', 'HUV6_AbvIso': 'HUVEC_6h_AX1177_vs_iso', 'HUV24_IL33vVeh': 'HUVEC_24h_IL33_vs_vehicle', 'HUV24_AbIL33vIL33': 'HUVEC_24h_AX1177+IL33_vs_IL33',
        'HUV24_AbIL33vIsoIL33': 'HUVEC_24h_AX1177+IL33_vs_iso+IL33', 'HUV24_AbvIso': 'HUVEC_24h_AX1177_vs_iso', 'HGM6_AbIL33vIL33': 'HGMEC_6h_AX1177+IL33_vs_IL33', 'HGM6_AbIL33vIsoIL33': 'HGMEC_6h_AX1177+IL33_vs_iso+IL33', 'HGM6_AbvIso': 'HGMEC_6h_AX1177_vs_iso',
        'HGM24_AbIL33vIL33': 'HGMEC_24h_AX1177+IL33_vs_IL33', 'HGM24_AbIL33vIsoIL33': 'HGMEC_24h_AX1177+IL33_vs_iso+IL33', 'HGM24_AbvIso': 'HGMEC_24h_AX1177_vs_iso'}
sig = pd.concat([ann[['symbol', 'gene_name', 'AveExpr']], L[list(nice)].rename(columns={c: 'log2FC_' + nice[c] for c in nice})], axis=1)
sig['pct_reversed_6h_vs_iso+IL33'] = 100 * (-L['HUV6_AbIL33vIsoIL33'] / a6); sig['pct_reversed_6h_vs_IL33'] = 100 * (-L['HUV6_AbIL33vIL33'] / a6); sig['ratio_24h_over_6h'] = a24 / a6
sig['delivered_adjP_HUVEC_6h_IL33'] = Q['HUV6_IL33vVeh']; sig['delivered_adjP_HUVEC_24h_IL33'] = Q['HUV24_IL33vVeh']; sig['implied_SE_delivered_HUVEC_6h'] = S['HUV6_IL33vVeh']; sig['empirical_SE_8_null_contrasts'] = emp_se
sig['empirical_t_HUVEC_6h_IL33'] = a6 / emp_se; sig['empirical_t_HUVEC_24h_IL33'] = a24 / emp_se; sig['delivered_P_unreliable_(implied_SE>1.5)'] = S['HUV6_IL33vVeh'] > 1.5; sig['robust_6h'] = rob[6]; sig['robust_24h'] = rob[24]; sig['zero_count_ties_of_14_endothelial_contrasts'] = ntie
t_sig = sig.loc[rob[6] | rob[24]].sort_values('log2FC_HUVEC_6h_IL33_vs_vehicle', ascending=False).reset_index()
a549 = [c for c in L.columns if c.startswith('A549')]; mcf7 = [c for c in L.columns if c.startswith('MCF7')]
uu = pd.DataFrame({'symbol': ann['symbol'], 'AveExpr_all_114_libraries': ann['AveExpr'], 'median_implied_SE_endothelial_contrasts': S[endo].median(axis=1), 'median_implied_SE_A549_contrasts': S[a549].median(axis=1), 'median_implied_SE_MCF7_contrasts': S[mcf7].median(axis=1), 'empirical_SE_endothelial_null': emp_se,
                   'max_abs_log2FC_endothelial': L[endo].abs().max(axis=1), 'log2FC_HUVEC_6h_IL33_vs_vehicle': a6, 'delivered_P_HUVEC_6h_IL33': P['HUV6_IL33vVeh'], 'empirical_t_HUVEC_6h_IL33': a6 / emp_se, 'n_contrasts_implied_SE_gt1p5': (S > 1.5).sum(axis=1), 'n_contrasts_implied_SE_lt0p02': (S < .02).sum(axis=1)})
t_unrel = uu[((S > 1.5).any(axis=1)) | ((S < .02).any(axis=1))].sort_values('median_implied_SE_endothelial_contrasts', ascending=False).reset_index()
t_serum = sj[['panel', 'assay', 'gene', 'OR', 'l95', 'u95', 'p.value', 'adj.p.value', 'z', 'composite_endpoint_0', 'composite_endpoint_1', 'row_hidden', 'excel_row', 'AveExpr'] + ['lfc_' + c for c in rc] + ['q_HUV6_IL33vVeh', 'se_HUV6_IL33vVeh', 'endothelial_IL33_class']].rename(
    columns={'gene': 'mapped_gene_symbol', 'z': 'z_(lnOR/SE)', 'AveExpr': 'RNAseq_AveExpr', 'lfc_HUV6_IL33vVeh': 'log2FC_HUVEC_6h_IL33_vs_vehicle', 'lfc_HUV6_AbIL33vIsoIL33': 'log2FC_HUVEC_6h_AX1177+IL33_vs_iso+IL33', 'lfc_HUV24_IL33vVeh': 'log2FC_HUVEC_24h_IL33_vs_vehicle',
             'lfc_HUV24_AbIL33vIsoIL33': 'log2FC_HUVEC_24h_AX1177+IL33_vs_iso+IL33', 'lfc_HGM6_AbIL33vIsoIL33': 'log2FC_HGMEC_6h_AX1177+IL33_vs_iso+IL33', 'lfc_HGM24_AbIL33vIsoIL33': 'log2FC_HGMEC_24h_AX1177+IL33_vs_iso+IL33', 'q_HUV6_IL33vVeh': 'RNAseq_delivered_adjP_HUVEC_6h', 'se_HUV6_IL33vVeh': 'RNAseq_implied_SE_HUVEC_6h'})
t_don = don.rename(columns={'grp': 'delivered_category', 'B2D7': '2D7'}).sort_values(['delivered_category', 'donor'])
t_don['delivered_category'] = t_don['delivered_category'].map({'NEG_NONPNA': 'COVID neg non-pneumonia', 'NEG_PNA': 'COVID neg pneumonia', 'POS_PNA': 'COVID pos pneumonia'})
t_ltest = pd.DataFrame(LT).T.reset_index().rename(columns={'index': 'marker'})
QC = [
 ('Methods annex vs files', 'Serum: annex says BH was applied "across all assays in the delivery"; the adjusted P-values correspond to 1,194 tests, 1,094 rows are delivered.', 'adj.p / p of the top row = 1194.0; re-adjusting across the delivered rows gives 206 rather than 178 rows at FDR<5%.', 'Delivered adj. P are slightly conservative. 100 tested assays are absent and there is no IL-33 row. Delivered values used as is.'),
 ('Methods annex vs files', 'RNA-seq: 38 arm x time-point groups were modelled; 26 contrasts are delivered. No IL-33-vs-control contrast exists for HGMEC, and HGMEC has no vehicle arm.', 'Contrast names in the two workbooks.', 'IL-33 responsiveness of HGMEC can only be inferred from AX-1177 reversal (antibody x IL-33 interaction). Request "IL33+IC119 vs IC119" in HGMEC from the archived fit.'),
 ('Methods annex vs files', 'RNA-seq: implied degrees of freedom are gene-specific (75.05-85.13), not a single value; 114 libraries - 38 groups would give 76 residual df.', 'df solved from each (t, P) pair.', 'Consistent with robust empirical-Bayes moderation; no effect on conclusions.'),
 ('RNA-seq workbook', 'Tabs "6h" and "24h" of AX-1177_rnaseq_contrasts.xlsx hold identical content: each contains all 24 contrasts for BOTH time points (629,040 rows). The "6h" tab has 419,535 trailing blank rows to the Excel row limit; the "24h" tab is partly re-sorted.', 'Row-by-row merge on (Comparison, ensembl): all values identical.', 'Time point must be read from the Comparison column, never from the tab name. One tab used.'),
 ('RNA-seq workbook', 'AX-1177_rnaseq_huvec_il33.xlsx: tabs are named "IL33_vs_Vehicle..." but the Comparison column says "IL33_vs_Nontreated..."; rows are sorted by logFC, not by P.', 'Top rows include SELE (P = 0.21) and CXCL1 (P = 0.99).', 'Treated as IL-33 vs the HUVEC vehicle arm described in the annex.'),
 ('RNA-seq statistics', 'Pooled single-model variance is not credible for genes with very large expression differences between groups: 4,329 rows have an implied SE > 1.5 log2 (max 36,723); 137 genes in all 14 endothelial contrasts. They include SELE, VCAM1, ICAM1, CXCL8, CXCL1, CCL2, PTGS2, PTX3 and IL1RL1.', 'Implied SE = |logFC / t|; median 0.33, 99th percentile 1.18.', 'Delivered P / adj.P / B for these genes are false negatives. Effect sizes are unaffected. Replaced by an empirical null (RMS of 8 null endothelial contrasts) and replication across independent contrasts. Re-fit per cell line from archived counts.'),
 ('RNA-seq statistics', 'The same defect in the other direction: 267 rows have an implied SE < 0.02 (min 0.00065), giving extreme P-values for trivial changes, e.g. AKR1C2 in A549 24 h (AX-1177 vs PBS): +0.11 log2 (8%), P = 1e-98.', 'Rows with |log2FC| < 0.3 and FDR < 5% in antibody-alone contrasts.', 'Not biological. Ignored.'),
 ('RNA-seq statistics', 'Antibody-alone contrasts behave as nulls but return 14-73 genes at FDR < 5% each and 25-58 genes at P < 1e-4 (2.6 expected); in the endothelial contrasts 90% of these come from low-count genes; sign concordance between time points is ~50%.', 'Null-contrast tail counts; replication table.', 'The model is anti-conservative for low-count genes. Low-count hits need independent replication; counts of "DEGs" overstate.'),
 ('RNA-seq statistics', 'Antibody-containing wells at 24 h show a small coordinated shift in proliferation and mitochondrial gene sets (MYC targets, E2F targets, oxidative phosphorylation): median +0.09 to +0.14 log2 in HGMEC and -0.06 to -0.11 log2 in HUVEC against isotype, with or without IL-33. In HGMEC at 24 h the contrast against IL-33 alone lists 1,032 genes at FDR < 5% but the isotype-matched contrast 269.', 'tables/hallmark_median_log2FC.csv; gene-set enrichment in tables/gsea_hallmark.csv.', 'Opposite directions in two endothelial types point to plate or culture-state effects rather than pharmacology, but the design cannot separate them. Isotype-matched contrasts used throughout; randomise plate layout in the next experiment.'),
 ('RNA-seq statistics', 'AveExpr is the average over all 114 libraries from four cell lines.', 'Methods annex, section 5.', 'Cannot be used to judge whether a gene (e.g. IL1RL1 / ST2) is expressed in a given cell line. Request per-group expression.'),
 ('RNA-seq design', 'One donor per endothelial line (HUVEC P2, HGMEC P5); one antibody and one ligand concentration (10 ug/mL vs 30 ng/mL = 41-fold molar excess, 83-fold in binding sites); antibody added with the ligand; reduced IL-33 only; A549 and MCF7 never received IL-33; no lung endothelium.', 'Methods annex, sections 1-3.', 'Shows neutralisation at saturating excess only; no potency, no therapeutic (delayed) setting, no oxidised-IL-33 or epithelial pharmacology.'),
 ('Serum workbook', '1,094 rows are 1,063 proteins: 27 proteins are measured on 2-4 panels (58 rows), e.g. IL-6 x4, HGF x2, OPG x2.', 'Assay-to-gene mapping.', '178 FDR-significant rows = 169 proteins. Replicate assays agree, which is useful technical confirmation.'),
 ('Serum workbook', 'Rows 4 and 16 (HGF-ONCII, IL6-ONCII) and column D (lower CI) are hidden.', 'Row / column dimensions of the sheet.', 'Included in the analysis.'),
 ('Serum workbook', 'No IL-33 row. The Inflammation panel contributes 77 rows; IL-4, IL-13, TSLP and the Inflammation-panel IL-5 assay are also absent.', 'Assay list.', 'The drug target itself has no read-out in patients in this delivery. Retrieve raw NPX and detection rates.'),
 ('Serum workbook', 'Back-calculation from the adjusted P-values locates the withheld assays: four of them have P below the FDR 5% threshold, and the smallest lies between 0.00021 and 0.00031, i.e. rank 19-21 of 1,194. Fifteen have P < 0.05.', 'A row whose p x 1194 / adj.p is an integer reveals its true rank; true rank minus delivered rank counts the withheld assays above it.', 'Identity unknown. At least four outcome-associated assays are missing from the table, one of them among the 21 strongest. Retrieve them before the committee if possible.'),
 ('Serum workbook', 'Columns composite_endpoint_0 / _1 are undefined in the annex; values are multiples of 1/56 and 1/44 (all < 10%), some stored as text.', 'Exact-fraction check.', 'Implies 56 patients without and 44 with the endpoint; probably the per-group fraction of values missing or below detection. Confirm with the vendor.'),
 ('Serum statistics', 'Odds ratios are "per log unit" of unspecified base; some confidence intervals are extremely wide (CSF-1: OR 90, 4.2-1,933).', 'OR / CI columns.', 'Proteins ranked by z or P, not by OR.'),
 ('Serum statistics', '82% of all assays have OR > 1; 176 of 178 FDR-significant rows have OR > 1; many are intracellular proteins.', 'Direction counts.', 'A global severity / tissue-damage signal; limits the specificity of any single marker.'),
 ('Lung workbook', 'The IL-33 columns and the eosinophil granule-protein columns are hidden (columns L-P and U-Z).', 'Column dimensions of the sheet.', 'Included in the analysis.'),
 ('Lung workbook', 'Donor-level fields are recorded on the first block only (merged cells); some "Notes" entries sit on a later block row.', 'Merged ranges.', 'Filled within donor.'),
 ('Lung workbook', 'Scores written "n+" are coded n + 0.5 in the numeric columns (maximum 5.5 on a nominal 0-5 scale); IL-33 values are mid-points of ranges; one cell holds an Excel formula; "N/A" and "ND" strings occur.', 'Text vs numeric column pairs (EPX, NE, tryptase).', 'Values used as delivered; rank-based tests only.'),
 ('Lung statistics', '74 blocks come from 31 donors (1-8 blocks each); three COVID+ donors supply 24 of the 49 COVID+ blocks.', 'Blocks per donor.', 'Analysed per donor. Block-level tests are pseudo-replicated: e.g. endothelial IL-33, COVID+ vs COVID-: P = 0.017 per block vs 0.052 per donor; EDN: P = 0.0006 vs 0.09.'),
 ('Lung labels', 'Disease-category labels are not always matched by the autopsy text: 4 of 10 "COVID neg pneumonia" donors have no pneumonia listed (one of them has no SARS-CoV-2 result); 2 of 16 "COVID pos pneumonia" donors have no acute pneumonia listed (one contributes 8 blocks); 3 of 5 "non-pneumonia" donors have pneumonia, pneumonitis or fungal lung infection. Every control has lung disease.', 'Manual read of the Pathology field.', 'Sensitivity analyses by autopsy-text classification; conclusions unchanged. There is no normal-lung comparator.'),
 ('Lung design', 'All donors are white and aged 64-98; single reader; endothelial IL-33 sits in the top category in 39 of 74 blocks.', 'Demographic and score columns.', 'Ceiling effect: the scale cannot show an increase in endothelium. Digital re-quantification recommended.'),
 ('Lung markers', 'IL-5R-alpha scores follow neutrophil elastase (Spearman 0.89) and not eosinophil peroxidase (0.12).', 'Donor-level correlations.', 'IL-5R-alpha is not an eosinophil-specific read-out in these lungs; eosinophil conclusions rest on EPX / EDN / MBP.'),
 ('Lung workbook', 'Tissue RNA identifiers exist for 22 blocks (22 donors); the RNA data are not part of the delivery.', 'Tissue RNA column.', 'An available resource for the next step (IL33, IL1RL1 isoforms, endothelial signature in tissue).')]
t_qc = pd.DataFrame(QC, columns=['area', 'finding', 'evidence', 'consequence_and_handling'])
with pd.ExcelWriter(os.path.join(OUT, 'tables', 'AX-1177_supporting_tables.xlsx')) as xw:
    t_qc.to_excel(xw, 'Data_QC_log', index=False); bm.to_excel(xw, 'Biomarker_candidates', index=False); t_contrast.to_excel(xw, 'RNAseq_contrast_summary', index=False); t_sig.to_excel(xw, 'RNAseq_robust_IL33_signature', index=False)
    t_unrel.to_excel(xw, 'RNAseq_unreliable_stat_genes', index=False); t_serum.to_excel(xw, 'Serum_all_assays_x_RNAseq', index=False); t_don.to_excel(xw, 'Lung_IHC_donor_level', index=False); t_ltest.to_excel(xw, 'Lung_IHC_donor_tests', index=False)
for nm, tb in [('data_qc_log', t_qc), ('biomarker_candidates', bm), ('lung_ihc_donor_level', t_don)]: tb.to_csv(os.path.join(OUT, 'tables', nm + '.csv'), index=False)
json.dump(K, open(os.path.join(OUT, 'tables', 'key_numbers.json'), 'w'), indent=1, default=str)
print('done; key numbers ->', os.path.join(OUT, 'tables', 'key_numbers.json'))
