"""Manual mapping of Olink Target 96 assay names (as delivered) to HGNC gene symbols.
Only names that are not already a gene symbol (after removing the panel suffix) are listed.
'TF' is listed because on the Cardiovascular II panel it denotes tissue factor (F3), not transferrin."""
alias = {
'4E-BP1':'EIF4EBP1',"5'-NT":'NT5E','ADAM 22':'ADAM22','ADAM 23':'ADAM23','ADAM 8':'ADAM8','ADAM-TS 15':'ADAMTS15','ADAM-TS13':'ADAMTS13','Alpha-2-MRAP':'LRPAP1',
'AP-N':'ANPEP','BLM hydrolase':'BLMH','BMP-4':'BMP4','BMP-6':'BMP6','CAIX':'CA9','CASP-3':'CASP3','CASP-8':'CASP8','CD40-L':'CD40LG','CD97':'ADGRE5','CLM-1':'CD300LF','CLM-6':'CD300C',
'CSF-1':'CSF1','CTSL1':'CTSL','CXL17':'CXCL17','CYR61':'CCN1','Dkk-1':'DKK1','Dkk-4':'DKK4','DLK-1':'DLK1','EN-RAGE':'S100A12','Ep-CAM':'EPCAM','ESM-1':'ESM1','FAM19A5':'TAFA5','FcRL2':'FCRL2',
'FGF-19':'FGF19','FGF-21':'FGF21','FGF-5':'FGF5','FGF-BP1':'FGFBP1','Flt3L':'FLT3LG','FR-alpha':'FOLR1','FR-gamma':'FOLR3','FS':'FST','FUT3/FUT5':'FUT3','G-CSF':'CSF3','Gal-1':'LGALS1','Gal-3':'LGALS3',
'Gal-4':'LGALS4','gal-8':'LGALS8','Gal-9':'LGALS9','GCP5':'GPC5','GDF-15':'GDF15','GDF-2':'GDF2','GDF-8':'MSTN','GDNFR-alpha-3':'GFRA3','GFR-alpha-1':'GFRA1','GH':'GH1','GIF':'CBLIF','GM-CSF-R-alpha':'CSF2RA',
'GT':'FABP6','HAOX1':'HAO1','HB-EGF':'HBEGF','hK11':'KLK11','hK14':'KLK14','hK8':'KLK8','HO-1':'HMOX1','hOSCAR':'OSCAR','HSP 27':'HSPB1','ICAM 5':'ICAM5','ICAM-2':'ICAM2','IFN-gamma':'IFNG','IFN-gamma-R1':'IFNGR1',
'IGFBP-1':'IGFBP1','IGFBP-2':'IGFBP2','IGFBP-7':'IGFBP7','IgG Fc receptor II-b':'FCGR2B','IL-10RA':'IL10RA','IL-10RB':'IL10RB','IL-12B':'IL12B','IL-15RA':'IL15RA','IL-17A':'IL17A','IL-17C':'IL17C','IL-17D':'IL17D',
'IL-17RA':'IL17RA','IL-18BP':'IL18BP','IL-18R1':'IL18R1','IL-1ra':'IL1RN','IL-1RT1':'IL1R1','IL-1RT2':'IL1R2','IL-20RA':'IL20RA','IL-27':'IL27','IL-4RA':'IL4R','IL-5R-alpha':'IL5RA','IL-6RA':'IL6R','IL12':'IL12A',
'IL2-RA':'IL2RA','IL8':'CXCL8','JAM-A':'F11R','JAM-B':'JAM2','KIM1':'HAVCR1','LAIR-2':'LAIR2','LAP TGF-beta-1':'TGFB1','LDL receptor':'LDLR','LIF-R':'LIFR','LOX-1':'OLR1','MAD homolog 5':'SMAD5',
'MCP-1':'CCL2','MCP-2':'CCL8','MCP-3':'CCL7','MCP-4':'CCL13','MESDC2':'MESD','MetAP 2':'METAP2','MIC-A/B':'MICA','MK':'MDK','MMP-1':'MMP1','MMP-10':'MMP10','MMP-2':'MMP2','MMP-3':'MMP3','MMP-9':'MMP9',
'MUC-16':'MUC16','N-CDase':'ASAH2','N2DL-2':'ULBP2','NEMO':'IKBKG','NEP':'MME','Notch 3':'NOTCH3','NOV':'CCN3','Nr-CAM':'NRCAM','NT-3':'NTF3','NT-proBNP':'NPPB','OPG':'TNFRSF11B','OPN':'SPP1','PAI':'SERPINE1',
'PAR-1':'F2R','PARP-1':'PARP1','PD-L1':'CD274','PD-L2':'PDCD1LG2','PDGF subunit A':'PDGFA','PDGF subunit B':'PDGFB','PDGF-R-alpha':'PDGFRA','PECAM-1':'PECAM1','PIgR':'PIGR','PLC':'HSPG2','PSGL-1':'SELPLG',
'PSP-D':'SFTPD','PVRL4':'NECTIN4','RAGE':'AGER','SCF':'KITLG','sFRP-3':'FRZB','SHPS-1':'SIRPA','Siglec-9':'SIGLEC9','SKR3':'ACVRL1','ST1A1':'SULT1A1','ST2':'IL1RL1','SYND1':'SDC1','t-PA':'PLAT','TFPI-2':'TFPI2',
'TGF-alpha':'TGFA','TGFR-2':'TGFBR2','THY 1':'THY1','TIE2':'TEK','TLT-2':'TREML2','TM':'THBD','TN-R':'TNR','TNF-R1':'TNFRSF1A','TNF-R2':'TNFRSF1B','TNFB':'LTA','TR':'TFRC','TR-AP':'ACP5','TRAIL':'TNFSF10',
'TRAIL-R2':'TNFRSF10B','TRANCE':'TNFSF11','TWEAK':'TNFSF12','U-PAR':'PLAUR','uPA':'PLAU','VEGFR-2':'KDR','VEGFR-3':'FLT4','vWF':'VWF','WIF-1':'WIF1','WISP-1':'CCN4',
'TF':'F3',
}
