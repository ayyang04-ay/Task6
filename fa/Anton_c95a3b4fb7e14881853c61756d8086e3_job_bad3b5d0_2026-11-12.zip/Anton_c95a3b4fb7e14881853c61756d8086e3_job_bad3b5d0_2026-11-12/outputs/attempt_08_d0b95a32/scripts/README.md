# Reproducing the AX-1177 audit analysis

```
python analysis_pipeline.py <folder with the four delivered .xlsx files> <output folder>   # tables, key_numbers.json, intermediate/
python make_figures.py <output folder>                                                      # figures/fig1 ... fig5
Rscript gsea_hallmark.R <output folder>                                                     # tables/gsea_hallmark.csv, hallmark_median_log2FC.csv
```

- Python 3.10+ with pandas, numpy, scipy, statsmodels, openpyxl, matplotlib, adjustText. R with fgsea, msigdbr (7.5.1), data.table.
- `olink_map.py` holds the hand-made mapping of Olink assay names to gene symbols.
- The manual reading of the autopsy text (acute pneumonia / lung injury, thrombo-emboli, label mismatches) is coded as donor lists in `analysis_pipeline.py`, section 3.
- `intermediate/` is created by the pipeline (about 40 MB) and is not shipped; the first step takes a few minutes, most of it reading the 123 MB contrasts workbook.
