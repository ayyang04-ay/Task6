#!/usr/bin/env python
"""AX-1177 portfolio audit - figures. Run after analysis_pipeline.py:
    python make_figures.py <output dir>     (reads <output dir>/intermediate, writes <output dir>/figures)
Needs matplotlib and adjustText."""
import sys, os, warnings
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from adjustText import adjust_text
from scipy import stats
warnings.filterwarnings('ignore')
OUT = sys.argv[1] if len(sys.argv) > 1 else '/tmp/outputs'
W = os.path.join(OUT, 'intermediate'); F = os.path.join(OUT, 'figures'); os.makedirs(F, exist_ok=True)
M = pd.read_pickle(os.path.join(W, 'rna_mats.pkl')); L, T, P, Q, S, ann = M['L'], M['T'], M['P'], M['Q'], M['S'], M['ann']
E = pd.read_pickle(os.path.join(W, 'rna_empirical.pkl')); emp_se = E['emp_se']
rob = pd.read_pickle(os.path.join(W, 'robust_sets.pkl')); rob6, rob24 = rob[6], rob[24]
sym2ens = ann.reset_index().sort_values('AveExpr', ascending=False).drop_duplicates('symbol').set_index('symbol')['ensembl']
a6, a24 = L['HUV6_IL33vVeh'], L['HUV24_IL33vVeh']

# ------------------------------------------------------------------ Figure 1: pharmacology
lab_genes = ['SELE', 'VCAM1', 'ICAM1', 'CXCL8', 'CXCL1', 'IL6', 'CSF2', 'CSF3', 'CCL20', 'CCL2', 'TNFRSF11B', 'PTX3', 'IL1RL1', 'F3', 'THBD', 'NOS3', 'CXCL6', 'TNF', 'KYNU', 'C3', 'CCL5', 'CXCL5']
fig, axes = plt.subplots(2, 3, figsize=(17, 11.2))
def panel(ax, x, y, sel, title, xl, yl, ident=True, labels=lab_genes, lim=(-6, 12.5)):
    ax.scatter(x[~sel], y[~sel], s=2, c='#c8c8c8', alpha=0.35, rasterized=True, label=f'all other genes (n={int((~sel).sum()):,})')
    ax.scatter(x[sel], y[sel], s=9, c='#1f77b4', alpha=0.7, rasterized=True, label=f'robust IL-33-responsive genes (n={int(sel.sum())})')
    ax.axhline(0, c='k', lw=0.6); ax.axvline(0, c='k', lw=0.6)
    if ident: ax.plot(lim, [-lim[0], -lim[1]], c='crimson', lw=1.2, ls='--', label='complete reversal (y = −x)')
    ax.set_xlim(lim); ax.set_ylim(-13.5, 6.5); ax.set_xlabel(xl, fontsize=10); ax.set_ylabel(yl, fontsize=10); ax.set_title(title, fontsize=10.5, fontweight='bold', loc='left')
    texts = []
    for g in labels:
        e = sym2ens.get(g)
        if e is None: continue
        ax.scatter([x[e]], [y[e]], s=22, c='darkorange', edgecolor='k', lw=0.4, zorder=5); texts.append(ax.text(x[e], y[e], g, fontsize=7.5, zorder=6))
    adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='0.4', lw=0.5)); ax.legend(fontsize=7.5, loc='upper right', frameon=False)
x, y = a6, L['HUV6_AbIL33vIsoIL33']
panel(axes[0, 0], x, y, rob6, f'A  HUVEC 6 h — AX-1177 reverses the IL-33 programme\n    r = {stats.pearsonr(x[rob6], y[rob6])[0]:.2f}; median reversal {(-y / x)[rob6].median() * 100:.0f}%', 'IL-33 vs vehicle (log2FC)', 'AX-1177+IL-33 vs isotype+IL-33 (log2FC)')
x, y = a24, L['HUV24_AbIL33vIsoIL33']
panel(axes[0, 1], x, y, rob24, f'B  HUVEC 24 h — smaller response, reversal still high\n    r = {stats.pearsonr(x[rob24], y[rob24])[0]:.2f}; median reversal {(-y / x)[rob24].median() * 100:.0f}%', 'IL-33 vs vehicle (log2FC)', 'AX-1177+IL-33 vs isotype+IL-33 (log2FC)')
x, y = a6, L['HUV6_AbvIso']
panel(axes[0, 2], x, y, rob6, f'C  HUVEC 6 h — AX-1177 alone leaves these genes alone\n    r = {stats.pearsonr(x[rob6], y[rob6])[0]:.2f}', 'IL-33 vs vehicle (log2FC)', 'AX-1177 vs isotype, no IL-33 (log2FC)', ident=False)
x, y = a6, L['HGM6_AbIL33vIsoIL33']
panel(axes[1, 0], x, y, rob6, f'D  HGMEC (glomerular EC) 6 h — same programme reversed\n    r = {stats.pearsonr(x[rob6], y[rob6])[0]:.2f}; slope {np.polyfit(x[rob6], y[rob6], 1)[0]:.2f} (x-axis = HUVEC response)', 'IL-33 vs vehicle in HUVEC, 6 h (log2FC)', 'HGMEC: AX-1177+IL-33 vs isotype+IL-33 (log2FC)')
x, y = a6, L['HGM24_AbIL33vIsoIL33']
panel(axes[1, 1], x, y, rob6, f'E  HGMEC 24 h — little signal left\n    r = {stats.pearsonr(x[rob6], y[rob6])[0]:.2f}; slope {np.polyfit(x[rob6], y[rob6], 1)[0]:.2f}', 'IL-33 vs vehicle in HUVEC, 6 h (log2FC)', 'HGMEC: AX-1177+IL-33 vs isotype+IL-33 (log2FC)')
ax = axes[1, 2]; x, y, sel = a6, a24, rob6
ax.scatter(x[~sel], y[~sel], s=2, c='#c8c8c8', alpha=0.35, rasterized=True); ax.scatter(x[sel], y[sel], s=9, c='#1f77b4', alpha=0.7, rasterized=True)
ax.plot([-6, 12.5], [-6, 12.5], c='crimson', lw=1.2, ls='--', label='24 h = 6 h'); ax.axhline(0, c='k', lw=0.6); ax.axvline(0, c='k', lw=0.6); ax.set_xlim(-6, 12.5); ax.set_ylim(-6, 12.5)
ax.set_xlabel('IL-33 vs vehicle, 6 h (log2FC)', fontsize=10); ax.set_ylabel('IL-33 vs vehicle, 24 h (log2FC)', fontsize=10)
ax.set_title(f'F  HUVEC time course — 6 h is the peak\n    slope {np.polyfit(x[sel], y[sel], 1)[0]:.2f}; median 24 h / 6 h ratio {(y / x)[sel & (x > 0)].median():.2f} (induced genes)', fontsize=10.5, fontweight='bold', loc='left')
texts = []
for g in ['SELE', 'VCAM1', 'TNF', 'IL6', 'F3', 'CSF2', 'CXCL6', 'CSF3', 'KYNU', 'C3', 'CXCL5', 'CXCL8', 'CCL20', 'ICAM1', 'CCL5', 'PTX3', 'IL1RL1']:
    e = sym2ens[g]; ax.scatter([x[e]], [y[e]], s=22, c='darkorange', edgecolor='k', lw=0.4, zorder=5); texts.append(ax.text(x[e], y[e], g, fontsize=7.5))
adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='0.4', lw=0.5)); ax.legend(fontsize=8, loc='upper left', frameon=False)
fig.suptitle('AX-1177 (Compound_47, 10 µg/mL) against recombinant reduced IL-33 (30 ng/mL) in primary human endothelial cells — RNA-seq contrasts as delivered\n'
             'Each point is one gene. "Robust" = |log2FC| ≥ 1 and ≥ 5× the gene\'s empirical noise (RMS of 8 null contrasts), excluding zero-count genes', fontsize=11, y=0.995)
plt.tight_layout(rect=[0, 0, 1, 0.95], w_pad=2.5, h_pad=2.0); plt.savefig(os.path.join(F, 'fig1_pharmacology_endothelium.png'), dpi=160); plt.close()

# ------------------------------------------------------------------ Figure 2: statistics caveats
fig, axes = plt.subplots(2, 2, figsize=(14.5, 11.5))
ax = axes[0, 0]; c = 'HUV6_IL33vVeh'; x = L[c]; y = -np.log10(P[c].clip(lower=1e-70)); bad = S[c] > 1.5
ax.scatter(x[~bad], y[~bad], s=3, c='#9a9a9a', alpha=0.4, rasterized=True, label='implied SE in normal range'); ax.scatter(x[bad], y[bad], s=14, c='crimson', alpha=0.9, label=f'implied SE > 1.5 log2 (n={int(bad.sum())})')
ax.set_xlabel('IL-33 vs vehicle, HUVEC 6 h (log2FC)'); ax.set_ylabel('−log10 P (as delivered)'); ax.set_title('A  Delivered P-values miss the classical endothelial activation genes', fontsize=10.5, fontweight='bold', loc='left')
texts = [ax.text(x[sym2ens[g]], y[sym2ens[g]], g, fontsize=8, color='crimson') for g in ['SELE', 'VCAM1', 'CXCL8', 'CXCL1', 'ICAM1', 'CCL2', 'PTGS2', 'PTX3', 'IL1RL1', 'SLC7A2', 'TNFAIP2', 'CD44']]
texts += [ax.text(x[sym2ens[g]], y[sym2ens[g]], g, fontsize=7.5, color='0.25') for g in ['CSF2', 'CCL20', 'IL6', 'TRAF1', 'NFKBIA', 'CXCL3', 'TNF']]
adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='0.5', lw=0.5)); ax.legend(fontsize=8, frameon=False, loc='upper left')
ax = axes[0, 1]; ms = S[c]
ax.scatter(emp_se[~bad], ms[~bad], s=3, c='#9a9a9a', alpha=0.3, rasterized=True); ax.scatter(emp_se[bad], ms[bad], s=14, c='crimson', alpha=0.9)
ax.set_xscale('log'); ax.set_yscale('log'); ax.plot([0.01, 3], [0.01, 3], 'k--', lw=0.8, label='delivered SE = empirical SE'); ax.set_xlim(0.01, 3); ax.set_ylim(0.01, 5e4)
ax.set_xlabel('Empirical SE of a 2-group contrast (RMS log2FC over 8 null endothelial contrasts)'); ax.set_ylabel('SE implied by delivered table (|log2FC / t|), HUVEC 6 h')
ax.set_title('B  For ~150 genes the pooled-model SE is not credible\n    (up to 10⁴ log2 units); for the rest it matches an empirical null', fontsize=10.5, fontweight='bold', loc='left')
texts = [ax.text(emp_se[sym2ens[g]], ms[sym2ens[g]], g, fontsize=8, color='crimson') for g in ['SELE', 'VCAM1', 'CXCL8', 'CXCL1', 'ICAM1', 'CCL2', 'PTGS2', 'PTX3', 'IL1RL1', 'CD93', 'CDH5', 'VWF', 'AKR1C2', 'KRT8', 'XBP1']]
adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='0.5', lw=0.5)); ax.legend(fontsize=8, frameon=False, loc='lower right')
ax = axes[1, 0]; c2 = 'A549_24_AbvPBS'; x = L[c2]; y = -np.log10(P[c2].clip(lower=1e-100)); sg = Q[c2] < 0.05; tiny = sg & (x.abs() < 0.3); low = sg & (x.abs() >= 0.3)
ax.scatter(x[~sg], y[~sg], s=3, c='#9a9a9a', alpha=0.4, rasterized=True)
ax.scatter(x[tiny], y[tiny], s=22, c='darkorange', edgecolor='k', lw=0.3, label=f'FDR<5%, |log2FC|<0.3 (n={int(tiny.sum())}): abundant genes, implied SE ≈ 0.001–0.02')
ax.scatter(x[low], y[low], s=22, c='#1f77b4', edgecolor='k', lw=0.3, label=f'FDR<5%, |log2FC|≥0.3 (n={int(low.sum())}): near-zero-count genes')
ax.set_yscale('symlog', linthresh=10); ax.set_ylim(0, 130); ax.set_xlabel('AX-1177 vs PBS, A549 24 h, no IL-33 (log2FC)'); ax.set_ylabel('−log10 P (as delivered; symlog axis)')
ax.set_title('C  Antibody-alone "hits" are artefacts: e.g. AKR1C2, +8% change, P = 1e-98', fontsize=10.5, fontweight='bold', loc='left')
adjust_text([ax.text(x[e], y[e], ann.loc[e, 'symbol'], fontsize=7.5) for e in x[tiny].index], ax=ax, arrowprops=dict(arrowstyle='-', color='0.5', lw=0.5)); ax.legend(fontsize=7.5, frameon=False, loc='center')
ax = axes[1, 1]
lab = {'HUV6_IL33vVeh': 'HUVEC 6h: IL-33 vs vehicle', 'HUV6_AbIL33vIsoIL33': 'HUVEC 6h: AX-1177+IL-33 vs iso+IL-33', 'HUV24_IL33vVeh': 'HUVEC 24h: IL-33 vs vehicle', 'HUV24_AbIL33vIsoIL33': 'HUVEC 24h: AX-1177+IL-33 vs iso+IL-33', 'HGM6_AbIL33vIsoIL33': 'HGMEC 6h: AX-1177+IL-33 vs iso+IL-33', 'HGM24_AbIL33vIsoIL33': 'HGMEC 24h: AX-1177+IL-33 vs iso+IL-33',
       'HUV6_AbvIso': 'HUVEC 6h: AX-1177 vs iso', 'HUV24_AbvIso': 'HUVEC 24h: AX-1177 vs iso', 'HGM6_AbvIso': 'HGMEC 6h: AX-1177 vs iso', 'HGM24_AbvIso': 'HGMEC 24h: AX-1177 vs iso', 'A549_6_AbvIso': 'A549 6h: AX-1177 vs iso', 'A549_24_AbvIso': 'A549 24h: AX-1177 vs iso', 'MCF7_6_AbvIso': 'MCF7 6h: AX-1177 vs iso', 'MCF7_24_AbvIso': 'MCF7 24h: AX-1177 vs iso',
       'A549_6_AbvPBS': 'A549 6h: AX-1177 vs PBS', 'A549_24_AbvPBS': 'A549 24h: AX-1177 vs PBS', 'MCF7_6_AbvPBS': 'MCF7 6h: AX-1177 vs PBS', 'MCF7_24_AbvPBS': 'MCF7 24h: AX-1177 vs PBS', 'A549_6_AbvDMSO': 'A549 6h: AX-1177 vs DMSO', 'A549_24_AbvDMSO': 'A549 24h: AX-1177 vs DMSO', 'MCF7_6_AbvDMSO': 'MCF7 6h: AX-1177 vs DMSO', 'MCF7_24_AbvDMSO': 'MCF7 24h: AX-1177 vs DMSO'}
n = [(Q[k] < 0.05).sum() for k in lab]; ypos = np.arange(len(lab))[::-1]
ax.barh(ypos, n, color=['#1f77b4'] * 6 + ['#bdbdbd'] * 16); ax.set_yticks(ypos); ax.set_yticklabels(list(lab.values()), fontsize=7.5); ax.set_xscale('log'); ax.set_xlim(5, 12000)
for yy, v in zip(ypos, n): ax.text(v * 1.08, yy, f'{v:,}', va='center', fontsize=7.5)
ax.set_xlabel('Genes at FDR < 5% (of 26,210; delivered adj.P.Val)'); ax.set_title('D  IL-33 contrasts: thousands of genes. Antibody-alone: 14–73,\n    not reproducible across time points or cell types', fontsize=10.5, fontweight='bold', loc='left')
plt.tight_layout(); plt.savefig(os.path.join(F, 'fig2_rnaseq_statistics_caveats.png'), dpi=160); plt.close()

# ------------------------------------------------------------------ Figure 3: serum
j = pd.read_pickle(os.path.join(W, 'serum_x_rna.pkl')); u = pd.read_pickle(os.path.join(W, 'serum_gene_level.pkl')); j['lnOR'] = np.log(j['OR'])
fig = plt.figure(figsize=(19, 11)); gs = fig.add_gridspec(2, 3, width_ratios=[1.3, 0.95, 1.2], wspace=0.42, hspace=0.38)
ax = fig.add_subplot(gs[:, 0]); ax.scatter(j['lnOR'].clip(-2, 3.6), -np.log10(j['p.value']), s=6, c='#b5b5b5', alpha=0.6, rasterized=True, label='all assays (1,094 rows = 1,063 proteins)')
sets = {'IL-33 receptor axis: sST2': (['ST2'], 'crimson', '*', 280),
        'IL-33-induced in endothelium, AX-1177-reversed,\nand FDR<5% in serum': (['IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO', 'IL8', 'CCL20', 'MCP-3', 'OPG-INFI', 'OPG-CVDIII', 'PTX3', 'CSF-1', 'IL-18R1', 'CTSS', 'B4GALT1'], '#1f77b4', 'o', 46),
        'IL-33-induced in endothelium (largest in vitro effects),\nnot FDR-significant in serum': (['CXCL6', 'G-CSF', 'CXCL1-INFI', 'CXCL1-CVDII', 'CXCL5', 'CX3CL1', 'VCAM1', 'ICAM1', 'SELE', 'TNFRSF9', 'CCL5', 'CXCL10', 'MCP-1-INFI', 'MCP-1-CVDIII', 'TF', 'KYNU'], '#6baed6', 's', 34),
        'Type-2 / eosinophil / mast-cell proteins': (['IL5-IMO', 'CCL11-INFI', 'CCL11-IMO', 'CCL17', 'CCL24', 'MCP-4', 'FCER2', 'IL-5R-alpha', 'RNASE3', 'TPSAB1', 'IL-4RA', 'AREG-ONCII', 'AREG-IMO', 'IL13RA1', 'HPGDS', 'IL17RB'], '#2ca02c', '^', 46)}
texts = []
for name, (assays, col, mk, sz) in sets.items():
    d = j[j.assay.isin(assays)]; ax.scatter(d['lnOR'].clip(-2, 3.6), -np.log10(d['p.value']), s=sz, c=col, marker=mk, edgecolor='k', lw=0.4, label=name, zorder=4)
    texts += [ax.text(min(max(r['lnOR'], -2), 3.6), -np.log10(r['p.value']), r['assay'], fontsize=7, color=col if col != '#6baed6' else '#2b6ea6', zorder=5) for _, r in d.iterrows()]
for a in ['HGF', 'HGF-ONCII', 'OSM', 'HDGF', 'SEMA4C', 'ANXA1', 'CLEC5A', 'NPM1', 'PRTN3', 'CALR', 'vWF', 'ANGPT2', 'IL1B', 'TNF', 'IFN-gamma']:
    r = j[j.assay == a].iloc[0]; texts.append(ax.text(min(r['lnOR'], 3.6), -np.log10(r['p.value']), a, fontsize=6.8, color='0.3'))
pfdr = j.loc[j['adj.p.value'] < 0.05, 'p.value'].max()
ax.axhline(-np.log10(pfdr), c='k', ls='--', lw=0.8); ax.text(-1.95, -np.log10(pfdr) + 0.05, 'FDR 5% (delivered adj. P)', fontsize=7.5)
ax.axhline(-np.log10(0.05 / 1194), c='k', ls=':', lw=0.8); ax.text(-1.95, -np.log10(0.05 / 1194) + 0.05, 'Bonferroni (1,194 tests)', fontsize=7.5); ax.axvline(0, c='k', lw=0.6)
adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='0.5', lw=0.4)); ax.set_ylim(-0.3, 7.0)
ax.set_xlabel('ln(odds ratio) for ICU / ventilation / death within 30 d, per log unit of protein\n(adjusted for age, sex, NEWS2; values beyond 3.6 clipped)'); ax.set_ylabel('−log10 P')
ax.set_title(f'A  Serum at enrolment, 100 hospitalised COVID-19 patients:\n    sST2 ranks 2nd of 1,094 assays; {(j.OR > 1).mean() * 100:.0f}% of all assays have OR > 1', fontsize=10.5, fontweight='bold', loc='left')
ax.legend(fontsize=7.2, loc='upper left', bbox_to_anchor=(0.005, 0.995), frameon=True, framealpha=0.92)
ax = fig.add_subplot(gs[0, 1]); ind = u[u.induced_reversed]; unch = u[u.cls == 'unchanged (|log2FC|<0.3)']; rest = u[~u.induced_reversed]
data = [ind.z.values, unch.z.values, rest.z.values]; labels = [f'IL-33-induced &\nAX-1177-reversed\n(n={len(ind)})', f'unchanged by\nIL-33 (n={len(unch)})', f'all other proteins\nwith RNA data\n(n={len(rest)})']
bp = ax.boxplot(data, tick_labels=labels, showfliers=False, patch_artist=True, widths=0.55)
for p_, c_ in zip(bp['boxes'], ['#1f77b4', '#d9d9d9', '#d9d9d9']): p_.set_facecolor(c_); p_.set_alpha(0.7)
rng = np.random.default_rng(0)
for i, d in enumerate(data): ax.scatter(rng.normal(i + 1, 0.07, len(d)), d, s=5, c='k', alpha=0.25, rasterized=True)
for i, d in enumerate([ind, unch, rest]): ax.text(i + 1, 5.05, f'{int(d.sig.sum())}/{len(d)} = {d.sig.mean():.0%}\nat FDR<5%', ha='center', fontsize=8.5)
import statsmodels.api as sm
tab = np.array([[ind.sig.sum(), (~ind.sig).sum()], [rest.sig.sum(), (~rest.sig).sum()]]); t2 = sm.stats.Table2x2(tab); ci = t2.oddsratio_confint()
ax.set_ylim(-3.2, 5.9); ax.axhline(0, c='k', lw=0.6); ax.set_ylabel('Serum association z-score (ln OR / SE)'); ax.tick_params(axis='x', labelsize=7.8)
ax.set_title(f'B  IL-33 endothelial signature is not enriched among\n    outcome-associated proteins\n    (OR {t2.oddsratio:.2f}, 95% CI {ci[0]:.2f}–{ci[1]:.2f}; P = {stats.fisher_exact(tab)[1]:.2f})', fontsize=10, fontweight='bold', loc='left')
ax = fig.add_subplot(gs[1, 1]); ax.scatter(ind.a6, ind.z, s=22, c=np.where(ind.sig, '#1f77b4', '#bdbdbd'), edgecolor='k', lw=0.3)
adjust_text([ax.text(r.a6, r.z, r.gene, fontsize=7) for _, r in ind.iterrows() if r.sig or r.a6 >= 5 or r.gene in ('SELE', 'VCAM1', 'ICAM1', 'F3', 'CCL2')], ax=ax, arrowprops=dict(arrowstyle='-', color='0.5', lw=0.4))
rho = stats.spearmanr(ind.a6, ind.z); ax.axhline(0, c='k', lw=0.6); ax.set_xlabel('IL-33 induction in HUVEC, 6 h (log2FC)'); ax.set_ylabel('Serum association z-score')
ax.set_title(f'C  In vitro effect size does not track prognostic\n    strength (Spearman ρ = {rho[0]:.2f}, P = {rho[1]:.2f})', fontsize=10, fontweight='bold', loc='left')
ax = fig.add_subplot(gs[:, 2])
rows = [('IL-33 receptor axis / IL-1 family receptors', None), ('ST2', 'sST2 (IL1RL1)'), ('IL-18R1', 'IL-18R1'), ('IL-1RT2', 'IL-1R2'),
        ('IL-33-inducible endothelial products, FDR<5%', None), ('PTX3', 'PTX3'), ('OPG-INFI', 'OPG (Inflammation)'), ('OPG-CVDIII', 'OPG (CVD III)'), ('IL6', 'IL-6 (Inflammation)'), ('IL6-ONCII', 'IL-6 (Oncology II)'), ('IL6-CVDII', 'IL-6 (CVD II)'), ('IL6-IMO', 'IL-6 (Immune Response)'), ('IL8', 'IL-8 (CXCL8)'), ('CCL20', 'CCL20'), ('MCP-3', 'MCP-3 (CCL7)'),
        ('IL-33-inducible, strongest in vitro, not FDR-significant', None), ('TF', 'Tissue factor (F3)'), ('MCP-1-INFI', 'MCP-1 (CCL2)'), ('SELE', 'E-selectin'), ('ICAM1', 'ICAM-1'), ('VCAM1', 'VCAM-1'), ('CX3CL1', 'CX3CL1'), ('G-CSF', 'G-CSF (CSF3)'), ('CXCL1-INFI', 'CXCL1'), ('CXCL5', 'CXCL5'), ('CXCL6', 'CXCL6'),
        ('Type-2 / eosinophil / mast cell', None), ('IL-4RA', 'IL-4Rα'), ('RNASE3', 'ECP (RNASE3)'), ('IL-5R-alpha', 'IL-5Rα'), ('IL5-IMO', 'IL-5'), ('CCL11-INFI', 'Eotaxin-1 (CCL11)'), ('CCL24', 'Eotaxin-2 (CCL24)'), ('CCL17', 'TARC (CCL17)'), ('TPSAB1', 'Tryptase (TPSAB1)'), ('FCER2', 'CD23 (FCER2)')]
ypos = len(rows); yt = []; yl = []
for key, lab_ in rows:
    ypos -= 1
    if lab_ is None: ax.text(0.012, ypos, key, fontsize=8.6, fontweight='bold', va='center', ha='left', transform=ax.get_yaxis_transform()); continue
    r = j[j.assay == key].iloc[0]; col = '#1f77b4' if r['adj.p.value'] < 0.05 else '0.45'
    ax.plot([r['l95'], min(r['u95'], 45)], [ypos, ypos], c=col, lw=1.6); ax.scatter([r['OR']], [ypos], c=col, s=30, zorder=3); yt.append(ypos); yl.append(lab_)
    ax.text(1.02, ypos, f"{r['OR']:.2f} ({r['l95']:.2f}–{r['u95']:.2f}); q = {r['adj.p.value']:.3f}", fontsize=7.3, va='center', ha='left', transform=ax.get_yaxis_transform())
ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=8); ax.set_xscale('log'); ax.set_xlim(0.3, 45); ax.axvline(1, c='k', lw=0.8); ax.set_ylim(-1, len(rows))
ax.set_xlabel('Odds ratio (95% CI) per log unit; blue = FDR<5%'); ax.set_title('D  Selected proteins: OR (95% CI); q = delivered adj. P', fontsize=10.5, fontweight='bold', loc='left')
fig.subplots_adjust(left=0.05, right=0.885, top=0.93, bottom=0.09); plt.savefig(os.path.join(F, 'fig3_serum_proteomics.png'), dpi=160); plt.close()

# ------------------------------------------------------------------ Figure 4: lung IHC
don = pd.read_pickle(os.path.join(W, 'lung_donors.pkl'))
order = ['NEG_NONPNA', 'NEG_PNA', 'POS_PNA']; cols = {'NEG_NONPNA': '#7f7f7f', 'NEG_PNA': '#1f77b4', 'POS_PNA': '#d62728'}
names = {g: f"{t}\n({(don.grp == g).sum()} donors, {int(don.loc[don.grp == g, 'n_blocks'].sum())} blocks)" for g, t in zip(order, ['COVID− no pneumonia', 'COVID− pneumonia', 'COVID+ pneumonia'])}
panels = [('IL33_endo', 'IL-33, endothelium'), ('IL33_epi', 'IL-33, airway basal epithelium'), ('IL33_vsmc', 'IL-33, vascular smooth muscle'), ('EPX', 'Eosinophil peroxidase (EPX)'), ('NE', 'Neutrophil elastase')]
fig, axes = plt.subplots(2, 3, figsize=(16, 10)); rng = np.random.default_rng(3)
for ax, (m_, title) in zip(axes.flat, panels):
    for i, g in enumerate(order):
        d = don[don.grp == g]; xj = i + rng.uniform(-0.22, 0.22, len(d)); sup = (d.label_not_matched_by_text == 0).values
        ax.scatter(xj[sup], d.loc[sup, m_], s=30 + 22 * d.loc[sup, 'n_blocks'], c=cols[g], alpha=0.75, edgecolor='k', lw=0.5)
        ax.scatter(xj[~sup], d.loc[~sup, m_], s=30 + 22 * d.loc[~sup, 'n_blocks'], facecolors='none', edgecolor=cols[g], lw=1.6)
        ax.plot([i - 0.3, i + 0.3], [d[m_].mean()] * 2, c='k', lw=2); ax.text(i, -0.55 if m_ not in ('IL33_endo', 'IL33_epi') else 2.05, f'mean {d[m_].mean():.2f}', ha='center', fontsize=8.5)
    gg = [don.loc[don.grp == g, m_].dropna() for g in order]
    ax.set_xticks(range(3)); ax.set_xticklabels([names[g] for g in order], fontsize=8.5)
    if m_.startswith('IL33'):
        ax.axhline(5.5, c='0.4', ls=':', lw=1); ax.text(2.45, 5.56, 'top category ("5+")', fontsize=7.5, ha='right', va='bottom', color='0.3'); ax.set_ylim(1.9 if m_ != 'IL33_vsmc' else -0.8, 6.0); ax.set_ylabel('Donor mean score ("n+" coded n+0.5)')
    else: ax.set_ylim(-0.8, 5.3); ax.set_ylabel('Donor mean IHC score (0–5)')
    ax.set_title(f'{title}\n3-group KW P = {stats.kruskal(*gg).pvalue:.2f}; COVID+ vs COVID− pneumonia P = {stats.mannwhitneyu(gg[2], gg[1]).pvalue:.2f}', fontsize=9.3, fontweight='bold', loc='left')
ax = axes[1, 2]
for g, t in zip(order, ['COVID− no pneumonia', 'COVID− pneumonia', 'COVID+ pneumonia']):
    d = don[don.grp == g]; ax.scatter(d.NE, d.IL33_endo, s=30 + 22 * d.n_blocks, c=cols[g], alpha=0.75, edgecolor='k', lw=0.5, label=t)
r = stats.spearmanr(don.NE, don.IL33_endo); ax.set_xlabel('Neutrophil elastase, donor mean score'); ax.set_ylabel('IL-33 endothelium, donor mean score'); ax.axhline(5.5, c='0.4', ls=':', lw=1)
ax.set_title(f'Endothelial IL-33 vs neutrophil burden\nSpearman ρ = {r[0]:.2f}, P = {r[1]:.3f} (exploratory)', fontsize=9.3, fontweight='bold', loc='left'); ax.legend(fontsize=8, frameon=False, loc='lower left')
fig.suptitle(f'Post-mortem lung IHC, analysed per donor ({len(don)} donors; {int(don.n_blocks.sum())} blocks). Marker area ∝ blocks per donor (1–8). Open markers: donors whose disease-category label is not matched by the autopsy text.\n'
             'IL-33 is at or near the top of the scale in vascular endothelium in every group; nothing is higher in COVID+ pneumonia than in COVID− pneumonia.', fontsize=10.5, y=0.995)
plt.tight_layout(rect=[0, 0, 1, 0.95]); plt.savefig(os.path.join(F, 'fig4_lung_ihc_donor_level.png'), dpi=160); plt.close()

# ------------------------------------------------------------------ Figure 5: biomarker candidates
bm = pd.read_pickle(os.path.join(W, 'biomarker_table.pkl')).set_index('gene')
groups = [('Stratify / enrich\n(baseline serum)', ['IL1RL1']), ('PD candidates:\nIL-33-inducible,\nAX-1177-reversed,\nserum FDR<5%', ['IL6', 'CCL20', 'TNFRSF11B', 'IL18R1', 'CTSS', 'IL1B', 'CSF1', 'CCL7', 'CXCL8', 'PTX3']),
          ('Exploratory PD:\nserum FDR 5–10%', ['CCL2', 'F3', 'SELE', 'PLAU']), ('Pathway-proximal:\nlargest in vitro window,\nno prognostic signal\nin serum', ['CSF3', 'CXCL6', 'CXCL1', 'CXCL5', 'CX3CL1', 'CXCL10', 'VCAM1', 'ICAM1', 'CCL5', 'KYNU', 'TNFRSF9', 'MMP10', 'C1QTNF1']),
          ('In vitro only\n(not in delivered\nserum table)', ['CSF2', 'CXCL2', 'CXCL3', 'IL1A', 'LIF', 'C3', 'EBI3']), ('Repressed by IL-33,\nrestored by AX-1177', ['THBD', 'NOS3'])]
cols_ = ['HUVEC_IL33_6h_log2FC', 'HUVEC_reversal_6h_log2FC', 'HUVEC_IL33_24h_log2FC', 'HUVEC_reversal_24h_log2FC', 'HGMEC_reversal_6h_log2FC', 'HGMEC_reversal_24h_log2FC']
collab = ['HUVEC 6 h\nIL-33 vs veh', 'HUVEC 6 h\nAX-1177+IL-33\nvs iso+IL-33', 'HUVEC 24 h\nIL-33 vs veh', 'HUVEC 24 h\nAX-1177+IL-33\nvs iso+IL-33', 'HGMEC 6 h\nAX-1177+IL-33\nvs iso+IL-33', 'HGMEC 24 h\nAX-1177+IL-33\nvs iso+IL-33']
order = [g for _, gs_ in groups for g in gs_]; mat = bm.loc[order, cols_].values.astype(float); n = len(order)
fig = plt.figure(figsize=(16, 0.33 * n + 2.6)); ax = fig.add_axes([0.25, 0.075, 0.34, 0.825])
im = ax.imshow(mat, aspect='auto', cmap='RdBu_r', norm=TwoSlopeNorm(vmin=-10, vcenter=0, vmax=10))
for i in range(n):
    for k in range(len(cols_)): ax.text(k, i, f'{mat[i, k]:+.1f}', ha='center', va='center', fontsize=7.5, color='white' if abs(mat[i, k]) > 6 else 'k')
ax.set_xticks(range(len(cols_))); ax.set_xticklabels(collab, fontsize=8); ax.xaxis.tick_top()
ax.set_yticks(range(n)); ax.set_yticklabels([(bm.loc[g, 'protein'] if bm.loc[g, 'protein'].upper().replace('-', '') == g else f"{bm.loc[g, 'protein']} ({g})") + (' †' if bm.loc[g, 'model_stat_unreliable'] else '') for g in order], fontsize=8.5)
pos = 0
for gname, gs_ in groups:
    ax.axhline(pos - 0.5, c='k', lw=1.2); fig.text(0.005, 0.075 + 0.825 * (1 - (pos + len(gs_) / 2) / n), gname, fontsize=8.5, fontweight='bold', va='center', ha='left'); pos += len(gs_)
ax.axhline(n - 0.5, c='k', lw=1.2); ax.axvline(1.5, c='k', lw=0.8); ax.axvline(3.5, c='k', lw=0.8)
ax2 = fig.add_axes([0.605, 0.075, 0.055, 0.825]); z = bm.loc[order, 'serum_z'].values.astype(float).reshape(-1, 1)
ax2.imshow(np.ma.masked_invalid(z), aspect='auto', cmap='Purples', vmin=0, vmax=4.5); ax2.set_xticks([0]); ax2.set_xticklabels(['Serum z\n(outcome)'], fontsize=8); ax2.xaxis.tick_top(); ax2.set_yticks([])
for i, g in enumerate(order):
    r = bm.loc[g]
    ax2.text(0, i, 'n/a' if pd.isna(r['serum_z']) else f"{r['serum_z']:.1f}" + ('*' if r['serum_adjP'] < 0.05 else ''), ha='center', va='center', fontsize=8, color='0.4' if pd.isna(r['serum_z']) else ('white' if r['serum_z'] > 3 else 'k'))
pos = 0
for gname, gs_ in groups: ax2.axhline(pos - 0.5, c='k', lw=1.2); pos += len(gs_)
ax3 = fig.add_axes([0.675, 0.075, 0.32, 0.825]); ax3.set_xlim(0, 1); ax3.set_ylim(n - 0.5, -0.5); ax3.axis('off')
ax3.text(0.0, -1.4, 'Serum OR (95% CI); adj. P', fontsize=8.5, fontweight='bold'); ax3.text(0.62, -1.4, '24 h / 6 h', fontsize=8.5, fontweight='bold'); ax3.text(0.80, -1.4, 'Reversed 6 h', fontsize=8.5, fontweight='bold')
for i, g in enumerate(order):
    r = bm.loc[g]
    t = (f"{r['serum_OR']:.2f} ({r['serum_l95']:.2f}–{r['serum_u95']:.1f}); {r['serum_adjP']:.3f}" + (f"  [{int(r['serum_n_assays'])} assays]" if r['serum_n_assays'] > 1 else '')) if r['serum_n_assays'] > 0 else 'not in delivered serum table'
    ax3.text(0.0, i, t, fontsize=7.8, va='center'); ax3.text(0.66, i, f"{r['ratio_24h_over_6h']:.2f}", fontsize=7.8, va='center'); ax3.text(0.84, i, f"{r['pct_reversed_6h']:.0f}%", fontsize=7.8, va='center')
cax = fig.add_axes([0.25, 0.045, 0.34, 0.010]); cb = fig.colorbar(im, cax=cax, orientation='horizontal'); cb.set_label('log2 fold change', fontsize=8); cb.ax.tick_params(labelsize=7)
fig.suptitle('Candidate biomarkers: in vitro IL-33 response and AX-1177 reversal (both endothelial cell types, both time points) against prognostic signal in patient serum\n'
             '† delivered model P-value unreliable for this gene (implied SE > 1.5); effect confirmed against the empirical null.   * serum FDR < 5%.   n/a = protein absent from the delivered serum table.   PD = pharmacodynamic', fontsize=9.5, y=0.995)
plt.savefig(os.path.join(F, 'fig5_biomarker_candidates.png'), dpi=160); plt.close()
print('figures written to', F)
