# AX-1177 portfolio audit: recommendation, evidence and forward plan

Based only on the four delivered data files and the methods annex. Every number below can be regenerated with `scripts/analysis_pipeline.py`; supporting tables are in `tables/AX-1177_supporting_tables.xlsx`.

## 1. Recommendation

**Keep AX-1177, but change what it is kept for.** The data support the molecule and an endothelial mechanism. They do not support the current rationale, which is a virus-specific or type-2 role for IL-33 in severe lower respiratory infection. I recommend a conditional keep: re-scope the asset to IL-33-driven endothelial inflammation, run two inexpensive gates (a desk re-analysis, then in vitro and ex vivo work) before any further major spend, and drop it if those gates fail.

Three findings carry this position.

1. **AX-1177 neutralises IL-33 completely and cleanly in primary human endothelium.** At 6 h, IL-33 changed 460 genes robustly in umbilical vein endothelial cells (HUVEC). AX-1177 reversed 446 of them (97%) by at least half against both comparators (IL-33 alone and IL-33 plus isotype control), with a median reversal of 100% (interquartile range 91–105%). The same genes moved the same way in glomerular microvascular endothelial cells (HGMEC; 423 of 460). AX-1177 without IL-33 changed no gene reproducibly in any of four cell types.
2. **In patients, the IL-33 receptor axis is the strongest pathway-specific prognostic signal in the file.** Soluble ST2 (sST2, the circulating decoy form of the IL-33 receptor) ranked 2nd of 1,094 serum assays for ICU admission, ventilation or death (odds ratio 3.02 per log unit, 95% CI 1.83–5.01, adjusted for age, sex and the NEWS2 early-warning score). It is one of only two proteins that survive Bonferroni correction.
3. **Nothing in the data is virus-specific or type-2.** IL-33 staining in lung was no higher in COVID-19 pneumonia than in non-COVID pneumonia, eosinophil markers did not differ, and IL-5, eotaxins and TARC in serum were unrelated to outcome. What IL-33 drives in endothelium is a neutrophil- and monocyte-recruiting, pro-adhesive, pro-coagulant programme.

**What the data do not show** is that IL-33 drives deterioration in patients. The IL-33-inducible endothelial proteins are no more likely to be prognostic than any other serum protein (22% vs 17%), IL-33 itself is absent from the serum delivery, and there is no in vivo or lung-cell efficacy data. That gap is why the keep is conditional.

My confidence is high for finding 1, moderate for finding 2 (one cohort of 100), and the re-scoped indication is a hypothesis that the gates in section 5 are designed to test.

## 2. What each dataset shows

### 2.1 Endothelial pharmacology (RNA-seq; Figure 1)

![Figure 1](figures/fig1_pharmacology_endothelium.png)

| Read-out | HUVEC 6 h | HUVEC 24 h | HGMEC 6 h | HGMEC 24 h |
|---|---|---|---|---|
| Robust IL-33-responsive genes | 460 (366 up, 94 down) | 178 (153 up, 25 down) | not measurable (no IL-33-vs-control contrast delivered) | not measurable |
| Reversed ≥50% by AX-1177 vs both comparators | 446 (97%) | 162 (91%) | — | — |
| Median reversal vs isotype + IL-33 (IQR) | 100% (91–105%) | 85% (75–94%) | — | — |
| Median reversal vs IL-33 alone | 99% | 96% | — | — |
| HUVEC 6 h signature moving in the reversal direction | — | — | 423 of 460 (92%); slope −0.59 | 233 of 460 (51%); slope −0.12 |
| Correlation of AX-1177 alone with the IL-33 signature | −0.01 | 0.16 | 0.07 | 0.00 |

"Robust" means a change of at least two-fold that is also at least five times the gene's empirical noise (section 8 explains why the delivered P-values could not be used directly).

- **Size of the programme.** IL-33 induced E-selectin about 2,400-fold, GM-CSF 1,300-fold, CXCL6 680-fold, CCL20 590-fold, VCAM-1 430-fold, IL-8 290-fold, IL-6 56-fold and tissue factor 50-fold, and halved thrombomodulin. The top gene sets were TNF/NF-κB signalling, inflammatory response and interferon response (normalised enrichment +3.1 for IL-33, −3.1 with AX-1177).
- **Two vascular beds.** Glomerular endothelial cells showed the same AX-1177-sensitive programme at about 60% of the HUVEC magnitude, with VCAM-1 (−11.7 log2) and E-selectin (−8.7) the largest effects.
- **Time.** The response peaks early. Induced genes kept a median 39% of their 6 h change at 24 h, and only 31% of them kept half or more. In HGMEC the 24 h signal was about a fifth of the 6 h one, although a few genes (CCL5, VCAM-1, CXCL5, E-selectin) were still strongly AX-1177-sensitive.
- **Antibody alone.** Each antibody-alone contrast lists 14–73 genes at a false discovery rate (FDR) below 5%, but these do not replicate. Of 562 such genes, 11 recur in a second independent cell-line-by-time group (about 5 expected by chance) and none in a third.
- **One small signal to control next time.** Gene-set analysis picks up a shift in proliferation and mitochondrial gene sets in antibody-containing wells at 24 h, with or without IL-33. The median change against isotype is +7 to +10% in HGMEC and −4 to −7% in HUVEC. Opposite directions in two endothelial types point to plate or culture effects rather than pharmacology, but this design cannot separate them.
- **No type-2 output.** Eotaxin-3 (CCL26), IL-4, TSLP and periostin did not respond. CCL11, CCL24, CCL17, IL-5 and IL-13 fell below the expression filter in all four cell lines. Endothelium is not where a type-2 response would be expected, so on its own this is weak evidence.

Limits of this experiment: one antibody concentration at 41-fold molar excess over one IL-33 concentration, antibody added together with IL-33, reduced IL-33 only, one donor per cell type (the three replicates are cultures from that donor), no lung endothelium, and the two epithelial lines never received IL-33.

### 2.2 Serum proteomics in 100 hospitalised COVID-19 patients (Figure 3)

![Figure 3](figures/fig3_serum_proteomics.png)

| Protein | Odds ratio (95% CI) | Adjusted P | Induced by IL-33 in HUVEC at 6 h | Reversed by AX-1177 |
|---|---|---|---|---|
| sST2 | 3.02 (1.83–5.01) | 0.007 | 3.0-fold | 105% |
| PTX3 | 11.58 (3.40–39.4) | 0.012 | 4.5-fold | 104% |
| IL-6 (four assays) | 2.07–2.31 | 0.012–0.019 | 56-fold | 103% |
| OPG (two assays) | 4.40–6.77 | 0.014–0.020 | 28-fold | 104% |
| CCL20 | 1.83 (1.28–2.61) | 0.020 | 590-fold | 107% |
| MCP-3 | 1.72 (1.25–2.36) | 0.020 | 4.4-fold | imprecise (low counts) |
| IL-8 | 2.23 (1.35–3.68) | 0.023 | 290-fold | 103% |
| E-selectin | 2.08 (1.11–3.87) | 0.091 | 2,400-fold | 98% |
| G-CSF | 1.25 (0.87–1.79) | 0.40 | 320-fold | 100% |
| CXCL6 | 1.02 (0.63–1.64) | 0.98 | 680-fold | 87% |
| IL-5 | 1.00 (0.66–1.52) | 1.00 | below expression filter | — |
| Eotaxin-1 (two assays) | 0.98–1.08 | 0.90–0.98 | below expression filter | — |
| TARC | 0.85 (0.59–1.23) | 0.57 | below expression filter | — |

- **The sST2 signal is strong.** Only HGF ranks higher.
- **The signal is not specific.** 82% of all assays have an odds ratio above 1, and 176 of the 178 rows at FDR < 5% point the same way. Many are intracellular proteins. This is a general severity and tissue-damage signature.
- **The IL-33 endothelial signature is not enriched overall.** Of 65 serum proteins whose genes IL-33 induces and AX-1177 reverses, 14 (22%) are associated with outcome, against 145 of 850 (17%) of all other proteins (odds ratio 1.33, 95% CI 0.72–2.48, P = 0.39). The proteins with the largest IL-33 effects in vitro (CXCL6, G-CSF, CXCL1, CXCL5, VCAM-1) carry no prognostic signal.
- **It is concentrated at the very top, which I would present but not lean on.** Five of the 25 strongest prognostic proteins (sST2, PTX3, IL-6, IL-18R1, OPG) belong to that set, where 1.5 would be expected (P = 0.015). I chose the cut-off after seeing the ranking, so this is a description, not a test.
- **The target has no read-out, and some results are missing.** There is no IL-33 row, although IL-33 is normally part of the Inflammation panel that was run. The adjusted P-values correspond to 1,194 tests but 1,094 rows were delivered, so 100 tested assays are missing from the table. Back-calculating from the adjusted P-values, four of the missing assays would be significant at FDR 5% and one ranks about 20th of 1,194. Their identity is unknown.

Limits of this cohort: one centre, pre-vaccination, 100 patients with about 44 events, one sample at enrolment, and no treatment or symptom-duration data in the delivery.

### 2.3 Post-mortem lung (Figure 4)

![Figure 4](figures/fig4_lung_ihc_donor_level.png)

| Marker (donor means) | COVID+ pneumonia (16 donors) | COVID− pneumonia (10) | COVID− no pneumonia (5) | COVID+ minus COVID− pneumonia (95% CI) | P |
|---|---|---|---|---|---|
| IL-33, endothelium | 4.81 | 5.19 | 5.38 | −0.38 (−0.81 to +0.05) | 0.16 |
| IL-33, airway basal epithelium | 4.40 | 4.35 | 4.78 | +0.05 (−0.59 to +0.74) | 0.92 |
| IL-33, vascular smooth muscle | 2.48 | 3.08 | 3.45 | −0.59 (−1.32 to +0.12) | 0.15 |
| Eosinophil peroxidase | 1.88 | 1.75 | 1.20 | +0.12 (−0.47 to +0.71) | 0.67 |
| Neutrophil elastase | 3.58 | 3.55 | 2.50 | +0.03 (−0.53 to +0.61) | 1.00 |

Scores run from 0 to a top category of 5.5 as coded in the file. With 16 and 10 donors the intervals are wide: an epithelial or eosinophil difference of up to about 0.7 score units cannot be excluded, but anything more than a trivial increase in endothelial IL-33 can.

- **IL-33 is abundant in lung vessels in every donor.** Endothelium scored at least as high as airway epithelium in 27 of 31 donors, higher than vascular smooth muscle in all 31, and sat in the top category in 39 of 74 blocks.
- **It is not raised by COVID-19.** If anything endothelial and smooth-muscle staining was lower (endothelium −0.28 score units against all COVID− donors after adjusting for age and sex, P = 0.11). Endothelial IL-33 fell as neutrophil burden rose across all donors (Spearman −0.43, P = 0.016, exploratory).
- **I would not read the lower staining as IL-33 release.** In our own RNA-seq, 24 h of IL-33 stimulation lowered IL33 mRNA in HUVEC by 46%, and AX-1177 restored it (7.7 empirical standard errors from zero; the delivered adjusted P is 0.29). Activated endothelium appears to make less IL-33, so lower staining does not by itself show that the alarmin was released.
- **Neutrophils dominate, not eosinophils.** Neutrophil elastase was higher in pneumonia of either cause than without pneumonia (P = 0.007 using the autopsy text to define pneumonia). Eosinophil granule proteins did not separate COVID-19 from other pneumonia.
- **Vascular injury is a COVID-19 feature in the autopsy text.** Diffuse alveolar damage or acute lung injury was recorded in 7 of 16 COVID+ donors and none of 15 others (P = 0.007); pulmonary thrombo-emboli in 4 of 16 and none of 15 (P = 0.10).

Limits of this series: 31 donors aged 64–98, all white, one reader, a semi-quantitative scale that saturates in endothelium, and no normal lung.

## 3. The case to present

**One-paragraph version.** AX-1177 fully and specifically switches off a large IL-33-driven inflammatory programme in primary human endothelium from two vascular beds. In our COVID-19 cohort the soluble form of the IL-33 receptor is the second-strongest of 1,094 predictors of ICU admission, ventilation or death. Our data do not show that IL-33 causes that deterioration, and they give no support to the viral or type-2 rationale the programme started with. We therefore propose to keep the asset on a re-scoped endothelial-inflammation hypothesis, with a desk re-analysis and one round of in vitro and ex vivo experiments as gates, and to stop if patient material does not produce AX-1177-sensitive endothelial activation.

**Why keep.**

- The molecule is de-risked on its target in the relevant human cell type, with full reversal against an isotype-matched control and no reproducible off-target gene changes.
- The node it blocks sits upstream of several mediators that track poor outcome in our own patients (IL-6, IL-8, CCL20, OPG, PTX3). AX-1177 removes the whole IL-33-driven programme, not one cytokine.
- A candidate enrichment marker, sST2, already exists in patient serum and is one of the two strongest signals in the cohort.
- The target is present at high levels in human lung vessels.
- The open questions can be closed in steps. The first gate needs no new experiments and the second is in vitro work.

**What the committee will challenge, and the honest answer.**

| Challenge | Answer |
|---|---|
| "Is IL-33 actually driving severe viral infection?" | Not shown. Tissue IL-33 is not raised in COVID-19, there is no type-2 signal, and the IL-33 endothelial signature is not enriched among prognostic proteins. This is why the current label should be retired. |
| "sST2 is just a severity marker." | Correct. It is prognostic after adjustment for NEWS2, but it is a decoy receptor induced by many stimuli. I propose it for enrichment, not as proof of mechanism. |
| "Complete neutralisation at 41-fold excess proves little." | Correct. It shows specificity and maximal effect, not potency. Potency is in the biologics file and concentration–response is the first wet-lab gate. |
| "Why glomerular cells?" | They are the only microvascular endothelium tested. They show the programme is not a HUVEC peculiarity. They do not establish a kidney indication. |
| "The P-values for E-selectin and VCAM-1 are not significant." | That is a defect of the single pooled model, documented in section 8 and Figure 2. Against an empirical noise estimate both are more than 18 standard errors from zero and replicate in six independent contrasts. |

**If the committee prefers to drop.** What would be dropped is a clean IL-33 neutraliser with a defined endothelial mechanism and a ready enrichment marker. The reason would be that the disease link is unproven: no patient-level evidence that IL-33, rather than any other inflammatory driver, causes deterioration; no in vivo efficacy; and no support for the original viral or type-2 rationale.

## 4. The indication the data point at

The data point at a mechanism, vascular endothelial inflammation, more firmly than at a disease.

- **Lead setting: severe pneumonia with endothelial activation and high sST2, whatever the pathogen.** This keeps the patient population we have data for, but drops "viral" and "type-2" from the rationale. Non-COVID pneumonia lungs did not differ detectably from COVID-19 lungs for IL-33 or granulocytes, and the serum signature is a generic hyper-inflammatory one.
- **Repurposing hypothesis: microvascular inflammation of the kidney.** AX-1177 reverses the IL-33 programme in glomerular endothelial cells. There are no kidney patient data in the file, so this is a lead to test, not a position to defend yet.
- **A thread worth following in either setting: thrombo-inflammation.** IL-33 induced tissue factor 50-fold and halved thrombomodulin, serum tissue factor had an odds ratio of 3.02 (adjusted P = 0.051), and thrombo-emboli appeared only in COVID+ lungs.

The data give no support for repositioning to asthma or COPD. IL-33 and eosinophil scores did not differ in donors with those conditions noted (P = 0.13–0.97, 12 of 31 donors), and no airway epithelial pharmacology was done.

## 5. What the next studies have to establish

**Gate 0: desk work on data already held (no new experiments).**

1. Re-fit the RNA-seq per cell line from the archived counts and extract the missing contrasts, above all IL-33 vs control in HGMEC. This must establish that glomerular cells respond to IL-33 directly, which cell types express ST2, and correct P-values for the adhesion and chemokine genes.
2. Retrieve the 100 serum assays that were tested but not delivered, confirm whether IL-33 is among them, and obtain detection rates. Four of them are outcome-associated, so this could move the case in either direction. Re-run the outcome models on patient-level data with sST2 as a covariate and with a pre-specified IL-33 endothelial score. This must establish whether IL-33 is detectable, whether anything adds to sST2, and what sST2 threshold enriches.
3. Pull affinity, potency and oxidised-form binding from the biologics file to set concentrations for Gate 1.
4. Re-read the lung blocks with a second blinded reader or digital quantification, stain for ST2, E-selectin, VCAM-1 and tissue factor, and analyse the tissue RNA that appears to exist for 22 donors (identifiers are in the workbook). This must establish whether endothelial activation and the receptor are present where IL-33 is.

**Gate 1: in vitro and ex vivo.**

1. Concentration–response for AX-1177 against reduced and oxidised IL-33, in at least three donors each of lung microvascular endothelium, HGMEC and HUVEC, with a vehicle arm in every line and a randomised plate layout.
2. Delayed addition, with antibody given 1–2 h after IL-33, to model treatment rather than prevention.
3. Patient material. Apply serum or airway fluid from sST2-high and sST2-low patients to endothelial cells with AX-1177 or isotype. This is the experiment that decides the indication, because it measures how much patient-driven endothelial activation depends on IL-33.
4. Function: neutrophil and monocyte adhesion under flow, barrier integrity and tissue-factor activity.
5. If any respiratory epithelial claim is to be kept, primary airway epithelium with reduced and oxidised IL-33.

**Gate 2: patients and in vivo, only if Gate 1 passes.**

1. An independent, contemporary, mixed-pathogen pneumonia cohort with serial sampling, to replicate sST2 and measure IL-33 with a sensitive assay.
2. In vivo proof of concept with endothelial endpoints.
3. For the kidney option, IL-33 and ST2 in glomerular endothelium on biopsies and a kidney-disease serum cohort.

**Proposed stop criteria (thresholds are for discussion).**

- Lung or glomerular endothelium from at least two of three donors does not respond to IL-33, or full suppression needs concentrations the biologics file says are not achievable.
- AX-1177 reduces endothelial activation by patient material by less than about 30% in sST2-high samples.
- IL-33 is neither detectable nor higher in patients who deteriorate, and sST2 does not replicate.

## 6. Biomarkers, sampling time and roles in patients

![Figure 5](figures/fig5_biomarker_candidates.png)

| Marker | Role | Support | Main caveat |
|---|---|---|---|
| sST2 | **Patients:** stratification and enrichment at enrolment | 2nd of 1,094; survives Bonferroni | Prognostic only; not shown to predict response |
| IL-6, CCL20, OPG (core); IL-18R1, cathepsin S, IL-1β (secondary) | **Patients:** pharmacodynamic panel, change from baseline against placebo | The six proteins that pass on the delivered statistics alone: induced at least two-fold at 6 h and 24 h in HUVEC, reversed by AX-1177 in HUVEC at both times and in HGMEC at 6 h (all FDR < 5%), and FDR < 5% in serum | Not IL-33-specific; uninterpretable without a control arm |
| M-CSF, MCP-3 | **Patients:** exploratory pharmacodynamics | Meet the same criteria at 6 h and are FDR < 5% in serum; at 24 h M-CSF is below two-fold and MCP-3 is not significant | Transient; MCP-3 is near the detection floor in vitro |
| IL-8, PTX3 | **Patients:** add to the panel once the RNA-seq re-fit confirms them | FDR < 5% in serum; induced 290- and 4.5-fold and fully reversed | Delivered RNA-seq P-values are unreliable for both (section 8) |
| Soluble E-selectin, tissue factor, MCP-1 | **Patients:** exploratory pharmacodynamics | E-selectin is the largest in vitro effect and, from general knowledge rather than our data, is made only by endothelium; serum adjusted P 0.05–0.09 | Below the FDR threshold in serum |
| G-CSF, CXCL6, CXCL5, CXCL1, GM-CSF | **Laboratory:** potency and ex vivo read-outs | Largest and most sustained in vitro effects in both cell types | No prognostic signal in serum; GM-CSF is not in the serum table |
| E-selectin, VCAM-1, ICAM-1 transcripts | **Laboratory:** primary potency read-out | Largest effects; VCAM-1 is the strongest effect in HGMEC | Delivered P-values unreliable for all three |
| IL-33 (free, total, in complex with sST2) | **Patients:** target engagement | None | Assay gap; no IL-33 data in the delivery |
| Eosinophil and type-2 markers, IL-5Rα staining | Not recommended | No association in tissue or serum | IL-5Rα staining tracks neutrophils here (Spearman 0.89), not eosinophils (0.12) |

Cathepsin S is the only protein that passes every test in the file (both time points, both cell types, and serum), although its fold change is modest (4.4-fold) and its serum confidence interval is wide. No marker has been shown to predict response to AX-1177, because there are no interventional data.

**Sampling time.**

- **In vitro, 6 h for transcripts.** It is the peak, reversal is complete, and both cell types respond. Keep 24 h only for the sustained subset (GM-CSF, CXCL6, G-CSF, CXCL5, IL-8, CCL20) and for secreted protein, which our data do not cover. Add a 1–2 h point to separate the primary response from secondary TNF and IL-1 loops.
- **Patients, at enrolment.** Every prognostic result in the file comes from the enrolment sample, so stratification belongs there. For pharmacodynamics the in vitro kinetics argue for a first on-treatment sample within 24 h, but that timing is an inference and needs the serial cohort in Gate 2.

## 7. What I considered and ruled out

**Hypotheses.**

- **A type-2 or eosinophilic mechanism.** Set aside as a rationale: the patient data give it no support (no eosinophil difference in tissue; no association for IL-5, eotaxins or TARC in serum). Two limits apply. The tissue intervals are wide, and none of the cell types that mount type-2 responses were tested in vitro.
- **Virus-specific up-regulation of IL-33.** Not supported: staining was not higher in COVID-19 lungs in any compartment, and for endothelium anything more than a trivial increase is excluded (upper confidence limit +0.05 score units).
- **Lower endothelial staining as evidence of IL-33 release.** Not supported: not significant per donor, limited by a ceiling, and explained equally by activation lowering IL-33 expression.
- **Off-target or agonist activity of AX-1177.** Ruled out at the gene level within the limits of three replicates: nothing reproducible in four cell types. The small 24 h gene-set shift described in section 2.1 remains to be excluded with a randomised layout.
- **The serum signature as evidence that IL-33 drives outcome.** Ruled out: no enrichment, and the strongest IL-33 products are not prognostic.
- **Kidney as the lead indication.** Not yet: in vitro data from one donor and no patient data.
- **Asthma or COPD.** No supporting data.
- **GM-CSF or CXCL6 as lead patient markers because they are the largest hits.** Ruled out: GM-CSF is not in the serum table and CXCL6 has an odds ratio of 1.02.
- **24 h as the primary sampling time.** Ruled out: the response is about 40% of its 6 h size in HUVEC and about a fifth in HGMEC.

**Analysis choices.**

- **Filtering on adjusted P.** Rejected. It discards E-selectin, VCAM-1, IL-8, CXCL1, MCP-1, PTX3 and ST2, whose delivered P-values are artefacts.
- **Ranking on fold change alone.** Rejected. It admits low-count noise genes.
- **Analysing lung blocks individually.** Rejected. Three donors supply 24 of 49 COVID+ blocks, and block-level tests manufacture significance (endothelial IL-33 P = 0.017 per block against 0.052 per donor).
- **Reading the time point from the workbook tab.** Rejected. The "6h" and "24h" tabs are identical and each holds both time points.
- **Counting 178 significant serum rows as 178 proteins.** Rejected. They are 169 proteins; 27 proteins are measured on more than one panel.
- **Ranking serum proteins by odds ratio.** Rejected. The units are not comparable across assays (M-CSF: odds ratio 90, CI 4.2–1,933).

## 8. Data problems that affect interpretation

The full log, with evidence and handling for 26 items, is in the `Data_QC_log` sheet. The ones that matter most:

![Figure 2](figures/fig2_rnaseq_statistics_caveats.png)

- **The RNA-seq P-values are unreliable in both directions.** The single model fitted across four cell lines gives implausible standard errors for genes whose expression differs greatly between groups. 137 genes have implied standard errors above 1.5 log2 in every endothelial contrast (up to 16,536), which hides the strongest endothelial activation genes. Conversely AKR1C2 in A549 shows a change of 8% with P = 1e-98. Antibody-alone contrasts yield 25–58 genes at P < 1e-4 where 2.6 are expected.
- **How I handled it.** I took every delivered value as correct. Effect sizes do not depend on the variance model, so I used them with an empirical noise estimate taken from eight endothelial contrasts that should be null (antibody alone, and isotype + IL-33 against IL-33), and required replication across independent contrasts. For the 26,055 genes with credible model errors the empirical and model estimates agree (median ratio 1.01). The headline result does not depend on this choice: on the delivered statistics alone, 284 IL-33-responsive genes in HUVEC at 6 h have credible errors in both contrasts, and 99% of them are reversed by at least half (median 100%).

| Gene | IL-33 effect, HUVEC 6 h (log2) | Delivered P | Standard error implied by the table | Empirical standard error | Effect ÷ empirical error |
|---|---|---|---|---|---|
| SELE (E-selectin) | +11.2 | 0.21 | 8.9 | 0.61 | 18 |
| VCAM1 | +8.7 | 0.22 | 7.1 | 0.35 | 25 |
| CXCL8 (IL-8) | +8.2 | 0.047 | 4.1 | 0.24 | 35 |
| CXCL1 | +8.2 | 0.99 | 1,155 | 0.21 | 39 |
| ICAM1 | +6.0 | 0.001 | 1.7 | 0.14 | 43 |
| CCL2 (MCP-1) | +4.2 | 0.47 | 5.7 | 0.10 | 40 |
| PTX3 | +2.2 | 0.84 | 10.9 | 0.08 | 26 |
| IL1RL1 (ST2) | +1.6 | 0.85 | 8.3 | 0.09 | 18 |

- **HGMEC has no vehicle arm and no IL-33-vs-control contrast,** so its IL-33 response is inferred from what AX-1177 removes.
- **The serum table is incomplete and partly hidden.** 100 tested assays are missing (four of them outcome-associated) and there is no IL-33 row, two duplicate rows and the lower confidence limit column are hidden, and two columns are undefined. Those columns imply 56 patients without and 44 with the endpoint.
- **The lung workbook hides the IL-33 and eosinophil columns,** codes scores above the stated 0–5 scale, and carries category labels that the autopsy text does not always match (9 of 31 donors). Every control has lung disease; there is no normal lung.
- **I worked from summary tables only.** Raw counts, patient-level protein values and the fitted model were not delivered, so nothing could be re-fitted. The autopsy text classification and the assay-to-gene mapping were done by hand and are recorded in the scripts.

## 9. Files

| File | Contents |
|---|---|
| `AX-1177_portfolio_audit_report.md` / `.html` | This report |
| `figures/fig1`–`fig5` | Figures 1–5 |
| `tables/AX-1177_supporting_tables.xlsx` | Data QC log; biomarker candidates; contrast summary; robust IL-33 signature (538 genes); genes with unreliable statistics; all serum assays joined to RNA-seq; lung donor table and tests |
| `tables/gsea_hallmark.csv`, `tables/hallmark_median_log2FC.csv` | Gene-set enrichment and median effect sizes for the main contrasts |
| `tables/key_numbers.json` | The numbers quoted here (gene-set values are in `gsea_hallmark.csv`) |
| `scripts/` | `analysis_pipeline.py`, `make_figures.py`, `gsea_hallmark.R`, `olink_map.py` |
