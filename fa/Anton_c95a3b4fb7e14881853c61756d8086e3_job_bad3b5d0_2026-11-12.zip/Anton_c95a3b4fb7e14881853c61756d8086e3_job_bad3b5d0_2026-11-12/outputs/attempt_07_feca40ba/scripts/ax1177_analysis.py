#!/usr/bin/env python
"""
AX-1177 portfolio audit - reproducible analysis.

Reads the five delivered files, runs every analysis quoted in the recommendation memo and
writes tables to <out>/tables plus a cache (pickles, default <tmp>/ax1177_cache) used by ax1177_figures.py.
Gene sets (optional, for the Hallmark / Reactome statistics) are read from ./genesets - see export_genesets.R.

Usage:  python ax1177_analysis.py --data /tmp/world/filesystem --out /tmp/outputs
Needs:  pandas, numpy, scipy, statsmodels, openpyxl   (env used: `mm singlecell python ...`)
"""
import argparse, json, os, re, tempfile, warnings
import numpy as np, pandas as pd, openpyxl
from scipy import stats
from statsmodels.stats.multitest import multipletests
import statsmodels.formula.api as smf
warnings.filterwarnings('ignore')

ap = argparse.ArgumentParser()
ap.add_argument('--data', default='/tmp/world/filesystem'); ap.add_argument('--out', default='/tmp/outputs')
ap.add_argument('--cache', default=None); ap.add_argument('--genesets', default=None, help='optional dir with MSigDB tsv exports (H.tsv etc.) for enrichment')
args = ap.parse_args()
DATA, OUT = args.data, args.out
CACHE = args.cache or os.path.join(tempfile.gettempdir(), 'ax1177_cache'); TAB = os.path.join(OUT, 'tables')
os.makedirs(CACHE, exist_ok=True); os.makedirs(TAB, exist_ok=True)
KEY = {}          # key numbers quoted in the memo
ISSUES = []       # data-integrity log
def issue(dataset, what, consequence, handling): ISSUES.append(dict(dataset=dataset, issue=what, consequence=consequence, handling=handling))
rng = np.random.default_rng(0)

# =====================================================================================================
# 1. LOAD
# =====================================================================================================
def read_sheet(path, sheet):
    wb = openpyxl.load_workbook(path, read_only=True); ws = wb[sheet]
    it = ws.iter_rows(values_only=True); hdr = list(next(it)); rows = [r for r in it]
    return pd.DataFrame(rows, columns=hdr)
def fix_entrez(e):
    if e is None: return None
    try:
        if isinstance(e, float) and np.isnan(e): return None
        return str(int(float(e)))
    except Exception: return str(e)

raw_cache = os.path.join(CACHE, 'rnaseq_long.pkl')
if os.path.exists(raw_cache):
    allc = pd.read_pickle(raw_cache); meta = json.load(open(os.path.join(CACHE, 'rnaseq_meta.json')))
else:
    f_con = os.path.join(DATA, 'AX-1177_rnaseq_contrasts.xlsx'); f_huv = os.path.join(DATA, 'AX-1177_rnaseq_huvec_il33.xlsx')
    s6 = read_sheet(f_con, '6h'); s24 = read_sheet(f_con, '24h')
    n_blank = int(s6.Comparison.isna().sum()); s6 = s6.dropna(subset=['Comparison'])
    # the two sheets are the same 24 contrasts: verify value identity
    a = s6.set_index(['Comparison', 'ensembl']).sort_index(); b = s24.set_index(['Comparison', 'ensembl']).sort_index()
    same = bool(a.index.equals(b.index) and np.allclose(a[['logFC', 't', 'P.Value', 'adj.P.Val']].values, b[['logFC', 't', 'P.Value', 'adj.P.Val']].values))
    h6 = read_sheet(f_huv, 'IL33_vs_Vehicle_HUVEC_6_hrs'); h24 = read_sheet(f_huv, 'IL33_vs_Vehicle_HUVEC_24_hrs')
    # active Excel filters: which contrast is actually visible on each sheet when the workbook is opened?
    import zipfile
    def sheet_filter(path, member):
        zf = zipfile.ZipFile(path); n_hidden = 0; tail = b''
        with zf.open(member) as fh:
            while True:
                chunk = fh.read(1 << 24)
                if not chunk: break
                n_hidden += (tail[-12:] + chunk).count(b'hidden="1"') - tail[-12:].count(b'hidden="1"'); tail = (tail + chunk)[-20000:]
        mm_ = re.search(rb'<autoFilter.*?</autoFilter>', tail, flags=re.S)
        vals = re.findall(rb'<filter val="([^"]+)"', mm_.group(0)) if mm_ else []
        return dict(hidden_rows=int(n_hidden), filter_values=[v.decode() for v in vals])
    filt = {'6h': sheet_filter(f_con, 'xl/worksheets/sheet1.xml'), '24h': sheet_filter(f_con, 'xl/worksheets/sheet2.xml')}
    meta = dict(sheet6h_rows=int(len(s6)), sheet24h_rows=int(len(s24)), sheet6h_blank_rows=n_blank, sheets_identical=same,
                sheet6h_comparisons=sorted(s6.Comparison.unique()), huvec_labels=[h6.Comparison.iloc[0], h24.Comparison.iloc[0]], excel_filters=filt)
    allc = pd.concat([s24, h6, h24], ignore_index=True)
    allc['entrez'] = allc.entrez.map(fix_entrez)
    for c in ['logFC', 'AveExpr', 't', 'P.Value', 'adj.P.Val', 'B']: allc[c] = allc[c].astype(float)
    allc.to_pickle(raw_cache); json.dump(meta, open(os.path.join(CACHE, 'rnaseq_meta.json'), 'w'))
KEY['rnaseq_meta'] = meta
issue('RNA-seq contrasts workbook', f"Sheets named '6h' and '24h' are the same 24-contrast table (values identical = {meta['sheets_identical']}) with different Excel filters switched on: '6h' displays only {', '.join(meta['excel_filters']['6h']['filter_values'])} and '24h' only {', '.join(meta['excel_filters']['24h']['filter_values'])}; {meta['excel_filters']['6h']['hidden_rows']:,} rows (23 of 24 contrasts) are filtered out of view on each sheet, and 22 contrasts - every HGMEC, antibody-alone, epithelial and IL-33-alone-comparator contrast - are visible on neither. The '6h' sheet is also padded with {meta['sheet6h_blank_rows']:,} empty rows to Excel's row limit.",
      'Opened in Excel, the workbook shows only the two HUVEC neutralisation contrasts - the other 22 are present but invisible. Read by script, every contrast comes back twice; stacking the sheets double-counts every gene.', 'Filters ignored; one copy used (24 contrasts x 26,210 genes); timepoint taken from the Comparison label.')
issue('RNA-seq HUVEC workbook', "Sheet names say 'IL33_vs_Vehicle_HUVEC_...' but the Comparison column says 'IL33_vs_Nontreated_HUVEC_...'; the annex lists a 'Vehicle' arm only.",
      'Comparator identity (vehicle vs untreated) is ambiguous.', "Treated as IL-33 vs the HUVEC 'Vehicle' arm; to be confirmed with the lab.")

short = {
 'IL33_vs_Nontreated_HUVEC_6_hrs': 'HUVEC_IL33_6h', 'IL33_vs_Nontreated_HUVEC_24_hrs': 'HUVEC_IL33_24h',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs': 'HUVEC_N_6h', 'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs': 'HUVEC_N_24h',
 'Compound_47_IL33_vs_IL33_HUVEC_6hrs': 'HUVEC_M_6h', 'Compound_47_IL33_vs_IL33_HUVEC_24hrs': 'HUVEC_M_24h',
 'Compound_47_vs_IC119_HUVEC_6hrs': 'HUVEC_A_6h', 'Compound_47_vs_IC119_HUVEC_24hrs': 'HUVEC_A_24h',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs': 'HGMEC_N_6h', 'Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs': 'HGMEC_N_24h',
 'Compound_47_IL33_vs_IL33_HGMEC_6hrs': 'HGMEC_M_6h', 'Compound_47_IL33_vs_IL33_HGMEC_24hrs': 'HGMEC_M_24h',
 'Compound_47_vs_IC119_HGMEC_6hrs': 'HGMEC_A_6h', 'Compound_47_vs_IC119_HGMEC_24hrs': 'HGMEC_A_24h',
 'Compound_47_vs_IC119_A549_6hrs': 'A549_A_6h', 'Compound_47_vs_IC119_A549_24hrs': 'A549_A_24h',
 'Compound_47_vs_IC119_MCF7_6hrs': 'MCF7_A_6h', 'Compound_47_vs_IC119_MCF7_24hrs': 'MCF7_A_24h',
 'Compound_47_vs_PBS_A549_6hrs': 'A549_P_6h', 'Compound_47_vs_PBS_A549_24hrs': 'A549_P_24h',
 'Compound_47_vs_PBS_MCF7_6hrs': 'MCF7_P_6h', 'Compound_47_vs_PBS_MCF7_24hrs': 'MCF7_P_24h',
 'Compound_47_vs_DMSO_A549_6hrs': 'A549_D_6h', 'Compound_47_vs_DMSO_A549_24hrs': 'A549_D_24h',
 'Compound_47_vs_DMSO_MCF7_6hrs': 'MCF7_D_6h', 'Compound_47_vs_DMSO_MCF7_24hrs': 'MCF7_D_24h'}
# N = IL33+AX-1177 vs IL33+isotype (primary neutralisation contrast; shares no arm with IL33-vs-vehicle)
# M = IL33+AX-1177 vs IL33 alone ; A = AX-1177 alone vs isotype ; P / D = AX-1177 alone vs PBS / DMSO
allc['SE'] = allc.logFC / allc.t
L = allc.pivot(index='ensembl', columns='Comparison', values='logFC').rename(columns=short)
Q = allc.pivot(index='ensembl', columns='Comparison', values='adj.P.Val').rename(columns=short)
P = allc.pivot(index='ensembl', columns='Comparison', values='P.Value').rename(columns=short)
S = allc.pivot(index='ensembl', columns='Comparison', values='SE').rename(columns=short)
T = allc.pivot(index='ensembl', columns='Comparison', values='t').rename(columns=short)
ann = allc.drop_duplicates('ensembl').set_index('ensembl')[['symbol', 'entrez', 'gene_name', 'AveExpr']].reindex(L.index)
KEY['n_genes'] = int(len(L)); KEY['n_contrasts'] = int(L.shape[1])

# ---- implied degrees of freedom (checks the 'single pooled model' statement in the annex)
samp = allc[(allc['P.Value'] > 1e-12) & (allc['P.Value'] < 0.5) & (allc.t.abs() > 2)].sample(400, random_state=1)
from scipy import optimize
def implied_df(t, p):
    try: return optimize.brentq(lambda df: np.log(2 * stats.t.sf(abs(t), df)) - np.log(p), 1, 5000)
    except Exception: return np.nan
dfs = pd.Series([implied_df(t, p) for t, p in zip(samp.t, samp['P.Value'])]).dropna()
KEY['implied_total_df_mode'] = float(dfs.round(1).mode().iloc[0])   # 76 residual df (114 libraries - 38 groups) + prior df

# =====================================================================================================
# 2. RNA-seq: noise model, variance artefact, signatures
# =====================================================================================================
nullc = ['HUVEC_A_6h', 'HUVEC_A_24h', 'HGMEC_A_6h', 'HGMEC_A_24h']       # antibody alone vs isotype in endothelium = true nulls
ann['endo_null_rms'] = np.sqrt((L[nullc] ** 2).mean(axis=1))             # empirical per-gene noise of a 3-vs-3 endothelial contrast (4 df)
o = ann.AveExpr.sort_values().index
ann['SE_HUVEC'] = S['HUVEC_IL33_6h']
ann['SE_trend'] = S.loc[o, 'HUVEC_IL33_6h'].rolling(501, center=True, min_periods=50).median().reindex(ann.index)
ann['SE_ratio'] = ann.SE_HUVEC / ann.SE_trend
ann['var_inflated'] = ann.SE_ratio > 4
ok = ~ann.var_inflated
KEY['n_var_inflated'] = int(ann.var_inflated.sum())
KEY['null_rms_vs_modelSE_median_ratio_noninflated'] = float((ann.endo_null_rms / ann.SE_HUVEC)[ok].median())
KEY['SE_examples'] = {g: dict(model_SE=float(ann.SE_HUVEC[ann.symbol == g].iloc[0]), empirical_noise=float(ann.endo_null_rms[ann.symbol == g].iloc[0]))
                      for g in ['CXCL1', 'SELE', 'VCAM1', 'CXCL8', 'ICAM1', 'CCL2', 'IL1RL1', 'CD93', 'CDH5', 'GAPDH']}
issue('RNA-seq statistics', f"All contrasts come from ONE linear model over 114 libraries / 4 cell types (implied total df = {KEY['implied_total_df_mode']}: 76 residual + prior). {KEY['n_var_inflated']} genes have model SEs >=4x the expression trend (e.g. CXCL1 SE = {KEY['SE_examples']['CXCL1']['model_SE']:.0f} log2 units vs empirical noise {KEY['SE_examples']['CXCL1']['empirical_noise']:.2f}); a few highly expressed genes have deflated SEs.",
      'Model t / P / adj.P are unusable for these genes, which include SELE, VCAM1, ICAM1, CXCL1, CXCL8, CCL2, PTX3, IL1RL1. An adj.P filter silently drops the canonical endothelial-activation genes; tiny effects on abundant genes can look significant.',
      'Effect sizes (logFC) retained; significance for flagged genes assessed against an empirical noise estimate from the four antibody-alone endothelial contrasts; all signature calls require replication in an arm-independent contrast. Refit per cell line from archived counts recommended.')

T4 = stats.t.ppf(1 - 0.0005, 4)     # two-sided p<0.001 on 4 df for the empirical-noise rescue
sets = {}
for tp in ('6h', '24h'):
    I, N, M = L[f'HUVEC_IL33_{tp}'], L[f'HUVEC_N_{tp}'], L[f'HUVEC_M_{tp}']; qI, qN = Q[f'HUVEC_IL33_{tp}'], Q[f'HUVEC_N_{tp}']
    zI, zN = I / ann.endo_null_rms, N / ann.endo_null_rms
    model_up = (qI < 0.05) & (I > 1); model_dn = (qI < 0.05) & (I < -1)
    cv_up = model_up & (qN < 0.05) & (N < -1); cv_dn = model_dn & (qN < 0.05) & (N > 1)
    resc_up = ann.var_inflated & (I > 2) & (zI > T4) & (N < -2) & (zN < -T4) & ~cv_up
    resc_dn = ann.var_inflated & (I < -2) & (zI < -T4) & (N > 2) & (zN > T4) & ~cv_dn
    sets[tp] = dict(model_up=model_up, model_dn=model_dn, cv_up=cv_up, cv_dn=cv_dn, resc_up=resc_up, resc_dn=resc_dn, core_up=cv_up | resc_up, core_dn=cv_dn | resc_dn)
    same_dir = int(((qI < 0.05) & (I > 1) & (qN < 0.05) & (N > 1)).sum() + ((qI < 0.05) & (I < -1) & (qN < 0.05) & (N < -1)).sum())
    KEY[f'HUVEC_{tp}'] = dict(n_adjP05=int((qI < 0.05).sum()), model_up=int(model_up.sum()), model_dn=int(model_dn.sum()), cv_up=int(cv_up.sum()), cv_dn=int(cv_dn.sum()),
                              rescued_up=sorted(ann.symbol[resc_up]), rescued_dn=sorted(ann.symbol[resc_dn]), core_up=int((cv_up | resc_up).sum()), core_dn=int((cv_dn | resc_dn).sum()),
                              same_direction_false_positive_proxy=same_dir)
    # why the non-replicated DEGs are not trusted: they are not seen in the IL33+isotype arm either
    il33_iso = I + M - N; resid = I + M
    for nm, s in [('cv_up', cv_up), ('noncv_up', model_up & ~cv_up), ('cv_dn', cv_dn), ('noncv_dn', model_dn & ~cv_dn)]:
        KEY[f'HUVEC_{tp}'][nm + '_medians'] = dict(IL33_vs_veh=float(I[s].median()), IL33plusIso_vs_veh=float(il33_iso[s].median()), IL33plusAX_vs_veh=float(resid[s].median()),
                                                   AveExpr=float(ann.AveExpr[s].median()), frac_no_entrez=float(ann.entrez[s].isna().mean()))
    # neutralisation, estimated on genes selected on the IL-33 effect ONLY (no selection on the AX-1177 contrast)
    for thr in (3, 4):
        sel = ((qI < 0.05) | (ann.var_inflated & (zI > T4))) & (I > thr)
        rev = (-100 * N[sel] / I[sel]).values; rs = resid[sel].values
        bm = lambda x: [float(v) for v in np.percentile([np.median(rng.choice(x, len(x))) for _ in range(5000)], [2.5, 97.5])]
        KEY[f'HUVEC_{tp}'][f'neutralisation_ge{2**thr}fold'] = dict(n=int(sel.sum()), median_pct_reversed=float(np.median(rev)), ci95=bm(rev), iqr=[float(np.percentile(rev, 25)), float(np.percentile(rev, 75))],
                                                                   median_residual_vs_vehicle_log2=float(np.median(rs)), residual_ci95=bm(rs), n_lt50pct=int((rev < 50).sum()))
pd.to_pickle(sets, os.path.join(CACHE, 'sigsets.pkl'))
issue('RNA-seq DEG lists', f"IL-33 vs vehicle in HUVEC gives {KEY['HUVEC_6h']['n_adjP05']:,} (6 h) and {KEY['HUVEC_24h']['n_adjP05']:,} (24 h) genes at adj.P<0.05, but of the {KEY['HUVEC_6h']['model_up']+KEY['HUVEC_6h']['model_dn']:,} with |log2FC|>1 at 6 h only {KEY['HUVEC_6h']['cv_up']+KEY['HUVEC_6h']['cv_dn']} replicate (opposite sign, adj.P<0.05) in the arm-independent AX-1177 contrast; 'repressed' genes replicate worst ({KEY['HUVEC_6h']['cv_dn']}/{KEY['HUVEC_6h']['model_dn']}).",
      'Non-replicating genes are low-count transcripts that are off in the IL-33-alone (and partly vehicle) arm only; contrasts sharing that arm mirror its noise.', 'Working signature = replicated genes + rescued variance-artefact genes.')

# ---- HGMEC (no vehicle arm, no IL-33-vs-control contrast delivered): AX-1177-sensitive component only
hg = {}
for tp in ('6h', '24h'):
    n, m, qn, qm = L[f'HGMEC_N_{tp}'], L[f'HGMEC_M_{tp}'], Q[f'HGMEC_N_{tp}'], Q[f'HGMEC_M_{tp}']
    dn = (qn < 0.05) & (n < -1) & (qm < 0.05) & (m < -1)
    dn_resc = ann.var_inflated & (n < -2) & (m < -2) & ((n / ann.endo_null_rms) < -T4) & ~dn
    hg[tp] = dict(dn=dn, supported=dn | dn_resc)
    hu = sets[tp]['core_up']
    KEY[f'HGMEC_{tp}'] = dict(n_N_adjP05=int((qn < 0.05).sum()), n_M_adjP05=int((qm < 0.05).sum()), suppressed_N_and_M=int(dn.sum()), suppressed_incl_rescued=int((dn | dn_resc).sum()),
                              shared_with_HUVEC_core=int((dn & hu).sum()), shared_incl_rescued=int(((dn | dn_resc) & hu).sum()))
pd.to_pickle(hg, os.path.join(CACHE, 'hgmec_sets.pkl'))
c6 = sets['6h']['core_up']; strong = c6 & (L.HUVEC_IL33_6h > 3)
KEY['HGMEC_vs_HUVEC_amplitude_6h_strong'] = float(L.HGMEC_N_6h[strong].sum() / L.HUVEC_N_6h[strong].sum())
KEY['kinetics'] = dict(HUVEC_24h_over_6h_sum_ratio=float(L.HUVEC_IL33_24h[c6].sum() / L.HUVEC_IL33_6h[c6].sum()), HUVEC_median_retention=float((L.HUVEC_IL33_24h[c6] / L.HUVEC_IL33_6h[c6]).median()),
                       HUVEC_6h_core_still_in_24h_core=float(sets['24h']['core_up'][c6].mean()),
                       HGMEC_24h_over_6h_sum_ratio=float(L.HGMEC_N_24h[c6].sum() / L.HGMEC_N_6h[c6].sum()),      # on the HUVEC-defined signature: no selection on HGMEC noise
                       HGMEC_24h_over_6h_sum_ratio_on_HGMEC_selected_set=float(L.HGMEC_N_24h[hg['6h']['supported']].sum() / L.HGMEC_N_6h[hg['6h']['supported']].sum()),
                       HGMEC_over_HUVEC_6h_amplitude_on_HUVEC_signature=float(L.HGMEC_N_6h[c6].sum() / L.HUVEC_N_6h[c6].sum()))
KEY['HGMEC_HUVEC_overlap_hypergeom_p'] = float(stats.hypergeom.sf(int((hg['6h']['supported'] & c6).sum()) - 1, len(L), int(c6.sum()), int(hg['6h']['supported'].sum())))
issue('RNA-seq design', 'HGMEC has no vehicle arm and no IL-33-vs-control contrast was delivered; IL-33 arms exist only in endothelial lines; A549/MCF7 received antibody or vehicles only (no IL-33); a DMSO arm is present although no test article is described as DMSO-formulated.',
      'IL-33 response in HGMEC can only be inferred as the AX-1177-sensitive component; nothing in the package tests IL-33 biology or AX-1177 efficacy in an epithelial or lung cell.', 'HGMEC reported as AX-1177-sensitive component; epithelial lines used only as off-target controls.')
issue('RNA-seq design', "n = 3 'biological replicates' per arm come from a single donor per endothelial line (HUVEC P2, HGMEC P5); one antibody concentration (10 ug/mL ~ 68 nM vs 1.66 nM IL-33, ~41-fold molar excess); antibody added together with IL-33; reduced IL-33 only; two timepoints.",
      'No donor-to-donor generalisation, no potency (IC50/IC90), no therapeutic (delayed) dosing, no test of the oxidised-IL-33 claim, peak time unknown.', 'Stated as limits; addressed in the next-study plan.')

# ---- antibody alone (16 contrasts, 4 cell types)
alone = ['HUVEC_A_6h', 'HUVEC_A_24h', 'HGMEC_A_6h', 'HGMEC_A_24h', 'A549_A_6h', 'A549_A_24h', 'MCF7_A_6h', 'MCF7_A_24h', 'A549_P_6h', 'A549_P_24h', 'MCF7_P_6h', 'MCF7_P_24h', 'A549_D_6h', 'A549_D_24h', 'MCF7_D_6h', 'MCF7_D_24h']
sig = Q[alone] < 0.05
rep = {}
for line in ['HUVEC', 'HGMEC', 'A549', 'MCF7']:
    for comp in (['A'] if line in ('HUVEC', 'HGMEC') else ['A', 'P', 'D']):
        a, b = f'{line}_{comp}_6h', f'{line}_{comp}_24h'
        both = sig[a] & sig[b] & (np.sign(L[a]) == np.sign(L[b])); rep[f'{line}_{comp}'] = sorted(ann.symbol[both])
hi = ann.AveExpr > 2
KEY['antibody_alone'] = dict(n_sig_per_contrast={c: int(sig[c].sum()) for c in alone}, total_calls=int(sig.values.sum()), total_tests=int(sig.size), reproduced_both_timepoints=rep,
                             median_AveExpr_of_calls=float(np.median([ann.AveExpr[sig[c]].median() for c in alone])),
                             slope_vs_IL33_signature_6h=float(np.polyfit(L.HUVEC_IL33_6h[c6], L.HUVEC_A_6h[c6], 1)[0]),
                             slope_vs_IL33_signature_24h=float(np.polyfit(L.HUVEC_IL33_24h[sets['24h']['core_up']], L.HUVEC_A_24h[sets['24h']['core_up']], 1)[0]),
                             r_6h_vs_24h_wellexpressed={ln: float(np.corrcoef(L.loc[hi, f'{ln}_A_6h'], L.loc[hi, f'{ln}_A_24h'])[0, 1]) for ln in ['HUVEC', 'HGMEC', 'A549', 'MCF7']},
                             reference_r_IL33_6h_vs_24h=float(np.corrcoef(L.loc[hi, 'HUVEC_IL33_6h'], L.loc[hi, 'HUVEC_IL33_24h'])[0, 1]))
# ---- anything AX-1177 does in the presence of IL-33 beyond reversal? (ends away from vehicle, both comparators)
beyond = {}
for tp in ('6h', '24h'):
    I, N, M = L[f'HUVEC_IL33_{tp}'], L[f'HUVEC_N_{tp}'], L[f'HUVEC_M_{tp}']; resid = I + M; z = resid / ann.endo_null_rms
    for sgn, nm in [(1, 'above'), (-1, 'below')]:
        beyond[(tp, nm)] = (Q[f'HUVEC_N_{tp}'] < 0.05) & (Q[f'HUVEC_M_{tp}'] < 0.05) & (sgn * N > 1) & (sgn * M > 1) & (sgn * resid > 1) & (sgn * z > 5) & ok
KEY['beyond_reversal'] = {f'{tp}_{nm}': int(v.sum()) for (tp, nm), v in beyond.items()}
KEY['beyond_reversal']['replicated_6h_and_24h'] = int((beyond[('6h', 'above')] & beyond[('24h', 'above')]).sum() + (beyond[('6h', 'below')] & beyond[('24h', 'below')]).sum())
# ---- any IL-33-preparation effect that AX-1177 does NOT remove? genes up (or down) vs vehicle in ALL three IL-33-containing arms
ins = {}
for tp in ('6h', '24h'):
    I, N, M = L[f'HUVEC_IL33_{tp}'], L[f'HUVEC_N_{tp}'], L[f'HUVEC_M_{tp}']; resid = I + M; il33_iso = I + M - N; z = lambda x: x / ann.endo_null_rms
    up = (I > 1) & (resid > 1) & (il33_iso > 1) & (z(I) > 4) & (z(resid) > 4) & (z(il33_iso) > 4)
    dn = (I < -1) & (resid < -1) & (il33_iso < -1) & (z(I) < -4) & (z(resid) < -4) & (z(il33_iso) < -4)
    ins[tp] = dict(up_in_all_three_IL33_arms=int(up.sum()), down_in_all_three=int(dn.sum()))
KEY['antibody_insensitive_check'] = ins      # symmetric counts = vehicle-arm noise, not an antibody-insensitive IL-33 effect
# ---- intensity-dependent offsets between arms (technical): median logFC of abundant genes (AveExpr>8) minus moderately expressed genes (AveExpr 2-4)
hi_ab = (ann.AveExpr > 8) & ok; lo_ab = (ann.AveExpr > 2) & (ann.AveExpr <= 4) & ok
KEY['intensity_offset_log2'] = {c: float(L.loc[hi_ab, c].median() - L.loc[lo_ab, c].median()) for c in L.columns}
KEY['intensity_offset_n_genes'] = dict(abundant=int(hi_ab.sum()), moderate=int(lo_ab.sum()))
io = KEY['intensity_offset_log2']
issue('RNA-seq statistics', "Arm-level, expression-dependent offsets at 24 h: abundant genes (AveExpr>8) sit {:+.2f} log2 (HUVEC) and {:+.2f} (HGMEC) away from moderately expressed genes in the antibody-alone contrasts at 24 h ({:+.2f} / {:+.2f} at 6 h), {:+.2f} in HGMEC IL-33+AX-1177 vs IL-33+isotype and {:+.2f} vs IL-33 alone. Every Hallmark set moves together with the offset.".format(
          io['HUVEC_A_24h'], io['HGMEC_A_24h'], io['HUVEC_A_6h'], io['HGMEC_A_6h'], io['HGMEC_N_24h'], io['HGMEC_M_24h']),
      "Small coordinated shifts of abundant transcripts (ribosomal, MYC/E2F targets, OXPHOS) reach FDR significance (e.g. 1,032 genes in HGMEC 24 h vs IL-33 alone) and can be misread as a proliferation effect of AX-1177. Opposite sign in the two endothelial lines and presence without IL-33 mark it as technical.",
      'No conclusion drawn from effects < 1 log2; signature requires |log2FC| > 1. Refit with per-cell-line normalisation recommended; add a direct proliferation read-out next time.')
# ---- HGMEC 24 h: IL33-alone arm offset (M vs N)
KEY['HGMEC_24h_M_vs_N'] = dict(n_M_adjP05=int((Q.HGMEC_M_24h < 0.05).sum()), n_N_adjP05=int((Q.HGMEC_N_24h < 0.05).sum()))

# ---- master gene table
d = pd.DataFrame({'symbol': ann.symbol, 'entrez': ann.entrez, 'gene_name': ann.gene_name, 'AveExpr': ann.AveExpr,
    'HUVEC_IL33_6h': L.HUVEC_IL33_6h, 'HUVEC_IL33_6h_adjP': Q.HUVEC_IL33_6h, 'HUVEC_AX1177_rev_6h': L.HUVEC_N_6h, 'HUVEC_rev_6h_adjP': Q.HUVEC_N_6h,
    'HUVEC_IL33_24h': L.HUVEC_IL33_24h, 'HUVEC_IL33_24h_adjP': Q.HUVEC_IL33_24h, 'HUVEC_AX1177_rev_24h': L.HUVEC_N_24h, 'HUVEC_rev_24h_adjP': Q.HUVEC_N_24h,
    'HUVEC_AX1177_vs_IL33alone_6h': L.HUVEC_M_6h, 'HUVEC_AX1177_vs_IL33alone_24h': L.HUVEC_M_24h,
    'HGMEC_AX1177_rev_6h': L.HGMEC_N_6h, 'HGMEC_rev_6h_adjP': Q.HGMEC_N_6h, 'HGMEC_AX1177_rev_24h': L.HGMEC_N_24h, 'HGMEC_rev_24h_adjP': Q.HGMEC_N_24h,
    'HUVEC_Ab_alone_6h': L.HUVEC_A_6h, 'HUVEC_Ab_alone_24h': L.HUVEC_A_24h, 'HGMEC_Ab_alone_6h': L.HGMEC_A_6h, 'HGMEC_Ab_alone_24h': L.HGMEC_A_24h,
    'resid_vs_vehicle_6h': L.HUVEC_IL33_6h + L.HUVEC_M_6h, 'resid_vs_vehicle_24h': L.HUVEC_IL33_24h + L.HUVEC_M_24h,
    'empirical_noise_rms': ann.endo_null_rms, 'model_SE': ann.SE_HUVEC, 'SE_inflation_ratio': ann.SE_ratio, 'model_p_unreliable': ann.var_inflated,
    'core_6h': sets['6h']['core_up'], 'core_24h': sets['24h']['core_up'], 'core_down_6h': sets['6h']['core_dn'], 'core_down_24h': sets['24h']['core_dn'], 'HGMEC_supported_6h': hg['6h']['supported'], 'HGMEC_supported_24h': hg['24h']['supported']})
d['pct_rev_6h'] = -100 * d.HUVEC_AX1177_rev_6h / d.HUVEC_IL33_6h; d['pct_rev_24h'] = -100 * d.HUVEC_AX1177_rev_24h / d.HUVEC_IL33_24h
d['empirical_z_IL33_6h'] = d.HUVEC_IL33_6h / d.empirical_noise_rms
d['pan_endothelial_durable'] = d.core_6h & d.core_24h & d.HGMEC_supported_6h
KEY['signature_sizes'] = dict(core6=int(d.core_6h.sum()), core24=int(d.core_24h.sum()), core6_and_24=int((d.core_6h & d.core_24h).sum()), core6_and_HGMEC=int((d.core_6h & d.HGMEC_supported_6h).sum()), pan=int(d.pan_endothelial_durable.sum()))

# ---- hallmark enrichment of the core signature (optional: needs MSigDB export)
gsdir = args.genesets or os.path.join(os.path.dirname(os.path.abspath(__file__)), 'genesets')
if os.path.exists(os.path.join(gsdir, 'H.tsv')):
    g = pd.read_csv(os.path.join(gsdir, 'H.tsv'), sep='\t'); H = g.groupby('gs_name').ensembl_gene.apply(set).to_dict(); universe = set().union(*H.values()) & set(d.index)
    rows = []
    for tp in ('6h', '24h'):
        sel = set(d.index[d[f'core_{tp}']]) & universe
        for name, gs in H.items():
            g2 = gs & universe; k = len(g2 & sel)
            if k >= 3: rows.append((tp, name, len(g2), k, (k / len(sel)) / (len(g2) / len(universe)), stats.hypergeom.sf(k - 1, len(universe), len(g2), len(sel))))
    E = pd.DataFrame(rows, columns=['timepoint', 'hallmark', 'set_size', 'n_in_signature', 'fold_enrichment', 'p_hypergeom']).sort_values(['timepoint', 'p_hypergeom'])
    E.to_csv(os.path.join(TAB, 'rnaseq_signature_hallmark_enrichment.csv'), index=False)
    top = E[E.timepoint == '6h'].iloc[0]; KEY['hallmark_top_6h'] = dict(set=top.hallmark, k=int(top.n_in_signature), size=int(top.set_size), fold=float(top.fold_enrichment), p=float(top.p_hypergeom))
    # neutralisation by module at 24 h
    mod = {}
    for s in ['HALLMARK_TNFA_SIGNALING_VIA_NFKB', 'HALLMARK_INTERFERON_ALPHA_RESPONSE']:
        for tp in ('6h', '24h'):
            I, N, M = L[f'HUVEC_IL33_{tp}'], L[f'HUVEC_N_{tp}'], L[f'HUVEC_M_{tp}']
            sel = pd.Series(L.index.isin(H[s]), index=L.index) & (Q[f'HUVEC_IL33_{tp}'] < 0.05) & (I > 1)
            mod[f'{s}_{tp}'] = dict(n=int(sel.sum()), median_pct_reversed=float((-100 * N[sel] / I[sel]).median()), median_residual=float((I + M)[sel].median()))
    KEY['module_neutralisation'] = mod
    hiexp = (ann.AveExpr > 2) & ok; uni2 = set(L.index[hiexp]); outm = {}
    for nm, col in [('vs_IL33_alone', 'HGMEC_M_24h'), ('vs_IL33_plus_isotype', 'HGMEC_N_24h')]:
        sel = set(L.index[(Q[col] < 0.05) & (L[col] > 0) & hiexp]); rr = []
        for name, gs in H.items():
            g2 = gs & uni2; k = len(g2 & sel)
            if k >= 3 and len(sel): rr.append((name, k, len(g2), (k / len(sel)) / (len(g2) / len(uni2)), stats.hypergeom.sf(k - 1, len(uni2), len(g2), len(sel))))
        rr = sorted(rr, key=lambda x: x[4])[:3]
        outm[nm] = dict(n_up_wellexpressed=len(sel), top=[dict(set=a, k=b, size=c, fold=float(f), p=float(p)) for a, b, c, f, p in rr])
    KEY['HGMEC_24h_up_with_AX1177_hallmarks'] = outm
    myc = pd.Series(L.index.isin(H['HALLMARK_MYC_TARGETS_V1']), index=L.index) & hiexp; restm = hiexp & ~myc
    KEY['MYC_targets_shift'] = {c: dict(n=int(myc.sum()), median_log2FC=float(L.loc[myc, c].median()), median_rest=float(L.loc[restm, c].median()), ranksum_p=float(stats.mannwhitneyu(L.loc[myc, c], L.loc[restm, c]).pvalue),
                                        n_sig=int((Q.loc[myc, c] < 0.05).sum())) for c in ['HUVEC_A_6h', 'HUVEC_A_24h', 'HGMEC_A_6h', 'HGMEC_A_24h', 'HGMEC_N_24h', 'HGMEC_M_24h', 'A549_A_24h', 'MCF7_A_24h']}

# =====================================================================================================
# 3. SERUM PROTEOMICS
# =====================================================================================================
f_ser = os.path.join(DATA, 'AX-1177_serum_proteomics.xlsx')
ol = pd.read_excel(f_ser); wb = openpyxl.load_workbook(f_ser); ws = wb.worksheets[0]
from openpyxl.utils import get_column_letter
def hidden_columns(ws_):      # openpyxl stores runs of identically formatted columns as one dimension (min..max)
    out = []
    for c, dm in ws_.column_dimensions.items():
        if dm.hidden: out += [get_column_letter(i) for i in range(dm.min, min(dm.max, ws_.max_column) + 1)]
    return out
hidden_rows = [r for r, dm in ws.row_dimensions.items() if dm.hidden]; hidden_cols = hidden_columns(ws)
ol['rank'] = np.arange(1, len(ol) + 1)
ol['panel_s'] = ol.panel.str.replace('Olink Target 96 ', '').str.replace(r'\(v\.\d+\)', '', regex=True)
ol['lnOR'] = np.log(ol.OR); ol['se'] = (np.log(ol.u95) - np.log(ol.l95)) / (2 * 1.959964); ol['z'] = ol.lnOR / ol.se
m_bh = int(round(ol['adj.p.value'].iloc[0] / ol['p.value'].iloc[0]))         # BH denominator actually used (rank-1 row)
g0 = sorted(set(ol.composite_endpoint_0.round(6)) - {0})[0]; g1 = sorted(set(ol.composite_endpoint_1.round(6)) - {0})[0]
KEY['serum'] = dict(n_assays=int(len(ol)), bh_denominator=m_bh, hidden_rows=[ol.assay.iloc[r - 2] for r in hidden_rows], hidden_cols=hidden_cols,
                    n_no_event=int(round(1 / g0)), n_event=int(round(1 / g1)), n_assay_fdr05=int((ol['adj.p.value'] < 0.05).sum()), n_assay_fdr05_ORgt1=int(((ol['adj.p.value'] < 0.05) & (ol.OR > 1)).sum()),
                    wald_p_consistent=bool(np.allclose(2 * stats.norm.sf(ol.z.abs()), ol['p.value'], rtol=1e-3)), il33_delivered=bool(ol.assay.str.upper().str.replace('-', '').str.contains('IL33').any()),
                    inflammation_panel_assays_delivered=int((ol.panel_s == 'Inflammation').sum()))
issue('Serum proteomics', f"{len(ol):,} assays delivered but BH adjustment used m = {m_bh:,}; {m_bh - len(ol)} modelled assays are missing, spread across the p-value range. IL-33 (on the vendor's Inflammation panel, which was run) is not among the {KEY['serum']['inflammation_panel_assays_delivered']} Inflammation assays delivered; neither are IL-4, IL-13, TSLP.",
      'No read-out of the drug target in patients. Delivered adj.p values are slightly conservative relative to re-adjusting the delivered rows.', "Delivered adj.p used as is. Missing assays most plausibly failed a detectability filter (the two undocumented 'composite_endpoint_0/1' columns look like per-group fractions of flagged samples, all <10%) - to be confirmed.")
issue('Serum proteomics', f"Rows {', '.join(map(str, hidden_rows))} (assays {', '.join(KEY['serum']['hidden_rows'])}) and the confidence-limit columns ({', '.join(hidden_cols)}) are hidden in the sheet; 27 proteins are measured on more than one panel under panel-specific names.",
      'Counting assays double-counts proteins (178 assays = 167 proteins at FDR<0.05); hidden rows are duplicate measurements of HGF and IL-6 that agree with the visible ones.', 'De-duplicated to 1,063 unique proteins; duplicates used as a concordance check (r = 0.97).')
issue('Serum proteomics', "Odds ratios are 'per log unit' (base and scale not stated) and not standardised; 176 of 178 significant assays have OR>1; summary statistics only (no patient-level data).",
      'OR magnitudes are not comparable between assays (e.g. M-CSF OR 90, CI 4-1,933); a third of the proteome is nominally associated, so single-marker hits are not specific; no cut-offs, no multivariable or interaction analysis possible.', 'Ranked by z / p; patient-level NPX matrix requested as a next step.')
issue('Serum proteomics', f"Single-centre, pre-vaccination, SARS-CoV-2 only, n = 100 ({KEY['serum']['n_event']} events), one sample at enrolment.", 'Prognostic association only; not validated; no non-COVID comparator.', 'Stated as limits.')

suffixes = ['-ONCII', '-INFI', '-CVDIII', '-CVDII', '-IMO', '-CRE', '-NEUI', '-NEX', '-ODA', '-MET']
def strip(a):
    for s in suffixes:
        if a.endswith(s): return a[:-len(s)]
    return a
ol['assay_base'] = ol.assay.map(strip)
_cnt = ol.groupby('assay_base').size()
KEY['serum']['suffixed_assays_without_delivered_partner'] = sorted(ol.assay[(ol.assay != ol.assay_base) & (ol.assay_base.map(_cnt) == 1)])   # vendor suffixes mark assays present on >1 panel
issue('Serum proteomics', "Internal evidence that run assays were withheld: assay {} carries a duplicate-panel suffix although no sister assay for the same protein is delivered.".format(', '.join(KEY['serum']['suffixed_assays_without_delivered_partner'])),
      'Confirms, from within the file, that the delivery is a filtered subset of what was measured (consistent with the BH denominator of 1,194).', 'Request the full vendor output including detectability (LOD) flags.')
manual = {'ST2': 'IL1RL1', 'MCP-1': 'CCL2', 'MCP-2': 'CCL8', 'MCP-3': 'CCL7', 'MCP-4': 'CCL13', 'OPG': 'TNFRSF11B', 'IL8': 'CXCL8', 'CASP-8': 'CASP8', '4E-BP1': 'EIF4EBP1', 'EN-RAGE': 'S100A12',
 'TRAIL': 'TNFSF10', 'TRANCE': 'TNFSF11', 'TWEAK': 'TNFSF12', 'LAP TGF-beta-1': 'TGFB1', 'uPA': 'PLAU', 'U-PAR': 'PLAUR', 'PAI': 'SERPINE1', 't-PA': 'PLAT', 'TM': 'THBD', 'vWF': 'VWF', 'ESM-1': 'ESM1',
 'SYND1': 'SDC1', 'TIE2': 'TEK', 'CSF-1': 'CSF1', 'G-CSF': 'CSF3', 'GM-CSF-R-alpha': 'CSF2RA', 'IL-18R1': 'IL18R1', 'IL-1RT1': 'IL1R1', 'IL-1RT2': 'IL1R2', 'IL-1ra': 'IL1RN', 'IL-6RA': 'IL6R', 'IL2-RA': 'IL2RA',
 'IL-4RA': 'IL4R', 'IL-5R-alpha': 'IL5RA', 'TNF-R1': 'TNFRSF1A', 'TNF-R2': 'TNFRSF1B', 'TRAIL-R2': 'TNFRSF10B', 'LOX-1': 'OLR1', 'RAGE': 'AGER', 'Gal-9': 'LGALS9', 'Gal-3': 'LGALS3', 'Gal-4': 'LGALS4', 'Gal-1': 'LGALS1', 'gal-8': 'LGALS8',
 'HO-1': 'HMOX1', 'HSP 27': 'HSPB1', 'PSGL-1': 'SELPLG', 'PD-L1': 'CD274', 'PD-L2': 'PDCD1LG2', 'CD40-L': 'CD40LG', 'OPN': 'SPP1', 'PSP-D': 'SFTPD', 'MK': 'MDK', 'KIM1': 'HAVCR1', 'NT-proBNP': 'NPPB', 'AP-N': 'ANPEP',
 'BLM hydrolase': 'BLMH', 'CASP-3': 'CASP3', 'DLK-1': 'DLK1', 'Ep-CAM': 'EPCAM', 'ICAM-2': 'ICAM2', 'IGFBP-1': 'IGFBP1', 'IGFBP-2': 'IGFBP2', 'IGFBP-7': 'IGFBP7', 'IL-17RA': 'IL17RA', 'IL-18BP': 'IL18BP', 'JAM-A': 'F11R',
 'LDL receptor': 'LDLR', 'MMP-2': 'MMP2', 'MMP-3': 'MMP3', 'MMP-9': 'MMP9', 'MMP-1': 'MMP1', 'MMP-10': 'MMP10', 'Notch 3': 'NOTCH3', 'PDGF subunit A': 'PDGFA', 'PDGF subunit B': 'PDGFB', 'PECAM-1': 'PECAM1', 'PLC': 'HSPG2',
 'SHPS-1': 'SIRPA', 'TLT-2': 'TREML2', 'TR': 'TFRC', 'TR-AP': 'ACP5', 'ADAM-TS13': 'ADAMTS13', 'BMP-6': 'BMP6', 'Dkk-1': 'DKK1', 'FS': 'FST', 'GDF-2': 'GDF2', 'GH': 'GH1', 'GIF': 'CBLIF', 'GT': 'FABP6', 'HAOX1': 'HAO1',
 'IL-17D': 'IL17D', 'IL-27': 'IL27', 'IgG Fc receptor II-b': 'FCGR2B', 'NEMO': 'IKBKG', 'PAR-1': 'F2R', 'PARP-1': 'PARP1', 'PIgR': 'PIGR', 'hOSCAR': 'OSCAR', 'SCF': 'KITLG', 'TF': 'F3', 'CTSL1': 'CTSL', 'FGF-21': 'FGF21',
 'FGF-19': 'FGF19', 'FGF-5': 'FGF5', 'Flt3L': 'FLT3LG', 'IFN-gamma': 'IFNG', 'IL-10RA': 'IL10RA', 'IL-10RB': 'IL10RB', 'IL-12B': 'IL12B', 'IL-15RA': 'IL15RA', 'IL-17A': 'IL17A', 'IL-17C': 'IL17C', 'IL-20RA': 'IL20RA',
 'LIF-R': 'LIFR', 'NT-3': 'NTF3', 'ST1A1': 'SULT1A1', 'TGF-alpha': 'TGFA', 'TNFB': 'LTA', 'GDF-15': 'GDF15', 'ADAM 22': 'ADAM22', 'ADAM 23': 'ADAM23', 'Alpha-2-MRAP': 'LRPAP1', 'BMP-4': 'BMP4', 'CLM-1': 'CD300LF', 'CLM-6': 'CD300C',
 'Dkk-4': 'DKK4', 'FcRL2': 'FCRL2', 'GCP5': 'GPC5', 'GDF-8': 'MSTN', 'GDNFR-alpha-3': 'GFRA3', 'GFR-alpha-1': 'GFRA1', 'IL12': 'IL12A', 'JAM-B': 'JAM2', 'LAIR-2': 'LAIR2', 'N-CDase': 'ASAH2', 'N2DL-2': 'ULBP2', 'NEP': 'MME',
 'Nr-CAM': 'NRCAM', 'PDGF-R-alpha': 'PDGFRA', 'SKR3': 'ACVRL1', 'Siglec-9': 'SIGLEC9', 'THY 1': 'THY1', 'TN-R': 'TNR', 'sFRP-3': 'FRZB', "5'-NT": 'NT5E', 'ADAM 8': 'ADAM8', 'ADAM-TS 15': 'ADAMTS15', 'CAIX': 'CA9', 'CXL17': 'CXCL17',
 'CYR61': 'CCN1', 'FGF-BP1': 'FGFBP1', 'FR-alpha': 'FOLR1', 'FR-gamma': 'FOLR3', 'IFN-gamma-R1': 'IFNGR1', 'MAD homolog 5': 'SMAD5', 'MIC-A/B': 'MICA', 'MUC-16': 'MUC16', 'MetAP 2': 'METAP2', 'PVRL4': 'NECTIN4', 'TFPI-2': 'TFPI2',
 'TGFR-2': 'TGFBR2', 'VEGFR-2': 'KDR', 'VEGFR-3': 'FLT4', 'WIF-1': 'WIF1', 'WISP-1': 'CCN4', 'hK11': 'KLK11', 'hK14': 'KLK14', 'hK8': 'KLK8', 'FUT3/FUT5': 'FUT3', 'KIF1BP': 'KIFBP', 'COL4A3BP': 'CERT1', 'MESDC2': 'MESD',
 'NOV': 'CCN3', 'FAM19A5': 'TAFA5', 'LRMP': 'IRAG2', 'ICAM 5': 'ICAM5', 'CD97': 'ADGRE5', 'HB-EGF': 'HBEGF'}
alt = {'CERT1': ['COL4A3BP'], 'KIFBP': ['KIF1BP', 'KIAA1279'], 'IRAG2': ['LRMP'], 'CCN1': ['CYR61'], 'CCN4': ['WISP1'], 'CCN3': ['NOV'], 'CCN5': ['WISP2'], 'TAFA5': ['FAM19A5'], 'MESD': ['MESDC2'], 'ADGRE5': ['CD97'],
       'CBLIF': ['GIF'], 'NECTIN4': ['PVRL4'], 'NECTIN2': ['PVRL2'], 'VEGFD': ['FIGF'], 'MICA': ['MICB']}
syms = set(ann.symbol)
def to_gene(b):
    gname = manual.get(b, b)
    if gname in syms: return gname
    for a in alt.get(gname, []):
        if a in syms: return a
    return gname
ol['gene'] = ol.assay_base.map(to_gene)
sym2ens = d.reset_index().drop_duplicates('symbol').set_index('symbol').ensembl
grp = ol.groupby('gene')
prot = pd.DataFrame({'n_assays': grp.size(), 'assays': grp.assay.apply('; '.join), 'panels': grp.panel_s.apply('; '.join), 'z_mean': grp.z.mean(), 'OR_geomean': np.exp(grp.lnOR.mean()),
                     'p_min': grp['p.value'].min(), 'adjp_min': grp['adj.p.value'].min(), 'adjp_max': grp['adj.p.value'].max()})
prot['ens'] = prot.index.map(lambda s: sym2ens.get(s, None)); prot['in_rnaseq'] = prot.ens.notna()
prot['sig05'] = (prot.adjp_min < 0.05) & (prot.OR_geomean > 1)
for c in ['HUVEC_IL33_6h', 'HUVEC_AX1177_rev_6h', 'HUVEC_IL33_24h', 'HUVEC_AX1177_rev_24h', 'HGMEC_AX1177_rev_6h', 'HGMEC_AX1177_rev_24h', 'model_p_unreliable']: prot[c] = prot.ens.map(d[c])
for c in ['core_6h', 'core_24h', 'pan_endothelial_durable', 'HGMEC_supported_6h']: prot[c] = prot.ens.map(d[c]).fillna(False).astype(bool)
prot['core_up_any'] = prot.core_6h | prot.core_24h
KEY['serum'].update(n_proteins=int(len(prot)), n_dup_proteins=int((prot.n_assays > 1).sum()), n_prot_sig=int(prot.sig05.sum()), n_prot_sig_protective=int(((prot.adjp_min < 0.05) & (prot.OR_geomean < 1)).sum()),
                    n_in_rnaseq=int(prot.in_rnaseq.sum()), frac_ORgt1=float((ol.OR > 1).mean()), n_p05=int((ol['p.value'] < 0.05).sum()))
dup = ol[ol.duplicated('gene', keep=False)]; pairs = []
for g_, s_ in dup.groupby('gene'):
    s_ = s_.sort_values('p.value')
    for i in range(1, len(s_)): pairs.append((s_.lnOR.iloc[0], s_.lnOR.iloc[i]))
KEY['serum']['duplicate_assay_r'] = float(np.corrcoef(np.array(pairs).T)[0, 1])
def one(assay): r = ol[ol.assay == assay].iloc[0]; return dict(OR=float(r.OR), l95=float(r.l95), u95=float(r.u95), p=float(r['p.value']), fdr=float(r['adj.p.value']), rank_among_delivered=int(r['rank']))
KEY['serum']['ST2'] = one('ST2'); KEY['serum']['HGF'] = one('HGF'); KEY['serum']['IL5'] = one('IL5-IMO'); KEY['serum']['IL6_assays'] = {a: one(a) for a in ['IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO']}
KEY['serum']['RAGE'] = one('RAGE'); KEY['serum']['EGFR'] = one('EGFR'); KEY['serum']['VCAM1'] = one('VCAM1'); KEY['serum']['SELE'] = one('SELE'); KEY['serum']['ICAM1'] = one('ICAM1')

axes = {
 'Neutrophil activation / granule': ['MPO', 'PRTN3', 'AZU1', 'LCN2', 'CEACAM8', 'DEFA1', 'PGLYRP1', 'RETN', 'CD177', 'MMP9', 'OSM', 'PI3', 'HGF', 'CXCL8', 'CXCL1', 'CXCL5', 'CXCL6', 'CSF3', 'TREM1', 'FCAR', 'FCGR3B', 'S100P', 'ARG1', 'CLEC5A', 'CHI3L1', 'MMP8', 'NCF2', 'VSTM1', 'LILRA5', 'TNFSF14', 'CLEC4D', 'TGFA', 'ANXA1'],
 'IL-33/ST2 axis & IL-1 family': ['IL1RL1', 'IL1R1', 'IL1R2', 'IL1RL2', 'IL1RN', 'IL18', 'IL18R1', 'IL18BP', 'IL1B', 'IL1RAP', 'IL33', 'AGER', 'EGFR', 'S100A12', 'IRAK1', 'IRAK4'],
 'IL-6 / acute phase / myeloid cytokines': ['IL6', 'IL6R', 'OSM', 'LIFR', 'CSF1', 'CCL2', 'CCL7', 'CCL20', 'CCL8', 'CXCL10', 'CXCL9', 'CXCL11', 'IFNG', 'TNF', 'TNFRSF1A', 'TNFRSF1B', 'IL10', 'IL15', 'IL12B', 'CD274', 'TNFRSF11B', 'PTX3', 'IL2RA', 'LTA', 'CCL3', 'CCL4', 'CCL19', 'IL17A', 'IL17C', 'IL7'],
 'Lung epithelial injury / remodelling': ['AGER', 'SFTPD', 'SFTPA1', 'KRT19', 'SCGB3A2', 'WFDC2', 'MUC16', 'TFF3', 'AREG', 'TGFA', 'MMP7', 'CDH1', 'EPCAM', 'MSLN', 'CEACAM5', 'SPINT1', 'SPINT2', 'PIGR', 'AGR2', 'TACSTD2', 'CXCL17', 'ITGB6', 'KRT18', 'LAMP3', 'CDCP1', 'EGF', 'HBEGF', 'EREG'],
 'Kidney / cardiac / organ injury': ['HAVCR1', 'CST3', 'REN', 'LCN2', 'NPPB', 'TNNI3', 'MB', 'GDF15', 'LGALS3', 'FABP4', 'IGFBP7', 'TFF3', 'FGF23', 'UMOD', 'MMP7', 'AMBP', 'SPP1', 'CA5A', 'FABP2', 'FGF21', 'HAO1', 'ALDH1A1', 'ARG1', 'SOD1', 'CA3', 'CKB'],
 'Endothelial activation / injury / coagulation': ['ANGPT2', 'ANGPT1', 'TEK', 'TIE1', 'SELE', 'SELP', 'VCAM1', 'ICAM1', 'ICAM2', 'PECAM1', 'CDH5', 'VWF', 'THBD', 'ESM1', 'SDC1', 'ADM', 'PLAT', 'SERPINE1', 'PLAUR', 'PLAU', 'EGFL7', 'CD93', 'NOS3', 'FLT1', 'VEGFA', 'KDR', 'FLT4', 'PGF', 'CLEC14A', 'ESAM', 'ENG', 'LYVE1', 'TFPI', 'F2R', 'PROC', 'EPHB4', 'ADAMTS13', 'F3', 'PDGFB', 'ROBO1', 'ACVRL1', 'JAM2', 'F11R', 'OLR1', 'NRP1', 'NRP2', 'PODXL', 'PTX3', 'TFPI2', 'COL18A1', 'NID1', 'LAMA4', 'COL4A1', 'HSPG2', 'GP6', 'GP1BA', 'CD40LG', 'F7', 'F11', 'SERPINA5'],
 'Type-2 / eosinophil / mast cell': ['IL5', 'IL5RA', 'IL4R', 'IL13RA1', 'IL17RB', 'CCL11', 'CCL24', 'CCL26', 'CCL17', 'CCL18', 'CCL13', 'RNASE3', 'TPSAB1', 'FCER2', 'HPGDS', 'MILR1', 'SIGLEC6', 'CLC', 'EPX', 'PRG2', 'POSTN', 'CCL22', 'TSLP', 'IL13', 'IL4', 'CPA3', 'KIT', 'KITLG', 'HNMT', 'SIGLEC10', 'CD69', 'ALOX15'],
}
sigset = set(prot.index[prot.sig05]); rows = []; axmemb = {}
def set_stats(name, genes):
    gset = set(x for x in genes if x in prot.index); k = len(gset & sigset); n = len(gset)
    o_, p_ = stats.fisher_exact([[k, n - k], [len(sigset) - k, len(prot) - len(sigset) - (n - k)]])
    zin = prot.z_mean[list(gset)]; zout = prot.z_mean[~prot.index.isin(gset)]
    return dict(set=name, n_measured=n, n_sig=k, pct_sig=100 * k / n, fisher_OR=o_, fisher_p=p_, median_z=float(zin.median()), median_z_rest=float(zout.median()), ranksum_p=float(stats.mannwhitneyu(zin, zout).pvalue),
                not_delivered=', '.join(sorted(set(genes) - gset)))
for a_, genes in axes.items(): rows.append(set_stats(a_, genes)); axmemb[a_] = [x for x in genes if x in prot.index]
rows.append(set_stats('IL-33-induced & AX-1177-reversed in endothelium (data-derived, HUVEC 6 h or 24 h)', list(prot.index[prot.core_up_any])))
rows.append(set_stats('Pan-endothelial durable signature (HUVEC 6 h + 24 h, HGMEC 6 h)', list(prot.index[prot.pan_endothelial_durable])))
AX = pd.DataFrame(rows); AX.to_csv(os.path.join(TAB, 'serum_axis_summary.csv'), index=False)
KEY['serum']['axes'] = {r['set']: dict(n=r['n_measured'], k=r['n_sig'], pct=r['pct_sig'], fisher_p=r['fisher_p'], median_z=r['median_z'], ranksum_p=r['ranksum_p']) for r in rows}
KEY['serum']['background_pct_sig'] = float(100 * prot.sig05.mean())
rfile = os.path.join(gsdir, 'REACTOME_selected.tsv')
if os.path.exists(rfile):       # independent, public definition of the neutrophil axis (not curated by the analyst)
    rg = pd.read_csv(rfile, sep='\t'); KEY['serum']['public_sets'] = {}
    for name, sub in rg.groupby('gs_name'):
        st = set_stats(name, sorted(set(sub.gene_symbol)))
        hyper = float(stats.hypergeom.sf(st['n_sig'] - 1, len(prot), st['n_measured'], len(sigset)))
        KEY['serum']['public_sets'][name] = dict(n=st['n_measured'], k=st['n_sig'], pct=st['pct_sig'], fisher_p=st['fisher_p'], hypergeom_p=hyper, median_z=st['median_z'], median_z_rest=st['median_z_rest'], ranksum_p=st['ranksum_p'])
        rows.append({**{k_: v_ for k_, v_ in st.items() if k_ != 'not_delivered'}, 'not_delivered': '(public set; not listed)'})
    pd.DataFrame(rows).to_csv(os.path.join(TAB, 'serum_axis_summary.csv'), index=False)

pr = prot[prot.in_rnaseq]; rho = stats.spearmanr(pr.HUVEC_IL33_6h, pr.z_mean)
KEY['serum']['bridge'] = dict(n=int(len(pr)), spearman_rho=float(rho.correlation), p=float(rho.pvalue), il33_inducible_and_outcome=sorted(prot.index[prot.core_up_any & prot.sig05]))
for a_, genes in axmemb.items(): prot['axis_' + re.sub(r'[^A-Za-z0-9]+', '_', a_).strip('_')] = prot.index.isin(genes)
pd.to_pickle(dict(axes=axmemb), os.path.join(CACHE, 'axes.pkl'))

# =====================================================================================================
# 4. POST-MORTEM LUNG
# =====================================================================================================
f_pm = os.path.join(DATA, 'AX-1177_postmortem_lung.xlsx'); wb = openpyxl.load_workbook(f_pm); ws = wb.worksheets[0]
names = ['sample_id', 'block_id', 'tissue_rna', 'sample_id_dup', 'lobe', 'category', 'race', 'sex', 'age', 'sars', 'pathology', 'HE_eos', 'EPX_raw', 'EDN_raw', 'MBP_raw', '2D7_raw', 'IL5Ra_NE_raw', 'NE_raw', 'IL5Ra_tryp_raw', 'tryptase_raw',
         'EPX', 'NE', 'tryptase', 'IL33_epi', 'IL33_endo', 'IL33_vsm', 'notes']
rows = []; formulas = []
for r in range(2, ws.max_row + 1):
    vals = [ws.cell(row=r, column=c).value for c in range(1, 28)]
    if vals[0] is None and vals[1] is None: continue
    for c, v in enumerate(vals, 1):
        if isinstance(v, str) and v.startswith('='): formulas.append((ws.cell(row=r, column=c).coordinate, v))
    rows.append(dict(zip(names, vals)) | dict(xl_row=r))
pm = pd.DataFrame(rows)
hidden_pm = hidden_columns(ws)
def ev(v): return eval(v[1:]) if isinstance(v, str) and v.startswith('=') else v     # only arithmetic literal formulas are present
def num(v):
    v = ev(v)
    if v is None: return np.nan
    if isinstance(v, (int, float)): return float(v)
    s_ = str(v).strip()
    if s_ in ('ND', 'N/A', ''): return np.nan
    m_ = re.match(r'^(\d)\+$', s_)
    return float(m_.group(1)) if m_ else float(s_)
for c in ['EPX', 'NE', 'tryptase', 'IL33_epi', 'IL33_endo', 'IL33_vsm']: pm[c] = pm[c].map(num)
for c in ['EPX_raw', 'EDN_raw', 'MBP_raw', '2D7_raw', 'IL5Ra_NE_raw', 'NE_raw', 'IL5Ra_tryp_raw', 'tryptase_raw']: pm[c.replace('_raw', '_n')] = pm[c].map(num)
pm['sample_id'] = pm.sample_id.astype(str)
for c in ['category', 'race', 'sex', 'age', 'sars', 'pathology']: pm[c] = pm.groupby('sample_id')[c].transform(lambda s_: s_.ffill().bfill())     # donor-level fields sit on the first block only
pm['notes_donor'] = pm.groupby('sample_id').notes.transform(lambda s_: '; '.join(sorted(set(x for x in s_.dropna()))))
pm['HE_eos_Y'] = (pm.HE_eos == 'Y').astype(float)
markers = ['IL33_epi', 'IL33_endo', 'IL33_vsm', 'EPX', 'NE', 'tryptase', 'EPX_n', 'EDN_n', 'MBP_n', '2D7_n', 'IL5Ra_NE_n', 'NE_n', 'IL5Ra_tryp_n', 'tryptase_n']
don = pm.groupby('sample_id').agg(category=('category', 'first'), sex=('sex', 'first'), age=('age', 'first'), sars=('sars', 'first'), n_blocks=('block_id', 'count'), notes=('notes_donor', 'first'), pathology=('pathology', 'first'),
                                  HE_eos_frac=('HE_eos_Y', 'mean'), **{m_: (m_, 'mean') for m_ in markers})
pt = don.pathology.str.lower()
don['COPD_hist'] = don.notes.str.contains('COPD'); don['emphysema_path'] = pt.str.contains('emphysema|emphysematous')
don['acute_pneumonia_path'] = pt.str.contains('bronchopneumonia|bronchpneumonia|organizing pneumonia|acute pneumonitis|sars-cov-2 pneumonia|pulmonary consolidation')
don['ALI_DAD_path'] = pt.str.contains('diffuse alveolar damage|acute lung injury') | (pt.str.contains('hyaline membranes|hyalin membranes') & ~pt.str.contains('no hyaline membranes'))
don['acute_lung_path'] = don.acute_pneumonia_path | don.ALI_DAD_path; don['thrombo_path'] = pt.str.contains('thromboembol|pulmonary emboli')
don['bronchopneumonia_path'] = pt.str.contains('bronchopneumonia|bronchpneumonia')
# block-ID series (accession/staining batches): A = GHP002415-2451 (incl. all non-pneumonia donors), B = GHP002749-2752 (4 COVID+ donors, up to 8 blocks), C = GHP002791-2801
pm['ghp'] = pm.block_id.str.extract(r'GHP00(\d{4})')[0].astype(int)
pm['block_series'] = pd.cut(pm.ghp, [0, 2500, 2780, 3000], labels=['A', 'B', 'C']).astype(str)
don['block_series'] = pm.groupby('sample_id').block_series.first()
series = {}
for m_ in ['MBP_n', 'EDN_n', 'EPX', 'IL33_endo', 'IL33_epi', 'IL33_vsm', 'NE']:
    xs = [don.loc[don.block_series == b_, m_].dropna() for b_ in ['A', 'B', 'C']]
    A_ = don[don.block_series == 'A']
    series[m_] = dict(median_A=float(xs[0].median()), median_B=float(xs[1].median()), median_C=float(xs[2].median()), kruskal_p_across_series=float(stats.kruskal(*xs).pvalue),
                      within_A_pneumonia_vs_nonpneumonia_p=float(stats.mannwhitneyu(A_.loc[A_.category != 'COVID neg non-pneumonia', m_], A_.loc[A_.category == 'COVID neg non-pneumonia', m_]).pvalue),
                      within_A_median_pneumonia=float(A_.loc[A_.category != 'COVID neg non-pneumonia', m_].median()), within_A_median_nonpneumonia=float(A_.loc[A_.category == 'COVID neg non-pneumonia', m_].median()))
cats = ['COVID pos pneumonia', 'COVID neg pneumonia', 'COVID neg non-pneumonia']
rows = []
for m_ in ['IL33_endo', 'IL33_epi', 'IL33_vsm', 'NE', 'EPX', 'EDN_n', 'MBP_n', 'tryptase', 'IL5Ra_NE_n', 'HE_eos_frac']:
    xs = [don.loc[don.category == c, m_].dropna() for c in cats]
    a_ = don.loc[don.acute_lung_path, m_]; b_ = don.loc[~don.acute_lung_path, m_]
    ac = don[don.acute_lung_path]
    rows.append(dict(marker=m_, median_COVIDpos_pneumonia=xs[0].median(), median_COVIDneg_pneumonia=xs[1].median(), median_COVIDneg_nonpneumonia=xs[2].median(), kruskal_p=stats.kruskal(*xs).pvalue,
                     p_COVIDpos_vs_COVIDneg_pneumonia=stats.mannwhitneyu(xs[0], xs[1]).pvalue, p_COVIDpos_vs_nonpneumonia=stats.mannwhitneyu(xs[0], xs[2]).pvalue, p_anypneumonia_vs_nonpneumonia=stats.mannwhitneyu(pd.concat(xs[:2]), xs[2]).pvalue,
                     sens_median_path_acute=a_.median(), sens_median_path_none=b_.median(), sens_p_path_acute_vs_none=stats.mannwhitneyu(a_, b_).pvalue,
                     sens_p_COVIDpos_vs_neg_within_path_acute=stats.mannwhitneyu(ac.loc[ac.sars == 'pos', m_], ac.loc[ac.sars != 'pos', m_]).pvalue))
PMS = pd.DataFrame(rows); PMS.to_csv(os.path.join(TAB, 'postmortem_group_stats_donor_level.csv'), index=False)
def sp(a_, b_): r_ = stats.spearmanr(don[a_], don[b_]); return dict(rho=float(r_.correlation), p=float(r_.pvalue))
ols = smf.ols('IL33_endo ~ NE + age + C(sex)', don).fit()
naive = {m_: float(stats.mannwhitneyu(pm.loc[pm.category == 'COVID pos pneumonia', m_].dropna(), pm.loc[pm.category != 'COVID pos pneumonia', m_].dropna()).pvalue) for m_ in ['IL33_endo', 'IL33_vsm', 'IL33_epi']}
donor = {m_: float(stats.mannwhitneyu(don.loc[don.category == 'COVID pos pneumonia', m_], don.loc[don.category != 'COVID pos pneumonia', m_]).pvalue) for m_ in ['IL33_endo', 'IL33_vsm', 'IL33_epi']}
KEY['postmortem'] = dict(n_blocks=int(len(pm)), n_donors=int(len(don)), donors_per_group=don.category.value_counts().to_dict(), blocks_per_group=pm.category.value_counts().to_dict(), blocks_per_donor_range=[int(don.n_blocks.min()), int(don.n_blocks.max())],
    age_range=[float(don.age.min()), float(don.age.max())], hidden_columns=hidden_pm, formula_cells=formulas, max_IL33_score=float(pm[['IL33_epi', 'IL33_endo', 'IL33_vsm']].max().max()),
    endo_blocks_at_max=f"{int((pm.IL33_endo == 5.5).sum())}/{int(pm.IL33_endo.notna().sum())}", donors_endo_ge425=int((don.IL33_endo >= 4.25).sum()), donors_epi_ge425=int((don.IL33_epi >= 4.25).sum()), donors_vsm_ge425=int((don.IL33_vsm >= 4.25).sum()),
    group_stats={r_['marker']: {k: (float(v) if not isinstance(v, str) else v) for k, v in r_.items() if k != 'marker'} for r_ in rows},
    spearman_IL33endo_NE=sp('IL33_endo', 'NE'), spearman_IL33endo_age=sp('IL33_endo', 'age'), spearman_IL33endo_EPX=sp('IL33_endo', 'EPX'), spearman_IL33epi_EPX=sp('IL33_epi', 'EPX'), spearman_NE_IL5Ra=sp('NE', 'IL5Ra_NE_n'),
    ols_IL33endo_NE_adj_age_sex=dict(coef=float(ols.params['NE']), p=float(ols.pvalues['NE'])), naive_block_level_p_COVIDpos_vs_rest=naive, donor_level_p_COVIDpos_vs_rest=donor,
    label_vs_pathology=pd.crosstab(don.category, don.acute_lung_path).to_dict(), DAD_by_group=pd.crosstab(don.category, don.ALI_DAD_path).to_dict(), thrombo_by_group=pd.crosstab(don.category, don.thrombo_path).to_dict(),
    block_series=series, donors_per_series=pd.crosstab(don.category, don.block_series).to_dict(),
    race_values=sorted(set(pm.race.dropna().astype(str))), sex_counts=don.sex.value_counts().to_dict(),
    COPD_or_emphysema=int((don.COPD_hist | don.emphysema_path).sum()), bronchopneumonia_all=int(don.bronchopneumonia_path.sum()), bronchopneumonia_COVIDpos=int((don.bronchopneumonia_path & (don.sars == 'pos')).sum()), n_COVIDpos=int((don.sars == 'pos').sum()),
    acute_pneumonia_or_ALI_documented=int(don.acute_lung_path.sum()), missing_sars=list(don.index[don.sars.isna()]), tissue_rna_ids=int(pm.tissue_rna.notna().sum()))
_naive = pd.read_excel(f_pm); _naive = _naive[_naive['Histology Block ID'].notna()]; n_blank_cat = int(_naive['Disease Category'].isna().sum()); n_rows_pm = int(len(_naive))
issue('Post-mortem lung', f"Columns {', '.join(hidden_pm)} are hidden in the sheet - this includes every IHC read-out (eosinophil, neutrophil, mast-cell and all three IL-33 columns). Donor-level fields are merged and sit on the first block only; text ('n+', 'ND', 'N/A') is mixed with numbers; {len(formulas)} IL-33 value is a typed-in formula ({'; '.join(c + ' ' + f for c, f in formulas)}).",
      f"Opened in a spreadsheet, the IL-33 data are invisible. A naive import leaves {n_blank_cat} of {n_rows_pm} block rows without a disease category and returns score columns as text. The formula shows the IL-33 scores are hand-averaged composites of two readings.",
      'All columns read; donor fields forward-filled by sample ID; formula evaluated (3.25); N/A and ND set missing.')
issue('Post-mortem lung', f"Scores are stated to be 0-5 but reach {KEY['postmortem']['max_IL33_score']} ('n+' recorded as n.5) and IL-33 values are quarter-point composites; single reader; endothelial IL-33 is at the maximum in {KEY['postmortem']['endo_blocks_at_max']} blocks.",
      'Semi-quantitative, ceiling-limited, not blinded-replicated: small group differences cannot be resolved.', 'Treated as ordinal; rank-based donor-level tests.')
issue('Post-mortem lung', f"{KEY['postmortem']['n_blocks']} blocks from {KEY['postmortem']['n_donors']} donors ({KEY['postmortem']['blocks_per_donor_range'][0]}-{KEY['postmortem']['blocks_per_donor_range'][1]} blocks each; three COVID+ donors contribute 24 of 49 COVID+ blocks).",
      f"Block-level tests are pseudo-replicated: IL-33 endothelium COVID+ vs rest p = {naive['IL33_endo']:.3f} by block but {donor['IL33_endo']:.3f} by donor.", 'All inference at donor level (block means) or mixed models.')
issue('Post-mortem lung', "Group labels do not match the autopsy diagnoses: 4 of 10 'COVID neg pneumonia' donors have no pneumonia listed; 2 of 5 'non-pneumonia' donors have organising pneumonia / acute pneumonitis; the comparators have fibrosis, coccidioidomycosis, emphysema. One donor has no SARS-CoV-2 result. All donors are 64-98 years old and white.",
      'There is no healthy-lung reference and the control group is not disease-free; label-based contrasts are diluted.', 'Sensitivity analysis re-grouping donors by pathology-documented acute pneumonia / lung injury.')

issue('Post-mortem lung', "Blocks come in three accession series (GHP002415-2451, 2749-2752, 2791-2801) that are confounded with group: all non-pneumonia donors are in the first; MBP staining differs between series (donor medians {:.2f} / {:.2f} / {:.2f}, Kruskal-Wallis p = {:.1e}); IL-33 and neutrophil elastase do not (p = {:.2f}, {:.2f}).".format(
          series['MBP_n']['median_A'], series['MBP_n']['median_B'], series['MBP_n']['median_C'], series['MBP_n']['kruskal_p_across_series'], series['IL33_endo']['kruskal_p_across_series'], series['NE']['kruskal_p_across_series']),
      'Eosinophil granule stains cannot be compared across series; the apparent MBP/EDN excess in pneumonia is partly a series effect.', 'Eosinophil conclusions restricted to within-series comparisons; IL-33 and neutrophil results checked within the first series.')
# =====================================================================================================
# 5. EXPORT
# =====================================================================================================
d.to_pickle(os.path.join(CACHE, 'master_gene_table.pkl')); prot.to_pickle(os.path.join(CACHE, 'prot.pkl')); ol.to_pickle(os.path.join(CACHE, 'olink.pkl')); pm.to_pickle(os.path.join(CACHE, 'pm_blocks.pkl')); don.to_pickle(os.path.join(CACHE, 'pm_donors.pkl'))
d.reset_index().round(5).to_csv(os.path.join(TAB, 'rnaseq_master_gene_table.csv'), index=False)
sig_cols = ['symbol', 'gene_name', 'AveExpr', 'HUVEC_IL33_6h', 'HUVEC_IL33_6h_adjP', 'HUVEC_AX1177_rev_6h', 'HUVEC_rev_6h_adjP', 'pct_rev_6h', 'resid_vs_vehicle_6h', 'HUVEC_IL33_24h', 'HUVEC_IL33_24h_adjP', 'HUVEC_AX1177_rev_24h', 'HUVEC_rev_24h_adjP',
            'pct_rev_24h', 'resid_vs_vehicle_24h', 'HGMEC_AX1177_rev_6h', 'HGMEC_rev_6h_adjP', 'HGMEC_AX1177_rev_24h', 'HGMEC_rev_24h_adjP', 'HUVEC_Ab_alone_6h', 'HUVEC_Ab_alone_24h', 'empirical_noise_rms', 'model_SE', 'model_p_unreliable',
            'core_6h', 'core_24h', 'HGMEC_supported_6h', 'pan_endothelial_durable']
d.loc[d.core_6h | d.core_24h, sig_cols].sort_values('HUVEC_IL33_6h', ascending=False).reset_index().round(4).to_csv(os.path.join(TAB, 'rnaseq_IL33_AX1177_signature_induced.csv'), index=False)
d.loc[d.core_down_6h | d.core_down_24h, sig_cols + ['core_down_6h', 'core_down_24h']].sort_values('HUVEC_IL33_6h').reset_index().round(4).to_csv(os.path.join(TAB, 'rnaseq_IL33_AX1177_signature_repressed.csv'), index=False)
csum = pd.DataFrame([dict(contrast=c, short=short[c], n_adjP05=int((Q[short[c]] < 0.05).sum()), n_adjP05_abs_lfc_gt1=int(((Q[short[c]] < 0.05) & (L[short[c]].abs() > 1)).sum()), up=int(((Q[short[c]] < 0.05) & (L[short[c]] > 1)).sum()),
                          down=int(((Q[short[c]] < 0.05) & (L[short[c]] < -1)).sum()), n_abs_lfc_gt1_any_p=int((L[short[c]].abs() > 1).sum())) for c in short])
csum.to_csv(os.path.join(TAB, 'rnaseq_contrast_summary.csv'), index=False)
ol_out = ol[['panel', 'assay', 'gene', 'OR', 'l95', 'u95', 'p.value', 'adj.p.value', 'z', 'rank', 'composite_endpoint_0', 'composite_endpoint_1']].copy()
ol_out['n_assays_for_protein'] = ol_out.gene.map(prot.n_assays); ol_out['hidden_row_in_source'] = ol_out['rank'].add(1).isin(hidden_rows)
for c in ['HUVEC_IL33_6h', 'HUVEC_AX1177_rev_6h', 'HUVEC_IL33_24h', 'HUVEC_AX1177_rev_24h', 'HGMEC_AX1177_rev_6h', 'core_6h', 'core_24h', 'pan_endothelial_durable']: ol_out[c] = ol_out.gene.map(prot[c])
ol_out.round(5).to_csv(os.path.join(TAB, 'serum_proteomics_annotated_assay_level.csv'), index=False)
prot.reset_index().rename(columns={'index': 'gene'}).round(5).to_csv(os.path.join(TAB, 'serum_proteomics_protein_level.csv'), index=False)
pm.drop(columns=['pathology']).to_csv(os.path.join(TAB, 'postmortem_blocks_tidy.csv'), index=False)
don.drop(columns=['pathology']).reset_index().round(3).to_csv(os.path.join(TAB, 'postmortem_donor_level.csv'), index=False)
pd.DataFrame(ISSUES).to_csv(os.path.join(TAB, 'data_integrity_log.csv'), index=False)

# ---- biomarker shortlist
def row(gene, label, role, readiness, caveat, rna=True):
    r_ = dict(marker=label, gene=gene, proposed_role=role, readiness=readiness, caveat=caveat)
    if rna and gene in sym2ens.index:
        e = sym2ens[gene]      # percent reversal is only meaningful where IL-33 moves the gene at least 2-fold
        r_.update(HUVEC_IL33_6h_log2FC=d.HUVEC_IL33_6h[e], HUVEC_pct_reversed_6h=d.pct_rev_6h[e] if abs(d.HUVEC_IL33_6h[e]) >= 1 else np.nan, HUVEC_IL33_24h_log2FC=d.HUVEC_IL33_24h[e],
                  HUVEC_pct_reversed_24h=d.pct_rev_24h[e] if abs(d.HUVEC_IL33_24h[e]) >= 1 else np.nan, HGMEC_AX1177_rev_6h_log2FC=d.HGMEC_AX1177_rev_6h[e],
                  in_signature_6h=bool(d.core_6h[e]), in_signature_24h=bool(d.core_24h[e]), HGMEC_supported_6h=bool(d.HGMEC_supported_6h[e]), model_p_unreliable=bool(d.model_p_unreliable[e]))
    s_ = ol[ol.gene == gene].sort_values('p.value')
    if len(s_):
        b_ = s_.iloc[0]; r_.update(serum_assay=b_.assay, serum_OR=b_.OR, serum_l95=b_.l95, serum_u95=b_.u95, serum_p=b_['p.value'], serum_FDR=b_['adj.p.value'], serum_n_assays=len(s_), serum_FDR_all_assays='; '.join(f"{x:.3f}" for x in s_['adj.p.value']))
    return r_
BM = pd.DataFrame([
 row('IL1RL1', 'sST2', 'Prognostic enrichment / stratification at screening; candidate predictive marker (test by treatment x marker interaction)', 'Ready for patients (serum immunoassay); cut-off must be derived from patient-level data', 'Prognostic only; decoy receptor - high sST2 may mean axis active OR already buffered; modest, HUVEC-only IL-33 inducibility (model p unusable)'),
 row('IL6', 'IL-6', 'Pharmacodynamic / response (Tier 1)', 'Ready (routine clinical assay)', 'Not IL-33-specific (any NF-kB stimulus); interpret only as change vs placebo'),
 row('CXCL8', 'IL-8 (CXCL8)', 'Pharmacodynamic / response (Tier 1)', 'Ready (multiplex immunoassay)', 'As IL-6; RNA model p unusable - effect size and replication used'),
 row('CCL20', 'CCL20', 'Pharmacodynamic / response (Tier 1)', 'Ready (multiplex immunoassay)', 'As IL-6'),
 row('TNFRSF11B', 'OPG (TNFRSF11B)', 'Pharmacodynamic / response (Tier 1)', 'Ready (immunoassay)', 'As IL-6; slower-turnover protein'),
 row('PTX3', 'PTX3', 'Pharmacodynamic / response (Tier 1, early)', 'Ready (immunoassay)', '6 h only, modest induction, RNA model p unusable'),
 row('CCL7', 'MCP-3 (CCL7)', 'Pharmacodynamic / response (Tier 1, early)', 'Ready (multiplex immunoassay)', '6 h only; low expression'),
 row('CSF1', 'M-CSF (CSF1)', 'Pharmacodynamic / response (Tier 1, early)', 'Ready (immunoassay)', '6 h only; serum OR imprecise'),
 row('IL1B', 'IL-1beta', 'Exploratory PD', 'Needs high-sensitivity assay', 'Low circulating abundance'),
 row('IL18R1', 'sIL-18R1', 'Exploratory PD', 'Research assay', 'Receptor; shedding biology unknown'),
 row('CCL2', 'MCP-1 (CCL2)', 'Pharmacodynamic (Tier 2)', 'Ready', 'Serum association borderline (FDR 0.05)'),
 row('F3', 'Tissue factor (F3)', 'Pharmacodynamic (Tier 2) / thrombo-inflammation read-out', 'Research assay (antigen or activity)', '6 h only; serum association borderline'),
 row('SELE', 'sE-selectin', 'Proximal PD (largest dynamic range); Tier 2 in serum', 'Ready (immunoassay)', 'Serum association weak (FDR 0.09); RNA model p unusable'),
 row('CX3CL1', 'Fractalkine (CX3CL1)', 'Pharmacodynamic (Tier 2)', 'Ready', 'Serum FDR 0.16'),
 row('CSF2', 'GM-CSF (CSF2)', 'Proximal PD (strongest gene; in vitro / ex vivo / airway samples)', 'High-sensitivity assay needed', 'No serum read-out in our data'),
 row('CSF3', 'G-CSF (CSF3)', 'Proximal PD', 'Ready', 'Not outcome-associated in serum'),
 row('CXCL1', 'CXCL1', 'Proximal PD', 'Ready', 'Not outcome-associated in serum; RNA model p unusable'),
 row('CXCL5', 'CXCL5', 'Proximal PD (durable to 24 h in both endothelial types)', 'Ready', 'Not outcome-associated; platelet-derived in serum'),
 row('CXCL6', 'CXCL6', 'Proximal PD', 'Ready', 'Not outcome-associated'),
 row('VCAM1', 'sVCAM-1', 'Proximal PD', 'Ready', 'Not outcome-associated; RNA model p unusable'),
 row('ICAM1', 'sICAM-1', 'Proximal PD', 'Ready', 'Not outcome-associated'),
 row('HGF', 'HGF', 'Disease-severity covariate / negative control for IL-33 specificity', 'Ready', 'Top prognostic protein but not IL-33-regulated in endothelium'),
 row('PRTN3', 'Proteinase 3 (neutrophil granule)', 'Downstream disease-activity monitoring (neutrophil activation)', 'Research assay', 'Not IL-33-regulated in endothelium; indirect'),
 row('IL5', 'IL-5', 'None - do not use', '-', 'No association (OR 1.00) and not expressed/induced'),
 row('CCL11', 'Eotaxin-1 (CCL11)', 'None - do not use', '-', 'No association'),
 row('IL33', 'IL-33 protein (free reduced / oxidised; IL-33:sST2 complex)', 'Target engagement - the missing marker', 'Not available: needs high-sensitivity, drug-tolerant assays', 'IL-33 on the panel that was run but not delivered; nothing in our data measures the target in patients', rna=False),
])
BM.round(4).to_csv(os.path.join(TAB, 'biomarker_shortlist.csv'), index=False)
json.dump(KEY, open(os.path.join(TAB, 'key_numbers.json'), 'w'), indent=1, default=str)
print(json.dumps(KEY, indent=1, default=str)[:6000])
print('\nwrote tables to', TAB)
