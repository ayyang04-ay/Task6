#!/usr/bin/env python
"""
AX-1177 portfolio audit - figures. Run after ax1177_analysis.py (reads its cache).
Usage: python ax1177_figures.py --out /tmp/outputs      (env used: `mm singlecell python ...`; needs matplotlib, adjustText)
"""
import argparse, os, tempfile, warnings
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from adjustText import adjust_text
from scipy import stats
warnings.filterwarnings('ignore')
ap = argparse.ArgumentParser(); ap.add_argument('--out', default='/tmp/outputs'); ap.add_argument('--cache', default=None); args = ap.parse_args()
OUT = args.out; CACHE = args.cache or os.path.join(tempfile.gettempdir(), 'ax1177_cache'); FIG = os.path.join(OUT, 'figures'); os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'savefig.dpi': 200, 'font.family': 'DejaVu Sans'})
d = pd.read_pickle(os.path.join(CACHE, 'master_gene_table.pkl')); res = pd.read_pickle(os.path.join(CACHE, 'sigsets.pkl'))
prot = pd.read_pickle(os.path.join(CACHE, 'prot.pkl')); ol = pd.read_pickle(os.path.join(CACHE, 'olink.pkl')); axes_members = pd.read_pickle(os.path.join(CACHE, 'axes.pkl'))['axes']
don = pd.read_pickle(os.path.join(CACHE, 'pm_donors.pkl')); pm = pd.read_pickle(os.path.join(CACHE, 'pm_blocks.pkl'))
sym = d.reset_index().drop_duplicates('symbol').set_index('symbol')
def gv(g, c): return sym.loc[g, c]
T4 = stats.t.ppf(1 - 0.0005, 4)

# ------------------------------------------------------------------------------------------------ Fig 1
lab = ['SELE', 'VCAM1', 'ICAM1', 'CXCL1', 'CXCL8', 'CXCL6', 'CSF2', 'CSF3', 'CCL20', 'IL6', 'CX3CL1', 'TNF', 'F3', 'CCL2', 'TNFRSF11B', 'CXCL5', 'C3', 'PTX3', 'CXCL10', 'IL1B']
fig, axes = plt.subplots(2, 3, figsize=(14.5, 9))
def panel(ax, x, y, core, title, xl, yl, labs):
    bg = ~core
    ax.scatter(d.loc[bg, x], d.loc[bg, y], s=3, c='#c8c8c8', alpha=.35, rasterized=True, label=f'all other genes (n={int(bg.sum()):,})')
    c_ok = core & ~d.model_p_unreliable; c_bad = core & d.model_p_unreliable
    ax.scatter(d.loc[c_ok, x], d.loc[c_ok, y], s=9, c='#1f77b4', alpha=.8, label=f'signature gene (n={int(c_ok.sum())})')
    ax.scatter(d.loc[c_bad, x], d.loc[c_bad, y], s=26, c='#d62728', marker='D', alpha=.9, label=f'signature gene with inflated model SE (variance artefact; n={int(c_bad.sum())})')
    ax.plot([-13, 13], [13, -13], 'k--', lw=.8, label='complete reversal (y = −x)'); ax.axhline(0, c='k', lw=.4); ax.axvline(0, c='k', lw=.4)
    tx = [ax.text(gv(g, x), gv(g, y), g, fontsize=7.5) for g in labs]
    adjust_text(tx, ax=ax, arrowprops=dict(arrowstyle='-', color='k', lw=.4))
    ax.set_title(title, fontsize=10, loc='left'); ax.set_xlabel(xl); ax.set_ylabel(yl); ax.legend(fontsize=6.5, loc='upper right', frameon=False); ax.set_xlim(-5, 12.5); ax.set_ylim(-13.5, 5)
panel(axes[0, 0], 'HUVEC_IL33_6h', 'HUVEC_AX1177_rev_6h', d.core_6h, 'A  HUVEC 6 h: AX-1177 mirrors the IL-33 response', 'IL-33 vs vehicle (log2FC)', 'IL-33+AX-1177 vs IL-33+isotype (log2FC)', lab)
panel(axes[0, 1], 'HUVEC_IL33_24h', 'HUVEC_AX1177_rev_24h', d.core_24h, 'B  HUVEC 24 h: response smaller, still reversed', 'IL-33 vs vehicle (log2FC)', 'IL-33+AX-1177 vs IL-33+isotype (log2FC)',
      ['CSF2', 'CXCL6', 'CSF3', 'CCL20', 'CXCL8', 'CXCL1', 'C3', 'CXCL10', 'CXCL5', 'SELE', 'VCAM1', 'TNF', 'IL6'])
ax = axes[0, 2]; c = d.core_6h
ax.scatter(d.HUVEC_IL33_6h, d.HUVEC_Ab_alone_6h, s=3, c='#c8c8c8', alpha=.35, rasterized=True); ax.scatter(d.loc[c, 'HUVEC_IL33_6h'], d.loc[c, 'HUVEC_Ab_alone_6h'], s=9, c='#1f77b4', alpha=.8)
ax.axhline(0, c='k', lw=.4); ax.axvline(0, c='k', lw=.4); ax.set_xlim(-5, 12.5); ax.set_ylim(-13.5, 5)
sl = np.polyfit(d.loc[c, 'HUVEC_IL33_6h'], d.loc[c, 'HUVEC_Ab_alone_6h'], 1)[0]
ax.set_title('C  HUVEC 6 h: AX-1177 alone does nothing', fontsize=10, loc='left'); ax.set_xlabel('IL-33 vs vehicle (log2FC)'); ax.set_ylabel('AX-1177 vs isotype, no IL-33 (log2FC)')
ax.text(0.03, 0.05, f'slope across {int(c.sum())} signature genes = {sl:+.3f}\n0 genes changed at both 6 h and 24 h vs isotype\nin HUVEC, HGMEC, A549 or MCF7', transform=ax.transAxes, fontsize=8)
ax = axes[1, 0]; u = d.core_6h | d.HGMEC_supported_6h; b = d.core_6h & d.HGMEC_supported_6h
ax.scatter(d.loc[~u, 'HUVEC_AX1177_rev_6h'], d.loc[~u, 'HGMEC_AX1177_rev_6h'], s=3, c='#c8c8c8', alpha=.35, rasterized=True)
ax.scatter(d.loc[u & ~b, 'HUVEC_AX1177_rev_6h'], d.loc[u & ~b, 'HGMEC_AX1177_rev_6h'], s=8, c='#ff7f0e', alpha=.7, label=f'signature in one cell type only (n={int((u & ~b).sum())})')
ax.scatter(d.loc[b, 'HUVEC_AX1177_rev_6h'], d.loc[b, 'HGMEC_AX1177_rev_6h'], s=10, c='#2ca02c', alpha=.9, label=f'shared HUVEC + HGMEC (n={int(b.sum())})'); ax.plot([-13, 4], [-13, 4], 'k--', lw=.8, label='y = x')
tx = [ax.text(gv(g, 'HUVEC_AX1177_rev_6h'), gv(g, 'HGMEC_AX1177_rev_6h'), g, fontsize=7.5) for g in ['SELE', 'VCAM1', 'ICAM1', 'CXCL1', 'CXCL8', 'CSF2', 'CSF3', 'CCL20', 'IL6', 'BIRC3', 'CXCL2', 'CCL2']]
adjust_text(tx, ax=ax, arrowprops=dict(arrowstyle='-', color='k', lw=.4)); ax.axhline(0, c='k', lw=.4); ax.axvline(0, c='k', lw=.4); ax.set_xlim(-13.5, 5); ax.set_ylim(-13.5, 5)
ax.set_title('D  6 h: same AX-1177-sensitive programme in glomerular EC', fontsize=10, loc='left'); ax.set_xlabel('HUVEC: IL-33+AX-1177 vs IL-33+isotype (log2FC)'); ax.set_ylabel('HGMEC: IL-33+AX-1177 vs IL-33+isotype (log2FC)'); ax.legend(fontsize=6.5, frameon=False, loc='upper left')
ax = axes[1, 1]; data = []; labels = []
for tp in ['6h', '24h']:
    I = d[f'HUVEC_IL33_{tp}']; N = d[f'HUVEC_AX1177_rev_{tp}']; q = d[f'HUVEC_IL33_{tp}_adjP']; z = I / d.empirical_noise_rms
    for thr in (3, 4):
        sel = ((q < 0.05) | (d.model_p_unreliable & (z > T4))) & (I > thr)
        data.append((-100 * N[sel] / I[sel]).clip(-50, 160).values); labels.append(f'{tp[:-1]} h\n≥{2**thr}-fold\n(n={int(sel.sum())})')
bp = ax.boxplot(data, tick_labels=labels, showfliers=False, patch_artist=True, widths=.55)
for p_, c_ in zip(bp['boxes'], ['#1f77b4', '#1f77b4', '#aec7e8', '#aec7e8']): p_.set_facecolor(c_)
for i, v in enumerate(data):
    ax.scatter(np.random.default_rng(i).normal(i + 1, .07, len(v)), v, s=5, c='k', alpha=.35, zorder=3); ax.text(i + 1, 158, f'median\n{np.median(v):.0f}%', ha='center', va='top', fontsize=8)
ax.axhline(100, c='k', ls='--', lw=.8); ax.axhline(0, c='k', lw=.4); ax.set_ylim(-55, 165)
ax.set_ylabel('% of IL-33 induction reversed by AX-1177\n(vs isotype-matched IL-33 arm)'); ax.set_title('E  Neutralisation of strongly induced genes (HUVEC)', fontsize=10, loc='left')
ax = axes[1, 2]; c6 = d.core_6h
ax.scatter(d.loc[c6, 'HUVEC_IL33_6h'], d.loc[c6, 'HUVEC_IL33_24h'], s=9, c='#1f77b4', alpha=.7)
ratio = d.loc[c6, 'HUVEC_IL33_24h'].sum() / d.loc[c6, 'HUVEC_IL33_6h'].sum(); ratio_h = d.loc[c6, 'HGMEC_AX1177_rev_24h'].sum() / d.loc[c6, 'HGMEC_AX1177_rev_6h'].sum()
ax.plot([0, 12], [0, 12], 'k--', lw=.8, label='no decay (y = x)'); ax.plot([0, 12], [0, 12 * ratio], 'r-', lw=.8, label=f'observed: 24 h ≈ {100*ratio:.0f}% of 6 h amplitude (HGMEC: ≈ {100*ratio_h:.0f}%)')
tx = [ax.text(gv(g, 'HUVEC_IL33_6h'), gv(g, 'HUVEC_IL33_24h'), g, fontsize=7.5) for g in ['SELE', 'VCAM1', 'CXCL1', 'CXCL8', 'CXCL6', 'CSF2', 'CSF3', 'CCL20', 'IL6', 'TNF', 'F3', 'C3', 'CX3CL1', 'CXCL10', 'ICAM1', 'TNFRSF11B', 'CXCL5']]
adjust_text(tx, ax=ax, arrowprops=dict(arrowstyle='-', color='k', lw=.4))
ax.axhline(0, c='k', lw=.4); ax.set_xlabel('IL-33 vs vehicle at 6 h (log2FC)'); ax.set_ylabel('IL-33 vs vehicle at 24 h (log2FC)'); ax.set_title(f'F  The response is front-loaded ({int(c6.sum())} 6 h signature genes)', fontsize=10, loc='left'); ax.legend(fontsize=7, frameon=False, loc='upper left')
plt.tight_layout(); plt.savefig(os.path.join(FIG, 'fig2_rnaseq_pharmacology.png'), bbox_inches='tight'); plt.close()

# ------------------------------------------------------------------------------------------------ Fig 2
groups = [
 ('Axis / enrichment marker', ['IL1RL1']),
 ('TIER 1 PD\nIL-33-induced, AX-1177-reversed\nAND outcome-associated in serum\n(FDR < 0.05)', ['IL6', 'CXCL8', 'CCL20', 'TNFRSF11B', 'PTX3', 'CCL7', 'CSF1', 'IL1B', 'IL18R1']),
 ('TIER 2 PD\nsame, but serum association\nborderline (FDR 0.05–0.2)', ['CCL2', 'F3', 'SELE', 'CX3CL1', 'PLAU', 'SERPINE1']),
 ('PROXIMAL PD ONLY\nlarge IL-33 effect, no outcome\nassociation in serum', ['CSF2', 'CSF3', 'CXCL1', 'CXCL5', 'CXCL6', 'CXCL10', 'VCAM1', 'ICAM1', 'TNFRSF9']),
 ('CONTEXT\nprognostic, but NOT IL-33-\nregulated in endothelium', ['HGF', 'OSM', 'PRTN3', 'RETN', 'ANXA1', 'CLEC5A']),
 ('TYPE-2 / EOSINOPHIL / MAST CELL\nno signal in either dataset', ['IL5', 'CCL11', 'CCL17', 'CCL24', 'CCL18', 'TPSAB1', 'RNASE3', 'IL5RA']),
]
disp = {'IL1RL1': 'sST2 (IL1RL1)', 'CXCL8': 'IL-8 (CXCL8)', 'TNFRSF11B': 'OPG (TNFRSF11B)', 'CCL7': 'MCP-3 (CCL7)', 'CSF1': 'M-CSF (CSF1)', 'IL1B': 'IL-1β', 'IL18R1': 'IL-18R1', 'CCL2': 'MCP-1 (CCL2)', 'F3': 'Tissue factor (F3)', 'SELE': 'E-selectin (SELE)',
        'PLAU': 'uPA (PLAU)', 'SERPINE1': 'PAI-1 (SERPINE1)', 'CSF2': 'GM-CSF (CSF2)', 'CSF3': 'G-CSF (CSF3)', 'IL6': 'IL-6', 'CX3CL1': 'Fractalkine (CX3CL1)', 'TNFRSF9': '4-1BB (TNFRSF9)', 'IL5': 'IL-5', 'CCL11': 'Eotaxin-1 (CCL11)', 'CCL17': 'TARC (CCL17)',
        'CCL24': 'Eotaxin-2 (CCL24)', 'CCL18': 'PARC (CCL18)', 'TPSAB1': 'Tryptase (TPSAB1)', 'RNASE3': 'ECP (RNASE3)', 'IL5RA': 'IL-5Rα'}
cols = ['HUVEC_IL33_6h', 'HUVEC_AX1177_rev_6h', 'HUVEC_IL33_24h', 'HUVEC_AX1177_rev_24h', 'HGMEC_AX1177_rev_6h', 'HGMEC_AX1177_rev_24h']
collab = ['HUVEC\n6 h\nIL-33', 'HUVEC\n6 h\n+AX-1177', 'HUVEC\n24 h\nIL-33', 'HUVEC\n24 h\n+AX-1177', 'HGMEC\n6 h\n+AX-1177', 'HGMEC\n24 h\n+AX-1177']
rows = []; ylab = []; gbreaks = []; glabels = []
for gname, genes in groups:
    gbreaks.append(len(rows)); glabels.append(gname)
    for g in genes: rows.append(g); ylab.append(disp.get(g, g))
n = len(rows); M = np.full((n, len(cols)), np.nan); flag = []
for i, g in enumerate(rows):
    if g in sym.index: M[i, :] = sym.loc[g, cols].values.astype(float); flag.append(bool(sym.loc[g, 'model_p_unreliable']))
    else: flag.append(False)
fig = plt.figure(figsize=(15.5, 0.30 * n + 2.4))
gs = fig.add_gridspec(2, 4, width_ratios=[2.6, 1.55, 3.2, 4.3], height_ratios=[n, 0.45], wspace=0.02, hspace=0.06)
axg = fig.add_subplot(gs[0, 0]); axl = fig.add_subplot(gs[0, 1]); axh = fig.add_subplot(gs[0, 2]); axf = fig.add_subplot(gs[0, 3]); axc = fig.add_subplot(gs[1, 2])
im = axh.imshow(M, aspect='auto', cmap='RdBu_r', norm=TwoSlopeNorm(vmin=-10, vcenter=0, vmax=10), extent=(-0.5, len(cols) - 0.5, n - 0.5, -0.5))
for i in range(n):
    for j in range(len(cols)):
        v = M[i, j]
        if np.isnan(v): axh.text(j, i, 'n.e.', ha='center', va='center', fontsize=6.5, color='#666')
        else: axh.text(j, i, f'{v:+.1f}', ha='center', va='center', fontsize=7, color='white' if abs(v) > 5.5 else 'black')
axh.set_xticks(range(len(cols))); axh.set_xticklabels(collab, fontsize=7); axh.xaxis.tick_top(); axh.set_yticks([])
for s in axh.spines.values(): s.set_visible(False)
axh.tick_params(length=0); axh.set_ylim(n - 0.5, -0.5)
for ax in (axg, axl): ax.set_ylim(n - 0.5, -0.5); ax.set_xlim(0, 1); ax.axis('off')
for i, (y, f) in enumerate(zip(ylab, flag)): axl.text(0.97, i, y + (' *' if f else ''), ha='right', va='center', fontsize=8)
for k, (b, gl) in enumerate(zip(gbreaks, glabels)):
    e = gbreaks[k + 1] if k + 1 < len(gbreaks) else n
    axg.text(0.97, (b + e - 1) / 2, gl, ha='right', va='center', fontsize=7.8, fontweight='bold', linespacing=1.25)
for b in gbreaks[1:]:
    for ax in (axg, axl, axh, axf): ax.plot([0, 1], [b - 0.5, b - 0.5], color='k', lw=1.1, transform=ax.get_yaxis_transform(), clip_on=False)
axf.set_ylim(n - 0.5, -0.5); axf.set_xscale('log'); axf.axvline(1, color='k', lw=.6); xmin, xmax = 0.4, 40
for i, g in enumerate(rows):
    sub = ol[ol.gene == g].sort_values('p.value')
    if len(sub) == 0: axf.text(1.08, i, 'no serum readout (assay not delivered)', fontsize=6.8, va='center', color='#666'); continue
    r = sub.iloc[0]; col = '#d62728' if r['adj.p.value'] < 0.05 else ('#ff7f0e' if r['adj.p.value'] < 0.2 else '#7f7f7f')
    axf.plot([max(r.l95, xmin), min(r.u95, xmax)], [i, i], color=col, lw=1.4)
    if r.u95 > xmax: axf.plot(xmax, i, marker='>', color=col, ms=5)
    if r.OR <= xmax: axf.plot(r.OR, i, 'o', color=col, ms=5)
    axf.text(xmax * 1.25, i, f"OR {r.OR:.2f} ({r.l95:.2f}–{r.u95:.1f}); FDR {r['adj.p.value']:.3f}" + (f"; {len(sub)} assays agree" if len(sub) > 1 else ''), fontsize=6.8, va='center')
axf.set_xlim(xmin, xmax * 25); axf.set_yticks([]); axf.spines['left'].set_visible(False); axf.set_xticks([0.5, 1, 2, 5, 10, 20, 40]); axf.set_xticklabels(['0.5', '1', '2', '5', '10', '20', '40']); axf.minorticks_off()
axf.set_xlabel('Serum odds ratio per log unit for ICU / ventilation / death\n(n=100 hospitalised; adj. age, sex, NEWS2). Red FDR<0.05, orange FDR<0.2', fontsize=8); axf.xaxis.set_label_position('top'); axf.xaxis.tick_top()
cb = fig.colorbar(im, cax=axc, orientation='horizontal'); cb.ax.tick_params(labelsize=7); cb.set_label('log2 fold change: IL-33 vs vehicle, or IL-33+AX-1177 vs IL-33+isotype', fontsize=7.5)
fig.text(0.5, 0.045, '* model p-value unusable for this gene (pooled-variance artefact); effect sizes are shown and were confirmed against an empirical noise estimate.   n.e. = gene absent from the delivered gene list (filtered as not expressed).', ha='center', fontsize=7.5)
fig.suptitle('Biomarker map — what IL-33 switches on in endothelium, what AX-1177 switches off, and what tracks outcome in patients', fontsize=11.5, y=0.955)
plt.savefig(os.path.join(FIG, 'fig5_biomarker_map.png'), bbox_inches='tight'); plt.close()

# ------------------------------------------------------------------------------------------------ Fig 3
nm = {'IL1RL1': 'sST2', 'TNFRSF11B': 'OPG', 'CXCL8': 'IL-8', 'CCL7': 'MCP-3', 'IL5': 'IL-5', 'CCL11': 'eotaxin-1', 'CCL17': 'TARC', 'TPSAB1': 'tryptase', 'CSF3': 'G-CSF', 'AGER': 'sRAGE', 'SELE': 'E-selectin', 'CSF1': 'M-CSF', 'IL6': 'IL-6', 'RNASE3': 'ECP',
      'IL4R': 'IL-4Rα', 'VWF': 'vWF', 'F3': 'tissue factor', 'HAVCR1': 'KIM-1', 'SPP1': 'OPN', 'CCL2': 'MCP-1', 'IL1B': 'IL-1β', 'IL18R1': 'IL-18R1', 'IL1R2': 'IL-1R2', 'GDF15': 'GDF-15', 'SFTPD': 'SP-D', 'CST3': 'cystatin C', 'KITLG': 'SCF'}
sig = set(prot.index[prot.sig05]); bgp = prot.sig05.mean(); zthr = prot.loc[prot.sig05, 'z_mean'].min()
sets = [
 ('Neutrophil activation / granule', '#ff7f0e', axes_members['Neutrophil activation / granule'], ['HGF', 'ANXA1', 'OSM', 'PRTN3', 'CXCL8', 'CSF3', 'CXCL1', 'CXCL6']),
 ('IL-33/ST2 axis & IL-1 family', '#d62728', axes_members['IL-33/ST2 axis & IL-1 family'], ['IL1RL1', 'IL18R1', 'IL1R2', 'IL1B', 'AGER', 'EGFR']),
 ('IL-33-induced & AX-1177-reversed\nin endothelium (data-derived)', '#2ca02c', list(prot.index[prot.core_up_any]), ['PTX3', 'IL6', 'TNFRSF11B', 'CCL20', 'CCL7', 'SELE', 'VCAM1', 'CXCL6', 'SOD2', 'F3']),
 ('IL-6 / myeloid cytokines', '#9467bd', axes_members['IL-6 / acute phase / myeloid cytokines'], ['IL6', 'OSM', 'CSF1', 'IFNG', 'TNF']),
 ('Lung epithelial injury / repair', '#8c564b', axes_members['Lung epithelial injury / remodelling'], ['AGR2', 'AREG', 'AGER', 'SFTPD']),
 ('Kidney / cardiac / organ injury', '#7f7f7f', axes_members['Kidney / cardiac / organ injury'], ['SPP1', 'GDF15', 'HAVCR1', 'CST3']),
 ('Endothelial injury / coagulation', '#17becf', axes_members['Endothelial activation / injury / coagulation'], ['PTX3', 'VWF', 'ANGPT2', 'F3', 'SELE', 'VCAM1', 'ICAM1']),
 ('Type-2 / eosinophil / mast cell', '#1f77b4', axes_members['Type-2 / eosinophil / mast cell'], ['IL5', 'CCL11', 'CCL17', 'TPSAB1', 'IL4R', 'RNASE3', 'KITLG']),
]
fig = plt.figure(figsize=(16, 11)); gs = fig.add_gridspec(2, 2, width_ratios=[1.35, 1], height_ratios=[1.15, 1], hspace=0.30, wspace=0.42)
ax = fig.add_subplot(gs[0, 0]); rng = np.random.default_rng(1); n = len(sets); ypos = {s[0]: n - i for i, s in enumerate(sets)}
ax.scatter(prot.z_mean, rng.normal(0, .16, len(prot)), s=4, c='#c8c8c8', alpha=.6, rasterized=True); tx = []
for name, c, g, labs in sets:
    g = [x for x in g if x in prot.index]; y0 = ypos[name]; jit = rng.uniform(-.22, .22, len(g)); z = prot.z_mean[g].values
    ax.scatter(z, y0 + jit, s=22, c=c, edgecolor='k', lw=.3, zorder=3)
    for gene in labs:
        if gene in g: i = g.index(gene); tx.append(ax.text(z[i], y0 + jit[i], nm.get(gene, gene), fontsize=7.3))
adjust_text(tx, ax=ax, arrowprops=dict(arrowstyle='-', color='k', lw=.4), expand=(1.05, 1.15))
ax.axvline(zthr, ls='--', c='k', lw=.7); ax.text(zthr + 0.03, n + 0.62, 'FDR 0.05', fontsize=7.5); ax.axvline(0, c='k', lw=.4)
ax.set_yticks([0] + [ypos[s[0]] for s in sets]); ax.set_yticklabels([f'All {len(prot):,} proteins'] + [s[0] for s in sets], fontsize=8.3); ax.set_ylim(-0.6, n + 0.8)
ax.set_xlabel('Association with ICU / ventilation / death within 30 d: Wald z (log OR ÷ SE; adj. age, sex, NEWS2)'); ax.set_title('A  Serum proteome vs deterioration, by biology (each dot = one protein)', loc='left', fontsize=10.5)
ax = fig.add_subplot(gs[0, 1]); rows = []
for name, c, g, _ in sets:
    g = set(x for x in g if x in prot.index); k = len(g & sig); m = len(g); o, p = stats.fisher_exact([[k, m - k], [len(sig) - k, len(prot) - len(sig) - (m - k)]])
    zin = prot.z_mean[list(g)]; zout = prot.z_mean[~prot.index.isin(g)]; rows.append((name, c, m, k, 100 * k / m, p, zin.median(), stats.mannwhitneyu(zin, zout).pvalue))
R = pd.DataFrame(rows, columns=['set', 'col', 'n', 'k', 'pct', 'p_fisher', 'median_z', 'p_ranksum']); y = np.arange(len(R))[::-1]
ax.barh(y, R.pct, color=R.col, alpha=.85); ax.axvline(100 * bgp, ls='--', c='k', lw=.8); ax.text(100 * bgp + 0.7, len(R) - 0.42, f'all proteins: {100*bgp:.0f}% ({len(sig)}/{len(prot):,})', fontsize=7.5)
for yi, (_, r) in zip(y, R.iterrows()): ax.text(r.pct + 1, yi, f"{int(r.k)}/{int(r.n)};  Fisher p={r.p_fisher:.2g};  median z {r.median_z:.2f} (rank-sum p={r.p_ranksum:.2g})", va='center', fontsize=7.4)
ax.set_yticks(y); ax.set_yticklabels(R.set, fontsize=8.3); ax.set_xlim(0, 118); ax.set_xlabel('% of proteins in set associated with deterioration (FDR<0.05, OR>1)'); ax.set_title('B  Share of each set that is outcome-associated', loc='left', fontsize=10.5)
ax = fig.add_subplot(gs[1, 0]); p = prot[prot.in_rnaseq]; c = p.core_up_any
ax.scatter(p.HUVEC_IL33_6h, p.z_mean, s=7, c='#c8c8c8', alpha=.7, rasterized=True)
ax.scatter(p.HUVEC_IL33_6h[c & ~p.sig05], p.z_mean[c & ~p.sig05], s=26, c='#98df8a', edgecolor='k', lw=.3, label=f'IL-33-induced & AX-1177-reversed; NOT outcome-associated (n={int((c & ~p.sig05).sum())})')
ax.scatter(p.HUVEC_IL33_6h[c & p.sig05], p.z_mean[c & p.sig05], s=34, c='#2ca02c', edgecolor='k', lw=.4, label=f'IL-33-induced & AX-1177-reversed AND outcome-associated (n={int((c & p.sig05).sum())})')
ax.scatter(p.HUVEC_IL33_6h['IL1RL1'], p.z_mean['IL1RL1'], s=90, c='#d62728', edgecolor='k', lw=.5, marker='*', label='sST2 (IL1RL1)')
rho = stats.spearmanr(p.HUVEC_IL33_6h, p.z_mean)
tx = [ax.text(p.HUVEC_IL33_6h[g], p.z_mean[g], nm.get(g, g), fontsize=7.5) for g in ['IL6', 'CXCL8', 'CCL20', 'TNFRSF11B', 'PTX3', 'CCL7', 'CSF1', 'IL1B', 'IL18R1', 'CSF3', 'CXCL1', 'CXCL6', 'VCAM1', 'SELE', 'ICAM1', 'CX3CL1', 'F3', 'CCL2', 'CXCL10', 'TNF', 'TNFRSF9', 'CXCL5', 'HGF', 'IL1RL1', 'CTSS', 'SOD2', 'KYNU'] if g in p.index]
adjust_text(tx, ax=ax, arrowprops=dict(arrowstyle='-', color='k', lw=.4))
ax.axhline(0, c='k', lw=.4); ax.axvline(0, c='k', lw=.4); ax.axhline(zthr, ls='--', c='k', lw=.6); ax.text(10.2, zthr + 0.07, 'FDR 0.05', fontsize=7)
ax.set_xlabel('Endothelial IL-33 response: HUVEC 6 h log2FC (IL-33 vs vehicle)'); ax.set_ylabel('Serum association with deterioration (Wald z)'); ax.set_title('C  Bridge: endothelial IL-33 response vs serum outcome association', loc='left', fontsize=10.5)
k_in = int((prot.core_up_any & prot.sig05).sum()); n_in = int(prot.core_up_any.sum()); pf = stats.fisher_exact([[k_in, n_in - k_in], [len(sig) - k_in, len(prot) - len(sig) - (n_in - k_in)]])[1]
ax.text(0.99, 0.02, f'{len(p)} proteins with RNA-seq data; Spearman ρ = {rho.correlation:.2f} (p = {rho.pvalue:.0e})\nset-level: {k_in}/{n_in} ({100*k_in/n_in:.0f}%) IL-33-inducible proteins outcome-associated vs {100*(len(sig)-k_in)/(len(prot)-n_in):.0f}% of the rest; Fisher p = {pf:.2f}', transform=ax.transAxes, ha='right', va='bottom', fontsize=7.6)
ax.legend(fontsize=7.2, frameon=False, loc='upper right', bbox_to_anchor=(1.0, 0.30))
ax = fig.add_subplot(gs[1, 1]); dup = ol[ol.duplicated('gene', keep=False)].copy(); pairs = []
for g, s in dup.groupby('gene'):
    s = s.sort_values('p.value')
    for i in range(1, len(s)): pairs.append((g, s.lnOR.iloc[0], s.lnOR.iloc[i]))
P = pd.DataFrame(pairs, columns=['gene', 'a', 'b']); ax.scatter(P.a, P.b, s=24, c='#1f77b4', edgecolor='k', lw=.3); ax.plot([-0.8, 2.05], [-0.8, 2.05], 'k--', lw=.7); r = np.corrcoef(P.a, P.b)[0, 1]
tx = [ax.text(P[P.gene == g].a.iloc[0], P[P.gene == g].b.iloc[0], nm.get(g, g), fontsize=7.5) for g in ['IL6', 'HGF', 'TNFRSF11B', 'CCL2', 'TNFRSF10A', 'VEGFA', 'KITLG', 'IL10', 'PLAU'] if (P.gene == g).any()]
adjust_text(tx, ax=ax, arrowprops=dict(arrowstyle='-', color='k', lw=.4))
ax.set_xlabel('log OR, same protein — panel with smallest p'); ax.set_ylabel('log OR, same protein — other panel(s)'); ax.set_title(f'D  QC: the {dup.gene.nunique()} proteins measured on >1 panel agree (r = {r:.2f})', loc='left', fontsize=10.5)
ax.text(0.97, 0.03, f'{len(ol):,} delivered assays = {len(prot):,} unique proteins.\n{int(((ol["adj.p.value"]<0.05)&(ol.OR>1)).sum())} of {int((ol["adj.p.value"]<0.05).sum())} FDR-significant assays have OR > 1:\na one-directional, severity-driven proteome.\nRank by z or p, not by OR — "per log unit" ORs are\nnot standardised (e.g. M-CSF OR 90, 95% CI 4–1,933).', transform=ax.transAxes, va='bottom', ha='right', fontsize=7.8)
plt.savefig(os.path.join(FIG, 'fig3_serum_proteomics.png'), bbox_inches='tight'); plt.close()

# ------------------------------------------------------------------------------------------------ Fig 4
cats = ['COVID neg non-pneumonia', 'COVID neg pneumonia', 'COVID pos pneumonia']
shortc = {c: c.replace('COVID neg non-pneumonia', 'COVID−\nno pneumonia').replace('COVID neg pneumonia', 'COVID−\npneumonia').replace('COVID pos pneumonia', 'COVID+\npneumonia') + f'\n(n={int((don.category==c).sum())})' for c in cats}
colors = {'COVID neg non-pneumonia': '#7f7f7f', 'COVID neg pneumonia': '#1f77b4', 'COVID pos pneumonia': '#d62728'}
fig, axes = plt.subplots(2, 3, figsize=(15, 9.2)); rng = np.random.default_rng(3)
def dots(ax, m, title):
    for i, c in enumerate(cats):
        v = don.loc[don.category == c, m].dropna(); nb = don.loc[v.index, 'n_blocks']
        ax.scatter(i + rng.uniform(-.18, .18, len(v)), v, s=18 + 10 * nb, c=colors[c], alpha=.8, edgecolor='k', lw=.4); ax.plot([i - .28, i + .28], [v.median(), v.median()], c='k', lw=2)
        ax.text(i, 6.08, f'median {v.median():.2f}', ha='center', va='top', fontsize=8)
    kw = stats.kruskal(*[don.loc[don.category == c, m].dropna() for c in cats]).pvalue
    ax.set_xticks(range(3)); ax.set_xticklabels([shortc[c] for c in cats], fontsize=8); ax.set_ylim(-0.3, 6.1); ax.axhline(5, ls=':', c='k', lw=.6)
    ax.set_ylabel('IHC score (donor mean of blocks)'); ax.set_title(f'{title}\nKruskal–Wallis p = {kw:.2f}', loc='left', fontsize=9.8)
dots(axes[0, 0], 'IL33_endo', 'A  IL-33, endothelium'); dots(axes[0, 1], 'IL33_epi', 'B  IL-33, bronchial/bronchiolar basal epithelium'); dots(axes[0, 2], 'IL33_vsm', 'C  IL-33, vascular smooth muscle')
dots(axes[1, 0], 'NE', 'D  Neutrophil elastase'); dots(axes[1, 1], 'EPX', 'E  Eosinophil peroxidase')
axes[0, 0].text(0.02, 0.03, 'dot size ∝ number of blocks (1–8); dotted line = stated top of scale (5);\nrecorded scores reach 5.5; group labels as delivered', transform=axes[0, 0].transAxes, fontsize=7.3)
ax = axes[1, 2]
for c in cats:
    s = don[don.category == c]; ax.scatter(s.NE + rng.uniform(-.06, .06, len(s)), s.IL33_endo + rng.uniform(-.04, .04, len(s)), s=45, c=colors[c], edgecolor='k', lw=.4, alpha=.85, label=shortc[c].replace('\n', ' '))
r = stats.spearmanr(don.NE, don.IL33_endo); b = np.polyfit(don.NE, don.IL33_endo, 1); xx = np.linspace(2.3, 5.2, 20); ax.plot(xx, np.polyval(b, xx), 'k--', lw=.8)
import statsmodels.formula.api as smf
pa = smf.ols('IL33_endo ~ NE + age + C(sex)', don).fit().pvalues['NE']
ax.set_xlabel('Neutrophil elastase score (donor mean)'); ax.set_ylabel('IL-33 endothelial score (donor mean)')
ax.set_title(f'F  More neutrophils, less endothelial IL-33\nSpearman ρ = {r.correlation:.2f}, p = {r.pvalue:.3f} (n = {len(don)} donors; exploratory;\nnot significant after age/sex adjustment, p = {pa:.2f})', loc='left', fontsize=9.8); ax.legend(fontsize=7.5, frameon=False, loc='lower left')
plt.tight_layout(); plt.savefig(os.path.join(FIG, 'fig4_postmortem_lung.png'), bbox_inches='tight'); plt.close()

# ------------------------------------------------------------------------------------------------ Fig 5
fig, axes = plt.subplots(1, 3, figsize=(16.5, 5.2)); ax = axes[0]; ok = ~d.model_p_unreliable
ax.scatter(d.AveExpr[ok], d.model_SE[ok], s=3, c='#c8c8c8', alpha=.4, rasterized=True, label=f'model SE follows the expression trend (n={int(ok.sum()):,})')
ax.scatter(d.AveExpr[~ok], d.model_SE[~ok], s=12, c='#d62728', alpha=.8, label=f'model SE inflated ≥4× over trend (n={int((~ok).sum())})')
offs = {'CXCL1': (8, 6), 'SELE': (-42, 10), 'VCAM1': (-48, -4), 'CXCL8': (8, -4), 'ICAM1': (8, -10), 'CCL2': (-30, -14), 'PTX3': (-34, 8), 'IL1RL1': (-46, 6), 'CD93': (8, 0), 'CDH5': (8, 4), 'VWF': (8, 4), 'PECAM1': (10, 10), 'GAPDH': (6, 8), 'KRT19': (8, 4), 'XBP1': (8, 4), 'PTGS2': (8, 6)}
for g, (dx, dy) in offs.items(): ax.annotate(g, (gv(g, 'AveExpr'), gv(g, 'model_SE')), xytext=(dx, dy), textcoords='offset points', fontsize=7.5, arrowprops=dict(arrowstyle='-', color='k', lw=.4))
ax.set_yscale('log'); ax.set_xlabel('Average log2 expression across all 114 libraries (AveExpr)'); ax.set_ylabel('Model standard error (logFC ÷ t), HUVEC IL-33 6 h contrast')
ax.set_title(f'A  One pooled model for 4 cell types breaks the error\n    estimate for {int((~ok).sum())} genes — including the canonical markers', loc='left', fontsize=10); ax.legend(fontsize=7.5, frameon=False, loc='upper left', bbox_to_anchor=(0.0, 0.93))
ax.text(0.98, 0.02, f'For the other {int(ok.sum()):,} genes the model SE equals the\nempirical noise of the antibody-alone (null) contrasts\n(median ratio {(d.empirical_noise_rms/d.model_SE)[ok].median():.2f}), so those p-values are usable.', transform=ax.transAxes, ha='right', va='bottom', fontsize=7.3)
ax = axes[1]; I = d.HUVEC_IL33_6h; N = d.HUVEC_AX1177_rev_6h; q = d.HUVEC_IL33_6h_adjP; model = (q < 0.05) & (I.abs() > 1); core = d.core_6h | d.core_down_6h; cv = model & core; ncv = model & ~core
ax.scatter(I[ncv], N[ncv], s=8, c='#ff7f0e', alpha=.6, label=f'"significant" vs vehicle, NOT reproduced vs isotype arm (n={int(ncv.sum())})'); ax.scatter(I[cv], N[cv], s=8, c='#1f77b4', alpha=.7, label=f'reproduced in the independent isotype-controlled contrast (n={int(cv.sum())})')
ax.plot([-5, 12], [5, -12], 'k--', lw=.7); ax.axhline(0, c='k', lw=.4); ax.axvline(0, c='k', lw=.4); ax.set_xlabel('IL-33 vs vehicle, HUVEC 6 h (log2FC)'); ax.set_ylabel('IL-33+AX-1177 vs IL-33+isotype (log2FC)')
ax.set_title('B  Half of the nominal IL-33 DEG list (adj.P<0.05, |log2FC|>1)\n    does not replicate in an arm-independent contrast', loc='left', fontsize=10); ax.legend(fontsize=7.2, frameon=False, loc='lower left')
ax = axes[2]; rows = []
for tp in ['6h', '24h']:
    r = res[tp]; rows.append((int(r['model_up'].sum()), int(r['cv_up'].sum()), int(r['resc_up'].sum()))); rows.append((int(r['model_dn'].sum()), int(r['cv_dn'].sum()), int(r['resc_dn'].sum())))
R = pd.DataFrame(rows, columns=['model', 'cv', 'rescued']); x = np.arange(len(R))
ax.bar(x - 0.2, R.model, width=0.4, color='#ff7f0e', label='model list (adj.P<0.05, |log2FC|>1)'); ax.bar(x + 0.2, R.cv, width=0.4, color='#1f77b4', label='cross-validated (also reversed by AX-1177 vs isotype arm)')
ax.bar(x + 0.2, R.rescued, width=0.4, bottom=R.cv, color='#d62728', label='rescued: large effect, model p broken by variance artefact')
for i, r in R.iterrows(): ax.text(i - 0.2, r.model + 8, str(r.model), ha='center', fontsize=8); ax.text(i + 0.2, r.cv + r.rescued + 8, f'{r.cv}+{r.rescued}' if r.rescued else str(r.cv), ha='center', fontsize=8)
ax.set_xticks(x); ax.set_xticklabels(['6 h\ninduced', '6 h\nrepressed', '24 h\ninduced', '24 h\nrepressed']); ax.set_ylabel('genes (HUVEC, IL-33 vs vehicle)'); ax.set_title('C  Working signature after cross-validation and rescue', loc='left', fontsize=10); ax.legend(fontsize=7.2, frameon=False)
plt.tight_layout(); plt.savefig(os.path.join(FIG, 'fig6_rnaseq_qc.png'), bbox_inches='tight'); plt.close()
print('figures written to', FIG)

# ------------------------------------------------------------------------------------------------ evidence chain (saved as fig1)
import json
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
K = json.load(open(os.path.join(OUT, 'tables', 'key_numbers.json')))
n6 = K['HUVEC_6h']['neutralisation_ge16fold']; n24 = K['HUVEC_24h']['neutralisation_ge16fold']; st2 = K['serum']['ST2']; pmk = K['postmortem']; nd = K['serum'].get('public_sets', {}).get('REACTOME_NEUTROPHIL_DEGRANULATION')
G, A, R = '#2ca02c', '#ff9f1c', '#d62728'
fig, ax = plt.subplots(figsize=(16, 7.4)); ax.set_xlim(-1.5, 101.7); ax.set_ylim(0, 100); ax.axis('off')
w, h, y0, gap = 13.6, 42, 33, 8.0; xs = [0.2 + i * (w + gap) for i in range(5)]; ym = y0 + h / 2
def box(x, title, body, col):
    ax.add_patch(FancyBboxPatch((x, y0), w, h, boxstyle='round,pad=0.3,rounding_size=1.2', fc='white', ec=col, lw=2.6))
    ax.text(x + w / 2, y0 + h - 2.0, title, ha='center', va='top', fontsize=10.5, fontweight='bold', linespacing=1.15)
    ax.text(x + w / 2, y0 + h - 16.5, body, ha='center', va='top', fontsize=8.2, linespacing=1.4)
def arrow(i, label, col, ls='-'):
    x0, x1 = xs[i] + w + 0.9, xs[i + 1] - 0.9
    ax.add_patch(FancyArrowPatch((x0, ym), (x1, ym), arrowstyle='-|>', mutation_scale=20, lw=2.6, color=col, linestyle=ls))
    ax.text((x0 + x1) / 2, ym + 4.5, label, ha='center', va='bottom', fontsize=8, color=col, fontweight='bold', linespacing=1.2)
box(xs[0], 'IL-33 stored\nin the lung', f"Tissue IHC: present in\nall {pmk['n_donors']} donors;\nendothelium richest\n(score ≥ 4.25 in {pmk['donors_endo_ge425']}/{pmk['n_donors']}).\nNot higher in diseased\nlung (p = {pmk['group_stats']['IL33_endo']['kruskal_p']:.2f}).", G)
box(xs[1], 'IL-33 released\nand active\nin patients', "NOT MEASURED.\nIL-33 assay was run\nbut not delivered;\nno bioactivity data.\nsST2 is only a proxy.", R)
box(xs[2], 'Endothelium\nactivated', f"{K['signature_sizes']['core6']} genes at 6 h:\nE-selectin, VCAM-1,\nCXCL1/6/8, G-CSF,\nGM-CSF, IL-6, tissue factor.\nShown in HUVEC and\nglomerular endothelium,\nnot in lung cells.", A)
box(xs[3], 'Neutrophils\nrecruited and\nactivated', "Tissue: elastase higher\nin pneumonia (p = {:.3f}).\nSerum: neutrophil-\ndegranulation proteins\ntrack outcome\n({:.0f} % vs {:.0f} % of panel).".format(pmk['group_stats']['NE']['p_anypneumonia_vs_nonpneumonia'], nd['pct'] if nd else float('nan'), K['serum']['background_pct_sig']), A)
box(xs[4], 'Deterioration:\nICU, ventilation\nor death', f"Serum, n = 100:\nsST2 is #2 of {K['serum']['bh_denominator']:,}\nassays (OR {st2['OR']:.2f},\nFDR {st2['fdr']:.3f}); IL-6, IL-8,\nCCL20, OPG also\nassociated.", A)
arrow(0, 'not\ntested', R, ls=(0, (4, 3))); arrow(1, 'shown\nin vitro', G); arrow(2, 'hypothesis,\nnot tested', R, ls=(0, (4, 3))); arrow(3, 'association,\nnot causal', A)
xb = xs[1] + w + gap / 2
ax.plot([xb, xb], [y0 - 8, ym - 3.0], color=G, lw=3.2); ax.plot([xb - 1.5, xb + 1.5], [ym - 3.0, ym - 3.0], color=G, lw=3.2)
ax.text(xb, y0 - 9.5, f"AX-1177 blocks this step: {n6['median_pct_reversed']:.0f} % reversal at 6 h (95 % CI {n6['ci95'][0]:.1f}–{n6['ci95'][1]:.1f}), {n24['median_pct_reversed']:.0f} % at 24 h;\nno effect on its own in 4 cell types. Tested only with simultaneous addition, one concentration.", ha='center', va='top', fontsize=8.8, color=G, fontweight='bold', linespacing=1.35)
ax.text(50, 98, 'AX-1177 evidence chain — what our data show at each link', ha='center', va='top', fontsize=14, fontweight='bold')
ax.text(50, 90.5, 'green = demonstrated in our data        amber = shown with limits, or association only        red = not in our data', ha='center', va='top', fontsize=9.5)
ax.text(85, 7, 'Type-2 / eosinophil route: no support in serum\n(IL-5 OR 1.00) or cells; at most marginal in tissue.', ha='center', va='center', fontsize=9, color='#555', style='italic', bbox=dict(boxstyle='round,pad=0.5', fc='#f3f3f3', ec='#bbb'))
ax.text(14, 7, 'Virus-specific route: no support — COVID+ and COVID−\npneumonia lungs do not differ on any IHC marker.', ha='center', va='center', fontsize=9, color='#555', style='italic', bbox=dict(boxstyle='round,pad=0.5', fc='#f3f3f3', ec='#bbb'))
plt.savefig(os.path.join(FIG, 'fig1_evidence_chain.png'), bbox_inches='tight'); plt.close()
print('evidence chain written')
