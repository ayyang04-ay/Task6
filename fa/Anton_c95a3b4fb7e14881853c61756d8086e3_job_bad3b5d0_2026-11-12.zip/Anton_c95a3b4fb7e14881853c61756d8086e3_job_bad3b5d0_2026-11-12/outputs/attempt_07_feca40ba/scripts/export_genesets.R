#!/usr/bin/env Rscript
# Exports the MSigDB gene sets used by ax1177_analysis.py (Hallmark + Reactome 'Neutrophil degranulation') from msigdbr 7.5.1.
# Usage: Rscript export_genesets.R [outdir]      (env used here: `mm renv Rscript export_genesets.R genesets`)
suppressMessages({library(msigdbr); library(dplyr)})
args <- commandArgs(trailingOnly = TRUE); out <- ifelse(length(args) >= 1, args[1], "genesets"); dir.create(out, showWarnings = FALSE)
h <- msigdbr(species = "Homo sapiens", category = "H")
write.table(h[, c("gs_name", "gene_symbol", "ensembl_gene")], file.path(out, "H.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
r <- msigdbr(species = "Homo sapiens", category = "C2", subcategory = "CP:REACTOME") %>% filter(gs_name %in% c("REACTOME_NEUTROPHIL_DEGRANULATION"))
write.table(r[, c("gs_name", "gene_symbol", "ensembl_gene")], file.path(out, "REACTOME_selected.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
cat("msigdbr", as.character(packageVersion("msigdbr")), ": wrote", nrow(h), "Hallmark rows and", nrow(r), "Reactome rows to", out, "\n")
