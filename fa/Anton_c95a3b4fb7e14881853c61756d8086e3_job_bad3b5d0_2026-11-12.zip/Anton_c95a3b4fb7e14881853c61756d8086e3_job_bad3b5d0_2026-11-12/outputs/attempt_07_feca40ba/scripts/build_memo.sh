#!/usr/bin/env bash
# Rebuilds the .docx and self-contained .html versions of the memo from the markdown (needs pandoc >= 3; here: `mm genomics pandoc`).
set -euo pipefail
cd "$(dirname "$0")/.."
PANDOC="${PANDOC:-micromamba run -n genomics pandoc}"
$PANDOC AX-1177_portfolio_recommendation.md -f markdown --reference-doc=scripts/memo_build/reference_landscape.docx -o AX-1177_portfolio_recommendation.docx
$PANDOC AX-1177_portfolio_recommendation.md -f markdown --standalone --embed-resources -V maxwidth=78em \
  --include-in-header=scripts/memo_build/style.html --metadata pagetitle="AX-1177 portfolio audit recommendation" -o AX-1177_portfolio_recommendation.html
echo "built docx + html"
