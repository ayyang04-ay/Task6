# AX-1177 portfolio audit — deliverables

| File | What it is |
|---|---|
| `AX-1177_portfolio_recommendation.md` / `.docx` / `.html` | The recommendation memo (same content in three formats; the `.html` is self-contained) |
| `figures/fig1_evidence_chain.png` | One-slide summary: what is shown, associated, or untested at each link from target to outcome |
| `figures/fig2_rnaseq_pharmacology.png` | IL-33 response and its reversal by AX-1177 in HUVEC/HGMEC; antibody alone; kinetics |
| `figures/fig3_serum_proteomics.png` | Serum proteome vs deterioration by biology; bridge to the endothelial IL-33 response; duplicate-assay QC |
| `figures/fig4_postmortem_lung.png` | Donor-level IL-33 IHC by compartment and group; neutrophil and eosinophil markers |
| `figures/fig5_biomarker_map.png` | Candidate markers: IL-33 induction, AX-1177 reversal, serum association, proposed role |
| `figures/fig6_rnaseq_qc.png` | Why the delivered RNA-seq statistics cannot be used as they are, and how the working signature was built |
| `tables/key_numbers.json` | Every number quoted in the memo, as produced by the scripts |
| `tables/biomarker_shortlist.csv` | 26 markers with cell, serum evidence, proposed role, readiness and caveat |
| `tables/rnaseq_IL33_AX1177_signature_induced.csv` | 464 IL-33-induced, AX-1177-reversed genes (6 h and/or 24 h), incl. the 69-gene pan-endothelial durable set |
| `tables/rnaseq_IL33_AX1177_signature_repressed.csv` | IL-33-repressed genes that replicate (not used for conclusions) |
| `tables/rnaseq_master_gene_table.csv` | All 26,210 genes: effects, adj.P, reversal, residual vs vehicle, noise estimates, reliability flags |
| `tables/rnaseq_contrast_summary.csv`, `rnaseq_signature_hallmark_enrichment.csv` | Per-contrast DEG counts; Hallmark enrichment of the signature |
| `tables/serum_proteomics_annotated_assay_level.csv`, `serum_proteomics_protein_level.csv`, `serum_axis_summary.csv` | Serum data mapped to genes, de-duplicated to 1,063 proteins, annotated with the endothelial IL-33 response; set-level tests |
| `tables/postmortem_blocks_tidy.csv`, `postmortem_donor_level.csv`, `postmortem_group_stats_donor_level.csv` | Tidy tissue data (hidden columns restored, donor fields filled), donor means, group tests incl. sensitivity analysis |
| `tables/data_integrity_log.csv` | 17 data issues: what, consequence, how handled |
| `scripts/ax1177_analysis.py`, `ax1177_figures.py`, `export_genesets.R`, `genesets/`, `build_memo.sh` | Reproducible pipeline (≈ 3 min): `python ax1177_analysis.py --data <dir> --out <dir>`, then `python ax1177_figures.py --out <dir>`; `build_memo.sh` rebuilds the .docx/.html from the markdown |
