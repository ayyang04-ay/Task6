# AX-1177 (anti-IL-33 mAb) — portfolio audit recommendation

**Basis:** the five delivered files only (methods annex, two RNA-seq contrast workbooks, serum proteomics, post-mortem lung IHC). Statements that rely on knowledge from outside these files are marked *(outside our data)*. Every number below is reproduced by `scripts/` and listed in `tables/key_numbers.json`.

---

## 1. Recommendation

**Keep AX-1177 — but re-scoped and stage-gated, not as currently framed.**

| | |
|-----------|------------------------------------------------------------------------------------------|
| **Keep** | The molecule. It does what it should: complete, clean neutralisation of IL-33 in primary human endothelium. |
| **Change** | The hypothesis. Nothing in our data is virus-specific and nothing is type-2/eosinophilic. What the data describe is an **sST2-high, neutrophil-dominant inflammatory endotype of acute lung injury in hospitalised severe pneumonia** — of which severe viral LRTI is one cause, not the defining feature — with vascular endothelium as the one site of drug action we have actually demonstrated. |
| **Gate** | Fund only the de-risking package in §5. The disease link today is one prognostic association (sST2) plus mechanism in non-lung endothelial cells. It is not yet evidence that blocking IL-33 changes outcome. |
| **Stop if** | (a) no AX-1177-neutralisable IL-33 activity can be shown in patient samples, or (b) AX-1177 does nothing once IL-33 exposure has already started (it has only been tested added together with IL-33), or (c) sST2 does not replicate as an independent enrichment marker. |

![Figure 1. Evidence chain: what our data show at each link between the target and the clinical outcome.](figures/fig1_evidence_chain.png){width=100%}

**Why not "drop":** neither the molecule nor the target has failed a test, and the open questions are cheap to answer — the first set with data and samples we already hold (§5, Stage 0).

**Why not "keep as is":** the current label (severe *viral* LRTI) is not what the evidence describes, and the package contains no lung-cell, no therapeutic-timing and no causal data.

---

## 2. The case for keeping — what the data show

| # | Finding | Key numbers | Confidence |
|----|----------------------|--------------------------------------------------------|---------------|
| 1 | **AX-1177 fully neutralises IL-33 in primary human endothelium.** | HUVEC, 6 h: the 69 genes induced ≥16-fold by IL-33 are reversed by a median **101 %** (95 % CI 98.5–101.8; IQR 95–103) versus the isotype-matched IL-33 arm; expression under IL-33 + AX-1177 is indistinguishable from vehicle (median residual +0.02 log2). 24 h: **92 %** (CI 84.5–94.3), NF-κB targets back at vehicle level. Antibody was added at the same time as IL-33, with no pre-incubation. | High, for the conditions tested (one concentration ≈ 41-fold molar excess; one donor per cell type) |
| 2 | **Same pharmacology in a second, microvascular bed.** | Glomerular endothelium (HGMEC), 6 h: 163 genes of the independently derived HUVEC signature are also suppressed by AX-1177 (of 236 suppressed in HGMEC overall; chance overlap ≈ 4). VCAM-1 −11.7, E-selectin −8.7, GM-CSF −7.1, CXCL1 −6.3 log2; amplitude ≈ 56 % of HUVEC. | Moderate (the IL-33 effect itself cannot be computed in HGMEC — no control contrast delivered) |
| 3 | **AX-1177 alone is silent.** | 16 antibody-alone contrasts in 4 cell types (HUVEC, HGMEC, A549, MCF7): 14–73 FDR hits each (0.15 % of tests), **none reproduced at both timepoints against isotype**; 99 % are low-count transcripts or sub-1.4-fold shifts of abundant genes; slope against the IL-33 signature −0.01. No agonism, no off-target programme, no effect of the IL-33:antibody complex beyond reversal. (A ≤ 0.2 log2 arm-level drift of abundant transcripts at 24 h is technical — §7.) | High at single-gene level |
| 4 | **What IL-33 switches on is a neutrophil-recruiting, pro-adhesive, pro-coagulant endothelial programme — not a type-2 programme.** | 424 induced genes at 6 h; 94 of 197 Hallmark "TNFα signalling via NF-κB" genes (9.4-fold enrichment, p = 3 × 10⁻⁷⁶). E-selectin +11.2 log2, GM-CSF +10.3, CXCL6 +9.4, CCL20 +9.2, VCAM-1 +8.7, G-CSF +8.3, IL-8 +8.2, CXCL1 +8.2, ICAM-1 +6.0, IL-6 +5.8, tissue factor +5.6; thrombomodulin −1.0. Eotaxins, TARC, IL-5, IL-13, periostin: not expressed or unchanged. | High |
| 5 | **The IL-33 receptor axis tracks deterioration in patients.** | Serum sST2 is the **2nd-strongest of 1,194 assays modelled** for ICU admission / ventilation / death in 100 hospitalised patients: OR 3.02 per log unit (95 % CI 1.83–5.01), p = 1.7 × 10⁻⁵, FDR 0.007, after adjustment for age, sex and NEWS2. It is the only IL-33-pathway-specific protein in the delivery; had it been the single pre-specified test it would stand without any multiplicity correction. | High that the association exists in this cohort; low that it is causal |
| 6 | **Several mediators that AX-1177 switches off in endothelium are the same ones that track deterioration.** | IL-6 (measured on four panels: OR 2.07–2.31, all FDR < 0.02), IL-8, CCL20, OPG, PTX3, MCP-3, M-CSF — each IL-33-induced, AX-1177-reversed *and* outcome-associated (FDR < 0.05). | Moderate (see §3, point 2) |
| 7 | **The target is present where it would need to be.** | IL-33 protein in lung endothelium of every donor (donor mean ≥ 4.25 on the nominal 0–5 scale in 30/31), basal airway epithelium (22/31) and vascular smooth muscle. Endothelium is the richest compartment. | High for presence; says nothing about activity |

![Figure 2. AX-1177 pharmacology in primary human endothelium (RNA-seq).](figures/fig2_rnaseq_pharmacology.png){width=100%}

---

## 3. What the data do not show — the challenges the committee will raise

1. **Association is not causation.** sST2 is a prognostic marker in our cohort; nothing we hold shows that removing IL-33 changes the course. sST2 is also a decoy receptor *(outside our data)*, so "high sST2" can mean "axis active" or "IL-33 already buffered".
2. **The bridge from mechanism to patients is real but not specific.** Of 74 serum proteins encoded by IL-33-induced, AX-1177-reversed genes, 15 (20 %) are outcome-associated versus 15 % of all other proteins (Fisher p = 0.25); the correlation between endothelial IL-33 inducibility and outcome association is weak (Spearman ρ = 0.15, p = 8 × 10⁻⁶, 915 proteins). The strongest IL-33-induced genes — G-CSF, CXCL1, CXCL5, CXCL6, VCAM-1, ICAM-1 — are **not** outcome-associated in serum.
3. **What dominates deterioration is neutrophil/myeloid activation that IL-33-stimulated endothelium does not itself produce.** Of the 93 measured proteins in the public Reactome "neutrophil degranulation" set, 25 (27 %) are outcome-associated against 16 % of the whole panel (p = 0.004; rank-sum p = 3 × 10⁻⁷); in my own 32-protein neutrophil-activation list it is 17 (53 %), but I assembled that list after seeing the ranking, so treat it as descriptive. The top protein, HGF, is not IL-33-regulated in our cells. Classical endothelial-injury markers are not enriched (4 of 60). IL-33 could sit upstream of neutrophil recruitment — that is the hypothesis, not a result.
4. **The drug target itself was never read out in patients.** IL-33 is on the vendor's Inflammation panel that was run *(panel content: outside our data)*, but it is not among the delivered assays. The file shows the filtering from the inside: adjusted p-values were computed over 1,194 assays while 1,094 are delivered, and IL-5 carries a duplicate-panel suffix (IL5-IMO) although its sister assay is absent. Why the 100 were withheld is not documented.
5. **IL-33 is not increased in diseased lung.** Median endothelial IL-33 score per donor: COVID+ pneumonia 4.81, COVID− pneumonia 5.50, no pneumonia 5.50 (Kruskal–Wallis p = 0.11). If anything it is lower where neutrophils are higher (ρ = −0.43, p = 0.016, exploratory; p = 0.11 after age/sex adjustment) — compatible with release of a stored alarmin or with loss on endothelial activation *(both outside our data)*; IHC cannot tell which.
6. **No lung cell was ever stimulated.** The functional data come from umbilical-vein and kidney-glomerular endothelium. A549 and MCF7 received antibody or vehicle only — no IL-33.
7. **The response is front-loaded.** By 24 h only 44 % of the 6-h amplitude remains in HUVEC and 23 % in HGMEC. We tested co-addition only; patients present after the trigger. Whether late blockade does anything is unknown.
8. **Single concentration, single donor per cell type, reduced IL-33 only.** No potency estimate; "n = 3 biological replicates" are replicate cultures from one donor; the claim that AX-1177 also covers oxidised IL-33 is untested, and the receptors reported for oxidised IL-33 *(outside our data)* give it no support in serum (sRAGE OR 2.3, FDR 0.16; EGFR OR 1.2, FDR 0.87).
9. **Host defence.** The programme AX-1177 removes (GM-CSF, G-CSF, CXCL chemokines, adhesion molecules) is how neutrophils reach infected tissue. Acute bronchopneumonia is recorded in 15 of 31 autopsies, including 9 of the 16 SARS-CoV-2-positive donors. Our data cannot say whether blocking this programme is safe.

Stating these first is the defence: the gated plan in §5 is built to answer each one.

![Figure 3. Serum proteome versus deterioration in 100 hospitalised patients, and the bridge to the endothelial IL-33 response.](figures/fig3_serum_proteomics.png){width=100%}

---

## 4. What indication do our data point at?

**Not a pathogen and not type-2 disease — an endotype.** The three datasets line up on one picture (the gaps between them are in §3):

* *Cells:* IL-33 switches on an endothelial programme for neutrophil recruitment (CXCL chemokines, G-CSF, GM-CSF, adhesion molecules) with a pro-coagulant shift — shown at transcript level, not yet by a functional assay; AX-1177 removes it.
* *Patients:* deterioration tracks sST2, the IL-1 family, IL-6 and neutrophil activation; the type-2 axis is flat — IL-5 OR 1.00 (0.66–1.52), eotaxin-1 1.08, TARC 0.85, eotaxin-2 0.92, PARC 1.05, tryptase 1.07; only 1 of the 21 type-2/eosinophil/mast-cell proteins measured (IL-4Rα) is outcome-associated, and as a group they sit *below* the rest of the proteome (median z 0.19 vs 1.38, p = 0.013).
* *Tissue:* pneumonia lungs are neutrophil-rich (elastase 4.25 vs 3.0 in non-pneumonia, p = 0.007) whether SARS-CoV-2-positive or not; COVID+ and COVID− pneumonia do not differ on any IHC marker — IL-33 in three compartments, neutrophil, eosinophil and mast-cell stains (smallest p = 0.15); eosinophil peroxidase does not differ between groups (p = 0.32). (The autopsy diagnoses do differ: diffuse alveolar damage in 7 of 16 COVID+ donors and none of the other 15, p = 0.007 — so this is a statement about the IL-33 axis and granulocytes, not about lung pathology in general.)

| Candidate indication | Support in our data | Verdict |
|--------------------------|--------------------------------------------------|--------------------|
| **sST2-high, neutrophil-dominant acute lung injury in hospitalised severe pneumonia (any pathogen), at risk of progression to ICU/ventilation** | All three datasets (mechanism, prognostic marker, tissue) — each with caveats | **Lead hypothesis.** The population our outcome data describe. |
| Severe *viral* LRTI as such (current label) | A subset of the above; no dataset shows virus specificity. Serum cohort is SARS-CoV-2 only, so non-viral pneumonia is untested rather than excluded | Retain as the entry population; select by biomarker, not by virus |
| Renal / glomerular microvascular inflammation | One dataset, but in the disease-relevant cell: glomerular endothelium mounts the same AX-1177-sensitive programme at 6 h, though it fades faster (23 % left at 24 h). No kidney tissue, no renal clinical data; kidney-injury markers in serum are not outcome-enriched (4/23; KIM-1 OR 1.7, FDR 0.11; cystatin C OR 1.4, FDR 0.34) | Secondary and unproven. One cheap test in Stage 0 (do sST2 and the PD panel track kidney injury in the patient-level data?); beyond that it needs its own disease evidence |
| Thrombo-inflammation read-out (not a stand-alone indication) | Tissue factor +5.6 log2 (50-fold) and reversed; thrombomodulin down; serum tissue factor OR 3.0 (FDR 0.051), vWF FDR 0.050; pulmonary thromboemboli in 4/16 COVID+ vs 0/15 other donors (p = 0.10) | Add as an exploratory endpoint |
| COPD / chronic airway disease | Not tested. 18 of 31 autopsy donors had COPD or emphysema and abundant epithelial IL-33, but there is no comparison group and no epithelial functional data | Cannot be argued from this package; would need airway-epithelial pharmacology and a COPD cohort |
| Type-2 / eosinophilic disease (asthma-like rationale) | No support in serum or cells; at most marginal, and series-confounded, in tissue (§7) | **Ruled out as a rationale on these data** |

![Figure 4. Post-mortem lung, donor level: IL-33 by compartment, neutrophil and eosinophil markers.](figures/fig4_postmortem_lung.png){width=100%}

---

## 5. Forward plan — what the next studies have to establish

| Stage | Must establish | Design (minimum) | Go | No-go |
|--------------|------------------------|------------------------------------|----------------|----------------|
| **0. Use what we already hold** (no new wet-lab work) | (i) The signature and neutralisation estimates survive a correct statistical model. (ii) sST2 carries information beyond IL-6 and NEWS2, and has a usable cut-off. (iii) Whether IL-33 was detectable at all. (iv) Whether diseased lung carries the AX-1177-reversible signature. (v) Whether the axis tracks kidney injury (the only inexpensive test of the renal hypothesis) | Refit RNA-seq per cell line from the archived counts; deliver the missing IL-33-vs-control contrast for HGMEC; confirm the "Vehicle/Nontreated" comparator. Obtain patient-level proteomics and the 100 withheld assays; multivariable and marker-by-marker covariation analysis, including against KIM-1/cystatin C and any recorded kidney outcomes. Score the 69-gene signature in the tissue RNA already logged for 22 autopsy blocks (sheet column "Tissue RNA") | Signature and ≥ 90 % reversal hold in the refit; sST2 independent of IL-6/NEWS2; Tier-1 PD proteins co-vary with sST2 | Signature does not survive the refit, or sST2 is fully explained by generic severity |
| **1. Lung relevance and therapeutic window** | The programme exists in human **lung** microvascular endothelium and airway epithelium; AX-1177 potency (IC50/IC90); whether it works when given **after** IL-33; whether oxidised IL-33 matters; that transcripts translate into protein and function | ≥ 3 donors per cell type; reduced and oxidised IL-33; single and repeated IL-33 exposure (to mimic ongoing release); antibody concentration–response; pre-, co- and delayed addition (+1, +2, +4 h); time course 1–48 h; secreted proteins, surface adhesion molecules, neutrophil adhesion/transmigration, barrier function, tissue-factor activity | ≥ 90 % suppression of the protein panel at exposures achievable in patients **and** ≥ 50 % suppression of the subsequent response when antibody is added ≥ 2 h after IL-33 | No benefit of delayed addition even under repeated exposure → the acute, already-hospitalised setting is not viable |
| **2. Causality in patient samples** | IL-33 is biologically active in the patients we would treat, and AX-1177 removes that activity; sST2 replicates, including outside COVID-19 | High-sensitivity assays for free reduced/oxidised IL-33 and IL-33:sST2 complex in banked sera (and airway samples); ex vivo bioassay — patient serum on endothelial cells ± AX-1177, signature read-out; independent cohort incl. influenza/RSV and bacterial pneumonia | A definable subgroup (expected: sST2-high) with AX-1177-neutralisable activity; sST2 replicates | No neutralisable activity in any subgroup |
| **3. In vivo proof of concept and host-defence safety** | Blocking IL-33 reduces neutrophilic lung injury without impairing pathogen clearance | Model that expresses human IL-33 or a validated surrogate antibody (species cross-reactivity is not in our data); injury model plus bacterial challenge | Less injury, clearance preserved | No benefit, or impaired clearance |

Thresholds are proposals to be agreed before the experiments are run.

---

## 6. Biomarkers, roles and sampling timepoint

**Sampling timepoint: 6 h.** At 6 h the signature is widest (424 vs 139 genes in HUVEC; 236 vs 34 in HGMEC), largest (24 h retains 44 % of the amplitude in HUVEC and 23 % in HGMEC) and neutralisation is estimated most tightly (101 %, CI 98.5–101.8, vs 92 %, CI 84.5–94.3). Use 24 h only for secreted-protein accumulation and durability. Nothing earlier than 6 h was sampled, so the true peak is unknown — add 1–2 h and 12 h next time. In patients, the only timepoint for which we hold data is **enrolment**, where the serum associations were measured — so that is the baseline/selection sample. Because the IL-33 response in cells is over its peak within a day, take the first on-treatment sample within 24 h (a proposal, not a data-derived value).

| Marker | Evidence in our data | Role | Into patients? |
|------------------|--------------------------------------|------------------------|------------------|
| **sST2** | Rank 2 of 1,194 for deterioration (OR 3.02). In HUVEC, *IL1RL1* rises 3-fold with IL-33 and is fully reversed, but not in HGMEC and the model p-value is unusable | **Prognostic enrichment / stratification at screening.** Candidate predictive marker — only a treatment-by-marker interaction can show that | **Yes, now.** Cut-off needs patient-level data |
| **IL-6, IL-8, CCL20, OPG** | Induced by IL-33 at 6 h and 24 h, reversed ≥ 84 % at both, reproduced in HGMEC, and outcome-associated in serum (FDR 0.012–0.023) | **Pharmacodynamic / response (Tier 1)** | **Yes**, as serial PD. Not IL-33-specific: interpret only as change versus placebo |
| PTX3, MCP-3, M-CSF | As above but 6 h only; serum FDR 0.012–0.037 | Early PD (Tier 1, transient) | Yes, early samples only |
| MCP-1, tissue factor, sE-selectin, fractalkine, uPA, PAI-1 | IL-33-induced and reversed; serum association borderline (FDR 0.05–0.16) | PD (Tier 2); tissue factor doubles as thrombo-inflammation read-out | Exploratory |
| GM-CSF, G-CSF, CXCL1, CXCL5, CXCL6, sVCAM-1, sICAM-1 | Largest IL-33 effects (up to 1,250-fold) and complete reversal, but no outcome association in serum (FDR 0.25–0.98; GM-CSF not delivered) | **Proximal mechanism PD** — in vitro, ex vivo, airway samples, early clinical pharmacology | Yes for mechanism; **not** for patient selection |
| 69-gene pan-endothelial signature | Induced at 6 h and 24 h in HUVEC and AX-1177-sensitive in HGMEC (`tables/rnaseq_IL33_AX1177_signature_induced.csv`) | Transcript read-out for cell, ex vivo serum-transfer and tissue-RNA work | No (needs cells or tissue) |
| HGF, neutrophil-granule proteins (PRTN3, resistin, CD177) | Strongest prognostic proteins; not IL-33-regulated in endothelium | Severity covariates; downstream monitoring of neutrophil activation; negative controls for IL-33 specificity | Yes, as covariates |
| Free IL-33 (reduced/oxidised), IL-33:sST2 complex | **Absent from our data** | **Target engagement — the missing marker** | Not yet; assay development is part of Stage 2 |
| Tissue IL-33 IHC | Present in every lung, endothelial score at ceiling in 39 of 74 blocks, no disease difference | — | **No** — does not discriminate, not obtainable in patients |
| IL-5, eotaxins, TARC, PARC, tryptase | No association with outcome; not induced by IL-33 | — | **No** |

Full list: `tables/biomarker_shortlist.csv`.

![Figure 5. Biomarker map: IL-33 induction and AX-1177 reversal in endothelium (left) against serum association with deterioration (right).](figures/fig5_biomarker_map.png){width=62%}

---

## 7. What I considered and ruled out

| Question | Test | Result |
|----------------------|----------------------|------------------------------------------|
| Is AX-1177 only a partial neutraliser? | % reversal on genes selected on IL-33 effect alone; residual versus vehicle | No. 101 % at 6 h, 92 % at 24 h; residual ≈ 0. A small late interferon-type module (CXCL10, MX2, OASL) is only ~74 % reversed at 24 h — worth one pre-incubation experiment |
| Does the antibody do anything by itself, or as a complex with IL-33? | 16 antibody-alone contrasts; genes ending away from vehicle under IL-33 + AX-1177 | No. Nothing reproducible (3–6 low-count genes per timepoint, none at both) |
| Is part of the "IL-33 response" not IL-33 (e.g. a contaminant)? | Genes up in all IL-33-containing arms including AX-1177 | No: 15 up vs 24 down at 6 h — symmetric noise |
| Does AX-1177 drive proliferation in glomerular endothelium? (1,032 FDR genes vs IL-33 alone at 24 h, led by MYC/E2F targets) | Same gene sets against the isotype arm and in antibody-alone contrasts; dependence on expression level | Not pharmacology on this evidence. It is a ≤ 0.2 log2 shift of *abundant* transcripts that tracks expression level, not pathway; it shrinks against the isotype arm (269 genes) and appears without IL-33 with **opposite sign in the two endothelial types** (MYC targets +0.10 log2 in HGMEC, −0.10 in HUVEC at 24 h; at most one gene individually significant). An arm-level technical offset — but add a direct proliferation read-out next time |
| Can the delivered p-values be used as they are? | Model SE versus empirical noise of the four antibody-alone endothelial contrasts | Not for 325 genes. One pooled model across four cell types gives, e.g., CXCL1 a standard error of 1,155 log2 units (empirical noise 0.20). E-selectin, VCAM-1, IL-8, CXCL1, MCP-1, PTX3 and *IL1RL1* all fail FDR for this reason alone. Rescued on effect size, empirical noise and replication |
| Is the IL-33 gene list reliable? | Replication in a contrast that shares no arm with IL-33-vs-vehicle | Half is not: 515 of 1,068 genes replicate at 6 h, and only 100 of 423 "repressed" genes. No conclusion rests on IL-33-repressed genes |
| Type-2 / eosinophil biology? | Serum type-2 proteins; IL-33-induced genes; tissue eosinophil markers | Absent in serum and cells. In tissue, eosinophil peroxidase does not differ between groups. Two other granule stains (EDN, MBP) are higher in pneumonia than in the five non-pneumonia donors (p ≈ 0.005), but at low scores (medians ≤ 1.75 of 5) and with no COVID+/COVID− difference; MBP staining also differs six-fold between block-ID series (p = 2 × 10⁻⁵), and within the one series that holds all non-pneumonia donors the difference is marginal (EDN p = 0.035, MBP p = 0.054). IL-5Rα staining follows neutrophil elastase (ρ = 0.89), not eosinophil peroxidase (ρ = 0.14) |
| Virus-specific biology? | COVID+ vs COVID− pneumonia lungs | No difference on any IHC marker (smallest p = 0.15), also when restricted to autopsy-documented pneumonia. Histology does differ (diffuse alveolar damage 7/16 vs 0/15) |
| Is IL-33 up-regulated in diseased lung? | Donor-level comparison: by label, by autopsy-documented injury, and within one block-ID series | No. Endothelial IL-33 is numerically lower with acute injury (4.88 vs 5.50; p = 0.054 by pathology, p = 0.048 within the series that holds all non-pneumonia donors); neutrophil elastase is higher in the same comparison (p = 0.002) |
| Is endothelial injury the outcome axis? | 60 endothelial/coagulation proteins | No: 4 of 60 outcome-associated (below background) |
| Kidney repositioning? | HGMEC; kidney-injury proteins | Mechanism only, transient; no disease evidence |
| Block-level tissue statistics? | Block versus donor-level test | Pseudo-replication: endothelial IL-33, COVID+ vs rest, p = 0.017 by block, 0.052 by donor. Donor level used throughout |
| Rank serum hits by odds ratio? | Duplicate assays; CI widths | No — "per log unit" is not standardised (M-CSF OR 90, CI 4–1,933). Ranked by z/p; 1,094 assays collapse to 1,063 proteins (167 associated) |

---

## 8. If the committee drops it anyway — what is being dropped, and why

* **What:** a pharmacologically validated anti-IL-33 antibody (complete neutralisation in two primary human endothelial beds, no intrinsic activity in four cell types), an AX-1177-reversible endothelial signature with serum-measurable read-outs, and a strong prognostic marker (sST2) in hospitalised respiratory infection.
* **Why a drop would be defensible:** the disease link is correlative; the target is not increased in diseased lung and was not measured in patients; the in vitro response is transient and was tested only with simultaneous dosing; there are no lung-cell, in vivo or host-defence data; the current indication label is not the one the data describe.
* **What should be kept regardless:** the sST2 finding and the Tier-1 PD panel are assets for the wider respiratory portfolio; the data-handling problems in §9 affect any programme analysed through the same pipeline.

---

## 9. Data issues that change interpretation

Full log with handling: `tables/data_integrity_log.csv`.

* **RNA-seq workbook:** the sheets named "6h" and "24h" are the same 24-contrast table with different Excel filters switched on. Opened in Excel, each shows a single contrast (HUVEC, IL-33 + AX-1177 vs IL-33 + isotype, at 6 h and 24 h respectively); the other 22 contrasts — every HGMEC, antibody-alone and epithelial contrast — are present but filtered out of view. Read by script, every contrast comes back twice. HUVEC sheet names say "Vehicle", row labels say "Nontreated".
* **RNA-seq statistics:** one linear model over 114 libraries and four cell types; 325 genes have unusable p-values (Figure 6A); arm-level drifts of abundant transcripts at 24 h (≤ 0.2 log2) make small "significant" effects uninterpretable — nothing here rests on effects below 2-fold. HGMEC has no vehicle arm.
* **Serum:** IL-33 and 99 other modelled assays are not delivered; two rows and the confidence-interval columns are hidden; 27 proteins are duplicated across panels; summary statistics only, so no cut-offs or multivariable analysis are possible; 35 % of assays are nominally associated and 176 of 178 significant assays point the same way — a severity-driven proteome in which single hits are not specific.
* **Post-mortem:** every IHC column, including all IL-33 data, is **hidden** in the sheet; donor fields are merged onto the first block (39 of 74 block rows have no disease category on a naive import); one IL-33 value is a typed-in formula, =(2+4.5)/2, so the scores are hand-averaged composites; scores reach 5.5 on a "0–5" scale; single reader; 1–8 blocks per donor; 4 of 10 "COVID-negative pneumonia" donors have no pneumonia in their autopsy diagnoses and 2 of 5 "non-pneumonia" donors do; there is no healthy-lung reference; one donor has no SARS-CoV-2 result; blocks fall into three ID series that are confounded with group, and MBP staining differs between them.

---

![Figure 6. Why the delivered RNA-seq statistics cannot be used as they are, and how the working signature was built.](figures/fig6_rnaseq_qc.png){width=100%}

---

## Appendix — methods in brief

* **RNA-seq.** 26 contrasts × 26,210 genes. Primary neutralisation contrast: IL-33 + AX-1177 vs IL-33 + isotype, which shares no arm with IL-33 vs vehicle, so agreement between the two is not a shared-arm artefact. Signature gene = adj.P < 0.05 and |log2FC| > 1 in both, opposite sign; empirical false-replication proxy (same sign in both) = 12 vs 515 genes at 6 h. Per-gene noise estimated from the four antibody-alone endothelial contrasts (true nulls; agrees with the model SE for 25,885 genes, median ratio 1.00); genes with model SE ≥ 4× the expression trend were rescued if |log2FC| > 2 and > 8.6 × empirical noise in both contrasts. Percent reversal computed on genes selected on the IL-33 contrast only; confidence intervals are bootstraps over genes and are descriptive (genes share arms). Residual = IL-33 + AX-1177 vs vehicle (algebraic sum of two delivered contrasts from the same model). HGMEC: AX-1177-sensitive component only; its two IL-33 comparisons share the AX-1177 arm, so the independent check is overlap with the HUVEC signature; HGMEC kinetics are computed on the HUVEC-defined signature.
* **Serum.** Wald z recomputed from OR and CI (matches delivered p). Assays mapped to genes and collapsed to 1,063 proteins; a-priori marker sets and the data-derived IL-33 set tested by Fisher exact and rank-sum against all other proteins. The marker sets are listed in `scripts/ax1177_analysis.py`; I assembled them from general knowledge *after* seeing the ranked table, so their p-values are descriptive, not confirmatory. The neutrophil result is therefore also reported for an independent public set (Reactome "neutrophil degranulation", MSigDB 7.5.1).
* **Post-mortem.** All columns read, donor fields forward-filled, block scores averaged per donor; rank-based tests at donor level (n = 31); sensitivity analysis regrouping donors by autopsy-documented acute pneumonia / lung injury.
* **Not done, and why.** No re-estimation of p-values from counts (counts not delivered); no patient-level modelling (summary statistics only); no formal pathway analysis of the serum data beyond set tests (the panel is a pre-selected 1,063-protein subset).

**Files.** `figures/` fig1–fig6 · `tables/` signature, biomarker shortlist, annotated serum and tissue tables, integrity log, key numbers · `scripts/` `ax1177_analysis.py`, `ax1177_figures.py`.
