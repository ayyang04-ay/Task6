# AX-1177 (anti-IL-33 antibody): portfolio audit assessment

*Basis: the four delivered data files and the methods annex. Every number below was recomputed from those files. External resources were used only to annotate genes and proteins. Where I use general knowledge or an inference, it is labelled as such.*

---

## 1. Recommendation

**Keep AX-1177, but re-scope it and put it behind gates. Do not keep it as an all-comers "severe lower respiratory viral infection" programme as currently framed.**

- **The molecule does what it was made to do.** In primary human endothelial cells, AX-1177 removes the response to IL-33: 308 genes change robustly with IL-33, and about 6 remain changed when AX-1177 is present, which is the noise level of the experiment. The antibody on its own changes nothing in four cell types.
- **The disease link is real but indirect, and it runs through the host response, not the virus.** The soluble IL-33 receptor (sST2) is the second-strongest predictor of intensive care, ventilation or death among 1,094 serum assays, and IL-33 protein is abundant in the lung endothelium of 30 of the 31 donors examined. But IL-33 itself was never shown to be raised: it is no higher in COVID-19 lungs than in other lungs, and it is missing from the serum table.
- **The missing evidence is cheap to get.** Most of it sits in material we already hold: archived counts, serum assays that were run but not delivered, stored serum, and lung RNA. That argues for gating the asset, not dropping it.

"Keep" here means: fund only the work in section 5, agree the stop criteria in advance, and commit no IND-enabling spend until the first two gates are passed.

This is a judgement, not a calculation. It would change to "drop" if the stored serum and archives turn out not to exist, or if the portfolio has no place for a biomarker-selected indication.

---

## 2. The case for keeping: what the data establish

### 2.1 AX-1177 neutralises IL-33 completely and specifically in human endothelium (Figure 1)

Design, from the annex: primary endothelial cells from umbilical vein (HUVEC) and kidney glomerulus (HGMEC); recombinant reduced IL-33 at 30 ng/mL (1.7 nM); AX-1177 or an isotype control at 10 µg/mL (68 nM, a 41-fold molar excess); antibody and IL-33 added together; RNA sequencing at 6 h and 24 h; three replicates per arm.

"Robustly changed" below means a p-value below 0.05 after adjustment for multiple testing, at least a 2-fold change, and a t-statistic beyond ±6. Contrasts in which nothing should change return 0–8 such genes, so that is the noise floor.

| Comparison | Robustly changed genes |
|---|---|
| IL-33 vs vehicle, HUVEC 6 h | **308** (272 up, 36 down) |
| IL-33 vs vehicle, HUVEC 24 h | 90 |
| AX-1177 + IL-33 vs vehicle, HUVEC 6 h / 24 h (what is left) | **6 / 2** * |
| Isotype + IL-33 vs IL-33 alone, HUVEC 6 h / 24 h | 6 / 1 * |
| AX-1177 alone vs isotype, PBS or DMSO: 20 comparisons, four cell types | 0–8 each |

\* Obtained by adding delivered contrasts; fold changes are exact, significance is approximate.

- **What IL-33 switches on.** An NF-κB programme (NFKBIA 8.8-fold, t = 44), neutrophil-attracting chemokines and growth factors (GM-CSF 1,260-fold, CXCL6 680-fold, CCL20 590-fold, G-CSF 320-fold, CXCL2, CXCL3, CXCL5), IL-6 (56-fold), and a pro-clotting switch (tissue factor up 50-fold, PAI-1 up 3.3-fold, thrombomodulin down 2-fold).
- **What AX-1177 does to it at 6 h.** 297 of the 308 genes (96%) are significantly reversed against isotype + IL-33. The median gene is reversed by 101%; pooled across genes, 96% of the response is removed (95% interval 93–99%).
- **At 24 h.** The IL-33 response has shrunk to less than half its 6 h size. AX-1177 reverses 81 of 90 genes and removes 77–89% of the response, depending on the comparator arm. What remains is a small interferon-type signal (CXCL10, OASL, IFIT1–3).
- **Second vascular bed.** In kidney glomerular endothelium, 226 of the same 308 genes (73%) are significantly reversed at 6 h, at roughly 55–60% of the HUVEC magnitude. At 24 h the effect is close to the noise floor (6 robust genes).
- **Specificity.** No gene is reproducibly changed by AX-1177 alone across independent arms, and no inflammatory gene set moves in a consistent direction. The isotype does not blunt IL-33.

Limits: one antibody concentration, one IL-33 concentration, antibody and cytokine added at the same moment, RNA only. Potency and affinity are in the biologics file, not in this delivery.

![Figure 1](figures/fig1_neutralisation.png)

*Figure 1. AX-1177 against IL-33 in primary endothelial cells. A–C: each point is a gene; points on the dashed line are fully reversed. Orange circles are the canonical activation markers whose p-values are unusable in the delivered model (section 8). D: number of robustly changed genes in each comparison. E: share of the IL-33 induction removed, per gene.*

### 2.2 IL-33 is abundant in human lung endothelium (Figure 2)

Post-mortem lung from 31 donors (74 tissue blocks), scored 0 to "5+" (coded 5.5).

- Endothelial IL-33 averages 5.0. Thirty of the 31 donors average 4.25 or higher (the other scores 3.0), and 39 of the 74 blocks sit at the scale maximum.
- Basal airway epithelium averages 4.45; vascular smooth muscle 2.8.

The target is present, in quantity, in the cell type where we have the pharmacology.

![Figure 2](figures/fig2_lung_ihc.png)

*Figure 2. Post-mortem lung, one point per donor, groups as labelled in the file. IL-33 is high in every group and not higher in COVID-19 pneumonia. Neutrophil elastase rises with pneumonia of either cause.*

### 2.3 The soluble IL-33 receptor predicts deterioration (Figure 3)

One hundred patients hospitalised with COVID-19; 44 reached the composite endpoint of intensive care, invasive ventilation or death within 30 days (group sizes inferred from the file's per-group columns; the annex does not give them). Each serum protein was tested with adjustment for age, sex and NEWS2 (National Early Warning Score 2).

- **sST2: odds ratio 3.02 per log unit (95% CI 1.83–5.01), p = 1.7 × 10⁻⁵.** It ranks second of 1,094 assays. Only sST2 and HGF survive a Bonferroni correction, the strictest adjustment for testing this many proteins.
- Three secreted products that IL-33 induces in endothelium and AX-1177 reverses are also tied to outcome: **IL-6** (four independent assays, odds ratios 2.07–2.31), **CCL20** (1.83) and **OPG** (6.8 and 4.4 on two panels).

That "ST2" on the Olink panel is the soluble IL-33 receptor is general knowledge; the annex does not say so.

![Figure 3](figures/fig3_serum_proteomics.png)

*Figure 3. Serum proteins against the composite endpoint. A: all 1,094 delivered assays. B: selected proteins with odds ratios and 95% intervals.*

### 2.4 The three data sets describe the same biology

- **Endothelium and neutrophils, not type-2 inflammation.** Genes for neutrophil chemotaxis are 45-fold over-represented in the 68-gene core signature. In lung tissue, neutrophil elastase is higher in pneumonia than without it (3.55–3.58 vs 2.50, p = 0.007; 3.67 vs 2.74, p = 0.002, when donors are re-grouped by what the pathology text says). In serum, neutrophil and myeloid activation proteins sit among the leading hits (proteinase 3, CD177, resistin, IL-8).
- **The COVID-19 lungs show vascular injury.** The pathology text records pulmonary thromboemboli in 4 of the 16 COVID-positive donors and diffuse alveolar damage or acute lung injury in 7, against none of the 15 COVID-negative donors. In cells, IL-33 pushes endothelium towards clotting (tissue factor up, thrombomodulin down) and AX-1177 reverses it.
- **Type-2 markers are flat.** IL-5 odds ratio 1.00, eotaxin-1 1.08, eotaxin-2 0.92, TARC 0.85, tryptase 1.07.

---

## 3. Where the case is weak, and how to answer

| The committee will ask | What our data say | Answer |
|---|---|---|
| Is IL-33 raised in these patients? | Not shown. Lung IL-33 is no higher in COVID-19 pneumonia than in COVID-negative pneumonia (endothelium 4.81 vs 5.19, p = 0.16) or than in lungs without pneumonia (5.38). Adjusted for age and sex, the COVID-19 difference is −0.21 (95% CI −0.60 to +0.18). IL-33 is one of the 92 assays on the standard Inflammation panel (general knowledge of the panel) but is not in the delivered table. | We have the receptor, not the ligand. Measuring IL-33 in stored serum is the first gate. |
| Is sST2 just a marker of being sick? | It is independent of age, sex and NEWS2. But two other soluble IL-1-family receptors are tied to outcome as well (IL-1R2 odds ratio 4.5, IL-18R1 6.1). | sST2 is a strong prognostic marker. It is not proof that IL-33 drives the disease. |
| Do IL-33's endothelial targets show up in patients' blood? | Weakly. The rank correlation between a gene's IL-33 response and its protein's association with outcome is 0.15. Of 50 robust targets measured in serum, 11 (22%) are outcome-associated against 17% of all other proteins (p = 0.34). | Consistent with an IL-33 footprint, not specific to one. IL-1 and TNF induce the same kind of programme (general knowledge). |
| Why umbilical-vein and kidney endothelium for a lung programme? | No lung cell was ever exposed to IL-33. The two epithelial lines (A549, MCF7) received antibody only. | The mechanism holds in two vascular beds. Lung microvascular endothelium is the first new experiment. |
| Would it work in a patient, where the antibody arrives after IL-33? | Untested. Antibody and IL-33 were added together, at a 41-fold excess. | Delayed addition and a dose titration are in the plan. |
| The antibody binds oxidised IL-33 too. Does that matter? | Untested. Only reduced IL-33 was used. | No claim can be made for the oxidised form from this data. |
| How solid is the cell work? | One donor per endothelial type, three replicates, RNA only, no protein or functional read-out. | Enough to show mechanism. Not enough to set a dose or predict efficacy. |
| Could blocking IL-33 during an infection do harm? | IL-33 also switches on interferon-response genes in endothelium (Hallmark interferon-α set, enrichment score +2.7), and AX-1177 removes most of that. There are no data on viral control. | Unknown. It is a question for the in-vivo work. |

Not in the delivery at all, so not assessed: in-vivo efficacy, pharmacokinetics, safety, manufacturability, and the competitive and commercial position.

![Figure 4](figures/fig4_biomarker_triangulation.png)

*Figure 4. Each point is a protein measured in serum whose gene is also in the RNA-seq. Horizontal axis: what IL-33 does to the transcript in endothelium. Vertical axis: how strongly the serum protein tracks deterioration. Dark blue: supported in both data sets.*

---

## 4. The indication the data point at

**Patients hospitalised with severe pneumonia who are at risk of progressing to respiratory failure, selected by high sST2 at admission. The population is defined by the host response, not by the pathogen. The mechanism is IL-33-driven activation of vascular endothelium.**

Severe viral infection stays the lead setting, because it is the only one with clinical data. What changes is how the population is drawn. Whether non-viral pneumonia belongs in it is open, and Gate A decides it.

| Element | Evidence in our data | Strength |
|---|---|---|
| Host response rather than virus | For: IL-33 and granulocyte staining do not differ between COVID-positive and COVID-negative pneumonia (twelve read-outs, every p ≥ 0.15). Secreted antiviral proteins do not track outcome (IFN-γ odds ratio 1.03, CXCL10 1.30, IFN-λ1 1.28; none significant); inflammatory and myeloid proteins do. Against: diffuse alveolar damage and thromboemboli are recorded only in COVID-positive donors, and the serum cohort is COVID-19 only. | Moderate for defining the population by host response. Open for including non-viral pneumonia. |
| Endothelium | Two endothelial cell types respond and are rescued. Endothelium carries the highest IL-33 score in lung. Thromboemboli in 4 of 16 COVID-positive lungs. Serum shows a partial endothelial-injury signal (PTX3, VEGF-A, uPAR significant; von Willebrand factor, tissue factor and angiopoietin-2 borderline; ICAM-1, VCAM-1 and thrombomodulin not). | Moderate. |
| sST2 as the selection marker | Second of 1,094 assays, survives Bonferroni. | Strong as a prognostic marker. Untested as a predictor of drug benefit. |
| IL-33 as the driver | None directly. | Weak. This is the gap the gates address. |

The data do not point at asthma or other type-2 disease, at COPD, or at kidney disease (section 7).

---

## 5. What the next studies have to establish

Four statements are not yet supported and each needs to become true:

1. **IL-33 is released and active in the patients we would treat.** Today: not shown.
2. **Lung endothelium responds as umbilical and kidney endothelium do, and AX-1177 blocks it when given after the insult, at achievable concentrations.** Today: other vascular beds, simultaneous addition, one dose.
3. **The endothelial IL-33 programme is switched on in diseased human lung and tracks sST2.** Today: protein presence only, and a weak serum overlap.
4. **Blocking IL-33 changes an outcome-relevant function in vivo.** Today: nothing.

### Plan

| Step | Work | Establishes |
|---|---|---|
| **0. Desk work on data we hold** | (a) Re-fit the RNA-seq per cell line from the archived counts and extract the contrasts that were never delivered: IL-33 vs control in HGMEC, AX-1177 + IL-33 vs vehicle, isotype + IL-33 vs isotype. (b) Retrieve the 100 serum assays that were tested but not delivered, with detection rates. (c) Re-run the sST2 model with IL-6 included and derive a cut-off from patient-level data. (d) Score the 68-gene signature in lung tissue RNA; the lung file records a tissue-RNA sample ID for 22 of the 31 donors. | Valid statistics for the canonical markers and the ST2 transcript. Whether IL-33 was measurable. Whether sST2 adds to IL-6. Statement 3 in tissue. |
| **Gate A. Target in patients** | High-sensitivity assay for IL-33, free and bound to sST2, in the stored serum of the 100 patients. Replicate sST2, IL-6, CCL20 and OPG in an independent cohort that includes non-COVID viral and bacterial pneumonia. | Statements 1 and 3. |
| **Gate B. Disease-relevant pharmacology** | Primary human lung microvascular endothelium from at least three donors. Titrate IL-33 and AX-1177. Add antibody before, with, and 1–4 h after IL-33. Test reduced and oxidised IL-33. Read RNA at 6 h and secreted protein at 6 h and 24 h. Add functional read-outs: neutrophil adhesion and transmigration, barrier integrity, tissue-factor activity. Then test whether supernatant from injured or virus-infected airway epithelium activates endothelium in a way AX-1177 blocks. | Statement 2, and the unproven link between infection and IL-33-driven endothelial activation. |
| **Gate C. In vivo** | Proof of mechanism in an animal model, using the Gate B markers. Design is outside what this data can inform. | Statement 4. |

### Stop criteria, to agree now

- IL-33, free or bound to sST2, is not measurable above background in patient serum, or shows no relation to sST2 or outcome.
- sST2 loses its association once IL-6 is in the model, or fails in the independent cohort.
- Lung microvascular endothelium does not mount the response, or AX-1177 added 1–4 h after IL-33 does not shut it down.
- Supernatant from injured epithelium activates endothelium in a way AX-1177 does not block.

---

## 6. Biomarkers, sampling time, and roles

### Sampling time

- **In cells: 6 h.** The response is 308 genes at 6 h against 90 at 24 h. Neutralisation replicates in the second endothelial type at 6 h (226 of 308 genes) but is near noise there at 24 h. By 24 h TNF is back to baseline and tissue factor has fallen from 50-fold to 2-fold.
- **24 h is secondary**, for secreted-protein accumulation, and only for the markers that are still induced: GM-CSF, G-CSF, CXCL5, CXCL6, CCL20. Protein timing is my inference; the delivery holds no protein data from cells.
- **In patients: serum at enrolment, before dosing.** That is the only time point at which any marker has been shown to carry information. On-treatment timing is unknown and needs serial sampling in the first patient study.

### Markers and roles

| Marker | In cells: IL-33 effect → with AX-1177 (HUVEC 6 h) | In patient serum (odds ratio, adjusted p) | Role |
|---|---|---|---|
| **sST2** | Transcript up 3-fold → back to baseline; p-value unusable (section 8) | 3.02, 0.007 | **Patients: selection and stratification at enrolment.** Prognostic. Not shown to predict benefit or to move with drug. |
| **IL-6** | Up 56-fold → fully reversed | 2.07–2.31 on four assays, 0.012–0.019 | **Patients: pharmacodynamic marker**, and a prognostic covariate. Not specific to IL-33. |
| **CCL20** | Up 590-fold → fully reversed; sustained at 24 h | 1.83, 0.020 | **Patients: pharmacodynamic marker.** |
| **OPG (TNFRSF11B)** | Up 28-fold → fully reversed | 6.8 and 4.4, 0.014 and 0.020 | **Patients: pharmacodynamic marker.** |
| M-CSF, IL-18R1, cathepsin S, IL-1β | Up 4- to 13-fold → fully reversed | All < 0.05; M-CSF interval very wide | Patients: exploratory pharmacodynamic markers. |
| G-CSF, CXCL5, CXCL6 | Up 40- to 680-fold → fully reversed; sustained at 24 h | 1.0–1.25, not significant | Cell potency read-outs. In patients, exploratory evidence of pathway engagement only. |
| **GM-CSF** | Up 1,260-fold → fully reversed, both cell types, both times | Not in the serum table | **Lead read-out for the cell potency assay.** Patient use unknown. |
| Tissue factor, thrombomodulin, PAI-1 | Pro-clotting switch → reversed | Tissue factor 3.0, 0.051 | Functional read-outs in cells. Exploratory in patients. |
| E-selectin, VCAM-1, ICAM-1, IL-8, CXCL1, MCP-1, PTX3 | Up 4- to 2,400-fold → mirrored by AX-1177, but p-values unusable | IL-8 and PTX3 significant | **On hold** until the RNA-seq is re-fitted. |
| IL-33, free and bound to sST2 | n/a | Not in the delivered table | **Target engagement in patients. Needed; no assay data exist.** |
| Type-2 markers (IL-5, eotaxins, TARC) | n/a | 0.85–1.08, not significant | Not recommended. |
| Lung IL-33 staining | n/a | n/a | Not recommended for selection: near the ceiling in every donor. |

---

## 7. What I considered and ruled out

| Option or reading | Verdict | Why |
|---|---|---|
| Keep as an all-comers severe viral infection asset, unchanged | Ruled out | Nothing we measured around IL-33 is virus-specific. The one clinical signal is a host-response marker, sST2, so the population should be drawn by it (section 4). |
| Drop outright | Not recommended | The evidence against the indication is absent, not negative, and most of it can be obtained from existing material. The drop narrative is in section 9. |
| Asthma or other type-2, eosinophilic disease | Ruled out on our data | Type-2 serum markers are flat. Lung IL-33 does not track eosinophil granule proteins (correlations −0.20 to +0.08). The cell system contains no type-2 cells. |
| COPD | Not supported | Lung IL-33 does not differ by recorded COPD (11 donors vs 20; p = 0.21–0.59). No COPD cohort. Airway epithelium was never exposed to IL-33, reduced or oxidised. |
| Kidney disease | Logged, not pursued | The only evidence is the response of one kidney endothelial cell type. Serum kidney-injury markers are not outcome-associated after correction (KIM-1 p = 0.03 and 0.07; cystatin C p = 0.18). No kidney tissue. |
| Pulmonary fibrosis | Not supported | Three donors. |
| Lung IL-33 staining as the rationale or as a selection marker | Ruled out | At the ceiling in every group; not higher in disease. |
| Lower IL-33 staining in inflamed lung as a sign of IL-33 release | Not used | Endothelial IL-33 is lower where neutrophil elastase is higher (rank correlation −0.43, p = 0.02, 31 donors). Release of a stored protein and loss of the cells that hold it look the same on a stain. |
| sST2 as evidence that IL-33 is raised | Ruled out | Two other soluble IL-1-family receptors are tied to outcome as well, and IL-33 itself is not in the table. |
| E-selectin, VCAM-1, ICAM-1, IL-8 as lead biomarkers | Parked | They top the delivered list by fold change but carry no usable p-value. |
| 24 h as the main sampling time | Ruled out | Smaller response, not reproduced in the second cell type. |
| Genes changed by antibody alone as off-target or safety signals | Ruled out | Low-count noise; none reproduces across arms. |

---

## 8. Data notes that affect how far the numbers can be pushed

**Hidden content. All of it was read.**

- The contrasts workbook shows one contrast per tab; a filter hides the other 23. Both tabs hold the same 24 contrasts at both time points, so the tab names "6h" and "24h" are misleading.
- The three IL-33 staining columns in the lung file are hidden, along with nine others.
- Two rows (second-panel measurements of HGF and IL-6) and the lower confidence bound are hidden in the serum file.

**Gaps**

- No IL-33-vs-control contrast exists for the kidney endothelial cells. Their IL-33 response is inferred from what AX-1177 removes.
- Serum adjusted p-values were computed over 1,194 tests; 1,094 were delivered. About 4 of the 100 undelivered assays met the 5% threshold, the strongest with p between 0.0002 and 0.0003. The file cannot show which assays those are. Fifteen Inflammation-panel assays are absent, including IL-33, TSLP, IL-4 and IL-13. The two undocumented columns in the file look like detection-failure rates, which suggests these assays were removed for poor detection; that is my inference.

**Statistics**

- **For 282 genes the RNA-seq p-values in endothelial contrasts are unusable (Figure 5).** The model's standard error is more than 5 times the scatter seen across eight contrasts in which nothing should change (median 20 times). The set includes SELE, VCAM1, ICAM1, CXCL8, CXCL1, CCL2, PTX3, IL1RL1 and NOS3. Their fold changes are 8 to 43 times that scatter and are mirrored by AX-1177, so the effects are very probably real. I have kept them out of the supported list until the data are re-fitted per cell line.

![Figure 5](figures/fig5_qc_variance_inflation.png)

*Figure 5. Model standard error against observed scatter, one point per gene. Grey points lie on the diagonal: the model is sound for them. Orange circles are the 282 genes whose standard error is inflated.*

- Contrasts with no expected effect still return 14–73 genes at adjusted p < 0.05, nearly all low-count genes. Counts at that threshold alone overstate every effect, which is why the stricter definition is used throughout.
- The delivered sheets are sorted by fold change. Three or four of the top 40 genes on each are not significant.
- Serum odds ratios are "per log unit" with the base unstated, and intervals are very wide for narrow-range assays (M-CSF 4.2–1,933). Proteins were ranked by p-value, not by odds ratio.

**Cohorts**

- Serum: one centre, 100 patients, COVID-19 only, before vaccination. No adjustment for treatment, comorbidity or time since symptom onset.
- Lung: donors aged 64–98. Three donors supply 24 of the 49 COVID-positive blocks, so donors, not blocks, are the unit of analysis. One reader; more than half of the endothelial scores sit at the maximum.
- Several lung group labels disagree with the pathology text, and the "no pneumonia" group is not normal lung (fibrosis, organising pneumonia, fungal infection). Re-grouping donors by the text leaves the conclusions unchanged: IL-33 is not higher with pneumonia (endothelium 4.89 vs 5.35), neutrophil elastase is (p = 0.002), and COVID-positive and COVID-negative pneumonia do not differ. The one exception is the eosinophil-protein difference between pneumonia and no pneumonia, which disappears, so I do not rely on it.

The full list, with cell references, is in the `file_observations` sheet of the workbook.

---

## 9. If the committee decides to drop

**What we would be dropping:** a clean, on-mechanism anti-IL-33 antibody that fully neutralises IL-33-driven endothelial activation in two human vascular beds and has no detectable activity of its own.

**Why:** our human data do not show that IL-33 itself is raised or causal in severe viral lung infection. Lung IL-33 is not disease-specific. The clinical link rests on sST2, a prognostic marker that is not specific to IL-33. The cell work uses neither lung cells nor a disease-relevant stimulus.

**What we would not be able to say:** that the asset failed. No experiment in the package tested the disease hypothesis and came back negative.

---

## Appendix: how the numbers were produced

- **RNA-seq.** All 26 delivered contrasts (24 in the contrasts workbook, hidden rows included, plus IL-33 vs vehicle at two time points) were read for 26,210 genes. Contrasts not delivered were derived by adding or subtracting delivered ones, which is exact for fold changes because every contrast comes from the same model. Their significance was approximated from the standard errors of the component contrasts.
- **Reversal.** Per gene, the AX-1177 effect divided by the IL-33 effect, using the isotype-controlled contrast so that the two share no arm. Pooled estimates carry bootstrap 95% intervals over genes.
- **Standard-error check.** For each gene, the model standard error was compared with the root-mean-square fold change across eight endothelial contrasts in which no effect is expected. For 25,928 genes the ratio has a median of 1.00.
- **Serum.** Wald z-scores were recomputed from the odds ratios and confidence intervals and match the delivered p-values. Olink assay names were mapped to gene symbols by hand; 145 of the 1,063 proteins have no RNA-seq row because the gene was filtered as unexpressed. Gene symbols in the RNA-seq tables are out of date for some rows (LTBR, THOP1 and MRC2 sit under clone-based names), so joins were checked on Ensembl ID.
- **Lung.** Donor-level fields were filled down from merged cells. "N+" scores were read as N + 0.5, as the sheet's own numeric columns do. Each donor's blocks were averaged; groups were compared by Mann–Whitney and Kruskal–Wallis tests, with a linear model for age and sex.
- **Gene sets.** MSigDB Hallmark and Reactome (pre-ranked enrichment on t-statistics) and Gene Ontology (over-representation).
- **External resources.** MSigDB gene sets, org.Hs.eg.db gene symbols and the standard content of the Olink panels. They were used for annotation only.

## Files

- `AX-1177_portfolio_assessment.html` — this report with figures embedded.
- `AX-1177_supporting_tables.xlsx` — 17 sheets: marker shortlist, per-contrast counts, the 68-gene signature, serum-to-RNA join, lung tables, file observations.
- `figures/` — Figures 1–5 as PNG.
