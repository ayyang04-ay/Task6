#!/usr/bin/env python
"""Step 3 - post-mortem lung IHC. One row per histology block; donor-level fields sit in merged cells on one row per donor.
The donor (not the block) is the unit of analysis. Run: micromamba run -n singlecell python 03_lung.py /tmp/world/filesystem /tmp/work /tmp/outputs
"""
import sys, re, json, warnings
import numpy as np, pandas as pd, openpyxl
from scipy import stats
import statsmodels.formula.api as smf
warnings.filterwarnings("ignore")
SRC = sys.argv[1] if len(sys.argv) > 1 else "/tmp/world/filesystem"
WORK = sys.argv[2] if len(sys.argv) > 2 else "/tmp/work"
OUT = sys.argv[3] if len(sys.argv) > 3 else "/tmp/outputs"
KEY = {}
ws = openpyxl.load_workbook(f"{SRC}/AX-1177_postmortem_lung.xlsx").worksheets[0]      # formulas preserved on purpose
names = ["sample_id", "block_id", "tissue_rna_id", "sample_id_dup", "lobe", "disease_category", "race", "sex", "age", "sars_cov_2", "pathology", "he_eosinophils",
         "EPX_ihc", "EDN_ihc", "MBP_ihc", "2D7_ihc", "IL5Ra_duplexNE", "NE_duplexIL5Ra", "IL5Ra_duplexTryp", "Tryp_duplexIL5Ra", "EPX", "NE", "Tryptase",
         "IL33_epithelium", "IL33_endothelium", "IL33_vsmc", "lung_conditions_note", "unused"]
rows = []
for r in ws.iter_rows(min_row=2, max_row=ws.max_row):
    v = [c.value for c in r]
    if any(x is not None for x in v):
        rows.append(dict(zip(names, v), xl_row=r[0].row))
b = pd.DataFrame(rows)
KEY["n_blocks"] = int(len(b)); KEY["n_merged_cell_ranges"] = int(len(ws.merged_cells.ranges))
num = ["EPX", "NE", "Tryptase", "IL33_epithelium", "IL33_endothelium", "IL33_vsmc"]
KEY["formula_cells"] = [f"{c}@row{r.xl_row}: {r[c]}" for _, r in b.iterrows() for c in num if isinstance(r[c], str) and r[c].startswith("=")]
KEY["non_numeric_entries"] = {c: b[c].map(lambda x: x if isinstance(x, str) and not x.startswith("=") else None).dropna().value_counts().to_dict() for c in num}
def tonum(x):
    if isinstance(x, str):
        if x.startswith("="): return float(eval(x[1:]))          # the single formula cell '=(2+4.5)/2'
        return np.nan                                            # 'N/A', 'ND'
    return x
for c in num: b[c] = b[c].map(tonum).astype(float)
b["donor"] = b.sample_id.astype(str).str.strip()
KEY["id_type_mismatch_rows"] = [int(r.xl_row) for _, r in b.iterrows() if type(r.sample_id) != type(r.sample_id_dup)]
dfields = ["disease_category", "race", "sex", "age", "sars_cov_2", "pathology", "lung_conditions_note"]
for c in dfields: b[c] = b.groupby("donor")[c].transform(lambda s: s.ffill().bfill())
for c in ["disease_category", "sars_cov_2"]: b[c] = b[c].astype("string").str.strip()
KEY["score_range"] = {c: [float(b[c].min()), float(b[c].max())] for c in num}
KEY["blocks_at_max_score_5_5"] = {c: f"{int((b[c] == 5.5).sum())}/{int(b[c].notna().sum())}" for c in ["IL33_epithelium", "IL33_endothelium", "IL33_vsmc"]}

# ---- donor table ----
d = b.groupby("donor", sort=False).agg(n_blocks=("block_id", "size"), category=("disease_category", "first"), sars_cov_2=("sars_cov_2", "first"), sex=("sex", "first"), age=("age", "first"), race=("race", "first"),
        IL33_endothelium=("IL33_endothelium", "mean"), IL33_epithelium=("IL33_epithelium", "mean"), IL33_vsmc=("IL33_vsmc", "mean"), EPX=("EPX", "mean"), NE=("NE", "mean"), Tryptase=("Tryptase", "mean"),
        n_rna_blocks=("tissue_rna_id", "count"), lung_conditions_note=("lung_conditions_note", "first"), pathology=("pathology", "first"))
d["covid"] = (d.category == "COVID pos pneumonia").astype(int); d["male"] = (d.sex == "M").astype(int); d["age"] = d.age.astype(float)
def flag(txt, rx, drop=None):
    t = txt.lower()
    if drop: t = re.sub(drop, "", t)
    return bool(re.search(rx, t))
d["path_pneumonia"] = d.pathology.map(lambda s: flag(s, r"pneumonia|pneumonitis|bronchpneumonia"))
d["path_DAD"] = d.pathology.map(lambda s: flag(s, r"diffuse alveolar damage|hyalin[e]? membranes", r"no hyalin[e]? membranes"))
d["path_acute_lung"] = d.path_pneumonia | d.path_DAD | d.pathology.map(lambda s: flag(s, r"acute lung injury|pulmonary consolidation"))
d["path_thromboembolic"] = d.pathology.map(lambda s: flag(s, r"thromboembol|pulmonary emboli|thrombosis"))
d["path_emphysema"] = d.pathology.map(lambda s: flag(s, r"emphysem"))
d["note_COPD"] = d.lung_conditions_note.fillna("").str.contains("COPD"); d["note_asthma"] = d.lung_conditions_note.fillna("").str.contains("Asthma")
d.drop(columns=["pathology"]).to_csv(f"{OUT}/tables/T5_lung_donor_level.csv")
b.drop(columns=["pathology", "unused", "sample_id_dup"]).to_csv(f"{OUT}/tables/T5b_lung_block_level_clean.csv", index=False)
d.to_pickle(f"{WORK}/lung_donors_final.pkl"); b.to_pickle(f"{WORK}/lung_blocks_final.pkl")

KEY["n_donors"] = int(len(d)); KEY["donors_by_category"] = d.category.value_counts().to_dict(); KEY["blocks_by_category"] = b.disease_category.value_counts().to_dict()
KEY["race"] = d.race.value_counts().to_dict(); KEY["age_range"] = [float(d.age.min()), float(d.age.max())]; KEY["age_mean_by_covid"] = {int(k): round(float(v), 1) for k, v in d.groupby("covid").age.mean().items()}
top3 = b[b.disease_category == "COVID pos pneumonia"].groupby("donor").size().sort_values(ascending=False).head(3)
KEY["covid_blocks_from_top3_donors"] = f"{int(top3.sum())}/{int((b.disease_category == 'COVID pos pneumonia').sum())}"
KEY["donor_missing_sars_status"] = d.index[d.sars_cov_2.isna()].tolist()
KEY["label_vs_pathology_mismatch"] = {"'COVID neg pneumonia' without pneumonia/ALI in pathology text": d.index[(d.category == "COVID neg pneumonia") & ~d.path_acute_lung].tolist(),
                                     "'COVID neg non-pneumonia' with pneumonia/pneumonitis in text": d.index[(d.category == "COVID neg non-pneumonia") & d.path_acute_lung].tolist(),
                                     "'COVID pos pneumonia' without pneumonia/ALI in text": d.index[(d.category == "COVID pos pneumonia") & ~d.path_acute_lung].tolist()}
KEY["rna_extracted_blocks"] = int(b.tissue_rna_id.notna().sum())
mw = lambda x, y: float(stats.mannwhitneyu(x.dropna(), y.dropna()).pvalue)
res = {}
for v in ["IL33_endothelium", "IL33_vsmc", "IL33_epithelium", "EPX", "NE", "Tryptase"]:
    pos, neg = d.loc[d.covid == 1, v], d.loc[d.covid == 0, v]
    m = smf.ols(f"{v} ~ covid + age + male", data=d).fit(); ci = m.conf_int().loc["covid"]
    bb = b.dropna(subset=[v]); bp, bn = bb.loc[bb.disease_category == "COVID pos pneumonia", v], bb.loc[bb.disease_category != "COVID pos pneumonia", v]
    res[v] = dict(donor_mean_covid_pos=round(float(pos.mean()), 2), donor_mean_covid_neg=round(float(neg.mean()), 2),
                  donor_means_by_category={k: round(float(x), 2) for k, x in d.groupby("category")[v].mean().items()},
                  donor_level_MW_p=round(mw(pos, neg), 4), kruskal_3group_p=round(float(stats.kruskal(*[g[v].dropna() for _, g in d.groupby("category")]).pvalue), 4),
                  naive_block_level_MW_p=round(mw(bp, bn), 4), block_n=[int(len(bp)), int(len(bn))],
                  adj_covid_beta=round(float(m.params["covid"]), 2), adj_covid_CI=[round(float(ci[0]), 2), round(float(ci[1]), 2)], adj_covid_p=round(float(m.pvalues["covid"]), 3),
                  age_beta_per_decade=round(float(10 * m.params["age"]), 2), age_p=round(float(m.pvalues["age"]), 4), male_beta=round(float(m.params["male"]), 2), male_p=round(float(m.pvalues["male"]), 3),
                  spearman_age=round(float(stats.spearmanr(d[v], d.age, nan_policy="omit").statistic), 2), spearman_age_p=round(float(stats.spearmanr(d[v], d.age, nan_policy="omit").pvalue), 4))
KEY["tests"] = res
# sensitivity: block-level linear mixed model with a random intercept per donor
mmres = {}
bm = b.assign(covid=(b.disease_category == "COVID pos pneumonia").astype(int), male=(b.sex == "M").astype(int), age=b.age.astype(float))
for v in ["IL33_endothelium", "IL33_vsmc", "IL33_epithelium"]:
    bb = bm.dropna(subset=[v])
    mm = smf.mixedlm(f"{v} ~ covid + age + male", data=bb, groups=bb["donor"]).fit(reml=True)
    mmres[v] = dict(covid_beta=round(float(mm.params["covid"]), 2), covid_p=round(float(mm.pvalues["covid"]), 3), age_beta_per_decade=round(float(10 * mm.params["age"]), 2), age_p=round(float(mm.pvalues["age"]), 4))
KEY["mixed_model_block_level"] = mmres
a, n = d.path_acute_lung, ~d.path_acute_lung
m = smf.ols("IL33_endothelium ~ path_acute_lung + age + male", data=d.assign(path_acute_lung=d.path_acute_lung.astype(int))).fit()
KEY["acute_lung_pathology_any_cause"] = dict(n=[int(a.sum()), int(n.sum())], endo=[round(float(d.loc[a, "IL33_endothelium"].mean()), 2), round(float(d.loc[n, "IL33_endothelium"].mean()), 2)], endo_MW_p=round(mw(d.loc[a, "IL33_endothelium"], d.loc[n, "IL33_endothelium"]), 3),
      endo_adj_beta=round(float(m.params["path_acute_lung"]), 2), endo_adj_p=round(float(m.pvalues["path_acute_lung"]), 3),
      NE=[round(float(d.loc[a, "NE"].mean()), 2), round(float(d.loc[n, "NE"].mean()), 2)], NE_MW_p=round(mw(d.loc[a, "NE"], d.loc[n, "NE"]), 4),
      covid_vs_noncovid_within_acute_endo_p=round(mw(d.loc[a & (d.covid == 1), "IL33_endothelium"], d.loc[a & (d.covid == 0), "IL33_endothelium"]), 3))
KEY["compartments"] = dict(donor_mean={c: round(float(d[c].mean()), 2) for c in ["IL33_endothelium", "IL33_epithelium", "IL33_vsmc"]},
      wilcoxon_endo_vs_epi_p=float(f"{stats.wilcoxon(d.IL33_endothelium, d.IL33_epithelium).pvalue:.2g}"), wilcoxon_endo_vs_vsmc_p=float(f"{stats.wilcoxon(d.IL33_endothelium, d.IL33_vsmc).pvalue:.2g}"),
      donors_endo_ge_4=int((d.IL33_endothelium >= 4).sum()), min_donor_endo=float(d.IL33_endothelium.min()), blocks_with_endothelial_staining=f"{int((b.IL33_endothelium > 0).sum())}/{len(b)}")
sp = lambda x, y: (round(float(stats.spearmanr(d[x], d[y], nan_policy="omit").statistic), 2), round(float(stats.spearmanr(d[x], d[y], nan_policy="omit").pvalue), 3))
KEY["correlations_donor_level"] = {"IL33_endo~NE": sp("IL33_endothelium", "NE"), "IL33_endo~EPX": sp("IL33_endothelium", "EPX"), "IL33_epi~EPX": sp("IL33_epithelium", "EPX"), "IL33_endo~IL33_vsmc": sp("IL33_endothelium", "IL33_vsmc"), "IL33_endo~IL33_epi": sp("IL33_endothelium", "IL33_epithelium")}
for f in ["note_COPD", "path_emphysema", "note_asthma"]:
    KEY[f"IL33_epithelium_by_{f}"] = dict(n=[int(d[f].sum()), int((~d[f]).sum())], mean=[round(float(d.loc[d[f], "IL33_epithelium"].mean()), 2), round(float(d.loc[~d[f], "IL33_epithelium"].mean()), 2)], MW_p=round(mw(d.loc[d[f], "IL33_epithelium"], d.loc[~d[f], "IL33_epithelium"]), 3))
# intraclass correlation (blocks within donor)
icc = {}
for v in ["IL33_endothelium", "IL33_vsmc", "IL33_epithelium"]:
    bb = b.dropna(subset=[v]); k = bb.groupby("donor")[v].size(); bb = bb[bb.donor.isin(k[k >= 2].index)]; gr = [x[v].values for _, x in bb.groupby("donor")]
    n0 = (len(bb) - sum(len(x) ** 2 for x in gr) / len(bb)) / (len(gr) - 1)
    msb = sum(len(x) * (x.mean() - bb[v].mean()) ** 2 for x in gr) / (len(gr) - 1); msw = sum(((x - x.mean()) ** 2).sum() for x in gr) / (len(bb) - len(gr))
    icc[v] = round(float((msb - msw) / (msb + (n0 - 1) * msw)), 2)
KEY["ICC_blocks_within_donor"] = icc
json.dump(KEY, open(f"{OUT}/tables/key_numbers_lung.json", "w"), indent=1, default=str)
print(json.dumps(KEY, indent=1, default=str))
