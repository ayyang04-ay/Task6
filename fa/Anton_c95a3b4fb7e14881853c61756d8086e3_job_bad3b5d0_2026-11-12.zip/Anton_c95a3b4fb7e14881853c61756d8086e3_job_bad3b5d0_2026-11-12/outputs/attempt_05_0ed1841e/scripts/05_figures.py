#!/usr/bin/env python
"""Step 5 - figures. Run: micromamba run -n singlecell python 05_figures.py /tmp/work /tmp/outputs"""
import sys, json, warnings
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from adjustText import adjust_text
from scipy import stats
warnings.filterwarnings("ignore")
WORK = sys.argv[1] if len(sys.argv) > 1 else "/tmp/work"
OUT = sys.argv[2] if len(sys.argv) > 2 else "/tmp/outputs"
FIG = f"{OUT}/figures"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False, "axes.titlesize": 11, "axes.titleweight": "bold", "figure.dpi": 110, "savefig.dpi": 170, "font.family": "DejaVu Sans"})
L = pd.read_parquet(f"{WORK}/W_logFC.parquet"); M = pd.read_parquet(f"{WORK}/gene_master.parquet").reindex(L.index)   # same row order for all matrices
SE = pd.read_parquet(f"{WORK}/W_SE.parquet").reindex(L.index); T = pd.read_parquet(f"{WORK}/W_t.parquet").reindex(L.index); Z = pd.read_parquet(f"{WORK}/W_Zemp.parquet").reindex(L.index); A = pd.read_parquet(f"{WORK}/W_adjP.parquet").reindex(L.index)
assert (M.index == L.index).all() and (SE.index == L.index).all()
K = json.load(open(f"{OUT}/tables/key_numbers_rnaseq.json")); KS = json.load(open(f"{OUT}/tables/key_numbers_serum.json")); KL = json.load(open(f"{OUT}/tables/key_numbers_lung.json"))
ens = {r.delivered_symbol: e for e, r in M.iterrows()}
C_GREY, C_CORE, C_RED, C_BLUE, C_ORANGE, C_GREEN = "#c9c9c9", "#2b6cb0", "#c53030", "#2b6cb0", "#dd6b20", "#2f855a"

# ------------------------------------------------------------------ Figure 1
def fig1():
    fig, axs = plt.subplots(2, 2, figsize=(13.5, 8.6))
    core = M.core_signature.values
    lab = ["SELE", "VCAM1", "ICAM1", "CXCL8", "CXCL1", "CSF2", "CSF3", "IL6", "CCL2", "CCL20", "F3", "CXCL2", "TNFAIP3", "THBD", "NOS3", "IL1RL1", "PTX3"]
    panels = [("IL33_HUVEC_6h", "NEUT_HUVEC_6h", "A  HUVEC, 6 h", "IL-33 vs vehicle (log2 FC)", "AX-1177 effect under IL-33\n(log2 FC vs IL-33 + isotype)",
               f"top-25 induced genes: median reversal {K['top25_induced']['pct_reversal_6h_median']:.0f}%\n(IQR {K['top25_induced']['pct_reversal_6h_IQR'][0]:.0f}-{K['top25_induced']['pct_reversal_6h_IQR'][1]:.0f}%); errors-in-variables slope {K['neutralisation_HUVEC_6h_genes_selected_on_HGMEC']['deming_slope']:.2f}\n(n={K['neutralisation_HUVEC_6h_genes_selected_on_HGMEC']['n']} genes chosen on independent HGMEC data)"),
              ("IL33_HUVEC_24h", "NEUT_HUVEC_24h", "B  HUVEC, 24 h", "IL-33 vs vehicle (log2 FC)", "AX-1177 effect under IL-33\n(log2 FC vs IL-33 + isotype)",
               f"top-25 induced genes: median reversal {K['top25_induced']['pct_reversal_24h_median']:.0f}%\n(IQR {K['top25_induced']['pct_reversal_24h_IQR'][0]:.0f}-{K['top25_induced']['pct_reversal_24h_IQR'][1]:.0f}%); the IL-33 response itself has\ndecayed to ~{K['top25_induced']['HUVEC_IL33_24h_over_6h_pct']:.0f}% of its 6 h size (log2 scale)"),
              ("IL33_HUVEC_6h", "NEUT_HGMEC_6h", "C  Glomerular endothelium (HGMEC), 6 h", "IL-33 vs vehicle in HUVEC (log2 FC)  [no vehicle arm exists for HGMEC]", "HGMEC: AX-1177 effect under IL-33\n(log2 FC vs IL-33 + isotype)",
               f"same programme reversed; effect size = {K['top25_induced']['HGMEC_over_HUVEC_reversal_6h_pct']:.0f}% of HUVEC's\n(top-25 genes, log2 scale). % neutralisation not estimable:\nno IL-33-vs-baseline contrast was delivered for HGMEC"),
              ("IL33_HUVEC_6h", "AB_HUVEC_6h", "D  AX-1177 alone (no IL-33), HUVEC, 6 h", "IL-33 vs vehicle (log2 FC)", "AX-1177 alone vs isotype alone\n(log2 FC)",
               f"antibody alone does not move the IL-33 programme\n(slope {K['antibody_alone']['signature_slope_range'][0]:+.2f} to {K['antibody_alone']['signature_slope_range'][1]:+.2f} across 16 antibody-alone contrasts);\n0 'significant' genes replicate across time points or cell lines")]
    for ax, (cx, cy, title, xl, yl, note) in zip(axs.ravel(), panels):
        x, y = L[cx].values, L[cy].values
        ax.scatter(x[~core], y[~core], s=3, c=C_GREY, alpha=0.35, rasterized=True, linewidths=0)
        ax.scatter(x[core], y[core], s=9, c=C_CORE, alpha=0.75, rasterized=True, linewidths=0)
        if not cy.startswith("AB"): ax.plot([-6, 13], [6, -13], ls="--", c="k", lw=0.9)
        ax.axhline(0, c="k", lw=0.5); ax.axvline(0, c="k", lw=0.5)
        ax.set_xlim(-5, 12.5); ax.set_ylim(-13.5, 5.5); ax.set_xlabel(xl); ax.set_ylabel(yl); ax.set_title(title, loc="left")
        txt = []
        for g in (lab if cx != "IL33_HUVEC_24h" else ["SELE", "VCAM1", "CXCL8", "CXCL1", "CSF2", "CSF3", "IL6", "CCL20", "NOS3", "CXCL2", "ICAM1"]):
            e = ens[g]; gx, gy = L.loc[e, cx], L.loc[e, cy]
            if abs(gx) < 0.9 and abs(gy) < 0.9: continue
            ax.scatter([gx], [gy], s=22, facecolors="none", edgecolors=C_RED, linewidths=1.1, zorder=5)
            txt.append(ax.text(gx, gy, g, fontsize=8.5, color="#7b1f1f", zorder=6))
        adjust_text(txt, ax=ax, iter_lim=400, arrowprops=dict(arrowstyle="-", color="#7b1f1f", lw=0.5), expand=(1.25, 1.45))
        ax.text(0.02, 0.02, note, transform=ax.transAxes, ha="left", va="bottom", fontsize=8.6, bbox=dict(boxstyle="round", fc="white", ec="#999999", lw=0.6))
    h = [Line2D([], [], marker="o", ls="", c=C_CORE, ms=5, label=f"core IL-33 signature, n={K['core_signature_n']} genes (HUVEC 6 h: induced/repressed by IL-33 AND reversed by AX-1177; both adj.P<0.05, |log2FC|>1)"),
         Line2D([], [], marker="o", ls="", c=C_GREY, ms=5, label=f"all other genes (n={K['n_genes'] - K['core_signature_n']:,})"),
         Line2D([], [], ls="--", c="k", label="complete reversal (y = -x; panels A-C)"),
         Line2D([], [], marker="o", ls="", mfc="none", mec=C_RED, ms=6, label="named marker genes")]
    fig.legend(handles=h, loc="lower center", ncol=2, frameon=False, fontsize=9.2)
    fig.suptitle("AX-1177 reverses the IL-33 endothelial programme; the antibody alone is inert", fontsize=13, fontweight="bold", y=0.995)
    fig.tight_layout(rect=[0, 0.045, 1, 0.985]); fig.savefig(f"{FIG}/Fig1_rnaseq_neutralisation.png"); plt.close(fig)

# ------------------------------------------------------------------ Figure 2
def fig2():
    fig, axs = plt.subplots(1, 2, figsize=(13.5, 5.8), gridspec_kw=dict(width_ratios=[1.05, 1]))
    ax = axs[0]
    x, y = M.empirical_null_SE.values, SE["IL33_HUVEC_6h"].values; deg = M.degenerate_SE_flag.values
    ax.scatter(x[~deg], y[~deg], s=3, c=C_GREY, alpha=0.4, rasterized=True, linewidths=0)
    ax.scatter(x[deg], y[deg], s=14, c=C_RED, alpha=0.85, linewidths=0)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.plot([1e-2, 1e1], [1e-2, 1e1], "k--", lw=0.9)
    ax.set_xlim(0.012, 6); ax.set_ylim(0.012, 6e4)
    ax.set_xlabel("standard error implied by the data's own null contrasts (log2 units)\n(8 endothelial contrasts with no treatment effect, per gene)")
    ax.set_ylabel("standard error reported in the delivered table\n(= logFC / t, IL-33 vs vehicle, HUVEC 6 h)")
    ax.set_title("A  Delivered standard errors are impossible for a subset of genes", loc="left")
    txt = [ax.text(M.loc[ens[g], "empirical_null_SE"], SE.loc[ens[g], "IL33_HUVEC_6h"], g, fontsize=8.5, color="#7b1f1f") for g in ["SELE", "VCAM1", "CXCL8", "CXCL1", "CCL2", "PTGS2", "PTX3", "IL1RL1", "GAPDH", "CD93", "CDH5", "VWF", "KRT8"]]
    adjust_text(txt, ax=ax, iter_lim=400, arrowprops=dict(arrowstyle="-", color="#7b1f1f", lw=0.5))
    ax.legend(handles=[Line2D([], [], marker="o", ls="", c=C_RED, ms=5, label=f"{K['n_degenerate_SE_genes']} genes with median reported SE > 2 log2 units\n(median {K['degenerate_median_ratio_reported_to_empirical_SE']:.0f}x larger than the empirical SE)"),
                       Line2D([], [], marker="o", ls="", c=C_GREY, ms=5, label=f"all other genes (median ratio {K['empirical_vs_limma_SE_median_ratio_nondegenerate']:.2f})"), Line2D([], [], ls="--", c="k", label="agreement")], loc="lower right", frameon=False, fontsize=8.6)
    ax = axs[1]
    genes = ["CXCL1", "CCL2", "CXCL8", "PTX3", "VCAM1", "PTGS2", "SELE", "IL1RL1", "ICAM1", "TNFAIP3", "CXCL2", "IL6", "CSF2"]
    yv = np.arange(len(genes))[::-1]
    t = [abs(T.loc[ens[g], "IL33_HUVEC_6h"]) for g in genes]; z = [abs(Z.loc[ens[g], "IL33_HUVEC_6h"]) for g in genes]
    ax.barh(yv + 0.2, t, height=0.38, color="#718096", label="delivered moderated t (single 114-library model)")
    ax.barh(yv - 0.2, z, height=0.38, color=C_RED, label="re-scored: logFC / empirical null SE")
    for i, g in enumerate(genes):
        ax.text(max(t[i], z[i]) + 0.8, yv[i], f"log2FC {L.loc[ens[g], 'IL33_HUVEC_6h']:+.1f};  delivered adj.P {A.loc[ens[g], 'IL33_HUVEC_6h']:.2g}", va="center", fontsize=8.2)
    ax.axvline(2, c="k", lw=0.7, ls=":"); ax.set_yticks(yv); ax.set_yticklabels(genes); ax.set_xlim(0, 72)
    ax.axhline(yv[8] - 0.5, c="k", lw=0.6)
    ax.set_xlabel("|test statistic|, IL-33 vs vehicle, HUVEC 6 h\n(four genes below the line: comparators whose delivered statistics are intact)"); ax.set_title("B  Flagship genes fail the delivered test but not the data", loc="left")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.16), ncol=2, frameon=False, fontsize=8.6)
    fig.tight_layout(); fig.savefig(f"{FIG}/Fig5_statistics_artefact.png"); plt.close(fig)

# ------------------------------------------------------------------ Figure 3
def fig3():
    S = pd.read_parquet(f"{WORK}/serum_annot.parquet")
    fig, axs = plt.subplots(1, 2, figsize=(15, 9.2), gridspec_kw=dict(width_ratios=[1, 0.8]))
    ax = axs[0]
    x = np.clip(np.log2(S.OR), -2.6, 5.2); y = -np.log10(S["p.value"])
    ind = (S.endothelial_IL33_class == "IL-33-induced & AX-1177-reversed").values
    type2 = S.assay.isin(["IL5-IMO", "CCL11-INFI", "CCL11-IMO", "CCL17", "CCL24", "TPSAB1", "IL17RB", "IL-5R-alpha"]).values
    ax.scatter(x[~ind], y[~ind], s=9, c=C_GREY, alpha=0.6, linewidths=0)
    ax.scatter(x[ind], y[ind], s=26, c=C_RED, alpha=0.9, linewidths=0)
    ax.scatter(x[type2], y[type2], s=30, c=C_BLUE, marker="s", linewidths=0)
    st = S[S.assay == "ST2"].iloc[0]; ax.scatter([np.log2(st.OR)], [-np.log10(st["p.value"])], s=170, marker="*", c="k", zorder=6)
    pthr = S.loc[S["adj.p.value"] < 0.05, "p.value"].max(); ax.axhline(-np.log10(pthr), c="k", ls=":", lw=0.8); ax.text(-2.65, -np.log10(pthr) + 0.05, "FDR 0.05", ha="left", fontsize=8)
    ax.axhline(-np.log10(0.05), c="k", ls=":", lw=0.5); ax.text(-2.65, -np.log10(0.05) + 0.05, "p 0.05", ha="left", fontsize=8); ax.axvline(0, c="k", lw=0.5)
    ren = {"OPG-INFI": "OPG", "MCP-1-INFI": "MCP-1", "CXCL1-INFI": "CXCL1", "IL5-IMO": "IL-5", "CCL11-INFI": "eotaxin", "TPSAB1": "tryptase", "CCL17": "TARC", "CCL24": "eotaxin-2", "IL8": "IL-8", "IL6": "IL-6", "ST2": "sST2", "TF": "tissue factor", "SELE": "E-selectin", "VCAM1": "sVCAM-1", "ICAM1": "sICAM-1"}
    txt = []
    for a_ in ["ST2", "HGF", "PTX3", "IL6", "OPG-INFI", "IL-18R1", "IL8", "CCL20", "MCP-3", "MCP-1-INFI", "TF", "SELE", "CSF-1", "VCAM1", "ICAM1", "CXCL1-INFI", "G-CSF", "IL5-IMO", "CCL17", "CCL11-INFI", "TPSAB1"]:
        r = S[S.assay == a_].iloc[0]
        txt.append(ax.text(min(max(np.log2(r.OR), -2.6), 5.2), -np.log10(r["p.value"]), ren.get(a_, a_), fontsize=8.6, fontweight="bold" if a_ == "ST2" else "normal"))
    adjust_text(txt, ax=ax, iter_lim=400, arrowprops=dict(arrowstyle="-", color="#444444", lw=0.5), expand=(1.2, 1.4))
    ax.set_xlim(-2.7, 5.3); ax.set_ylim(-0.15, 5.8)
    ax.set_xlabel("log2 odds ratio per log unit of assay (clipped at 5.2; scale differs between assays)"); ax.set_ylabel("-log10 p (logistic model adjusted for age, sex, NEWS2)")
    ax.set_title(f"A  {KS['n_assays_delivered']:,} serum assays vs ICU / ventilation / death", loc="left")
    ax.text(-2.62, 5.62, "100 hospitalised COVID-19 patients;\n44 with the endpoint (count inferred)", fontsize=8.6, va="top")
    ax.legend(handles=[Line2D([], [], marker="*", ls="", c="k", ms=12, label=f"sST2: OR {KS['assay_ST2']['OR']} ({KS['assay_ST2']['CI'][0]}-{KS['assay_ST2']['CI'][1]}), rank {KS['assay_ST2']['rank']} of {KS['n_assays_delivered']:,}"),
                       Line2D([], [], marker="o", ls="", c=C_RED, ms=6, label="gene is IL-33-induced and AX-1177-reversed in endothelium (our RNA-seq)"),
                       Line2D([], [], marker="s", ls="", c=C_BLUE, ms=6, label="type-2 / eosinophil / mast-cell markers"),
                       Line2D([], [], marker="o", ls="", c=C_GREY, ms=6, label=f"other assays ({KS['n_p_lt_0_05']} of {KS['n_assays_delivered']:,} assays have p<0.05; {KS['n_OR_gt_1']} have OR>1)")],
              loc="upper center", bbox_to_anchor=(0.5, -0.1), ncol=1, frameon=False, fontsize=8.8)
    ax = axs[1]
    groups = [("IL-33 axis", "k", [("ST2", "sST2 (IL1RL1)")]),
              ("IL-33-induced in endothelium; associated with outcome", C_RED, [("IL6", "IL-6"), ("IL8", "IL-8"), ("CCL20", "CCL20"), ("MCP-3", "MCP-3 (CCL7)"), ("MCP-1-INFI", "MCP-1 (CCL2)"), ("OPG-INFI", "OPG"), ("PTX3", "PTX3"), ("TF", "tissue factor"), ("SELE", "E-selectin")]),
              ("IL-33-induced in endothelium; NOT associated", "#9b6b6b", [("VCAM1", "sVCAM-1"), ("ICAM1", "sICAM-1"), ("CXCL1-INFI", "CXCL1"), ("CXCL5", "CXCL5"), ("CXCL6", "CXCL6"), ("G-CSF", "G-CSF"), ("TNF", "TNF")]),
              (f"Type-2 / eosinophil / mast cell ({KS['marker_sets']['type2_eosinophil_mast_cell']['n_p_lt_0_05']} of {KS['marker_sets']['type2_eosinophil_mast_cell']['n']} such assays have p<0.05; 5 shown)", C_BLUE, [("IL5-IMO", "IL-5"), ("CCL11-INFI", "eotaxin (CCL11)"), ("CCL17", "TARC (CCL17)"), ("CCL24", "eotaxin-2 (CCL24)"), ("TPSAB1", "tryptase")]),
              (f"Neutrophil granule / activation ({KS['marker_sets']['neutrophil_granule_and_activation']['n_p_lt_0_05']} of {KS['marker_sets']['neutrophil_granule_and_activation']['n']} such assays have p<0.05; 4 shown)", C_GREEN, [("PRTN3", "proteinase 3"), ("CD177", "CD177"), ("LCN2", "NGAL (LCN2)"), ("RETN", "resistin")]),
              ("Cardiac / renal injury", "#6b46c1", [("NT-proBNP-MET", "NT-proBNP"), ("TNNI3", "troponin I"), ("KIM1-CVDII", "KIM-1"), ("CST3", "cystatin C")]),
              ("Top-ranked assay (not IL-33-regulated in endothelium)", "#555555", [("HGF", "HGF")])]
    y0 = 0; yt, yl = [], []
    for gname, col, items in groups:
        ax.text(0.36, y0, gname, fontsize=8.8, fontweight="bold", color=col, va="center", ha="left"); y0 -= 1
        for a_, nm in items:
            r = S[S.assay == a_].iloc[0]
            ax.plot([r.l95, min(r.u95, 60)], [y0, y0], c=col, lw=1.6); ax.scatter([r.OR], [y0], c=col, s=34, zorder=5)
            ax.text(70, y0, f"{r.OR:.2f} ({r.l95:.2f}-{r.u95:.2f});  FDR {r['adj.p.value']:.2g}", va="center", fontsize=8.2, clip_on=False)
            yt.append(y0); yl.append(nm); y0 -= 1
        y0 -= 0.6
    ax.text(70, 1.1, "OR (95% CI);  FDR", fontsize=8.4, fontweight="bold", va="center", clip_on=False)
    ax.axvline(1, c="k", lw=0.7); ax.set_xscale("log"); ax.set_xlim(0.35, 60); ax.set_ylim(y0 + 0.8, 1.6); ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=8.8)
    ax.set_xticks([0.5, 1, 2, 5, 10, 20, 50]); ax.set_xticklabels(["0.5", "1", "2", "5", "10", "20", "50"])
    ax.set_xlabel("odds ratio per log unit (95% CI), adjusted for age, sex, NEWS2"); ax.set_title("B  Selected assays", loc="left")
    fig.subplots_adjust(left=0.05, right=0.845, wspace=0.36, top=0.955, bottom=0.215)
    fig.savefig(f"{FIG}/Fig2_serum_proteomics.png"); plt.close(fig)

# ------------------------------------------------------------------ Figure 4
def fig4():
    d = pd.read_pickle(f"{WORK}/lung_donors_final.pkl"); b = pd.read_pickle(f"{WORK}/lung_blocks_final.pkl")
    cats = ["COVID pos pneumonia", "COVID neg pneumonia", "COVID neg non-pneumonia"]; cc = {cats[0]: C_RED, cats[1]: C_ORANGE, cats[2]: "#4a5568"}
    short = {cats[0]: "SARS-CoV-2 +", cats[1]: "SARS-CoV-2 -, 'pneumonia'", cats[2]: "SARS-CoV-2 -, 'non-pneumonia'"}
    fig, axs = plt.subplots(1, 3, figsize=(15.5, 5.4), gridspec_kw=dict(width_ratios=[1.25, 1, 1.1]))
    ax = axs[0]; rng = np.random.default_rng(3)
    comps = [("IL33_endothelium", "endothelium"), ("IL33_epithelium", "bronchial / bronchiolar\nbasal epithelium"), ("IL33_vsmc", "vascular smooth\nmuscle")]
    for i, (v, nm) in enumerate(comps):
        for j, c in enumerate(cats):
            y = d.loc[d.category == c, v].dropna(); xx = i + (j - 1) * 0.27 + rng.uniform(-0.07, 0.07, len(y))
            ax.scatter(xx, y, s=26, c=cc[c], alpha=0.8, linewidths=0); ax.plot([i + (j - 1) * 0.27 - 0.1, i + (j - 1) * 0.27 + 0.1], [y.median()] * 2, c="k", lw=2)
        t = KL["tests"][v]
        ax.text(i, 6.05, f"+ vs -:  p = {t['donor_level_MW_p']:.3f}\n(adjusted: {t['adj_covid_p']:.3f})", ha="center", fontsize=8.4)
    ax.set_xticks(range(3)); ax.set_xticklabels([c[1] for c in comps]); ax.set_ylim(-0.3, 6.75); ax.set_ylabel("IL-33 IHC score, mean per donor (delivered coding, max 5.5)")
    ax.set_title(f"A  IL-33 is in every lung; not raised in COVID-19 ({KL['n_donors']} donors)", loc="left")
    ax.legend(handles=[Line2D([], [], marker="o", ls="", c=cc[c], ms=6, label=f"{short[c]} (n={int((d.category == c).sum())})") for c in cats] + [Line2D([], [], c="k", lw=2, label="median"), Line2D([], [], ls="", label="p: SARS-CoV-2 + vs - donors, Mann-Whitney;\nadjusted: linear model with age and sex")], loc="lower left", frameon=False, fontsize=8.1)
    ax = axs[1]
    for c in cats:
        s = d[d.category == c]; ax.scatter(s.age, s.IL33_endothelium, s=34, c=cc[c], alpha=0.85, linewidths=0)
    sl, ic = np.polyfit(d.age, d.IL33_endothelium, 1); xs = np.array([d.age.min(), d.age.max()]); ax.plot(xs, sl * xs + ic, "k--", lw=1)
    t = KL["tests"]["IL33_endothelium"]
    ax.text(0.98, 0.17, f"Spearman rho = {t['spearman_age']:.2f} (p = {t['spearman_age_p']:.3f})\n+{t['age_beta_per_decade']:.2f} score units per decade (p = {t['age_p']:.3f}),\nadjusted for SARS-CoV-2 status and sex", transform=ax.transAxes, fontsize=8.6, va="bottom", ha="right")
    ax.set_xlabel("age at death (years)"); ax.set_ylabel("endothelial IL-33 score, mean per donor"); ax.set_ylim(2.7, 5.8); ax.set_title("B  Vascular IL-33 tracks age", loc="left")
    ax = axs[2]
    o = d.assign(co=d.category.map({c: i for i, c in enumerate(cats)})).sort_values(["co", "n_blocks"], ascending=[True, False]); ax.bar(range(len(o)), o.n_blocks, color=[cc[c] for c in o.category])
    ax.set_xticks([]); ax.set_xlabel("donors (one bar each)"); ax.set_ylabel("histology blocks scored"); ax.set_title("C  Blocks are not independent samples", loc="left")
    te, tv = KL["tests"]["IL33_endothelium"], KL["tests"]["IL33_vsmc"]
    ax.text(0.30, 0.97, f"{KL['covid_blocks_from_top3_donors']} SARS-CoV-2+ blocks come from 3 donors\n\nSARS-CoV-2 + vs -, Mann-Whitney p\n                  per block  per donor\nendothelium         {te['naive_block_level_MW_p']:.3f}      {te['donor_level_MW_p']:.3f}\nsmooth muscle       {tv['naive_block_level_MW_p']:.3f}      {tv['donor_level_MW_p']:.3f}\neosinophils (EPX)   {KL['tests']['EPX']['naive_block_level_MW_p']:.3f}      {KL['tests']['EPX']['donor_level_MW_p']:.3f}\n\nper-block tests overstate the evidence\n(within-donor ICC {KL['ICC_blocks_within_donor']['IL33_vsmc']:.2f}-{KL['ICC_blocks_within_donor']['IL33_epithelium']:.2f})",
            transform=ax.transAxes, va="top", fontsize=8.2, family="DejaVu Sans Mono", bbox=dict(boxstyle="round", fc="white", ec="#999999", lw=0.6))
    fig.tight_layout(); fig.savefig(f"{FIG}/Fig3_lung_IHC.png"); plt.close(fig)

# ------------------------------------------------------------------ Figure 5
def fig5():
    B = pd.read_csv(f"{OUT}/tables/T2_biomarker_shortlist.csv"); B = B[B.gene != "IL33"].reset_index(drop=True)
    cols = ["logFC_IL33_HUVEC_6h", "logFC_IL33_HUVEC_24h", "logFC_NEUT_HUVEC_6h", "logFC_NEUT_HUVEC_24h", "logFC_NEUT_HGMEC_6h", "logFC_NEUT_HGMEC_24h"]
    X = np.array([[M.loc[ens[g], c] for c in cols] for g in B.gene])
    order = ["IL1RL1", "IL6", "CXCL8", "CCL20", "CCL2", "CCL7", "TNFRSF11B", "PTX3", "F3", "SELE", "VCAM1", "ICAM1", "CSF2", "CSF3", "CXCL1", "CXCL2", "CXCL5", "CXCL6", "CX3CL1", "CCL5", "TNFAIP3", "NFKBIA", "THBD", "NOS3"]
    idx = [B.index[B.gene == g][0] for g in order]; B = B.loc[idx].reset_index(drop=True); X = X[idx]
    fig, ax = plt.subplots(figsize=(13.2, 8.0))
    im = ax.imshow(X, cmap="RdBu_r", vmin=-9, vmax=9, aspect="auto")
    for i in range(X.shape[0]):
        for j in range(X.shape[1]):
            ax.text(j, i, f"{X[i, j]:+.1f}", ha="center", va="center", fontsize=8.3, color="white" if abs(X[i, j]) > 5.5 else "black")
    ax.set_xticks(range(6)); ax.set_xticklabels(["IL-33\nvs vehicle\nHUVEC 6 h", "IL-33\nvs vehicle\nHUVEC 24 h", "+ AX-1177\nvs + isotype\nHUVEC 6 h", "+ AX-1177\nvs + isotype\nHUVEC 24 h", "+ AX-1177\nvs + isotype\nHGMEC 6 h", "+ AX-1177\nvs + isotype\nHGMEC 24 h"], fontsize=8.8)
    ax.xaxis.tick_top(); ax.set_yticks(range(len(B)))
    ax.set_yticklabels([f"{r.analyte}" + (" \u2020" if r.delivered_P_unreliable else "") for r in B.itertuples()], fontsize=9)
    for sp in ax.spines.values(): sp.set_visible(False)
    for yline in [0.5, 9.5, 19.5, 21.5]: ax.axhline(yline, c="k", lw=1.2)
    ax.axvline(1.5, c="k", lw=0.8); ax.axvline(3.5, c="k", lw=0.8)
    ax.text(6.0, -1.25, "patient serum: OR per log unit (95% CI); FDR", fontsize=9, fontweight="bold", va="center")
    for i, r in enumerate(B.itertuples()):
        if isinstance(r.serum_assays, str) and r.serum_assays != "not measured" and not np.isnan(r.serum_OR_per_log_unit) and r.gene not in ("NOS3",):
            sig = r.serum_FDR < 0.06
            ax.text(6.0, i, f"{r.serum_OR_per_log_unit:.2f} ({r.serum_OR_CI}); {r.serum_FDR:.2g}", fontsize=8.6, va="center", color=C_RED if sig else "#555555", fontweight="bold" if sig else "normal")
        else:
            ax.text(6.0, i, "not measured in serum" if r.gene != "NOS3" else "intracellular", fontsize=8.6, va="center", color="#999999", style="italic")
    for (y0, y1, lab, col) in [(0, 0, "PATIENT:\nstratify", "k"), (1, 9, "PATIENT:\nPD / response\n(exploratory)\n+ in vitro PD", C_RED), (10, 19, "IN VITRO /\nEX VIVO PD\n& potency", C_CORE), (20, 21, "pathway", "#555555"), (22, 23, "function", "#555555")]:
        ax.text(-2.95, (y0 + y1) / 2, lab, ha="center", va="center", fontsize=8.8, fontweight="bold", color=col)
    cb = fig.colorbar(im, ax=ax, orientation="horizontal", fraction=0.03, pad=0.02, shrink=0.35, anchor=(0.32, 1.0)); cb.set_label("log2 fold change", fontsize=8.8)
    ax.set_xlim(-0.5, 5.5)
    fig.text(0.02, 0.012, "\u2020 delivered limma P-value is unreliable for this gene (inflated standard error; see Fig. 5) - effect sizes are replicated across independent arms, cell lines and time points.\nSerum values in red: FDR <= 0.05 (MCP-1 and tissue factor 0.051; E-selectin shown in grey at FDR 0.09, nominal p = 0.02).", fontsize=8.3, va="bottom")
    fig.subplots_adjust(left=0.27, right=0.70, top=0.87, bottom=0.13)
    fig.suptitle("Biomarker shortlist: in-vitro pharmacology (left) and patient association (right)", fontsize=12.5, fontweight="bold", y=0.985)
    fig.savefig(f"{FIG}/Fig4_biomarker_shortlist.png"); plt.close(fig)

if __name__ == "__main__":
    for f in (fig1, fig2, fig3, fig4, fig5):
        np.random.seed(0)          # label placement (adjustText) uses random jitter; fix it so figures are reproducible
        f()
    print("figures written to", FIG)
