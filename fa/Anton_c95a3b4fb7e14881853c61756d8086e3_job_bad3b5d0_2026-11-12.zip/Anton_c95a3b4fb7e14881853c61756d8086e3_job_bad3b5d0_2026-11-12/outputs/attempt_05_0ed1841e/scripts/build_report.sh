#!/usr/bin/env bash
# Rebuilds the .docx from the markdown source (run after editing AX-1177_portfolio_audit_position.md).
# Usage: bash build_report.sh [OUT]      Needs pandoc (available in the 'renv' environment).
set -euo pipefail
OUT=${1:-/tmp/outputs}; TMP=$(mktemp -d)
micromamba run -n renv pandoc -o "$TMP/ref.docx" --print-default-data-file reference.docx
python3 - "$TMP" <<'PY'
import sys, re, zipfile
tmp = sys.argv[1]; zin = zipfile.ZipFile(f"{tmp}/ref.docx"); zout = zipfile.ZipFile(f"{tmp}/custom-reference.docx", "w", zipfile.ZIP_DEFLATED)
border = "".join(f'<w:{k} w:val="single" w:sz="4" w:space="0" w:color="A0AEC0" />' for k in ("top", "left", "bottom", "right", "insideH", "insideV"))
for it in zin.infolist():
    data = zin.read(it.filename)
    if it.filename == "word/styles.xml":                      # bordered tables, shaded header row, 9-pt table text
        st = data.decode()
        st = re.sub(r'(<w:style w:type="table" w:default="1" w:styleId="Table">.*?<w:tblInd [^>]*/>)', r'\1<w:tblBorders>' + border + '</w:tblBorders>', st, flags=re.S)   # schema order: tblInd, tblBorders, tblCellMar
        st = st.replace('<w:tcBorders>\n          <w:bottom w:val="single"/>\n        </w:tcBorders>', '<w:shd w:val="clear" w:color="auto" w:fill="EDF2F7" />')
        st = re.sub(r'(w:styleId="Compact">.*?</w:pPr>)', r'\1<w:rPr><w:sz w:val="18" /><w:szCs w:val="18" /></w:rPr>', st, flags=re.S)
        data = st.encode()
    if it.filename == "word/document.xml":                    # page set-up
        d = data.decode(); mar = '<w:pgSz w:w="16838" w:h="11906" w:orient="landscape" /><w:pgMar w:top="1021" w:right="1021" w:bottom="1021" w:left="1021" w:header="720" w:footer="720" w:gutter="0" />'   # A4 landscape: wide tables and figures stay legible
        d = d.replace("</w:footnotePr>", "</w:footnotePr>" + mar, 1) if "</w:footnotePr>" in d else d.replace("<w:sectPr>", "<w:sectPr>" + mar, 1)   # schema order: footnotePr before pgMar
        data = d.encode()
    zout.writestr(it, data)
zout.close()
PY
cd "$OUT" && micromamba run -n renv pandoc AX-1177_portfolio_audit_position.md -o AX-1177_portfolio_audit_position.docx --resource-path=. --reference-doc="$TMP/custom-reference.docx"
rm -rf "$TMP"; echo "wrote $OUT/AX-1177_portfolio_audit_position.docx"
