#!/usr/bin/env python
"""Step 2 - serum Olink summary statistics (one logistic model per assay vs the composite endpoint; adjusted for age, sex, NEWS2).
Run: micromamba run -n singlecell python 02_serum.py /tmp/work /tmp/outputs      (requires step 1 output gene_master.parquet)
"""
import sys, json
import numpy as np, pandas as pd
from scipy import stats
sys.path.insert(0, __file__.rsplit("/", 1)[0])
from olink_map import to_symbol

WORK = sys.argv[1] if len(sys.argv) > 1 else "/tmp/work"
OUT = sys.argv[2] if len(sys.argv) > 2 else "/tmp/outputs"
KEY = {}
d = pd.read_csv(f"{WORK}/serum_raw.csv")
d["rank"] = np.arange(1, len(d) + 1)
d["panel_short"] = d.panel.str.replace("Olink Target 96 ", "").str.replace(r"\(v\.\d+\)", "", regex=True)
d["gene"] = d.assay.map(to_symbol)
d["logOR"] = np.log(d.OR); d["se_logOR"] = (np.log(d.u95) - np.log(d.l95)) / (2 * 1.959964); d["z"] = d.logOR / d.se_logOR

# ---- integrity ----
KEY["n_assays_delivered"] = int(len(d)); KEY["n_panels"] = int(d.panel.nunique()); KEY["assays_per_panel"] = d.groupby("panel_short").size().to_dict()
KEY["n_missing_vs_13x92"] = int(13 * 92 - len(d))
KEY["wald_p_consistent_with_CI"] = bool(np.abs(np.log10(2 * stats.norm.sf(d.z.abs())) - np.log10(d["p.value"])).max() < 1e-3)
KEY["BH_denominator_implied_by_top_hit"] = round(float(d["adj.p.value"].iloc[0] / d["p.value"].iloc[0]), 1)   # rank 1: adj = p * N
n0 = np.sort(d.composite_endpoint_0.unique()); n1 = np.sort(d.composite_endpoint_1.unique())
KEY["undefined_columns"] = dict(composite_endpoint_0_values_x56=[round(float(v * 56), 3) for v in n0], composite_endpoint_1_values_x44=[round(float(v * 44), 3) for v in n1],
                                inference="values are multiples of 1/56 and 1/44 -> per-group fractions (most likely samples below LOD / missing) with 56 non-events and 44 events; max < 10%")
inflam_full = ["IL8","VEGFA","CD8A","MCP-3","GDNF","CDCP1","CD244","IL7","OPG","LAP TGF-beta-1","uPA","IL6","IL-17C","MCP-1","IL-17A","CXCL11","AXIN1","TRAIL","IL-20RA","CXCL9","CST5","IL-2RB","IL-1 alpha","OSM","IL2","CXCL1","TSLP","CCL4","CD6","SCF","IL18","SLAMF1","TGF-alpha","MCP-4","CCL11","TNFSF14","FGF-23","IL-10RA","FGF-5","MMP-1","LIF-R","FGF-21","CCL19","IL-15RA","IL-10RB","IL-22 RA1","IL-18R1","PD-L1","Beta-NGF","CXCL5","TRANCE","HGF","IL-12B","IL-24","IL13","ARTN","MMP-10","IL10","TNF","CCL23","CD5","CCL3","Flt3L","CXCL6","CXCL10","4E-BP1","IL-20","SIRT2","CCL28","DNER","EN-RAGE","CD40","IL33","IFN-gamma","FGF-19","IL4","LIF","NRTN","MCP-2","CASP-8","CCL25","CX3CL1","TNFRSF9","NT-3","TWEAK","CCL20","ST1A1","STAMBP","IL5","ADA","TNFB","CSF-1"]
import re
have = set(re.sub(r"-(INFI)$", "", a) for a in d.loc[d.panel_short == "Inflammation", "assay"])
KEY["inflammation_panel_assays_not_delivered"] = sorted(set(inflam_full) - have)     # catalogue content of Olink Target 96 Inflammation (background knowledge)
KEY["IL33_assay_in_delivery"] = bool(d.assay.str.fullmatch(r"IL-?33.*", case=False).any())

# ---- headline statistics ----
KEY["n_p_lt_0_05"] = int((d["p.value"] < 0.05).sum()); KEY["n_FDR_lt_0_05"] = int((d["adj.p.value"] < 0.05).sum())
KEY["n_OR_gt_1"] = int((d.OR > 1).sum()); KEY["n_FDR_lt_0_05_OR_gt_1"] = int(((d["adj.p.value"] < 0.05) & (d.OR > 1)).sum())
def row(a):
    r = d[d.assay == a].iloc[0]
    return dict(panel=r.panel_short, gene=r.gene, OR=round(float(r.OR), 2), CI=[round(float(r.l95), 2), round(float(r.u95), 2)], p=float(f"{r['p.value']:.2g}"), FDR=float(f"{r['adj.p.value']:.2g}"), rank=int(r["rank"]), z=round(float(r.z), 2))
for a in ["ST2", "HGF", "IL6", "IL6-ONCII", "IL6-CVDII", "IL6-IMO", "PTX3", "OPG-INFI", "OPG-CVDIII", "IL8", "CCL20", "MCP-1-INFI", "MCP-1-CVDIII", "MCP-3", "TF", "SELE", "VCAM1", "ICAM1", "CSF-1", "IL-18R1", "IL1B", "CXCL1-INFI", "CXCL5", "CXCL6", "G-CSF", "TNF", "CXCL10", "CX3CL1",
          "IL5-IMO", "CCL11-INFI", "CCL11-IMO", "CCL17", "CCL24", "TPSAB1", "IL17RB", "IL-5R-alpha", "RNASE3", "NT-proBNP-CVDIII", "NT-proBNP-MET", "TNNI3", "KIM1-CVDII", "KIM1-ODA", "CST3", "vWF", "ANGPT2", "RAGE", "IL-1RT1", "IL-4RA"]:
    KEY["assay_" + a] = row(a)
# ---- marker sets (analyst-defined from general biology; some members had been inspected individually beforehand, so set-level tests are descriptive) ----
SETS = {"neutrophil_granule_and_activation": ["PRTN3", "MPO", "AZU1", "DEFA1", "CEACAM8", "LCN2", "MMP-9", "PGLYRP1", "RETN", "CD177", "ARG1", "CHI3L1", "EN-RAGE", "S100P", "FCAR", "TREM1", "OSM", "HGF", "CLEC5A", "NCF2"],
        "type2_eosinophil_mast_cell": ["IL5-IMO", "CCL11-INFI", "CCL11-IMO", "CCL17", "CCL24", "TPSAB1", "IL17RB", "IL-5R-alpha", "RNASE3"],
        "cardiac": ["NT-proBNP-CVDIII", "NT-proBNP-MET", "TNNI3", "MB", "FABP4"], "renal": ["KIM1-CVDII", "KIM1-ODA", "CST3", "TFF3", "REN"]}
KEY["marker_sets"] = {}
for nm, lst in SETS.items():
    assert all(a in set(d.assay) for a in lst), [a for a in lst if a not in set(d.assay)]
    ins = d.assay.isin(lst); a_, b_ = d[ins], d[~ins]
    tab = [[int((a_["p.value"] < 0.05).sum()), int((a_["p.value"] >= 0.05).sum())], [int((b_["p.value"] < 0.05).sum()), int((b_["p.value"] >= 0.05).sum())]]
    KEY["marker_sets"][nm] = dict(n=int(ins.sum()), n_p_lt_0_05=tab[0][0], n_FDR_lt_0_05=int((a_["adj.p.value"] < 0.05).sum()), background_frac_p_lt_0_05=round(tab[1][0] / sum(tab[1]), 3),
                                  fisher_p=float(f"{stats.fisher_exact(tab)[1]:.2g}"), median_OR=round(float(a_.OR.median()), 2), not_significant=a_.loc[a_["p.value"] >= 0.05, "assay"].tolist())
# ---- multi-panel replicates ----
dup = d[d.gene.duplicated(keep=False)].groupby("gene").agg(n=("assay", "size"), assays=("assay", "; ".join), OR_min=("OR", "min"), OR_max=("OR", "max"), p_min=("p.value", "min"), p_max=("p.value", "max"))
dup["same_direction"] = d[d.gene.duplicated(keep=False)].groupby("gene").logOR.apply(lambda s: (np.sign(s) == np.sign(s.iloc[0])).all())
dup.to_csv(f"{OUT}/tables/T4b_serum_multipanel_replicates.csv")
KEY["multi_panel_proteins"] = int(len(dup)); KEY["multi_panel_same_direction"] = int(dup.same_direction.sum())
pairs = d[d.gene.duplicated(keep=False)].groupby("gene").z.apply(list); zz = np.array([(v[0], v[1]) for v in pairs])
KEY["multi_panel_z_correlation"] = round(float(np.corrcoef(zz[:, 0], zz[:, 1])[0, 1]), 3)

# ---- cross-reference with the endothelial IL-33 programme (step 1) ----
M = pd.read_parquet(f"{WORK}/gene_master.parquet")
s2e = {}
for ens, r in M.iterrows():
    for s in (r.symbol, r.delivered_symbol):
        if isinstance(s, str): s2e.setdefault(s, ens)
d["ensembl"] = d.gene.map(s2e)
x = d.merge(M[["logFC_IL33_HUVEC_6h", "empirical_z_IL33_HUVEC_6h", "limma_adjP_IL33_HUVEC_6h", "logFC_IL33_HUVEC_24h", "logFC_NEUT_HUVEC_6h", "logFC_NEUT_HUVEC_24h", "logFC_NEUT_HGMEC_6h", "logFC_NEUT_HGMEC_24h", "degenerate_SE_flag"]], left_on="ensembl", right_index=True, how="left")
ind = (x.logFC_IL33_HUVEC_6h >= 1) & (x.empirical_z_IL33_HUVEC_6h > 4) & (x.logFC_NEUT_HUVEC_6h <= -0.5 * x.logFC_IL33_HUVEC_6h)
x["endothelial_IL33_class"] = np.where(x.ensembl.isna(), "gene not in RNA-seq table", np.where(ind, "IL-33-induced & AX-1177-reversed", "not IL-33-induced"))
KEY["n_assays_mapped_to_RNAseq_gene"] = int(x.ensembl.notna().sum())
g = x[x.ensembl.notna()].groupby("gene").agg(z=("z", "mean"), p=("p.value", "min"), ind=("endothelial_IL33_class", lambda s: (s == "IL-33-induced & AX-1177-reversed").any()))
a_, b_ = g[g.ind], g[~g.ind]
tab = [[int((a_.p < 0.05).sum()), int((a_.p >= 0.05).sum())], [int((b_.p < 0.05).sum()), int((b_.p >= 0.05).sum())]]
KEY["enrichment_IL33_endothelial_genes_among_outcome_proteins"] = dict(n_IL33_induced_genes_measured=int(len(a_)), frac_p_lt_0_05=round(float((a_.p < 0.05).mean()), 3), background_frac=round(float((b_.p < 0.05).mean()), 3),
    fisher_OR=round(float(stats.fisher_exact(tab)[0]), 2), fisher_p_one_sided=round(float(stats.fisher_exact(tab, alternative="greater")[1]), 3), mannwhitney_p_one_sided=round(float(stats.mannwhitneyu(a_.z, b_.z, alternative="greater").pvalue), 3))
# sensitivity: permissive definition (robust induction + robust reversal of ANY magnitude, by empirical z) and adjustment for expression level
import statsmodels.api as sm
xs = x.merge(M[["empirical_z_NEUT_HUVEC_6h", "AveExpr_all_114_libraries"]], left_on="ensembl", right_index=True, how="left")
gs = xs[xs.ensembl.notna()].groupby("gene").agg(p=("p.value", "min"), lfc=("logFC_IL33_HUVEC_6h", "first"), zI=("empirical_z_IL33_HUVEC_6h", "first"), zN=("empirical_z_NEUT_HUVEC_6h", "first"), ave=("AveExpr_all_114_libraries", "first"))
gs["sig"] = gs.p < 0.05; ind2 = (gs.zI > 4) & (gs.zN < -4); rep2 = (gs.zI < -4) & (gs.zN > 4); unreg = gs.zI.abs() < 2
fe = lambda a, b: stats.fisher_exact([[int(gs.sig[a].sum()), int((~gs.sig[a]).sum())], [int(gs.sig[b].sum()), int((~gs.sig[b]).sum())]])
lg = sm.Logit(gs.sig.astype(int), sm.add_constant(pd.DataFrame({"induced": ind2.astype(int), "repressed": rep2.astype(int), "AveExpr": gs.ave}))).fit(disp=0)
KEY["enrichment_sensitivity_permissive_definition"] = dict(n_induced=int(ind2.sum()), frac_sig_induced=round(float(gs.sig[ind2].mean()), 3), n_unregulated=int(unreg.sum()), frac_sig_unregulated=round(float(gs.sig[unreg].mean()), 3),
    n_repressed=int(rep2.sum()), frac_sig_repressed=round(float(gs.sig[rep2].mean()), 3), fisher_induced_vs_unregulated_p=round(float(fe(ind2, unreg)[1]), 4), fisher_induced_vs_repressed_p=round(float(fe(ind2, rep2)[1]), 4),
    frac_sig_induced_log2FC_lt_0_5=round(float(gs.sig[ind2 & (gs.lfc < 0.5)].mean()), 2), frac_sig_induced_log2FC_ge_2=round(float(gs.sig[ind2 & (gs.lfc >= 2)].mean()), 2),
    logit_induced_coef_adjusted_for_expression=round(float(lg.params["induced"]), 3), logit_induced_p_adjusted_for_expression=round(float(lg.pvalues["induced"]), 3), logit_AveExpr_p=float(f"{lg.pvalues['AveExpr']:.1e}"))
cols = ["rank", "panel_short", "assay", "gene", "OR", "l95", "u95", "p.value", "adj.p.value", "z", "composite_endpoint_0", "composite_endpoint_1", "ensembl", "endothelial_IL33_class",
        "logFC_IL33_HUVEC_6h", "empirical_z_IL33_HUVEC_6h", "limma_adjP_IL33_HUVEC_6h", "logFC_IL33_HUVEC_24h", "logFC_NEUT_HUVEC_6h", "logFC_NEUT_HUVEC_24h", "logFC_NEUT_HGMEC_6h", "logFC_NEUT_HGMEC_24h", "degenerate_SE_flag"]
x[cols].to_csv(f"{OUT}/tables/T4_serum_annotated.csv", index=False); x.to_parquet(f"{WORK}/serum_annot.parquet")
top = x[(x.endothelial_IL33_class == "IL-33-induced & AX-1177-reversed") & (x["p.value"] < 0.05)]
KEY["IL33_induced_and_outcome_associated_assays"] = top.assay.tolist()
KEY["top30_hits_IL33_induced"] = x.head(30).loc[x.head(30).endothelial_IL33_class == "IL-33-induced & AX-1177-reversed", "assay"].tolist()
json.dump(KEY, open(f"{OUT}/tables/key_numbers_serum.json", "w"), indent=1)
print(json.dumps({k: v for k, v in KEY.items() if not k.startswith("assay_")}, indent=1))
print({k[6:]: (v["OR"], v["CI"], v["p"], v["FDR"], v["rank"]) for k, v in KEY.items() if k.startswith("assay_")})
