#!/usr/bin/env bash
# Re-runs the whole analysis from the delivered files.  Usage: bash run_all.sh [SRC] [WORK] [OUT]
# Needs the 'singlecell' (python: pandas, scipy, statsmodels, matplotlib, adjustText, openpyxl, pyarrow) and 'renv' (R: org.Hs.eg.db, msigdbr, fgsea) environments.
set -euo pipefail
SRC=${1:-/tmp/world/filesystem}; WORK=${2:-/tmp/work}; OUT=${3:-/tmp/outputs}
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$WORK" "$OUT/tables" "$OUT/figures"
PY="micromamba run -n singlecell python"; RS="micromamba run -n renv Rscript"
$PY "$HERE/00_parse_inputs.py" "$SRC" "$WORK"            # ~3 min (123 MB workbook)
$RS "$HERE/00b_annotation.R" "$WORK" 2>/dev/null
$PY "$HERE/01_rnaseq.py" "$WORK" "$OUT" > "$WORK/01_rnaseq.log"
$RS "$HERE/01b_gsea.R" "$WORK" "$OUT" > "$WORK/01b_gsea.log" 2>&1   # ~1 min
$PY "$HERE/02_serum.py" "$WORK" "$OUT" > "$WORK/02_serum.log"
$PY "$HERE/03_lung.py" "$SRC" "$WORK" "$OUT" > "$WORK/03_lung.log"
$PY "$HERE/04_biomarkers.py" "$WORK" "$OUT" > "$WORK/04_biomarkers.log"
$PY "$HERE/05_figures.py" "$WORK" "$OUT"
$PY "$HERE/06_integrity_log.py" "$OUT"
echo "all steps finished; tables in $OUT/tables, figures in $OUT/figures"
