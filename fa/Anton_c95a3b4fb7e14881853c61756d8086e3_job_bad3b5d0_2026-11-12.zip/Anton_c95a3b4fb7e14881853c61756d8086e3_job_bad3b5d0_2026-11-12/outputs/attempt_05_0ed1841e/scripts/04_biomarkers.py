#!/usr/bin/env python
"""Step 4 - biomarker shortlist: joins the endothelial pharmacology (step 1) with the patient serum associations (step 2).
Run: micromamba run -n singlecell python 04_biomarkers.py /tmp/work /tmp/outputs
Numbers are pulled from the step-1/2 tables; marker selection, classes and proposed roles are analyst judgement and are labelled as such.
"""
import sys, json
import numpy as np, pandas as pd
WORK = sys.argv[1] if len(sys.argv) > 1 else "/tmp/work"
OUT = sys.argv[2] if len(sys.argv) > 2 else "/tmp/outputs"
M = pd.read_parquet(f"{WORK}/gene_master.parquet"); S = pd.read_parquet(f"{WORK}/serum_annot.parquet")
sym2ens = {r.delivered_symbol: e for e, r in M.iterrows()}

# ---- (a) unbiased screen: what a purely rule-based filter returns ----
scr = M[(M.logFC_IL33_HUVEC_6h >= 4) & (M.empirical_z_IL33_HUVEC_6h > 5) & (M.pct_reversal_HUVEC_6h >= 85) & (M.logFC_NEUT_HGMEC_6h <= -2) & (M.max_abs_logFC_antibody_alone_endothelial < 2)].copy()
scr["retained_at_24h_pct_of_6h"] = 100 * scr.logFC_IL33_HUVEC_24h / scr.logFC_IL33_HUVEC_6h
best = S[S.ensembl.notna()].sort_values("p.value").drop_duplicates("ensembl").set_index("ensembl")
scr = scr.join(best[["assay", "OR", "l95", "u95", "p.value", "adj.p.value", "rank"]].add_prefix("serum_"))
scr.sort_values("logFC_IL33_HUVEC_6h", ascending=False).to_csv(f"{OUT}/tables/T2b_rule_based_screen_endothelial_PD_candidates.csv")
print("rule-based screen: %d genes (>=16x induced at 6h, z>5, >=85%% reversed in HUVEC, >=4x reversed in HGMEC, inert to antibody alone); %d have a serum assay; %d of those p<0.05"
      % (len(scr), scr.serum_assay.notna().sum(), (scr["serum_p.value"] < 0.05).sum()))

# ---- (b) curated shortlist with roles ----
P = [  # gene, protein / analyte, class, proposed role, where / when, caveat
 ("IL1RL1", "sST2 (soluble ST2)", "IL-33 axis (decoy receptor)", "PATIENT - stratification / prognostic enrichment at enrolment; exploratory PD",
  "serum, enrolment (pre-dose)", "prognostic, not shown predictive; inducible by other cytokines; decoy for IL-33; single panel, no cut-off yet"),
 ("IL6", "IL-6", "endothelial IL-33 product - cytokine", "PATIENT - PD / response (exploratory); IN VITRO PD", "serum pre-dose + on-treatment; supernatant 24 h / mRNA 6 h", "not IL-33-specific (many sources)"),
 ("CXCL8", "IL-8 (CXCL8)", "endothelial IL-33 product - neutrophil chemokine", "PATIENT - PD / response (exploratory); IN VITRO PD", "serum pre-dose + on-treatment; supernatant 24 h / mRNA 6 h", "not IL-33-specific; delivered P-value unreliable"),
 ("CCL20", "CCL20", "endothelial IL-33 product - chemokine", "PATIENT - PD / response (exploratory); IN VITRO PD", "serum pre-dose + on-treatment; mRNA 6 h", "not IL-33-specific"),
 ("CCL2", "MCP-1 (CCL2)", "endothelial IL-33 product - monocyte chemokine", "PATIENT - PD / response (exploratory); IN VITRO PD", "serum pre-dose + on-treatment; mRNA 6 h", "serum FDR 0.051; delivered P-value unreliable"),
 ("CCL7", "MCP-3 (CCL7)", "endothelial IL-33 product - monocyte chemokine", "PATIENT - PD / response (exploratory)", "serum pre-dose + on-treatment", "low basal expression in vitro (noisy logFC)"),
 ("TNFRSF11B", "OPG", "endothelial IL-33 product - vascular", "PATIENT - PD / response, endothelial (exploratory)", "serum pre-dose + on-treatment; mRNA 6 h", "HGMEC reversal modest"),
 ("PTX3", "PTX3", "endothelial IL-33 product - vascular pentraxin", "PATIENT - PD / response, endothelial (exploratory)", "serum pre-dose + on-treatment; mRNA 6 h", "4.5x induction only; delivered P-value unreliable"),
 ("F3", "Tissue factor (TF)", "pro-thrombotic switch", "PATIENT - PD, thrombo-inflammation (exploratory); IN VITRO PD (6 h only)", "serum pre-dose + on-treatment; mRNA 6 h", "transient in vitro (gone by 24 h); serum FDR 0.051"),
 ("SELE", "sE-selectin", "endothelial activation - adhesion molecule (endothelium-restricted)", "IN VITRO hallmark PD; PATIENT - PD, endothelial (exploratory)", "mRNA / surface protein 6 h; serum pre-dose + on-treatment", "serum association nominal (FDR 0.09); delivered P-value unreliable"),
 ("VCAM1", "VCAM-1 / sVCAM-1", "endothelial activation - adhesion molecule", "IN VITRO hallmark PD (both endothelial beds)", "mRNA / surface protein 6 h", "sVCAM-1 NOT associated with outcome in our cohort; delivered P-value unreliable"),
 ("ICAM1", "ICAM-1 / sICAM-1", "endothelial activation - adhesion molecule", "IN VITRO hallmark PD (both endothelial beds)", "mRNA / surface protein 6 h", "sICAM-1 NOT associated with outcome in our cohort"),
 ("CSF2", "GM-CSF", "myeloid growth factor", "IN VITRO PD / potency read-out (largest, most sustained signal)", "mRNA 6 h; supernatant 24 h", "not on the serum panels - no patient data"),
 ("CSF3", "G-CSF", "myeloid growth factor", "IN VITRO PD / potency read-out", "mRNA 6 h; supernatant 24 h", "serum G-CSF not associated with outcome"),
 ("CXCL1", "CXCL1 (GRO-alpha)", "neutrophil chemokine", "IN VITRO PD / potency read-out", "mRNA 6 h; supernatant 24 h", "serum CXCL1 not associated (2 panels); delivered P-value unreliable"),
 ("CXCL2", "CXCL2", "neutrophil chemokine", "IN VITRO PD / potency read-out", "mRNA 6 h", "not on the serum panels"),
 ("CXCL5", "CXCL5", "neutrophil chemokine", "IN VITRO PD (sustained to 24 h, incl. HGMEC)", "mRNA 6 h and 24 h", "serum CXCL5 not associated"),
 ("CXCL6", "CXCL6", "neutrophil chemokine", "IN VITRO PD (sustained to 24 h)", "mRNA 6 h and 24 h", "serum CXCL6 not associated"),
 ("CX3CL1", "Fractalkine (CX3CL1)", "chemokine / adhesion", "IN VITRO PD", "mRNA 6 h", "serum borderline (p 0.054)"),
 ("CCL5", "RANTES (CCL5)", "chemokine", "IN VITRO PD (HGMEC effect as large at 24 h as at 6 h)", "mRNA 6 h and 24 h", "serum CCL5 not associated"),
 ("TNFAIP3", "A20 (TNFAIP3)", "NF-kB pathway engagement (intracellular)", "IN VITRO pathway-engagement read-out (mRNA only)", "mRNA 6 h", "not a circulating analyte"),
 ("NFKBIA", "IkB-alpha (NFKBIA)", "NF-kB pathway engagement (intracellular)", "IN VITRO pathway-engagement read-out (mRNA only)", "mRNA 6 h", "not a circulating analyte"),
 ("THBD", "Thrombomodulin", "endothelial function (IL-33-repressed, restored by AX-1177)", "IN VITRO PD - anticoagulant phenotype", "mRNA 6 h", "2x effect; soluble TM not associated with outcome"),
 ("NOS3", "eNOS (NOS3)", "endothelial function (IL-33-repressed, restored by AX-1177)", "IN VITRO PD - vasoprotective phenotype", "mRNA 6 h and 24 h", "2x effect; intracellular"),
]
rows = []
for gene, prot, cls, role, when, cav in P:
    e = sym2ens[gene]; m = M.loc[e]; s = S[S.ensembl == e].sort_values("p.value")
    rows.append(dict(gene=gene, analyte=prot, marker_class=cls,
        IL33_fold_induction_HUVEC_6h=round(float(2 ** m.logFC_IL33_HUVEC_6h), 1), logFC_IL33_HUVEC_6h=round(float(m.logFC_IL33_HUVEC_6h), 2), logFC_IL33_HUVEC_24h=round(float(m.logFC_IL33_HUVEC_24h), 2),
        pct_reversal_by_AX1177_HUVEC_6h=round(float(m.pct_reversal_HUVEC_6h), 0), pct_reversal_by_AX1177_HUVEC_24h=round(float(m.pct_reversal_HUVEC_24h), 0) if abs(m.logFC_IL33_HUVEC_24h) > 0.5 else np.nan,
        logFC_AX1177_effect_HGMEC_6h=round(float(m.logFC_NEUT_HGMEC_6h), 2), logFC_AX1177_effect_HGMEC_24h=round(float(m.logFC_NEUT_HGMEC_24h), 2),
        empirical_z_IL33_6h=round(float(m.empirical_z_IL33_HUVEC_6h), 1), delivered_limma_adjP_IL33_6h=float(f"{m.limma_adjP_IL33_HUVEC_6h:.2g}"), delivered_P_unreliable=bool(m.degenerate_SE_flag),
        max_abs_logFC_antibody_alone=round(float(m.max_abs_logFC_antibody_alone_endothelial), 2),
        serum_assays="; ".join(s.assay) if len(s) else "not measured", serum_OR_per_log_unit=round(float(s.OR.iloc[0]), 2) if len(s) else np.nan,
        serum_OR_CI=f"{s.l95.iloc[0]:.2f}-{s.u95.iloc[0]:.2f}" if len(s) else "", serum_p=float(f"{s['p.value'].iloc[0]:.2g}") if len(s) else np.nan, serum_FDR=float(f"{s['adj.p.value'].iloc[0]:.2g}") if len(s) else np.nan,
        serum_rank_of_1094=int(s["rank"].iloc[0]) if len(s) else np.nan, proposed_role=role, matrix_and_timepoint=when, caveat=cav))
T = pd.DataFrame(rows)
T.loc[len(T)] = dict(gene="IL33", analyte="IL-33 (free / total; reduced vs oxidised; IL-33:sST2 complex)", marker_class="drug target", proposed_role="PATIENT - target engagement / dose selection (MUST BE BUILT)",
                     matrix_and_timepoint="serum (+ airway fluid if available), pre-dose + on-treatment", serum_assays="IL33 is on the Inflammation panel but is not in the delivery",
                     caveat="IL-33 was not measured in any blood sample in the data package (lung IHC only); IL33 transcript is not induced by IL-33 in the endothelial cells tested")
T.to_csv(f"{OUT}/tables/T2_biomarker_shortlist.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40); pd.set_option("display.max_colwidth", 34)
print(T[["gene", "IL33_fold_induction_HUVEC_6h", "logFC_IL33_HUVEC_24h", "pct_reversal_by_AX1177_HUVEC_6h", "pct_reversal_by_AX1177_HUVEC_24h", "logFC_AX1177_effect_HGMEC_6h", "logFC_AX1177_effect_HGMEC_24h", "empirical_z_IL33_6h", "delivered_limma_adjP_IL33_6h", "serum_OR_per_log_unit", "serum_OR_CI", "serum_p", "serum_FDR", "serum_rank_of_1094"]].to_string(index=False))
