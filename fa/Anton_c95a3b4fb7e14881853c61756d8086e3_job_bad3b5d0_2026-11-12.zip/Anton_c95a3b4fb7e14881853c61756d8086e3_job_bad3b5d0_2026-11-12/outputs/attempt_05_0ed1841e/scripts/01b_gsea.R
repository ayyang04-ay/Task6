# Step 1b - pre-ranked gene-set enrichment (fgsea) on the delivered contrasts, MSigDB v7.5.1 Hallmark + Reactome (msigdbr).
# Primary ranking = log2 fold change (the delivered t statistics are unreliable for ~130 key genes, see step 1); t-ranking kept as sensitivity.
# Run: micromamba run -n renv Rscript 01b_gsea.R /tmp/work /tmp/outputs
suppressMessages({library(msigdbr); library(fgsea); library(data.table)})
args <- commandArgs(trailingOnly = TRUE); work <- ifelse(is.na(args[1]), "/tmp/work", args[1]); out <- ifelse(is.na(args[2]), "/tmp/outputs", args[2])
set.seed(1)
x <- fread(file.path(work, "gsea_input.csv"))
mk <- function(d) split(d$ensembl_gene, d$gs_name)
sets <- list(HALLMARK = mk(msigdbr(species = "Homo sapiens", category = "H")), REACTOME = mk(msigdbr(species = "Homo sapiens", category = "C2", subcategory = "CP:REACTOME")))
contr <- sub("^lfc__", "", grep("^lfc__", names(x), value = TRUE))
res <- list()
for (cn in contr) for (stat in c("lfc", "t")) {
  v <- x[[paste0(stat, "__", cn)]]; names(v) <- x$ensembl
  v <- v[x$AveExpr > -3 & is.finite(v)]            # drop the lowest-count features (noise-dominated logFC)
  v <- v + seq_along(v) * 1e-12                    # deterministic tie-break
  for (sn in names(sets)) {
    if (sn == "REACTOME" && (stat == "t" || !grepl("^(IL33|NEUT)", cn))) next
    fg <- suppressWarnings(fgseaMultilevel(sets[[sn]], v, minSize = 15, maxSize = 500, eps = 0, nproc = 4))
    fg$contrast <- cn; fg$ranking <- stat; fg$collection <- sn
    fg$leadingEdge <- sapply(fg$leadingEdge, function(e) paste(head(x$symbol[match(e, x$ensembl)], 12), collapse = ","))
    res[[length(res) + 1]] <- fg
  }
}
res <- rbindlist(res)
fwrite(res[, .(collection, pathway, contrast, ranking, NES, pval, padj, size, leadingEdge)], file.path(out, "tables", "T1c_gsea_hallmark_reactome.csv"))
cat("done", nrow(res), "rows\n")
