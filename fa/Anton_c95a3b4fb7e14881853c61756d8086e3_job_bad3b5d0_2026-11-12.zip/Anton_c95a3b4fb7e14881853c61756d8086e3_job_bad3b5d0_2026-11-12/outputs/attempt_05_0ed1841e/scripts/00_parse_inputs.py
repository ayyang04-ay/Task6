#!/usr/bin/env python
"""Step 0 - parse the delivered workbooks into tidy tables (nothing is filtered or altered).

* RNA-seq workbooks are stream-parsed (the contrasts workbook is 123 MB / 1.68 M sheet rows). Every row is kept,
  including rows hidden by the Excel autofilter; the hidden flag and the Excel row number are recorded.
* Run:  micromamba run -n singlecell python 00_parse_inputs.py /tmp/world/filesystem /tmp/work
"""
import sys, re, zipfile
import xml.etree.ElementTree as ET
import pandas as pd, numpy as np

SRC = sys.argv[1] if len(sys.argv) > 1 else "/tmp/world/filesystem"
WORK = sys.argv[2] if len(sys.argv) > 2 else "/tmp/work"
NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"

def shared_strings(z):
    out = []
    with z.open("xl/sharedStrings.xml") as f:
        for _, el in ET.iterparse(f, events=("end",)):
            if el.tag == NS + "si":
                out.append("".join(t.text or "" for t in el.iter(NS + "t"))); el.clear()
    return out

def sheet_map(z):
    wb = ET.fromstring(z.read("xl/workbook.xml")); rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
    tgt = {r.attrib["Id"]: r.attrib["Target"] for r in rels}
    return [(s.attrib["name"], "xl/" + tgt[s.attrib[RID]].lstrip("/").replace("xl/", "")) for s in wb.find(NS + "sheets")]

def col_idx(ref):
    n = 0
    for ch in re.match(r"[A-Z]+", ref).group(0):
        n = n * 26 + (ord(ch) - 64)
    return n - 1

def parse_sheet(z, path, sst, ncol=11):
    rows, hidden, rnum, info = [], [], [], {}
    with z.open(path) as f:
        for _, el in ET.iterparse(f, events=("end",)):
            if el.tag == NS + "row":
                vals = [None] * ncol
                for c in el:
                    ci = col_idx(c.attrib["r"])
                    if ci >= ncol: continue
                    v = c.find(NS + "v")
                    if c.attrib.get("t") == "s":
                        vals[ci] = sst[int(v.text)] if v is not None else None
                    else:
                        vals[ci] = v.text if v is not None else None
                rows.append(vals); hidden.append(el.attrib.get("hidden") == "1"); rnum.append(int(el.attrib["r"])); el.clear()
            elif el.tag == NS + "autoFilter":
                info["autoFilter"] = ET.tostring(el, encoding="unicode")
    return rows, hidden, rnum, info

def parse_limma_workbook(fn, prefix):
    z = zipfile.ZipFile(fn); sst = shared_strings(z); out = []
    for name, path in sheet_map(z):
        rows, hidden, rnum, info = parse_sheet(z, path, sst)
        df = pd.DataFrame(rows[1:], columns=rows[0]); df["xl_row"] = rnum[1:]; df["xl_hidden"] = hidden[1:]; df["sheet"] = name
        n_empty = int(df.Comparison.isna().sum()); df = df[df.Comparison.notna()].copy()
        for c in ["logFC", "AveExpr", "t", "P.Value", "adj.P.Val", "B"]:
            df[c] = pd.to_numeric(df[c])
        safe = re.sub(r"[^A-Za-z0-9]+", "_", name); df.to_parquet(f"{WORK}/{prefix}_{safe}.parquet")
        print(f"[{prefix}] sheet '{name}': {len(df):,} data rows, {df.Comparison.nunique()} contrasts, {int(df.xl_hidden.sum()):,} rows hidden by filter, {n_empty:,} empty trailing rows")
        print("     filter/sort state:", re.sub(r'xmlns:\w+="[^"]+" ?', "", info.get("autoFilter", ""))[:330])
        out.append(df)
    return out

if __name__ == "__main__":
    h = parse_limma_workbook(f"{SRC}/AX-1177_rnaseq_huvec_il33.xlsx", "huvec")
    c = parse_limma_workbook(f"{SRC}/AX-1177_rnaseq_contrasts.xlsx", "contrasts")
    # integrity: are the "6h" and "24h" tabs of the contrasts workbook the same table?
    a, b = c[0], c[1]
    m = a.merge(b, on=["Comparison", "ensembl"], how="outer", suffixes=("_a", "_b"), indicator=True)
    same = (m._merge == "both").all() and all((m[k + "_a"] == m[k + "_b"]).all() for k in ["logFC", "AveExpr", "t", "P.Value", "adj.P.Val", "B"])
    print(f"contrasts workbook: tab '{a.sheet.iloc[0]}' and tab '{b.sheet.iloc[0]}' contain identical data for all {len(m):,} (contrast, gene) pairs: {same}")
    keep = ["Comparison", "ensembl", "logFC", "AveExpr", "t", "P.Value", "adj.P.Val", "B", "symbol", "entrez", "gene_name"]
    allc = pd.concat([h[0][keep], h[1][keep], b[keep]], ignore_index=True)
    assert allc.groupby("Comparison").size().nunique() == 1 and allc.Comparison.nunique() == 26
    allc.to_parquet(f"{WORK}/all_contrasts_long.parquet")
    print("combined long table:", allc.shape, "->", f"{WORK}/all_contrasts_long.parquet")
    # serum proteomics
    s = pd.read_excel(f"{SRC}/AX-1177_serum_proteomics.xlsx"); s.to_csv(f"{WORK}/serum_raw.csv", index=False); print("serum:", s.shape)
