#!/usr/bin/env python
"""Step 1 - RNA-seq contrast tables: integrity diagnostics, IL-33 response, AX-1177 neutralisation, antibody-alone effects.
Run: micromamba run -n singlecell python 01_rnaseq.py /tmp/work /tmp/outputs
Only the delivered limma tables are used (logFC, t, P, adj.P per contrast); no counts are available.
"""
import sys, json
import numpy as np, pandas as pd
from scipy import stats
from scipy.optimize import brentq

WORK = sys.argv[1] if len(sys.argv) > 1 else "/tmp/work"
OUT = sys.argv[2] if len(sys.argv) > 2 else "/tmp/outputs"
KEY = {}

SHORT = {
 'IL33_vs_Nontreated_HUVEC_6_hrs': 'IL33_HUVEC_6h', 'IL33_vs_Nontreated_HUVEC_24_hrs': 'IL33_HUVEC_24h',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs': 'NEUT_HUVEC_6h', 'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs': 'NEUT_HUVEC_24h',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs': 'NEUT_HGMEC_6h', 'Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs': 'NEUT_HGMEC_24h',
 'Compound_47_IL33_vs_IL33_HUVEC_6hrs': 'NEUTnoIso_HUVEC_6h', 'Compound_47_IL33_vs_IL33_HUVEC_24hrs': 'NEUTnoIso_HUVEC_24h',
 'Compound_47_IL33_vs_IL33_HGMEC_6hrs': 'NEUTnoIso_HGMEC_6h', 'Compound_47_IL33_vs_IL33_HGMEC_24hrs': 'NEUTnoIso_HGMEC_24h',
 'Compound_47_vs_IC119_HUVEC_6hrs': 'AB_HUVEC_6h', 'Compound_47_vs_IC119_HUVEC_24hrs': 'AB_HUVEC_24h',
 'Compound_47_vs_IC119_HGMEC_6hrs': 'AB_HGMEC_6h', 'Compound_47_vs_IC119_HGMEC_24hrs': 'AB_HGMEC_24h',
 'Compound_47_vs_IC119_A549_6hrs': 'AB_A549_6h', 'Compound_47_vs_IC119_A549_24hrs': 'AB_A549_24h',
 'Compound_47_vs_IC119_MCF7_6hrs': 'AB_MCF7_6h', 'Compound_47_vs_IC119_MCF7_24hrs': 'AB_MCF7_24h',
 'Compound_47_vs_DMSO_A549_6hrs': 'ABvDMSO_A549_6h', 'Compound_47_vs_DMSO_A549_24hrs': 'ABvDMSO_A549_24h',
 'Compound_47_vs_DMSO_MCF7_6hrs': 'ABvDMSO_MCF7_6h', 'Compound_47_vs_DMSO_MCF7_24hrs': 'ABvDMSO_MCF7_24h',
 'Compound_47_vs_PBS_A549_6hrs': 'ABvPBS_A549_6h', 'Compound_47_vs_PBS_A549_24hrs': 'ABvPBS_A549_24h',
 'Compound_47_vs_PBS_MCF7_6hrs': 'ABvPBS_MCF7_6h', 'Compound_47_vs_PBS_MCF7_24hrs': 'ABvPBS_MCF7_24h'}
DESCR = {
 'IL33_HUVEC': 'IL-33red vs vehicle (HUVEC)', 'NEUT': '(IL-33 + AX-1177) vs (IL-33 + isotype IC119)', 'NEUTnoIso': '(IL-33 + AX-1177) vs IL-33 alone',
 'AB': 'AX-1177 alone vs isotype IC119 alone', 'ABvDMSO': 'AX-1177 alone vs DMSO', 'ABvPBS': 'AX-1177 alone vs PBS'}

def load():
    long = pd.read_parquet(f"{WORK}/all_contrasts_long.parquet")
    long["contrast"] = long.Comparison.map(SHORT)
    assert long.contrast.notna().all()
    G = long.drop_duplicates("ensembl").set_index("ensembl")[["symbol", "entrez", "gene_name", "AveExpr"]]
    o = pd.read_csv(f"{WORK}/orgdb_ensembl_symbol.csv").drop_duplicates("ENSEMBL").set_index("ENSEMBL")
    G["hgnc_symbol"] = o.SYMBOL.reindex(G.index)
    clone = G.symbol.str.contains(r"\.") & G.hgnc_symbol.notna()
    G["best_symbol"] = np.where(clone, G.hgnc_symbol, G.symbol)
    W = {k: long.pivot(index="ensembl", columns="contrast", values=v)[list(SHORT.values())] for k, v in
         [("L", "logFC"), ("T", "t"), ("P", "P.Value"), ("A", "adj.P.Val")]}
    W["SE"] = W["L"] / W["T"]
    return long, G, W, int(clone.sum())

def deming(x, y):
    """Orthogonal (errors-in-both-variables, equal error variance) regression slope."""
    sxx, syy, sxy = np.var(x, ddof=1), np.var(y, ddof=1), np.cov(x, y)[0, 1]
    return (syy - sxx + np.sqrt((syy - sxx) ** 2 + 4 * sxy ** 2)) / (2 * sxy)

if __name__ == "__main__":
    long, G, W, n_clone = load()
    L, T, P, A, SE = W["L"], W["T"], W["P"], W["A"], W["SE"]
    sym = G.best_symbol
    KEY["n_genes"] = int(len(G)); KEY["n_contrasts"] = int(L.shape[1]); KEY["n_clone_style_symbols_with_hgnc"] = n_clone

    # ---------------- 1. contrast summary ----------------
    rows = []
    for c in L.columns:
        fam = c.rsplit("_", 2)[0] if not c.startswith("IL33") else "IL33_HUVEC"
        s = A[c] < 0.05
        rows.append(dict(contrast=c, delivered_label=[k for k, v in SHORT.items() if v == c][0], meaning=DESCR[fam], cell_line=c.split("_")[-2], time=c.split("_")[-1],
                         n_adjP_lt_0_05=int(s.sum()), n_up=int((s & (L[c] > 0)).sum()), n_down=int((s & (L[c] < 0)).sum()),
                         n_adjP_lt_0_05_and_absLFC_gt_1=int((s & (L[c].abs() > 1)).sum()), max_abs_logFC=float(L[c].abs().max()), min_P=float(P[c].min()),
                         sd_logFC_well_expressed_genes=float(L.loc[G.AveExpr > 3, c].std())))
    cs = pd.DataFrame(rows); cs.to_csv(f"{OUT}/tables/T1_rnaseq_contrast_summary.csv", index=False)

    # ---------------- 2. model diagnostics ----------------
    # 2a. implied total df from (t, P): robust empirical Bayes signature
    absT = T.abs(); best = absT.where((absT > 1.5) & (absT < 12)).idxmax(axis=1).dropna()
    dfs = pd.Series({g: brentq(lambda d: np.log(2 * stats.t.sf(abs(T.loc[g, c]), d)) - np.log(P.loc[g, c]), 0.5, 1e5) for g, c in best.items()})
    KEY["df_total_mode"] = float(dfs.round(2).mode().iloc[0]); KEY["df_total_min"] = float(dfs.min()); KEY["n_genes_df_total_below_mode"] = int((dfs < KEY["df_total_mode"] - 0.5).sum())
    # 2b. empirical null: 4 'antibody alone vs isotype alone' endothelial contrasts (uninduced state) and 4 derived 'isotype effect under IL-33'
    #     contrasts = (IL33+IC119) - IL33 = NEUTnoIso - NEUT (induced state). None shows reproducible signal (see section 4) -> use their
    #     mean squared logFC as a per-gene estimate of the sampling variance of a 3-vs-3 contrast.
    U = L[["AB_HUVEC_6h", "AB_HUVEC_24h", "AB_HGMEC_6h", "AB_HGMEC_24h"]]
    S = pd.concat([L[f"NEUTnoIso_{x}"] - L[f"NEUT_{x}"] for x in ["HUVEC_6h", "HUVEC_24h", "HGMEC_6h", "HGMEC_24h"]], axis=1)
    se_emp = np.sqrt(((U ** 2).mean(axis=1) + (S ** 2).mean(axis=1)) / 2)
    Z = L.div(se_emp, axis=0)                      # empirical-null z for every contrast
    se_med = SE.median(axis=1)
    degenerate = se_med > 2                        # typical SE is 0.1-0.8; >2 log2 units is not achievable with n=3 vs 3 replicate cultures
    ok = ~degenerate
    KEY["n_degenerate_SE_genes"] = int(degenerate.sum())
    KEY["empirical_vs_limma_SE_spearman_nondegenerate"] = float(stats.spearmanr(se_emp[ok], SE.loc[ok, "IL33_HUVEC_6h"]).statistic)
    KEY["empirical_vs_limma_SE_median_ratio_nondegenerate"] = float((se_emp[ok] / SE.loc[ok, "IL33_HUVEC_6h"]).median())
    KEY["z_emp_vs_t_limma_spearman_nondegenerate_IL33_6h"] = float(stats.spearmanr(Z.loc[ok, "IL33_HUVEC_6h"], T.loc[ok, "IL33_HUVEC_6h"]).statistic)
    abcols = [c for c in L.columns if c.startswith("AB")]
    dg = pd.DataFrame({"symbol": sym, "delivered_symbol": G.symbol, "AveExpr_all_114_libraries": G.AveExpr, "median_reported_SE_26_contrasts": se_med,
                       "reported_SE_IL33_HUVEC_6h": SE["IL33_HUVEC_6h"], "empirical_null_SE": se_emp, "ratio_reported_to_empirical": SE["IL33_HUVEC_6h"] / se_emp,
                       "max_abs_logFC_in_16_antibody_alone_contrasts": L[abcols].abs().max(axis=1),
                       "logFC_IL33_HUVEC_6h": L["IL33_HUVEC_6h"], "limma_t_IL33_HUVEC_6h": T["IL33_HUVEC_6h"], "limma_adjP_IL33_HUVEC_6h": A["IL33_HUVEC_6h"], "empirical_z_IL33_HUVEC_6h": Z["IL33_HUVEC_6h"],
                       "logFC_NEUT_HUVEC_6h": L["NEUT_HUVEC_6h"], "limma_adjP_NEUT_HUVEC_6h": A["NEUT_HUVEC_6h"], "empirical_z_NEUT_HUVEC_6h": Z["NEUT_HUVEC_6h"]})
    dg[degenerate].sort_values("median_reported_SE_26_contrasts", ascending=False).to_csv(f"{OUT}/tables/T7_degenerate_SE_genes.csv")
    KEY["degenerate_median_ratio_reported_to_empirical_SE"] = float(dg.loc[degenerate, "ratio_reported_to_empirical"].median())
    KEY["n_genes_reported_SE_gt_5x_empirical"] = int((dg.ratio_reported_to_empirical > 5).sum()); KEY["n_genes_reported_SE_gt_10x_empirical"] = int((dg.ratio_reported_to_empirical > 10).sum())
    strong = (L["IL33_HUVEC_6h"].abs() >= 2) & (Z["IL33_HUVEC_6h"].abs() > 5) & (L["NEUT_HUVEC_6h"] * L["IL33_HUVEC_6h"] < 0) & (L["NEUT_HUVEC_6h"].abs() > 1)
    missed = strong & (A["IL33_HUVEC_6h"] >= 0.05)
    KEY["strong_IL33_genes_n"] = int(strong.sum()); KEY["strong_IL33_genes_missed_by_delivered_adjP"] = sorted(sym[missed].tolist())
    for g in ["SELE", "VCAM1", "ICAM1", "CXCL8", "CXCL1", "CCL2", "PTGS2", "PTX3", "IL1RL1", "GAPDH", "CD93", "CSF2", "IL6", "F3", "THBD", "NOS3"]:
        e = G.index[G.symbol == g][0]
        KEY[f"gene_{g}"] = dict(logFC_IL33_6h=round(float(L.loc[e, "IL33_HUVEC_6h"]), 2), limma_t=round(float(T.loc[e, "IL33_HUVEC_6h"]), 3), limma_adjP=round(float(A.loc[e, "IL33_HUVEC_6h"]), 3),
                                reported_SE=round(float(SE.loc[e, "IL33_HUVEC_6h"]), 2), empirical_SE=round(float(se_emp[e]), 3), empirical_z=round(float(Z.loc[e, "IL33_HUVEC_6h"]), 1),
                                max_abs_null_logFC=round(float(L.loc[e, abcols].abs().max()), 2), max_abs_null_logFC_endothelial=round(float(L.loc[e, ["AB_HUVEC_6h", "AB_HUVEC_24h", "AB_HGMEC_6h", "AB_HGMEC_24h"]].abs().max()), 2),
                                logFC_NEUT_HUVEC_6h=round(float(L.loc[e, "NEUT_HUVEC_6h"]), 2), logFC_NEUT_HGMEC_6h=round(float(L.loc[e, "NEUT_HGMEC_6h"]), 2),
                                logFC_IL33_24h=round(float(L.loc[e, "IL33_HUVEC_24h"]), 2), logFC_NEUT_HUVEC_24h=round(float(L.loc[e, "NEUT_HUVEC_24h"]), 2), logFC_NEUT_HGMEC_24h=round(float(L.loc[e, "NEUT_HGMEC_24h"]), 2))
    # 2c. heavy tails in null contrasts
    t0 = T["AB_HUVEC_6h"]; KEY["null_contrast_frac_abs_t_gt4_observed"] = float((t0.abs() > 4).mean()); KEY["null_contrast_frac_abs_t_gt4_expected"] = float(2 * stats.t.sf(4, 85))

    # ---------------- 3. pharmacology: IL-33 response and its reversal ----------------
    I6, I24, N6, N24, H6, H24 = (L[c] for c in ["IL33_HUVEC_6h", "IL33_HUVEC_24h", "NEUT_HUVEC_6h", "NEUT_HUVEC_24h", "NEUT_HGMEC_6h", "NEUT_HGMEC_24h"])
    aI6, aN6, aH6, aI24, aN24, aH24 = (A[c] for c in ["IL33_HUVEC_6h", "NEUT_HUVEC_6h", "NEUT_HGMEC_6h", "IL33_HUVEC_24h", "NEUT_HUVEC_24h", "NEUT_HGMEC_24h"])
    both = (aI6 < 0.05) & (I6.abs() > 1) & (aN6 < 0.05) & (N6.abs() > 1)      # significant in two contrasts that share no arm
    core = both & (np.sign(I6) != np.sign(N6))                                # ... and in opposite directions = response AND reversal
    KEY["sig_in_both_contrasts_n"] = int(both.sum()); KEY["sig_in_both_but_same_direction_n"] = int((both & ~core).sum())
    KEY["core_signature_n"] = int(core.sum()); KEY["core_up"] = int((core & (I6 > 0)).sum()); KEY["core_down"] = int((core & (I6 < 0)).sum())
    def fit(x, y, mask):
        x_, y_ = x[mask].values, y[mask].values
        return dict(n=int(mask.sum()), pearson_r=round(float(np.corrcoef(x_, y_)[0, 1]), 3), ols_slope=round(float(np.polyfit(x_, y_, 1)[0]), 3), deming_slope=round(float(deming(x_, y_)), 3))
    indep = (aH6 < 0.05) & (H6.abs() > 1)            # gene set chosen on an independent experiment (HGMEC) -> no selection bias on HUVEC axes
    KEY["neutralisation_HUVEC_6h_genes_selected_on_HGMEC"] = fit(I6, N6, indep)
    KEY["neutralisation_HUVEC_6h_genes_selected_on_HUVEC_24h_response"] = fit(I6, N6, (aI24 < 0.05) & (I24.abs() > 1))
    KEY["neutralisation_HUVEC_24h_genes_selected_on_HGMEC"] = fit(I24, N24, indep)
    KEY["neutralisation_HUVEC_24h_genes_selected_on_HUVEC_6h_core"] = fit(I24, N24, core)
    KEY["HGMEC_vs_HUVEC_reversal_6h_core"] = fit(N6, H6, core); KEY["HGMEC_vs_HUVEC_reversal_24h_core"] = fit(N24, H24, core)
    KEY["isotype_effect_under_IL33_HUVEC_6h_slope"] = fit(I6, L["NEUTnoIso_HUVEC_6h"] - N6, indep)["ols_slope"]
    KEY["isotype_effect_under_IL33_HUVEC_24h_slope"] = fit(I24, L["NEUTnoIso_HUVEC_24h"] - N24, indep)["ols_slope"]
    KEY["isotype_vs_noisotype_comparator_HGMEC_6h"] = fit(H6, L["NEUTnoIso_HGMEC_6h"], core)
    # top-N induced genes (robust: empirical z > 5)
    for n in (10, 25, 50, 100):
        g6 = I6[Z["IL33_HUVEC_6h"] > 5].sort_values(ascending=False).index[:n]; g24 = I24[Z["IL33_HUVEC_24h"] > 5].sort_values(ascending=False).index[:n]
        r6 = -N6[g6] / I6[g6]; r24 = -N24[g24] / I24[g24]
        KEY[f"top{n}_induced"] = dict(min_fold_induction_6h=round(float(2 ** I6[g6].min()), 1), max_fold_induction_6h=round(float(2 ** I6[g6].max()), 0),
            pct_reversal_6h_median=round(float(100 * r6.median()), 0), pct_reversal_6h_IQR=[round(float(100 * r6.quantile(.25)), 0), round(float(100 * r6.quantile(.75)), 0)],
            pct_reversal_24h_median=round(float(100 * r24.median()), 0), pct_reversal_24h_IQR=[round(float(100 * r24.quantile(.25)), 0), round(float(100 * r24.quantile(.75)), 0)],
            HGMEC_over_HUVEC_reversal_6h_pct=round(float(100 * H6[g6].sum() / N6[g6].sum()), 0), HGMEC_over_HUVEC_reversal_24h_pct=round(float(100 * H24[g6].sum() / N24[g6].sum()), 0),
            HUVEC_IL33_24h_over_6h_pct=round(float(100 * I24[g6].sum() / I6[g6].sum()), 0),
            residual_vs_vehicle_median_abs_log2=round(float((I6[g6] + L["NEUTnoIso_HUVEC_6h"][g6]).abs().median()), 2))
    up = core & (I6 > 0)
    KEY["core_up_reversed_in_HGMEC_6h_frac_sig"] = round(float(((aH6 < 0.05) & (H6 < 0) & up).sum() / up.sum()), 3)
    KEY["core_up_reversed_in_HGMEC_24h_frac_sig"] = round(float(((aH24 < 0.05) & (H24 < 0) & up).sum() / up.sum()), 3)
    KEY["core_up_still_induced_2x_at_24h_frac"] = round(float(((I24 > 1) & up).sum() / up.sum()), 3)

    # ---------------- 4. antibody alone ----------------
    sig = {c: set(A.index[A[c] < 0.05]) for c in abcols}
    rep = []
    pairs = [("AB_HUVEC_6h", "AB_HUVEC_24h"), ("AB_HGMEC_6h", "AB_HGMEC_24h"), ("AB_A549_6h", "AB_A549_24h"), ("AB_MCF7_6h", "AB_MCF7_24h"),
             ("AB_HUVEC_6h", "AB_HGMEC_6h"), ("AB_HUVEC_24h", "AB_HGMEC_24h"), ("AB_A549_6h", "AB_MCF7_6h"), ("AB_A549_24h", "AB_MCF7_24h")]
    for a, b in pairs:
        ov = sig[a] & sig[b]
        rep.append(dict(contrast_a=a, contrast_b=b, n_sig_a=len(sig[a]), n_sig_b=len(sig[b]), overlap=len(ov), overlap_same_direction=int(sum(np.sign(L.loc[g, a]) == np.sign(L.loc[g, b]) for g in ov))))
    rep = pd.DataFrame(rep); rep.to_csv(f"{OUT}/tables/T1b_antibody_alone_reproducibility.csv", index=False)
    hits = pd.concat([pd.DataFrame({"c": c, "Ave": G.AveExpr.reindex(list(s)), "lfc": L.loc[list(s), c], "se": SE.loc[list(s), c]}) for c, s in sig.items()])
    KEY["antibody_alone"] = dict(n_contrasts=len(abcols), n_sig_range=[int(min(len(s) for s in sig.values())), int(max(len(s) for s in sig.values()))], total_hits=int(len(hits)),
        hits_low_expression_AveExpr_lt0_pct=round(float(100 * (hits.Ave < 0).mean()), 0), hits_tiny_effect_deflated_SE=int(((hits.lfc.abs() < 0.3) & (hits.se < 0.05)).sum()),
        replicating_across_independent_contrasts_same_direction=int(rep.overlap_same_direction.sum()), max_overlap_independent=int(rep.overlap.max()),
        signature_slope_range=[round(float(min((I6[core] * L[c][core]).sum() / (I6[core] ** 2).sum() for c in abcols)), 3), round(float(max((I6[core] * L[c][core]).sum() / (I6[core] ** 2).sum() for c in abcols)), 3)])

    # 4a. is everything AX-1177 does in the presence of IL-33 a reversal of the IL-33 programme? (immune-complex / off-programme effects)
    onp = (N6.abs() > 1) & (Z["NEUT_HUVEC_6h"].abs() > 5) & (aN6 < 0.05)
    rev = (np.sign(N6) != np.sign(I6)) & (I6.abs() > 0.5 * N6.abs())
    offp = onp & (I6.abs() < 0.3) & (Z["IL33_HUVEC_6h"].abs() < 2)
    KEY["AX1177_effect_under_IL33_HUVEC_6h"] = dict(n_genes_robustly_changed=int(onp.sum()), frac_that_are_reversals_of_IL33_effect=round(float((onp & rev).sum() / onp.sum()), 3),
        n_not_IL33_responsive=int(offp.sum()), not_IL33_responsive_max_AveExpr=round(float(G.AveExpr[offp].max()), 2), not_IL33_responsive_also_changed_in_HGMEC=int((offp & (H6.abs() > 1) & (np.sign(H6) == np.sign(N6)) & (aH6 < 0.05)).sum()))

    # 4b. vehicle and isotype effects in the epithelial lines, derived by subtraction: DMSO - PBS = (AB vs PBS) - (AB vs DMSO); IC119 - PBS = (AB vs PBS) - (AB vs IC119)
    hi = G.AveExpr.reindex(L.index) > 3
    der = {}
    for cl in ("A549", "MCF7"):
        for tp in ("6h", "24h"):
            der[f"DMSO-PBS_{cl}_{tp}"] = L[f"ABvPBS_{cl}_{tp}"] - L[f"ABvDMSO_{cl}_{tp}"]; der[f"IC119-PBS_{cl}_{tp}"] = L[f"ABvPBS_{cl}_{tp}"] - L[f"AB_{cl}_{tp}"]
    D = pd.DataFrame(der)[hi.values]
    cc = lambda a, b: float(np.corrcoef(D[a], D[b])[0, 1])
    KEY["vehicle_and_isotype_effects_epithelial"] = dict(
        sd_logFC_DMSO_vs_PBS=[round(float(D[c].std()), 3) for c in D if c.startswith("DMSO")], sd_logFC_IC119_vs_PBS=[round(float(D[c].std()), 3) for c in D if c.startswith("IC119")],
        sd_logFC_IL33_HUVEC_6h_for_scale=round(float(L.loc[hi.values, "IL33_HUVEC_6h"].std()), 3),
        r_DMSO_effect_6h_vs_24h=[round(cc("DMSO-PBS_A549_6h", "DMSO-PBS_A549_24h"), 3), round(cc("DMSO-PBS_MCF7_6h", "DMSO-PBS_MCF7_24h"), 3)],
        r_DMSO_effect_A549_vs_MCF7=[round(cc("DMSO-PBS_A549_6h", "DMSO-PBS_MCF7_6h"), 3), round(cc("DMSO-PBS_A549_24h", "DMSO-PBS_MCF7_24h"), 3)],
        r_IC119_effect_6h_vs_24h=[round(cc("IC119-PBS_A549_6h", "IC119-PBS_A549_24h"), 3), round(cc("IC119-PBS_MCF7_6h", "IC119-PBS_MCF7_24h"), 3)], n_genes=int(hi.sum()))

    # 4c. expression proxy per cell line. Per-line expression was not delivered (AveExpr is the 114-library mean). In contrasts with no treatment
    #     effect, a gene with near-zero counts in that line shows noise-dominated logFC (RMS ~0.6-1.3 log2) whereas an expressed gene shows < 0.2.
    grp = {"HUVEC": ["AB_HUVEC_6h", "AB_HUVEC_24h"], "HGMEC": ["AB_HGMEC_6h", "AB_HGMEC_24h"],
           "A549": [c for c in abcols if "A549" in c], "MCF7": [c for c in abcols if "MCF7" in c]}
    rms = pd.DataFrame({k: np.sqrt((L[v] ** 2).mean(axis=1)) for k, v in grp.items()})
    KEY["null_contrast_logFC_RMS_by_cell_line_expression_proxy"] = {g: {k: round(float(rms.loc[G.index[G.symbol == g][0], k]), 2) for k in grp}
                                                                   for g in ["IL1RL1", "IL1RAP", "IL33", "CDH5", "VWF", "PECAM1", "EPCAM", "TFF1", "KRT18", "ACTB"]}
    KEY["null_contrast_logFC_RMS_quantiles_all_genes"] = {k: [round(float(q), 2) for q in rms[k].quantile([0.25, 0.5, 0.9])] for k in grp}

    # 4d. sample mix-up check: sex-chromosome and lineage-identity genes should be flat in every within-cell-line contrast
    idg = ["XIST", "RPS4Y1", "DDX3Y", "KDM5D", "UTY", "CDH5", "VWF", "PECAM1", "KRT8", "KRT18", "KRT19", "GATA3", "ESR1", "NQO1", "AKR1C2"]
    sub = L.loc[[G.index[G.symbol == g][0] for g in idg]]
    KEY["identity_gene_check"] = dict(genes=idg, max_abs_logFC_any_contrast=round(float(sub.abs().max().max()), 2),
                                      max_abs_logFC_where_gene_expressed_in_that_line=round(float(max(
                                          sub.loc[[G.index[G.symbol == g][0] for g in ["CDH5", "VWF", "PECAM1"]], [c for c in L.columns if "HUVEC" in c or "HGMEC" in c]].abs().max().max(),
                                          sub.loc[[G.index[G.symbol == g][0] for g in ["KRT8", "KRT18", "NQO1"]], [c for c in L.columns if "A549" in c or "MCF7" in c]].abs().max().max())), 2))

    # ---------------- 5. master gene table ----------------
    M = pd.DataFrame({"symbol": sym, "delivered_symbol": G.symbol, "gene_name": G.gene_name, "AveExpr_all_114_libraries": G.AveExpr})
    for c in ["IL33_HUVEC_6h", "IL33_HUVEC_24h", "NEUT_HUVEC_6h", "NEUT_HUVEC_24h", "NEUT_HGMEC_6h", "NEUT_HGMEC_24h"]:
        M[f"logFC_{c}"] = L[c]; M[f"limma_adjP_{c}"] = A[c]; M[f"empirical_z_{c}"] = Z[c]
    M["pct_reversal_HUVEC_6h"] = -100 * N6 / I6; M["pct_reversal_HUVEC_24h"] = -100 * N24 / I24
    M["max_abs_logFC_antibody_alone_endothelial"] = L[["AB_HUVEC_6h", "AB_HUVEC_24h", "AB_HGMEC_6h", "AB_HGMEC_24h"]].abs().max(axis=1)
    M["empirical_null_SE"] = se_emp; M["degenerate_SE_flag"] = degenerate; M["core_signature"] = core
    M.to_parquet(f"{WORK}/gene_master.parquet"); M.to_csv(f"{OUT}/tables/T3_gene_master_table.csv.gz", compression={"method": "gzip", "mtime": 0})   # fixed mtime -> byte-identical on re-run
    L.to_parquet(f"{WORK}/W_logFC.parquet"); A.to_parquet(f"{WORK}/W_adjP.parquet"); T.to_parquet(f"{WORK}/W_t.parquet"); SE.to_parquet(f"{WORK}/W_SE.parquet"); Z.to_parquet(f"{WORK}/W_Zemp.parquet")
    G.to_parquet(f"{WORK}/genes_annot.parquet")
    gs = pd.DataFrame({"ensembl": L.index, "symbol": sym.reindex(L.index).values, "AveExpr": G.AveExpr.reindex(L.index).values})
    for c in ["IL33_HUVEC_6h", "IL33_HUVEC_24h", "NEUT_HUVEC_6h", "NEUT_HUVEC_24h", "NEUT_HGMEC_6h", "NEUT_HGMEC_24h", "AB_HUVEC_6h", "AB_HUVEC_24h", "AB_HGMEC_6h", "AB_HGMEC_24h", "AB_A549_6h", "AB_A549_24h", "AB_MCF7_6h", "AB_MCF7_24h"]:
        gs["lfc__" + c] = L[c].values; gs["t__" + c] = T[c].values
    gs.to_csv(f"{WORK}/gsea_input.csv", index=False)
    for c in ["IL33_HUVEC_6h", "IL33_HUVEC_24h", "NEUT_HUVEC_6h", "NEUT_HUVEC_24h", "NEUT_HGMEC_6h", "NEUT_HGMEC_24h"]:
        r = cs.set_index("contrast").loc[c]; KEY[f"DE_{c}"] = dict(adjP_lt_0_05=int(r.n_adjP_lt_0_05), up=int(r.n_up), down=int(r.n_down), and_absLFC_gt1=int(r.n_adjP_lt_0_05_and_absLFC_gt_1), sd_logFC_well_expressed=round(float(r.sd_logFC_well_expressed_genes), 3))
    KEY["null_sd_logFC_well_expressed_AB_contrasts"] = [round(float(cs.set_index("contrast").loc[c, "sd_logFC_well_expressed_genes"]), 3) for c in ["AB_HUVEC_6h", "AB_HUVEC_24h", "AB_HGMEC_6h", "AB_HGMEC_24h"]]
    json.dump(KEY, open(f"{OUT}/tables/key_numbers_rnaseq.json", "w"), indent=1)
    print(json.dumps(KEY, indent=1))
