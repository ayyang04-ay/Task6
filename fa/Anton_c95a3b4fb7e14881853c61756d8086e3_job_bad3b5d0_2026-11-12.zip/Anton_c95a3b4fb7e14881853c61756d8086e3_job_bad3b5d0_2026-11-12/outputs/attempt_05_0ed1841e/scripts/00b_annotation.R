# Step 0b - Ensembl -> HGNC symbol table from org.Hs.eg.db (used because 1,133 rows of the delivered RNA-seq tables carry
# clone-style names, e.g. ENSG00000076706 = MCAM is delivered as "AP002956.1"). Run: micromamba run -n renv Rscript 00b_annotation.R /tmp/work
suppressMessages({library(org.Hs.eg.db); library(AnnotationDbi)})
work <- commandArgs(trailingOnly = TRUE)[1]; if (is.na(work)) work <- "/tmp/work"
k <- keys(org.Hs.eg.db, keytype = "ENSEMBL")
m <- suppressMessages(AnnotationDbi::select(org.Hs.eg.db, keys = k, keytype = "ENSEMBL", columns = c("SYMBOL", "ENTREZID", "GENENAME")))
write.csv(m, file.path(work, "orgdb_ensembl_symbol.csv"), row.names = FALSE)
cat("wrote", nrow(m), "rows\n")
