import re
SUFFIX = r"-(INFI|ONCII|CVDII|CVDIII|IMO|CRE|ODA|NEX|NEUI|MET)$"
def strip(a): return re.sub(SUFFIX, "", a)
# Olink Target-96 assay name -> HGNC gene symbol (manual curation for names that are not gene symbols or are ambiguous)
MANUAL = {
 # ambiguous: look like gene symbols but mean something else on these panels
 "TF":"F3", "FS":"FST", "GH":"GH1", "GT":"FABP6", "MK":"MDK", "TR":"TFRC", "PLC":"HSPG2", "PAI":"SERPINE1", "OPN":"SPP1", "OPG":"TNFRSF11B",
 "ST2":"IL1RL1", "NEP":"MME", "TM":"THBD", "SCF":"KITLG", "GIF":"CBLIF", "SKR3":"ACVRL1", "TN-R":"TNR", "CAIX":"CA9", "5'-NT":"NT5E",
 "hK11":"KLK11","hK14":"KLK14","hK8":"KLK8","FR-alpha":"FOLR1","FR-gamma":"FOLR3","TGFR-2":"TGFBR2","MAD homolog 5":"SMAD5","MetAP 2":"METAP2",
 "MIC-A/B":"MICA","PVRL4":"NECTIN4","SYND1":"SDC1","CYR61":"CCN1","WISP-1":"CCN4","NOV":"CCN3","CXL17":"CXCL17","ESM-1":"ESM1","TFPI-2":"TFPI2",
 "Gal-1":"LGALS1","Gal-3":"LGALS3","Gal-4":"LGALS4","gal-8":"LGALS8","Gal-9":"LGALS9","ADAM 8":"ADAM8","ADAM-TS 15":"ADAMTS15","ADAM 22":"ADAM22","ADAM 23":"ADAM23",
 "IFN-gamma-R1":"IFNGR1","VEGFR-2":"KDR","VEGFR-3":"FLT4","WIF-1":"WIF1","FGF-BP1":"FGFBP1","MUC-16":"MUC16",
 "ADAM-TS13":"ADAMTS13","BMP-6":"BMP6","CD40-L":"CD40LG","CTSL1":"CTSL","Dkk-1":"DKK1","FGF-21":"FGF21","GDF-2":"GDF2","HAOX1":"HAO1","HB-EGF":"HBEGF","HO-1":"HMOX1",
 "HSP 27":"HSPB1","IL-17D":"IL17D","IL-1ra":"IL1RN","IL-27":"IL27","IL-4RA":"IL4R","IgG Fc receptor II-b":"FCGR2B","KIM1":"HAVCR1","LOX-1":"OLR1","NEMO":"IKBKG",
 "PAR-1":"F2R","PARP-1":"PARP1","PD-L2":"PDCD1LG2","PDGF subunit B":"PDGFB","PIgR":"PIGR","PSGL-1":"SELPLG","RAGE":"AGER","TIE2":"TEK","TRAIL-R2":"TNFRSF10B","hOSCAR":"OSCAR",
 "AP-N":"ANPEP","BLM hydrolase":"BLMH","CASP-3":"CASP3","DLK-1":"DLK1","Ep-CAM":"EPCAM","GDF-15":"GDF15","ICAM-2":"ICAM2","IGFBP-1":"IGFBP1","IGFBP-2":"IGFBP2","IGFBP-7":"IGFBP7",
 "IL-17RA":"IL17RA","IL-18BP":"IL18BP","IL-1RT1":"IL1R1","IL-1RT2":"IL1R2","IL-6RA":"IL6R","IL2-RA":"IL2RA","JAM-A":"F11R","LDL receptor":"LDLR","MCP-1":"CCL2",
 "MMP-2":"MMP2","MMP-3":"MMP3","MMP-9":"MMP9","NT-proBNP":"NPPB","Notch 3":"NOTCH3","PDGF subunit A":"PDGFA","PECAM-1":"PECAM1","PSP-D":"SFTPD","SHPS-1":"SIRPA",
 "TLT-2":"TREML2","TNF-R1":"TNFRSF1A","TNF-R2":"TNFRSF1B","TR-AP":"ACP5","U-PAR":"PLAUR","t-PA":"PLAT","uPA":"PLAU","vWF":"VWF",
 "4E-BP1":"EIF4EBP1","CASP-8":"CASP8","CSF-1":"CSF1","EN-RAGE":"S100A12","FGF-19":"FGF19","FGF-5":"FGF5","Flt3L":"FLT3LG","IFN-gamma":"IFNG","IL-10RA":"IL10RA","IL-10RB":"IL10RB",
 "IL-12B":"IL12B","IL-15RA":"IL15RA","IL-17A":"IL17A","IL-17C":"IL17C","IL-18R1":"IL18R1","IL-20RA":"IL20RA","IL8":"CXCL8","LAP TGF-beta-1":"TGFB1","LIF-R":"LIFR",
 "MCP-2":"CCL8","MCP-3":"CCL7","MCP-4":"CCL13","MMP-1":"MMP1","MMP-10":"MMP10","NT-3":"NTF3","PD-L1":"CD274","ST1A1":"SULT1A1","TGF-alpha":"TGFA","TNFB":"LTA",
 "TRAIL":"TNFSF10","TRANCE":"TNFSF11","TWEAK":"TNFSF12",
 "Alpha-2-MRAP":"LRPAP1","BMP-4":"BMP4","CLM-1":"CD300LF","CLM-6":"CD300C","Dkk-4":"DKK4","FcRL2":"FCRL2","G-CSF":"CSF3","GCP5":"GPC5","GDF-8":"MSTN","GDNFR-alpha-3":"GFRA3",
 "GFR-alpha-1":"GFRA1","GM-CSF-R-alpha":"CSF2RA","IL-5R-alpha":"IL5RA","IL12":"IL12B","JAM-B":"JAM2","LAIR-2":"LAIR2","N-CDase":"ASAH2","N2DL-2":"ULBP2","Nr-CAM":"NRCAM",
 "PDGF-R-alpha":"PDGFRA","Siglec-9":"SIGLEC9","THY 1":"THY1","sFRP-3":"FRZB",
 "FAM19A5":"TAFA5","CD97":"ADGRE5","MESDC2":"MESD","FUT3/FUT5":"FUT3","ICAM 5":"ICAM5","COL4A3BP":"CERT1","KIF1BP":"KIFBP",
}
def to_symbol(assay):
    b = strip(assay)
    return MANUAL.get(b, b)
