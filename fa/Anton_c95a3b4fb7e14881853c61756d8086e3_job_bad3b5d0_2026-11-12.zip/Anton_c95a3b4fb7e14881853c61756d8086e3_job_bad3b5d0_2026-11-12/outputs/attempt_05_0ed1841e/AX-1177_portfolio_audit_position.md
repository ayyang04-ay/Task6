---
title: "AX-1177 (anti-IL-33) — portfolio audit position"
subtitle: "Recommendation, supporting case, indication, biomarker plan and what was ruled out. Based only on the four delivered data files and the methods annex."
---

# 1. Recommendation

**Keep AX-1177 — but re-charter it and put it behind gates.** Do not keep it as "anti-IL-33 for severe lower respiratory *viral* infection": our data do not make that case. Keep it as an anti-IL-33 antibody for **IL-33-driven endothelial (vascular) inflammation in a biomarker-selected population**, and fund only a short evidence package (Section 6) before any further development spend.

The reasoning in three lines:

1. **The molecule does its job, cleanly.** In human primary endothelial cells AX-1177 returned the IL-33 response to baseline (umbilical vein) and reversed the same programme in glomerular endothelium; on its own it changed nothing reproducible in four cell lines.
2. **The biology it blocks is vascular, not airway.** Every cell in which we have shown IL-33 pharmacology is endothelial. No epithelial or lung-derived cell was ever exposed to IL-33, and nothing in the patient data points to a type-2 or virus-specific mechanism.
3. **There is a patient signal and a ready stratifier, but the disease link is inferential.** Serum sST2, the soluble IL-33 receptor, is the second-strongest of 1,094 proteins for ICU admission, ventilation or death. IL-33 itself was not measured in any blood sample; the only IL-33 read-out in people is lung staining, which is not raised in COVID-19.

**The indication our data point at** is endothelial activation in patients hospitalised with severe pneumonia who are sST2-high and at risk of progressing to respiratory failure. That is the same clinical setting as today, with a different mechanism, a biomarker-defined population and no restriction to viral aetiology. The only step-out our data touch is renal (glomerular) microvascular inflammation, and that rests on one cell line.

**What we cannot claim today:** that IL-33 is raised, released or causal in severe respiratory infection; that AX-1177 works in lung cells, in more than one donor, at more than one dose, or when given after the insult; or any efficacy in a disease model.

# 2. The case for keeping it

| Link in the argument | What our data show | Strength |
|------------|------------------------------------|------------|
| Drug neutralises target in human primary cells | The 25 most IL-33-induced genes in HUVEC (59- to ~2,400-fold at 6 h) were reversed by a median 100% (IQR 97–102%) at 6 h, and the top 25 at 24 h by 92% (84–94%), against an isotype control. Glomerular endothelium (HGMEC): same programme reversed (VCAM1 −11.7, SELE −8.7, ICAM1 −5.4 log2). | Strong (one donor per cell type, one dose) |
| Drug is clean | 16 antibody-alone contrasts in 4 cell lines: no gene replicates across time points or cell lines; the IL-33 signature does not move (slope −0.03 to +0.01). With IL-33 present, 96% of the 417 genes AX-1177 changes in HUVEC are IL-33-response genes moving back; the 5 that are not are low-count features not seen in HGMEC. | Strong |
| Target is present in the organ | IL-33 staining in 74/74 lung blocks from 31 donors; highest in endothelium (donor mean 5.02 on the 5.5-max coding, above basal epithelium at 4.45, p = 0.0006). | Strong for presence; not disease-specific |
| Axis tracks patient outcome | sST2: OR 3.02 per log unit (95% CI 1.83–5.01), FDR 0.0075, rank 2 of 1,094, adjusted for age, sex and NEWS2. | Moderate (association; one cohort) |
| Target itself raised or released in disease | Not measured in serum (the IL33 assay is missing from the delivery); lung IL-33 staining not higher in COVID-19. | **Absent** |
| Blocking the target changes disease | No in vivo or disease-model data of any kind. | **Absent** |

**2.1 Pharmacology (Fig. 1).** IL-33 (30 ng/mL) changed 4,031 genes in HUVEC at 6 h and 1,836 at 24 h (adj. P < 0.05). The programme is NF-κB-type endothelial activation (Hallmark TNFα/NF-κB NES +3.06, FDR 2×10⁻⁴³):

- adhesion molecules: E-selectin ×2,400, VCAM-1 ×430, ICAM-1 ×63;
- neutrophil and monocyte recruitment: GM-CSF ×1,260, G-CSF ×320, IL-8 ×290, CXCL1 ×290, MCP-1 ×18;
- IL-6 ×56;
- a pro-thrombotic switch: tissue factor ×50, with thrombomodulin and eNOS halved.

Fold changes for genes that are almost silent at baseline (E-selectin, VCAM-1, GM-CSF) are approximate.

AX-1177 (10 µg/mL, about 41-fold molar excess, added together with IL-33) mirrored this (NES −3.08 in HUVEC, −2.65 in HGMEC). Across genes chosen on independent data, the AX-1177 effect against the IL-33 effect has a slope of −1.05, i.e. complete reversal. Cells given IL-33 plus AX-1177 sat within about 12% of vehicle-treated cells for the top 25 genes (median residual 0.17 log2).

![Figure 1. IL-33 response (x) against the effect of AX-1177 in the presence of IL-33 (y). Points on the dashed line are fully reversed. Panel D: AX-1177 without IL-33.](figures/Fig1_rnaseq_neutralisation.png){width=9.5in}

**2.2 Patients (Fig. 2).** Beyond sST2, several proteins whose genes are IL-33-induced and AX-1177-reversed in our endothelial data also track the composite endpoint. These are IL-6 (four panels, OR 2.07–2.31, FDR ≤ 0.019), IL-8, CCL20, MCP-3, OPG and PTX3 (all FDR ≤ 0.023), with MCP-1 and tissue factor at FDR 0.051. The classical cardiac markers are weak by comparison (NT-proBNP OR 1.24, troponin I OR 1.18), so sST2 is unlikely to be simply reporting cardiac strain.

The outcome-associated serum profile is neutrophilic, not eosinophilic. Of 20 neutrophil granule and activation proteins on the panels (proteinase 3, CD177, NGAL, resistin and others), 19 have p < 0.05 against a 34% background; of 9 type-2, eosinophil or mast-cell markers, 1 does. Neutrophils are the population that IL-33-activated endothelium is programmed to recruit (GM-CSF, G-CSF, CXCL1/2/3/5/6/8). The link between the two is an inference, and I assembled the marker sets after seeing individual results, so treat the set-level counts as descriptive.

![Figure 2. Serum proteins against the composite endpoint (ICU admission, invasive ventilation or death within 30 days).](figures/Fig2_serum_proteomics.png){width=9.9in}

**2.3 Tissue (Fig. 3).** The target reservoir sits in the vessel wall of every lung examined, which is where the endothelial pharmacology would have to act.

![Figure 3. Lung IL-33 immunohistochemistry, analysed per donor.](figures/Fig3_lung_IHC.png){width=10.2in}

# 3. What I would concede up front

- **No circulating IL-33 data.** The Olink Inflammation panel includes an IL33 assay, but it is not in the delivered table. The multiple-testing denominator (1,194) shows that 100 assays were tested and not delivered. The one IL-33 measurement we would most want is therefore missing.
- **sST2 is a severity marker in a cohort where much tracks severity.** 384 of 1,094 assays (35%) have p < 0.05 and 82% have OR > 1. Proteins from IL-33-induced endothelial genes are not over-represented among the hits (40% vs 37% background, p = 0.35). A looser definition gives 47% vs 34%, but that disappears after adjusting for expression level (p = 0.21). The flagship adhesion molecules sVCAM-1 (OR 1.28, p = 0.43) and sICAM-1 (OR 1.67, p = 0.11) are not associated with outcome.
- **Lung IL-33 is not raised in COVID-19.** Per donor, endothelial IL-33 is 4.81 in SARS-CoV-2-positive lungs vs 5.25 in negative (p = 0.052; p = 0.11 after age and sex adjustment), and epithelial IL-33 is unchanged (p = 0.76). Staining abundance cannot show whether IL-33 was released.
- **The cell models are not the disease.** Umbilical-vein and glomerular endothelium, one donor each; one antibody concentration; antibody added with the stimulus; reduced IL-33 only; no lung microvascular cells; no virus; no IL-33 arm in the lung epithelial line. Judging by noise in the no-treatment contrasts, the two epithelial lines barely express the IL-33 receptor ST2 (*IL1RL1*), whereas both endothelial lines do, so the epithelial arms say nothing about epithelial IL-33 biology in either direction.
- **The delivered RNA-seq statistics are unreliable for the flagship genes** (Section 9, Fig. 5). I handled this, but the committee should hear it from us first.

# 4. Which indication the data point at

| Candidate | Evidence in our data | Verdict |
|-------------|------------------------------------|-----------|
| Severe lower respiratory *viral* infection, all-comers (current) | COVID-19 serum association (sST2). Nothing virus-specific: lung IL-33 does not differ detectably between SARS-CoV-2-positive and -negative pneumonia; the in vitro stimulus is sterile IL-33; no epithelial or antiviral data. | Not supported as framed |
| **Endothelial activation in severe pneumonia, sST2-high, aetiology-agnostic** | Endothelial pharmacology in two vascular beds; sST2 and IL-33-inducible endothelial products (IL-6, IL-8, CCL20, MCP-1/-3, OPG, PTX3, tissue factor) track ICU/ventilation/death; the serum profile of poor outcome is neutrophilic (19 of 20 neutrophil markers); IL-33 is stored in lung endothelium of every donor; pulmonary thrombo-emboli in 4/16 COVID-19 lungs vs 0/15 others. | **Best supported; where the human data are** |
| Renal microvascular (glomerular) inflammation | HGMEC respond and are rescued (60% of the HUVEC core induced genes significantly reversed at 6 h; effect about 69% of HUVEC's on the log2 scale). But: no baseline contrast, so no % neutralisation; effect largely gone by 24 h (6% of core genes); one donor; no renal patient data; KIM-1 only weakly associated (OR 1.66, p = 0.03) and cystatin C not (p = 0.18). | Option only; needs new data |
| Type-2 airway disease (asthma-like, eosinophilic) | IL-5 (OR 1.00), eotaxin, TARC, eotaxin-2 and tryptase all null (1 of 9 type-2 markers reaches p < 0.05); lung eosinophil peroxidase unrelated to IL-33 staining (ρ = −0.10, p = 0.61). | Not supported by our data |
| COPD / epithelial remodelling | Never tested: no IL-33 arm in A549, no oxidised IL-33. Epithelial IL-33 not different in donors with COPD (4.68 vs 4.32, p = 0.21; underpowered). | Untested; no signal |
| Cardiovascular (atherosclerosis, heart failure) | Suggestive only: vascular IL-33 rises with age (+0.34 score units per decade, p = 0.001); sST2 is a strong outcome marker. No cardiovascular cohort, tissue or model. | Not enough |
| Oncology (A549, MCF7) | Antibody alone has no effect in either line. | No |

# 5. What I considered and ruled out

| Hypothesis | Verdict | Evidence |
|---------------|----------|-----------------------------------|
| AX-1177 only partly neutralises IL-33 | Ruled out at this dose and schedule | 100% reversal at 6 h, 92% at 24 h; slope −1.05 |
| The endothelial response is caused by a contaminant in the recombinant IL-33 (e.g. endotoxin) rather than by IL-33 | Ruled out | An IL-33-specific antibody removes the whole response and the isotype does not |
| Reversal is an isotype or Fc artefact | Ruled out | Comparator is IL-33 + isotype. Adding isotype to IL-33 changes the signature by −3% at 6 h (−18% at 24 h in HUVEC, none in HGMEC) |
| AX-1177 has IL-33-independent activity | Ruled out in 4 cell lines | 632 nominal "hits" over 16 contrasts: 78% near-zero-count features, none replicating |
| Vehicle (DMSO vs PBS) or isotype has its own transcript effect | Ruled out in the epithelial lines | Derived DMSO-vs-PBS and isotype-vs-PBS contrasts sit at noise level (SD 0.09–0.13 log2 vs 0.38 for IL-33) and do not correlate between time points (r −0.03 to 0.16). So it does not matter that the annex does not say which vehicle the HUVEC arm received |
| SELE, VCAM1, CXCL8, CXCL1 and CCL2 "are not significant" | Ruled out — statistical artefact | Delivered adj. P 0.19–1.0, but effects of 18- to 2,400-fold replicate across independent arms, both time points and both cell lines; re-scored z = 18–40 (Fig. 5). The row left selected in the delivered workbook is VCAM1 at 24 h: an 8-fold reversal (log2FC −3.0) with adj. P 0.97 |
| The "6h" and "24h" tabs are time points | Ruled out | Both tabs hold the same 24 contrasts; 96% of rows are hidden by a filter |
| The epithelial arms show that epithelium does not respond to IL-33 | Cannot be concluded | A549 and MCF7 never received IL-33. *IL1RL1* log2FC noise in null contrasts is 0.96–1.27 in these lines vs 0.09–0.10 in the endothelial lines, the signature of near-zero counts (a proxy; per-line expression was not delivered) |
| IL-33 is up-regulated in COVID-19 lung | Not supported | Section 3 |
| Block-level "significance" in lung | Ruled out — pseudo-replication | 24 of 49 COVID-19 blocks come from 3 donors; endothelium p = 0.017 per block vs 0.052 per donor; eosinophils 0.025 vs 0.38 |
| Lower IL-33 in injured lung means release | Cannot be concluded | Lower with any acute lung pathology (4.89 vs 5.42, p = 0.019), but explained by age and sex (adjusted p = 0.35) |
| Serum independently confirms an IL-33 endothelial signature | Not supported | Section 3 |
| Disease is type-2, epithelial or virus-specific | Not supported or untested | Section 4 |

# 6. What the next studies have to establish

Five things, in order of cost. The numerical pass marks are my proposals for the committee to set, not values derived from the data.

| Gate | Question to settle | Study | Pass (proposed) | Kill |
|-------|------------|----------------------|-----------|--------|
| 0 — desk work, archived data | Are the flagship effects statistically sound; how complete is neutralisation in glomerular cells; does sST2 add to clinical scoring? | Re-fit RNA-seq per cell line from archived counts and extract the missing contrasts (IL-33 vs baseline in HGMEC). Retrieve the 100 undelivered Olink assays including IL33. Patient-level sST2: ROC, cut-off, added value over age + sex + NEWS2. Check whether expression data exist for the 22 lung blocks with tissue-RNA IDs. | Flagship genes FDR < 0.05; HGMEC reversal ≥ 80% for top genes; sST2 improves discrimination over the clinical model | sST2 adds nothing to NEWS2 at patient level |
| 1a — banked sera (n = 100, stored at −80 °C; if volume remains) | **Is IL-33 actually there?** | Ultrasensitive IL-33 (free, total, sST2-complexed; reduced vs oxidised) on enrolment sera | Quantifiable in most patients and related to sST2, the endothelial panel or outcome | Undetectable **and** 1b negative |
| 1b — functional | **Is endothelial activation in patients IL-33-dependent?** | Serum from sST2-high vs sST2-low patients on lung microvascular endothelium ± AX-1177 or isotype; 6 h read-out panel (Section 7) | AX-1177 removes a meaningful share (e.g. ≥ 30%) of serum-induced activation in sST2-high samples | No AX-1177-sensitive component |
| 1c — pharmacology in the right cells | Does it work in lung (and glomerular) microvascular endothelium, across donors, at achievable exposure, **after** the insult? | ≥ 3 donors per cell type; IL-33 and AX-1177 concentration–response (IC50/IC90); antibody added before, with and 1–4 h after IL-33; oxidised IL-33; 1–48 h time course; protein-level and functional confirmation (neutrophil adhesion, barrier function, tissue-factor activity) | IC90 at a clinically plausible concentration; ≥ 70% reversal with delayed addition; consistent across donors | Fails delayed addition or donor consistency |
| 2 — validation | Does sST2 select a reproducibly high-risk population beyond COVID-19; does blockade change disease? | Independent cohort including influenza, RSV and bacterial pneumonia, with serial sampling (day 0, 1, 3, 7). In vivo proof of mechanism (species cross-reactivity is in the biologics file, not in this package). | sST2 replicates with a pre-specified cut-off; in vivo effect on the endothelial panel | sST2 fails to replicate |

Decision rule: pass Gates 0–1 and proceed in sST2-high severe pneumonia. If 1a and 1b fail but 1c passes, IL-33 is not the driver in this setting; the renal or vascular option would then need its own human data before any commitment. Otherwise stop.

# 7. Biomarkers, sampling timepoint and roles

**Sampling timepoint.** For cell-based work, **6 h** is the primary timepoint for transcript read-outs:

- the response is largest (4,031 vs 1,836 genes; top genes retain only about 53% of their 6 h magnitude at 24 h);
- reversal is complete (100% vs 92%);
- the glomerular cells only report at 6 h (60% vs 6% of core induced genes significantly reversed);
- the 24 h data carry culture-state noise (proliferation gene sets move in opposite directions in HUVEC and HGMEC).

Keep 24 h as a secondary timepoint for secreted protein in supernatant and for durability. Only two timepoints exist, so the true peak is unknown; Gate 1c adds a time course.

For patients, the only timepoint our data support is **serum at enrolment, before dosing**. On-treatment sampling times (I would start with 24 h, day 3 and day 7) have to be set by the serial-sampling study in Gate 2.

**Markers and roles (Fig. 4; full table in `tables/T2_biomarker_shortlist.csv`).**

| Role | Markers | Basis in our data | Could go into patients? |
|---------|------------|------------------|---------------------|
| **Stratification / prognostic enrichment** | **sST2** | Rank 2 of 1,094, independent of NEWS2. Its gene is IL-33-inducible and AX-1177-reversible in HUVEC (3-fold). | **Yes — the one marker ready to select patients.** Prognostic only: not shown to predict response; needs a cut-off and replication. sST2 is also an IL-33 decoy, so a high level could mean IL-33 is already buffered; Gates 1a–b test this. |
| **Pharmacodynamic / response (exploratory)** | IL-6, IL-8, CCL20, MCP-1, MCP-3, OPG, PTX3, tissue factor; sE-selectin as the endothelium-restricted member | IL-33-induced and AX-1177-reversed in endothelium **and** associated with outcome in serum (FDR ≤ 0.023; MCP-1 and tissue factor 0.051; E-selectin nominal only, p = 0.02, FDR 0.09) | Yes, as a panel, pre-dose and on-treatment. All were quantifiable in every patient on this platform (reading the undefined columns as below-detection fractions). Not for selection: none is IL-33-specific, and none has been shown to move with AX-1177 in vivo. |
| **Target engagement** | Free and total IL-33, IL-33:sST2 complex | None — IL-33 was not measured in any blood sample | Needed for dose selection; assay has to be built (Gate 1a). |
| **In vitro / ex vivo potency and PD only** | VCAM-1, ICAM-1, GM-CSF, G-CSF, CXCL1, CXCL2, CXCL5, CXCL6, fractalkine, RANTES; pathway: TNFAIP3, NFKBIA; function: thrombomodulin and eNOS (restored by AX-1177) | Largest and most reproducible cell effects, in both endothelial beds | Low priority in patients. sVCAM-1, sICAM-1, CXCL1, CXCL5, CXCL6 and G-CSF are measurable in serum but show no relation to outcome in our cohort; GM-CSF and CXCL2 were not measured. |
| **Specificity comparators** | HGF, proteinase 3, CD177 | Strongly outcome-associated (HGF is rank 1) but not IL-33-regulated in our endothelial data | Yes, alongside the PD panel, to tell an IL-33-specific effect from general recovery. |
| **Do not use** | IL-5, eotaxins, TARC, tryptase | No association with outcome | No. |

![Figure 4. Biomarker shortlist: cell pharmacology (log2 fold changes) and patient serum association.](figures/Fig4_biomarker_shortlist.png){width=10in}

# 8. If the committee decides to drop it

What would be dropped is a clean, fully neutralising anti-IL-33 antibody with demonstrated pharmacology in human primary endothelium and a candidate enrichment biomarker. The reason would be that the link between IL-33 and outcome in severe respiratory infection is still inferred rather than shown: no IL-33 measurement in patient blood, no disease-relevant cell or model, no efficacy data. It would not be that the molecule failed a test. Gate 0 and Gate 1a–b use archived data and banked sera, so they are the cheapest way to turn that inference into a yes or a no.

# 9. Caveats on the delivered data

The full log is in `tables/T6_data_integrity_log.csv`. The ones that change conclusions:

- **RNA-seq statistics.** For 130 genes the delivered standard error is impossible, a median 108-fold larger than the data's own null contrasts imply. Examples: CXCL1 SE 1,155 log2 units; GAPDH 9.6 although its log2FC never exceeds 0.21 in 16 null contrasts. The affected genes are those with extreme between-cell-line or on/off expression, which includes the flagship read-outs. The most likely cause is the single model fitted across four unrelated cell lines, but I cannot confirm that without the fitted object. It is not a sample mix-up: lineage and sex-chromosome genes are flat in every contrast (largest change 0.5 log2 in lines that express them). I therefore relied on effect sizes replicated across independent arms, time points and cell lines, and on a re-scored statistic that agrees with the delivered one wherever the delivered one is sane (rank correlation 0.98). Gate 0 replaces this with a proper re-fit.
- **Serum table.** Two columns are undefined. Their values are multiples of 1/56 and 1/44, which I read as per-group missing or below-detection fractions, implying 56 non-events and 44 events — an inference. Odds ratios are per log unit of each assay and not comparable between assays.
- **Lung table.** Rows are blocks, not donors; all statistics here are per donor. Seven donors' group labels disagree with their own pathology text, and there is no healthy or young control. Scores are near the ceiling in endothelium (39 of 74 blocks at maximum), from a single reader.

![Figure 5. Delivered standard errors against those implied by the data's own null contrasts (A), and the consequence for flagship genes (B).](figures/Fig5_statistics_artefact.png){width=10.2in}

# Appendix — files and methods

**Files** (all under `/tmp/outputs/`)

- `figures/`
  - `Fig1_rnaseq_neutralisation.png` — IL-33 response vs AX-1177 reversal.
  - `Fig2_serum_proteomics.png` — serum associations.
  - `Fig3_lung_IHC.png` — lung IL-33 per donor.
  - `Fig4_biomarker_shortlist.png` — shortlist heat map.
  - `Fig5_statistics_artefact.png` — the standard-error problem and the re-scoring.
- `tables/`
  - `T1_rnaseq_contrast_summary.csv`, `T1b_antibody_alone_reproducibility.csv`, `T1c_gsea_hallmark_reactome.csv`
  - `T2_biomarker_shortlist.csv`, `T2b_rule_based_screen_endothelial_PD_candidates.csv`
  - `T3_gene_master_table.csv.gz` — all 26,210 genes.
  - `T4_serum_annotated.csv`, `T4b_serum_multipanel_replicates.csv`
  - `T5_lung_donor_level.csv`, `T5b_lung_block_level_clean.csv`
  - `T6_data_integrity_log.csv`, `T7_degenerate_SE_genes.csv`
  - `key_numbers_*.json` — the numbers quoted here (with the tables above).
- `scripts/` — `00`–`06`, re-runnable from the delivered files.

**Methods in brief**

- *RNA-seq.* Only the delivered contrast tables were used (26 contrasts × 26,210 genes; no counts). "Reversal" is −(log2FC of [IL-33 + AX-1177 vs IL-33 + isotype]) / (log2FC of [IL-33 vs vehicle]). These two contrasts share no arm, so noise cannot create a mirror image. The alternative comparator (IL-33 alone) shares an arm with the IL-33 contrast and was not used for quantification. Slopes are errors-in-variables (Deming) on genes selected from independent data.
- *Re-scored statistic.* log2FC divided by a per-gene empirical standard error from eight endothelial contrasts with no treatment effect (four antibody-alone, four isotype-effect).
- *Gene sets.* fgsea on MSigDB Hallmark and Reactome, ranked by log2FC.
- *Serum.* Delivered summary statistics only; assays mapped to genes by a curated table (`scripts/olink_map.py`); replicate assays collapsed per gene for set-level tests.
- *Lung.* Donor-level means of block scores; Mann–Whitney and Kruskal–Wallis tests; linear models with age and sex.
- *Outside knowledge used.* Only to read the data: Olink panel content (that IL33 is on the Inflammation panel), and that the "ST2" assay measures the soluble IL-33 receptor.
