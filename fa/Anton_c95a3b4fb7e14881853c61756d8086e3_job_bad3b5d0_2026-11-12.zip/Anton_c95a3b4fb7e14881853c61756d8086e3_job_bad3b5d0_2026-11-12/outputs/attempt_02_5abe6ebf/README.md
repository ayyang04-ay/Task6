# AX-1177 portfolio audit: output folder

Start with **`AX-1177_portfolio_audit_memo.md`** (same content as the PDF). It gives the recommendation, the case for it, the indication the data point at, the forward plan with biomarkers, sampling timepoint and kill criteria, and what was considered and ruled out.

| File | What it is |
|---|---|
| `AX-1177_portfolio_audit_memo.md` / `.pdf` | Committee memo. The PDF was generated programmatically and could not be opened in a viewer in this environment, so check its layout before circulating; the Markdown is the reference version |
| `figures/Fig1_invitro_pharmacology.png` | AX-1177 neutralises IL-33 signalling in endothelial cells; timepoint comparison |
| `figures/Fig2_serum_proteomics.png` | Serum proteins and outcome in 100 hospitalised patients |
| `figures/Fig3_postmortem_lung.png` | IL-33 and inflammatory-cell staining in lung, one point per donor |
| `figures/Fig4_rnaseq_statistics_caveat.png` | Why the delivered RNA-seq p-values cannot be used alone |
| `AX-1177_supporting_tables.xlsx` | README, column guide and 16 supporting tables (also as CSV in `tables/`) |
| `analysis_code/` | Scripts 01-07 and `run_all.sh`; re-runs everything from the four delivered files in about 5 minutes |

All numbers come from the four delivered data files and the methods annex. Content hidden in the delivered spreadsheets (12 columns in the lung file, two rows and one column in the serum file, 23 of 24 filtered comparisons in the RNA-seq workbook) was unhidden and used; see sheet `T9` for the full data-integrity log.
