"""
07_build_pdf.py  -  renders AX-1177_portfolio_audit_memo.md to PDF (text pages portrait, figures landscape)
Run:  micromamba run -n chem python 07_build_pdf.py
"""
import os, re, html
import matplotlib
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, NextPageTemplate, ListFlowable, ListItem, KeepTogether
from reportlab.lib.utils import ImageReader

OUT = "/tmp/outputs"; MD = f"{OUT}/AX-1177_portfolio_audit_memo.md"; PDF = f"{OUT}/AX-1177_portfolio_audit_memo.pdf"
fd = os.path.join(os.path.dirname(matplotlib.__file__), "mpl-data", "fonts", "ttf")
for name, f in [("DV", "DejaVuSans.ttf"), ("DV-B", "DejaVuSans-Bold.ttf"), ("DV-I", "DejaVuSans-Oblique.ttf"), ("DV-BI", "DejaVuSans-BoldOblique.ttf"), ("DVM", "DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(name, os.path.join(fd, f)))
pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-B", italic="DV-I", boldItalic="DV-BI")

base = ParagraphStyle("base", fontName="DV", fontSize=9.2, leading=12.6, alignment=TA_LEFT, spaceAfter=5)
st = {"p": base,
      "h1": ParagraphStyle("h1", parent=base, fontName="DV-B", fontSize=16, leading=20, spaceBefore=0, spaceAfter=8, textColor=colors.HexColor("#12355b")),
      "h2": ParagraphStyle("h2", parent=base, fontName="DV-B", fontSize=12, leading=15, spaceBefore=10, spaceAfter=5, textColor=colors.HexColor("#12355b")),
      "h3": ParagraphStyle("h3", parent=base, fontName="DV-B", fontSize=10, leading=13, spaceBefore=7, spaceAfter=4),
      "li": ParagraphStyle("li", parent=base, spaceAfter=2.5),
      "td": ParagraphStyle("td", parent=base, fontSize=7.6, leading=9.8, spaceAfter=0),
      "th": ParagraphStyle("th", parent=base, fontName="DV-B", fontSize=7.6, leading=9.8, spaceAfter=0, textColor=colors.white)}

def inline(t):
    t = html.escape(t, quote=False)
    t = re.sub(r"`([^`]+)`", r'<font name="DVM" size="8">\1</font>', t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?![\*\w])", r"<i>\1</i>", t)
    return t

def table_flow(rows, width):
    hdr, body = rows[0], rows[1:]
    ncol = len(hdr)
    # column widths proportional to (capped) content length
    lens = [max(len(r[i]) if i < len(r) else 0 for r in rows) for i in range(ncol)]
    w = [min(max(l, 6), 70) ** 0.75 for l in lens]; tot = sum(w); cw = [width * x / tot for x in w]
    data = [[Paragraph(inline(c), st["th"]) for c in hdr]] + [[Paragraph(inline(c), st["td"]) for c in (r + [""] * (ncol - len(r)))] for r in body]
    t = Table(data, colWidths=cw, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#12355b")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1f4f8")]), ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#b8c2cc")),
                           ("LEFTPADDING", (0, 0), (-1, -1), 3.5), ("RIGHTPADDING", (0, 0), (-1, -1), 3.5), ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]))
    return t

PW, PH = A4; M = 17 * mm
fw_p, fh_p = PW - 2 * M, PH - 2 * M; fw_l, fh_l = PH - 2 * M, PW - 2 * M
def footer(canvas, doc):
    canvas.saveState(); canvas.setFont("DV", 7); canvas.setFillColor(colors.HexColor("#666666"))
    w = canvas._pagesize[0]; canvas.drawString(M, 9 * mm, "AX-1177 portfolio audit position - prepared from the delivered data files only"); canvas.drawRightString(w - M, 9 * mm, f"page {doc.page}"); canvas.restoreState()
doc = BaseDocTemplate(PDF, pagesize=A4, leftMargin=M, rightMargin=M, topMargin=M, bottomMargin=M, title="AX-1177 portfolio audit position", author="")
doc.addPageTemplates([PageTemplate(id="portrait", frames=[Frame(M, M, fw_p, fh_p, id="fp", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)], pagesize=A4, onPage=footer),
                      PageTemplate(id="landscape", frames=[Frame(M, M, fw_l, fh_l, id="fl", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)], pagesize=landscape(A4), onPage=footer)])

lines = open(MD, encoding="utf-8").read().split("\n")
story = []; i = 0; in_fig = False
def flush_list(items, ordered):
    story.append(ListFlowable([ListItem(Paragraph(inline(x), st["li"]), leftIndent=14) for x in items], bulletType="1" if ordered else "bullet", bulletFontName="DV", bulletFontSize=8,
                              start=None if ordered else "•", leftIndent=14, bulletOffsetY=0)); story.append(Spacer(1, 3))
while i < len(lines):
    ln = lines[i]
    if not ln.strip(): i += 1; continue
    m = re.match(r"^!\[(.*?)\]\((.*?)\)", ln.strip())
    if m:
        path = os.path.join(OUT, m.group(2)); iw, ih = ImageReader(path).getSize(); sc = min(fw_l / iw, (fh_l - 4) / ih)
        story += [NextPageTemplate("landscape"), PageBreak(), Image(path, width=iw * sc, height=ih * sc)]; in_fig = True; i += 1; continue
    if in_fig:      # first non-figure block after the figures: back to portrait
        story += [NextPageTemplate("portrait"), PageBreak()]; in_fig = False
    if ln.startswith("# "): story.append(Paragraph(inline(ln[2:]), st["h1"])); i += 1; continue
    if ln.startswith("## "):
        if ln[3:].strip() == "Figures": i += 1; continue
        story.append(Paragraph(inline(ln[3:]), st["h2"])); i += 1; continue
    if ln.startswith("### "): story.append(Paragraph(inline(ln[4:]), st["h3"])); i += 1; continue
    if ln.lstrip().startswith("|"):
        rows = []
        while i < len(lines) and lines[i].lstrip().startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{3,}:?", c) for c in cells): rows.append(cells)
            i += 1
        story.append(table_flow(rows, fw_p)); story.append(Spacer(1, 6)); continue
    if re.match(r"^\s*[-*] ", ln) or re.match(r"^\s*\d+\. ", ln):
        ordered = bool(re.match(r"^\s*\d+\. ", ln)); items = []
        while i < len(lines) and (re.match(r"^\s*[-*] ", lines[i]) or re.match(r"^\s*\d+\. ", lines[i])):
            items.append(re.sub(r"^\s*([-*]|\d+\.) ", "", lines[i])); i += 1
        flush_list(items, ordered); continue
    para = [ln]; i += 1
    while i < len(lines) and lines[i].strip() and not re.match(r"^(#|\||\s*[-*] |\s*\d+\. |!\[)", lines[i]): para.append(lines[i]); i += 1
    story.append(Paragraph(inline(" ".join(para)), st["p"]))
doc.build(story)
print("written", PDF, os.path.getsize(PDF), "bytes")
