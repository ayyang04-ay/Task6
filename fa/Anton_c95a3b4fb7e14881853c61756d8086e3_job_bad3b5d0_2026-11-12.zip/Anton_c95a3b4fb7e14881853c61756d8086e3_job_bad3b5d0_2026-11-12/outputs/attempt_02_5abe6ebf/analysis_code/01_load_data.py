"""
01_load_data.py  -  AX-1177 portfolio audit
Loads the four delivered files exactly as delivered, INCLUDING content that is hidden in the
spreadsheets (hidden rows/columns, auto-filtered rows), and writes tidy caches + a data-integrity log.

Run:  micromamba run -n singlecell python 01_load_data.py
"""
import os, re, zipfile, warnings
import numpy as np, pandas as pd, openpyxl
from openpyxl.utils import get_column_letter
warnings.filterwarnings("ignore")

SRC   = "/tmp/world/filesystem"
CACHE = "/tmp/work/cache"
TAB   = "/tmp/outputs/tables"
os.makedirs(CACHE, exist_ok=True); os.makedirs(TAB, exist_ok=True)
log = []   # data-integrity log: (file, item, finding, consequence/handling)

# ------------------------------------------------------------------ 1. RNA-seq contrasts
f_huvec = f"{SRC}/AX-1177_rnaseq_huvec_il33.xlsx"
f_contr = f"{SRC}/AX-1177_rnaseq_contrasts.xlsx"
huv = pd.read_excel(f_huvec, sheet_name=None)
for sh, d in huv.items():
    lab = d.Comparison.unique().tolist()
    log.append(("rnaseq_huvec_il33.xlsx", f"sheet '{sh}'", f"{len(d)} rows; Comparison label inside the table = {lab}",
                "Sheet name / annex say 'Vehicle'; table label says 'Nontreated'. Treated as the same arm; identity of the vehicle (PBS or DMSO) is not stated."))
cache_c = f"{CACHE}/contrasts_sheets.pkl"
if os.path.exists(cache_c):
    con = pd.read_pickle(cache_c)
else:
    con = pd.read_excel(f_contr, sheet_name=None, engine="openpyxl")   # reads ALL rows, ignoring the active filter
    pd.to_pickle(con, cache_c)
# filter state of the workbook (read from the raw XML)
z = zipfile.ZipFile(f_contr)
for sheet_xml, sh in [("xl/worksheets/sheet1.xml", "6h"), ("xl/worksheets/sheet2.xml", "24h")]:
    raw = z.read(sheet_xml)
    tail = raw[raw.rfind(b"</sheetData>"):].decode()
    flt = re.findall(r'<filter val="([^"]+)"', tail)
    n_hidden = raw.count(b'hidden="1"')
    log.append(("rnaseq_contrasts.xlsx", f"sheet '{sh}'",
                f"auto-filter active: only {flt} is visible; {n_hidden:,} data rows are hidden by the filter",
                "All 24 contrasts are present under the filter. Everything was read and analysed, not just the visible contrast."))
a, b = con["6h"], con["24h"]
ka = a.sort_values(["Comparison", "ensembl"]).reset_index(drop=True)
kb = b.sort_values(["Comparison", "ensembl"]).reset_index(drop=True)
same = bool((ka[["Comparison", "ensembl"]].values == kb[["Comparison", "ensembl"]].values).all()
            and np.allclose(ka[["logFC", "t", "P.Value", "adj.P.Val"]].values, kb[["logFC", "t", "P.Value", "adj.P.Val"]].values))
log.append(("rnaseq_contrasts.xlsx", "sheets '6h' vs '24h'",
            f"the two sheets contain the SAME {len(a):,} rows (24 contrasts x 26,210 genes, both timepoints); identical = {same}",
            "Sheet names are view labels only. One copy used."))
allc = pd.concat(list(huv.values()) + [a], ignore_index=True)
short = {
 'IL33_vs_Nontreated_HUVEC_6_hrs':'IL33_HUVEC_6h', 'IL33_vs_Nontreated_HUVEC_24_hrs':'IL33_HUVEC_24h',
 'Compound_47_vs_IC119_HUVEC_6hrs':'Ab_vs_Iso_HUVEC_6h', 'Compound_47_vs_IC119_HUVEC_24hrs':'Ab_vs_Iso_HUVEC_24h',
 'Compound_47_vs_IC119_HGMEC_6hrs':'Ab_vs_Iso_HGMEC_6h', 'Compound_47_vs_IC119_HGMEC_24hrs':'Ab_vs_Iso_HGMEC_24h',
 'Compound_47_IL33_vs_IL33_HUVEC_6hrs':'AbIL33_vs_IL33_HUVEC_6h', 'Compound_47_IL33_vs_IL33_HUVEC_24hrs':'AbIL33_vs_IL33_HUVEC_24h',
 'Compound_47_IL33_vs_IL33_HGMEC_6hrs':'AbIL33_vs_IL33_HGMEC_6h', 'Compound_47_IL33_vs_IL33_HGMEC_24hrs':'AbIL33_vs_IL33_HGMEC_24h',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs':'AbIL33_vs_IsoIL33_HUVEC_6h', 'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs':'AbIL33_vs_IsoIL33_HUVEC_24h',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs':'AbIL33_vs_IsoIL33_HGMEC_6h', 'Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs':'AbIL33_vs_IsoIL33_HGMEC_24h',
 'Compound_47_vs_IC119_A549_6hrs':'Ab_vs_Iso_A549_6h', 'Compound_47_vs_IC119_A549_24hrs':'Ab_vs_Iso_A549_24h',
 'Compound_47_vs_IC119_MCF7_6hrs':'Ab_vs_Iso_MCF7_6h', 'Compound_47_vs_IC119_MCF7_24hrs':'Ab_vs_Iso_MCF7_24h',
 'Compound_47_vs_DMSO_A549_6hrs':'Ab_vs_DMSO_A549_6h', 'Compound_47_vs_DMSO_A549_24hrs':'Ab_vs_DMSO_A549_24h',
 'Compound_47_vs_DMSO_MCF7_6hrs':'Ab_vs_DMSO_MCF7_6h', 'Compound_47_vs_DMSO_MCF7_24hrs':'Ab_vs_DMSO_MCF7_24h',
 'Compound_47_vs_PBS_A549_6hrs':'Ab_vs_PBS_A549_6h', 'Compound_47_vs_PBS_A549_24hrs':'Ab_vs_PBS_A549_24h',
 'Compound_47_vs_PBS_MCF7_6hrs':'Ab_vs_PBS_MCF7_6h', 'Compound_47_vs_PBS_MCF7_24hrs':'Ab_vs_PBS_MCF7_24h'}
allc["c"] = allc.Comparison.map(short); assert allc.c.notna().all()
allc.to_pickle(f"{CACHE}/rnaseq_long.pkl")
log.append(("rnaseq (both files)", "contrast inventory",
            "26 contrasts delivered. NOT delivered: IL-33 vs control in HGMEC (HGMEC has no vehicle arm); antibody or isotype vs vehicle in HUVEC; DMSO vs PBS; any IL-33 arm in A549/MCF7",
            "IL-33 response size and % neutralisation can be quantified in HUVEC only. In HGMEC only the antibody-reversible part is visible. Lung epithelial line (A549) was never exposed to IL-33."))

# ------------------------------------------------------------------ 2. serum proteomics
f_ser = f"{SRC}/AX-1177_serum_proteomics.xlsx"
wb = openpyxl.load_workbook(f_ser); ws = wb.worksheets[0]
hid_rows = sorted(k for k, v in ws.row_dimensions.items() if v.hidden)
hid_cols = sorted(k for k, v in ws.column_dimensions.items() if v.hidden)
ser = pd.read_excel(f_ser)
ser["xl_row"] = np.arange(2, len(ser) + 2)
ser["hidden_in_sheet"] = ser.xl_row.isin(hid_rows)
ser.to_pickle(f"{CACHE}/serum_raw.pkl")
log.append(("serum_proteomics.xlsx", "hidden rows", f"rows {hid_rows} hidden = assays {ser[ser.hidden_in_sheet].assay.tolist()}",
            "Both are second-panel measurements of proteins already shown (HGF, IL6); concordant with the visible rows. Kept in the analysis."))
log.append(("serum_proteomics.xlsx", "hidden column", f"column(s) {hid_cols} hidden = '{ws.cell(row=1, column=4).value}' (lower 95% CI bound)", "Read and used."))

# ------------------------------------------------------------------ 3. post-mortem lung
f_lung = f"{SRC}/AX-1177_postmortem_lung.xlsx"
wb = openpyxl.load_workbook(f_lung); ws = wb.worksheets[0]
hdr = [ws.cell(row=1, column=c).value for c in range(1, ws.max_column + 1)]
hidden_cols = [(get_column_letter(c), hdr[c - 1]) for c in range(1, ws.max_column + 1) if ws.column_dimensions[get_column_letter(c)].hidden]
log.append(("postmortem_lung.xlsx", "hidden columns",
            "12 columns hidden: " + "; ".join(f"{l}={str(h).strip() if h else '(duplicate Sample ID)'}" for l, h in hidden_cols),
            "The three IL-33 IHC columns (the drug target) and all eosinophil-granule/basophil columns are hidden in the delivered view. All were unhidden and analysed."))
hdr[3] = "Sample ID (hidden dup)"; hdr[27] = "col_AB"
rows = []
for r in range(2, ws.max_row + 1):
    vals = [ws.cell(row=r, column=c).value for c in range(1, ws.max_column + 1)]
    if all(v is None for v in vals): continue
    rows.append([r] + vals)
lung = pd.DataFrame(rows, columns=["xl_row"] + [h.strip() if isinstance(h, str) else h for h in hdr])
lung["donor"] = lung["Sample ID"].astype(str).str.strip()
lung["group"] = np.where(lung.xl_row <= 16, "COVID- pneumonia", np.where(lung.xl_row <= 67, "COVID+ pneumonia", "COVID- non-pneumonia"))
def parse_score(v):
    """'3+' -> 3 (ordinal grade); 'ND'/'N/A' -> NaN; numbers kept; the single Excel formula is evaluated."""
    if v is None: return np.nan
    if isinstance(v, (int, float)): return float(v)
    s = str(v).strip()
    if s in ("ND", "N/A", "NA", ""): return np.nan
    if s.startswith("="): return float(eval(s[1:]))
    m = re.match(r"^(\d+(?:\.\d+)?)\s*\+?$", s)
    if m: return float(m.group(1))
    raise ValueError(v)
colmap = {'EPX IHC [0 (none)- 5 (severe)]':'EPX', 'EDN IHC [0 (none) - 5 (severe)]':'EDN', 'MBP IHC [0 (none) - 5 (severe)]':'MBP',
          '2D7 IHC [0 (none) - 5 (severe)]':'BASO_2D7', 'IL-5Ra (from duplex w NE)  [0 (none) - 5 (severe)]':'IL5Ra_duplexNE',
          'Neutrophil elastase (from duplex w IL5Ra) [0 (none) - 5 (severe)]':'NE', 'IL-5Ra (from duplex w tryptase)  [0 (none) - 5 (severe)]':'IL5Ra_duplexTryp',
          'Tryptase (from duplex w IL5Ra) [0 (none) - 5 (severe)]':'TRYPTASE', 'Eosinophil peroxidase':'EPX_numcol', 'Neutrophil elastase':'NE_numcol', 'Tryptase':'TRYPTASE_numcol',
          'IL-33, bronchial and bronchiolar basal epithelial cells':'IL33_epi', 'IL-33, endothelial cells':'IL33_endo', 'IL-33, vascular smooth muscle cells':'IL33_vsmc'}
for c, n in colmap.items(): lung[n] = lung[c].map(parse_score)
lung["HE_eos"] = (lung["H&E eosinophils apparent (Y/N)"] == "Y").astype(float)
lung["notes"] = lung["Notes - Approved lung conditions"]
lung.to_pickle(f"{CACHE}/lung_blocks.pkl")
nb = lung.groupby(["group", "donor"]).size()
log.append(("postmortem_lung.xlsx", "unit of analysis",
            f"{len(lung)} rows are histology blocks from {lung.donor.nunique()} donors (COVID+ {nb['COVID+ pneumonia'].shape[0]} donors/{int(nb['COVID+ pneumonia'].sum())} blocks; COVID- pneumonia {nb['COVID- pneumonia'].shape[0]}/{int(nb['COVID- pneumonia'].sum())}; non-pneumonia {nb['COVID- non-pneumonia'].shape[0]}/{int(nb['COVID- non-pneumonia'].sum())}); three COVID+ donors contribute 8 blocks each (24 of 49 COVID+ blocks)",
            "Blocks are not independent. All group tests done on donor means (n=31); block-level p-values shown only to illustrate the pseudo-replication."))
n55 = int((lung.IL33_endo == 5.5).sum())
log.append(("postmortem_lung.xlsx", "score scale",
            f"Annex states a 0-5 scale; numeric columns carry values up to 5.5 ('n+' was coded as n+0.5; intermediate values such as 4.25 are averages of two grades; one cell is a live formula '=(2+4.5)/2'). {n55}/{len(lung)} blocks ({100*n55/len(lung):.0f}%) sit at the top endothelial IL-33 value",
            "Scores treated as ordinal; rank-based tests used. Ceiling effect: the assay could not register an increase in most samples."))
log.append(("postmortem_lung.xlsx", "group labels vs pathology text",
            "Labels do not always match the free-text pathology: 4/10 'COVID- pneumonia' donors have no pneumonia recorded (1905, 1961, 1968, 1970); donor 1905 has no SARS-CoV-2 result; 2/16 'COVID+ pneumonia' donors have no acute pneumonia recorded (2067 - 8 blocks, 2101); 2/5 'non-pneumonia' controls have acute/organising pneumonia or pneumonitis (1976, 1956), 1 has pulmonary coccidioidomycosis (1944) and 2 have pulmonary fibrosis (1861, 1965)",
            "There is no normal-lung control. A sensitivity analysis re-classifies donors by pathology text."))
log.append(("postmortem_lung.xlsx", "other", "single reader, blinding not stated; all donors white, aged 64-98; donor-level fields (notes) sometimes sit on the 2nd block, not the first as the annex states; Sample ID stored as text for 15 donors and number for 16",
            "Donor fields forward/back-filled within donor; IDs harmonised as text."))
pd.DataFrame(log, columns=["file", "item", "finding", "consequence / how handled"]).to_csv(f"{TAB}/T9_data_integrity_log_part1.csv", index=False)
print("loaded: rnaseq rows", len(allc), "| serum assays", len(ser), "| lung blocks", len(lung), "| log items", len(log))
