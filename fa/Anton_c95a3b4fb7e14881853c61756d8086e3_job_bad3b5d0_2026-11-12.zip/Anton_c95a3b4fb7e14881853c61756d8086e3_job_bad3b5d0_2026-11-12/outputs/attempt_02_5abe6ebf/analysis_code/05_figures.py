"""
05_figures.py  -  AX-1177 portfolio audit: figures
Run:  micromamba run -n singlecell python 05_figures.py
"""
import warnings
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from adjustText import adjust_text
from scipy import stats
warnings.filterwarnings("ignore")
CACHE = "/tmp/work/cache"; FIG = "/tmp/outputs/figures"
plt.rcParams.update({"font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150, "savefig.dpi": 200, "font.family": "DejaVu Sans"})
BLUE, ORANGE, GREY, RED, GREEN, PURPLE = "#1f77b4", "#e6550d", "#9e9e9e", "#c0392b", "#2e8b57", "#6a51a3"
D = pd.read_pickle(f"{CACHE}/rnaseq_gene_table.pkl"); W = pd.read_pickle(f"{CACHE}/rnaseq_wide.pkl"); L, Q, S, ann = W["L"], W["Q"], W["S"], W["ann"]
sym = D.symbol

# =============================================================== FIGURE 1: in vitro pharmacology
fig, axs = plt.subplots(2, 3, figsize=(15, 9.4))
# --- A: IL-33 effect vs AX-1177 reversal, HUVEC 6 h
ax = axs[0, 0]
masked = (D.SE_ratio > 5) & (D.IL33_6h.abs() >= 1.5) & (D.q_IL33_6h > 0.05) & (D.pct_revIso_6h > 50)
robust = (D.IL33_6h.abs() >= 1) & (D.q_IL33_6h < 0.01) & (D.AveExpr > 0)
ax.scatter(D.IL33_6h[robust], D.revIso_6h[robust], s=9, c=BLUE, alpha=.55, lw=0, label=f"passes FDR in delivered table (n={int(robust.sum())})")
ax.scatter(D.IL33_6h[masked], D.revIso_6h[masked], s=34, c=ORANGE, edgecolor="k", lw=.4, zorder=3, label=f"large effect, fails FDR (inflated SE; n={int(masked.sum())})")
lim = [-5, 12.5]; ax.plot(lim, [-l for l in lim], "k--", lw=.8); ax.axhline(0, c="k", lw=.4); ax.axvline(0, c="k", lw=.4)
ax.text(7.3, -5.2, "complete\nreversal", fontsize=8, rotation=-38, ha="center")
lab = ["SELE", "VCAM1", "CXCL8", "CSF2", "IL6", "CCL20", "ICAM1", "F3", "CCL2", "PTX3", "IL1RL1", "TNF"]
txt = [ax.text(D.IL33_6h[i], D.revIso_6h[i], s_, fontsize=7.5) for i, s_ in zip(D.index[sym.isin(lab)], sym[sym.isin(lab)])]
adjust_text(txt, ax=ax, arrowprops=dict(arrowstyle="-", lw=.4, color="k"))
r = stats.pearsonr(D.IL33_6h[robust], D.revIso_6h[robust])[0]
ax.set_xlabel("IL-33 effect: log2FC, IL-33 vs vehicle"); ax.set_ylabel("AX-1177 effect: log2FC,\n(IL-33 + AX-1177) vs (IL-33 + isotype)")
ax.set_title(f"A  HUVEC, 6 h: AX-1177 reverses the IL-33 programme (r = {r:.2f})", loc="left"); ax.legend(fontsize=7, loc="upper right", frameon=False); ax.set_xlim(lim)
# --- B: antibody alone
ax = axs[0, 1]
both = robust | masked
ax.scatter(D.IL33_6h[both], L.loc[both, "Ab_vs_Iso_HUVEC_6h"], s=9, c=GREY, alpha=.6, lw=0, label="HUVEC, 6 h")
ax.scatter(D.IL33_6h[both], L.loc[both, "Ab_vs_Iso_HGMEC_6h"], s=9, c=PURPLE, alpha=.35, lw=0, label="HGMEC, 6 h")
ax.plot(lim, [-l for l in lim], "k--", lw=.8, alpha=.4); ax.axhline(0, c="k", lw=.6); ax.set_xlim(lim); ax.set_ylim(-13, 6)
ax.set_xlabel("IL-33 effect in HUVEC: log2FC, IL-33 vs vehicle"); ax.set_ylabel("AX-1177 alone: log2FC, AX-1177 vs isotype")
ax.set_title("B  Antibody without IL-33: no effect on the same genes", loc="left"); ax.legend(fontsize=7, frameon=False, loc="lower left")
# --- C: HGMEC vs HUVEC reversal at 6 h
ax = axs[0, 2]
core = (D.IL33_6h >= 2) & (D.q_IL33_6h < 0.01)
x, y = D.revIso_6h[core], D.G_revIso_6h[core]
ax.scatter(x, y, s=10, c=PURPLE, alpha=.6, lw=0)
mk = core & (D.SE_ratio > 5); ax.scatter(D.revIso_6h[mk], D.G_revIso_6h[mk], s=30, c=ORANGE, edgecolor="k", lw=.4)
sl = np.polyfit(x, y, 1); xx = np.array([-13, 1]); ax.plot(xx, sl[0] * xx + sl[1], c="k", lw=1); ax.plot(xx, xx, "k--", lw=.6, alpha=.5)
txt = [ax.text(D.revIso_6h[i], D.G_revIso_6h[i], sym[i], fontsize=7.5) for i in D.index[core & sym.isin(["SELE", "VCAM1", "CXCL8", "CXCL1", "CSF2", "CSF3", "IL6", "CCL20", "ICAM1", "BIRC3"])]]
adjust_text(txt, ax=ax, arrowprops=dict(arrowstyle="-", lw=.4, color="k"))
ax.set_xlabel("HUVEC: AX-1177 reversal, log2FC (6 h)"); ax.set_ylabel("HGMEC (glomerular): AX-1177 reversal, log2FC (6 h)")
ax.set_title(f"C  Same programme in glomerular endothelium,\n    about half the size (r = {stats.pearsonr(x, y)[0]:.2f}, slope = {sl[0]:.2f})", loc="left")
# --- D: reversal across beds and time
ax = axs[1, 0]
cols = [("HUVEC\n6 h", "revIso_6h", BLUE), ("HUVEC\n24 h", "revIso_24h", BLUE), ("HGMEC\n6 h", "G_revIso_6h", PURPLE), ("HGMEC\n24 h", "G_revIso_24h", PURPLE)]
data = [D.loc[core, c].values for _, c, _ in cols] + [L.loc[core, "Ab_vs_Iso_HUVEC_6h"].values]
bp = ax.boxplot(data, tick_labels=[n for n, _, _ in cols] + ["AX-1177 alone\nHUVEC 6 h"], showfliers=False, patch_artist=True, widths=.6, medianprops=dict(color="k"))
for patch, colr in zip(bp["boxes"], [c for _, _, c in cols] + [GREY]): patch.set_facecolor(colr); patch.set_alpha(.55)
ax.axhline(0, c="k", lw=.6)
nsig = [int((Q[c] < 0.05).sum()) for c in ["AbIL33_vs_IsoIL33_HUVEC_6h", "AbIL33_vs_IsoIL33_HUVEC_24h", "AbIL33_vs_IsoIL33_HGMEC_6h", "AbIL33_vs_IsoIL33_HGMEC_24h", "Ab_vs_Iso_HUVEC_6h"]]
for i, n in enumerate(nsig): ax.text(i + 1, 3.0, f"{n:,}\ngenes", ha="center", fontsize=7.5)
ax.set_ylim(-9, 4.2); ax.set_ylabel("log2FC of the 273 genes IL-33 induces ≥4-fold\n(antibody arm vs isotype arm)")
ax.set_title("D  The readable window is 6 h; by 24 h it has narrowed,\n    and in HGMEC it has almost closed", loc="left")
ax.text(0.02, 0.02, "numbers = genes at FDR<0.05 genome-wide in that contrast", transform=ax.transAxes, fontsize=7, color="#444")
# --- E: 6 h vs 24 h IL-33 effect (HUVEC)
ax = axs[1, 1]
e6 = (D.IL33_6h >= 2) & (D.pct_revIso_6h >= 70) & (D.pct_rev_6h >= 70)
cmap = {"early/transient": RED, "intermediate": GREY, "sustained": GREEN}
for k, c in cmap.items():
    m = e6 & (D.kinetic_class == k); ax.scatter(D.IL33_6h[m], D.IL33_24h[m], s=11, c=c, alpha=.7, lw=0, label=f"{k} (n={int(m.sum())})")
ax.plot([0, 12], [0, 12], "k--", lw=.7); ax.axhline(0, c="k", lw=.4)
txt = [ax.text(D.IL33_6h[i], D.IL33_24h[i], sym[i], fontsize=7.5) for i in D.index[e6 & sym.isin(["SELE", "VCAM1", "CXCL8", "CSF2", "CSF3", "IL6", "CCL20", "ICAM1", "F3", "TNF", "CXCL6", "CXCL5", "IL1B", "IL18R1", "TNFRSF11B", "KYNU"])]]
adjust_text(txt, ax=ax, arrowprops=dict(arrowstyle="-", lw=.4, color="k"))
ax.set_xlabel("IL-33 effect at 6 h (log2FC vs vehicle), HUVEC"); ax.set_ylabel("IL-33 effect at 24 h (log2FC vs vehicle), HUVEC")
ax.set_title(f"E  Most of the IL-33 response has decayed by 24 h\n    (median 24 h / 6 h = {(D.IL33_24h[e6] / D.IL33_6h[e6]).median():.2f} on the log scale)", loc="left"); ax.legend(fontsize=7, frameon=False, loc="upper left")
# --- F: headline markers, fold change with IL-33 vs with IL-33 + AX-1177
ax = axs[1, 2]
genes = ["SELE", "VCAM1", "ICAM1", "CXCL8", "CXCL1", "CSF3", "CSF2", "IL6", "CCL20", "TNFRSF11B", "F3", "IL18R1", "PTX3", "IL1RL1"]
disp = {"TNFRSF11B": "TNFRSF11B (OPG)", "F3": "F3 (tissue factor)", "IL1RL1": "IL1RL1 (ST2)", "CSF3": "CSF3 (G-CSF)", "CSF2": "CSF2 (GM-CSF)", "CXCL8": "CXCL8 (IL-8)", "SELE": "SELE (E-selectin)"}
g = D[sym.isin(genes)].drop_duplicates("symbol").set_index("symbol").loc[genes][::-1]
yy = np.arange(len(g))
ax.barh(yy + .2, g.IL33_6h, height=.38, color=ORANGE, label="IL-33 vs vehicle")
ax.barh(yy - .2, g.resid_6h, height=.38, color=BLUE, label="IL-33 + AX-1177 vs vehicle")
ax.set_yticks(yy); ax.set_yticklabels([disp.get(s_, s_) for s_ in g.index], fontsize=8); ax.axvline(0, c="k", lw=.6)
for y_, (s_, row) in zip(yy, g.iterrows()): ax.text(max(row.IL33_6h, 0) + .15, y_ + .2, f"{2**row.IL33_6h:,.0f}×" if row.IL33_6h > 3.3 else f"{2**row.IL33_6h:.1f}×", va="center", fontsize=7)
ax.set_xlabel("log2 fold change vs vehicle, HUVEC, 6 h"); ax.set_xlim(-2.3, 13.5)
ax.set_title("F  Headline markers: induction is abolished\n    (fold induction by IL-33 shown at bar end)", loc="left"); ax.legend(fontsize=7, frameon=False, loc="lower right")
ax.text(0.99, 0.17, "blue bars below zero (CSF2, CCL20):\nundetectable without IL-33, so the\nresidual is count noise", transform=ax.transAxes, fontsize=6.5, ha="right", color="#444")
fig.suptitle("Figure 1. AX-1177 (10 µg/mL, added together with IL-33, no pre-incubation) neutralises IL-33 (30 ng/mL) signalling in two primary human endothelial cell types", fontsize=11, y=1.0)
fig.tight_layout(); fig.savefig(f"{FIG}/Fig1_invitro_pharmacology.png", bbox_inches="tight"); plt.close(fig)

# =============================================================== FIGURE 2: serum proteomics
s = pd.read_pickle(f"{CACHE}/serum_annotated.pkl")
fig = plt.figure(figsize=(15, 8.6)); gs = fig.add_gridspec(2, 3, width_ratios=[1.15, 1.25, 1], height_ratios=[1, 1])
# --- A: all assays ranked by z
ax = fig.add_subplot(gs[:, 0])
ss = s.sort_values("z", ascending=False).reset_index(drop=True); ss["x"] = np.arange(1, len(ss) + 1)
ax.scatter(ss.x, ss.z, s=5, c="#cfcfcf", lw=0)
sigz = ss[ss.FDR05 & (ss.z > 0)].z.min(); ax.axhline(sigz, c="k", ls=":", lw=.8); ax.text(1090, sigz + .06, "FDR 0.05", ha="right", fontsize=7.5)
il33g = ["IL6", "TNFRSF11B", "PTX3", "IL18R1", "CCL20", "CCL7", "CXCL8"]; t2 = ["IL5", "CCL17", "CCL11", "CCL24", "CCL13", "TPSAB1", "IL5RA"]
m = ss.gene.isin(il33g); ax.scatter(ss.x[m], ss.z[m], s=26, c=ORANGE, edgecolor="k", lw=.4, zorder=3, label="IL-33-inducible, AX-1177-reversible\nendothelial products (our RNA-seq)")
m2 = ss.gene.isin(t2); ax.scatter(ss.x[m2], ss.z[m2], s=26, c=GREEN, edgecolor="k", lw=.4, zorder=3, label="type-2 / eosinophil / mast-cell markers")
m3 = ss.gene == "IL1RL1"; ax.scatter(ss.x[m3], ss.z[m3], s=70, c=RED, marker="*", edgecolor="k", lw=.4, zorder=4, label="sST2 (soluble IL-33 decoy receptor)")
keep = ss[m | m2 | m3].drop_duplicates("gene")
txt = [ax.text(r_.x, r_.z, {"IL1RL1": "sST2", "TNFRSF11B": "OPG", "CCL7": "MCP-3", "CXCL8": "IL-8", "IL18R1": "IL-18R1", "CCL13": "MCP-4", "CCL11": "eotaxin-1", "CCL24": "eotaxin-2", "TPSAB1": "tryptase", "IL5RA": "IL-5Rα", "IL5": "IL-5", "CCL17": "CCL17/TARC"}.get(r_.gene, r_.gene), fontsize=7.5) for r_ in keep.itertuples()]
adjust_text(txt, ax=ax, arrowprops=dict(arrowstyle="-", lw=.4, color="k"))
ax.axhline(0, c="k", lw=.5); ax.set_xlabel("1,094 assays, ranked"); ax.set_ylabel("association with ICU / ventilation / death (Wald z; adjusted for age, sex, NEWS2)")
ax.set_title(f"A  sST2 is the 2nd-strongest of 1,094 assays,\n    but {int(s.FDR05.sum())} assays are significant and {int((s.FDR05 & (s.OR > 1)).sum())} of them point the same way", loc="left")
ax.legend(fontsize=7, frameon=False, loc="upper right"); ax.text(0.03, 0.05, "IL-33 itself: on the panel run,\nnot in the delivered results", transform=ax.transAxes, fontsize=8.5, color=RED, style="italic")
# --- B: forest
ax = fig.add_subplot(gs[:, 1])
rowsF = [("IL-33 axis", [("ST2", "sST2")]),
         ("IL-33-inducible in endothelium and\nreversed by AX-1177 (our RNA-seq)", [("IL6", "IL-6"), ("OPG-INFI", "OPG"), ("PTX3", "PTX3"), ("IL-18R1", "IL-18R1"), ("CCL20", "CCL20"), ("MCP-3", "MCP-3 (CCL7)"), ("IL8", "IL-8"), ("TF", "tissue factor"), ("MCP-1-INFI", "MCP-1 (CCL2)"), ("SELE", "E-selectin"), ("ICAM1", "ICAM-1"), ("VCAM1", "VCAM-1"), ("G-CSF", "G-CSF"), ("CXCL1-INFI", "CXCL1"), ("CXCL5", "CXCL5"), ("CXCL6", "CXCL6")]),
         ("Type-2 / eosinophil / mast cell", [("IL5-IMO", "IL-5"), ("IL-5R-alpha", "IL-5Rα"), ("CCL17", "CCL17 (TARC)"), ("CCL11-INFI", "eotaxin-1"), ("CCL24", "eotaxin-2"), ("MCP-4", "MCP-4 (CCL13)"), ("RNASE3", "ECP (RNASE3)"), ("TPSAB1", "tryptase")])]
sa = s.set_index("assay"); y = 0; yt, yl = [], []
for grp, items in rowsF:
    ax.text(0.085, y, grp, fontsize=8, fontweight="bold", va="center"); y -= 1.25 if "\n" in grp else 1
    for a_, lab_ in items:
        r_ = sa.loc[a_]; c = RED if r_["adj.p.value"] < 0.05 else ("#555" if r_["p.value"] < 0.05 else "#aaa")
        ax.plot([r_.l95, r_.u95], [y, y], c=c, lw=1.6); ax.scatter([r_.OR], [y], c=c, s=28, zorder=3)
        yt.append(y); yl.append(lab_); y -= 1
    y -= .5
ax.axvline(1, c="k", lw=.7); ax.set_xscale("log"); ax.set_xlim(0.08, 45); ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=8)
ax.set_xticks([0.25, 0.5, 1, 2, 4, 8, 16, 32]); ax.set_xticklabels(["0.25", "0.5", "1", "2", "4", "8", "16", "32"])
ax.set_xlabel("odds ratio per log unit (95% CI), composite endpoint"); ax.set_title("B  What tracks with outcome: sST2 and IL-6-type/endothelial products.\n    What does not: the type-2 arm", loc="left")
for c, t in [(RED, "FDR < 0.05"), ("#555", "nominal p < 0.05"), ("#aaa", "not significant")]: ax.plot([], [], c=c, lw=2, label=t)
ax.legend(fontsize=7, frameon=False, loc="lower right")
# --- C: class bars
ax = fig.add_subplot(gs[0, 2])
T5 = pd.read_csv("/tmp/outputs/tables/T5_serum_biology_class_summary.csv")
t = T5[T5["class"] != "ALL PROTEINS (background)"].copy(); bg = T5[T5["class"] == "ALL PROTEINS (background)"]["pct_FDR<0.05"].iloc[0]
t = t.sort_values("pct_FDR<0.05"); colr = [GREEN if "Type-2" in c else (RED if "IL-33" in c else GREY) for c in t["class"]]
ax.barh(range(len(t)), t["pct_FDR<0.05"], color=colr, alpha=.8); ax.axvline(bg, c="k", ls="--", lw=.8); ax.text(bg + .5, len(t) - .45, f"all proteins: {bg:.0f}%", fontsize=7.5, va="bottom")
ax.set_yticks(range(len(t))); ax.set_yticklabels([c.replace(" / ", "/\n", 1) if len(c) > 34 else c for c in t["class"]], fontsize=7.5)
for i, r_ in enumerate(t.itertuples()): ax.text(r_._4 + .6, i, f"{r_._3}/{r_.proteins_measured}", va="center", fontsize=7.5)
ax.set_xlabel("% of proteins in class with FDR < 0.05"); ax.set_xlim(0, 52); ax.set_title("C  Prognostic signal by biology class", loc="left")
# --- D: signature enrichment
ax = fig.add_subplot(gs[1, 2])
E = pd.read_csv("/tmp/outputs/tables/T5b_IL33_signature_enrichment_among_prognostic_proteins.csv")
xl = ["broad\n≥2-fold,\n≥50% reversed", "strict, 6 h\n≥4-fold,\n≥80% reversed", "core\nstrict + reversed\nin HGMEC"]
xx = np.arange(3); ax.bar(xx - .2, E.pct_in_set, width=.38, color=ORANGE, label="proteins in IL-33 signature"); ax.bar(xx + .2, E.pct_outside_set, width=.38, color=GREY, label="all other proteins")
for i, r_ in enumerate(E.itertuples()): ax.text(i, max(r_.pct_in_set, r_.pct_outside_set) + 1.5, f"{r_.prognostic_in_set}/{r_.proteins_in_set}\nOR {r_.Fisher_OR:.2f}, p = {r_.Fisher_p:.2f}", ha="center", fontsize=7.5)
ax.set_xticks(xx); ax.set_xticklabels(xl, fontsize=7.5); ax.set_ylabel("% prognostic (FDR < 0.05)"); ax.set_ylim(0, 42); ax.legend(fontsize=7, frameon=False, loc="upper left")
ax.set_title("D  The IL-33 endothelial signature is not\n    significantly enriched among prognostic proteins", loc="left")
fig.suptitle("Figure 2. Serum proteomics at enrolment, 100 hospitalised COVID-19 patients (44 reached ICU / ventilation / death within 30 days)", fontsize=11, y=1.0)
fig.tight_layout(); fig.savefig(f"{FIG}/Fig2_serum_proteomics.png", bbox_inches="tight"); plt.close(fig)

# =============================================================== FIGURE 3: post-mortem lung (donor level)
don = pd.read_pickle(f"{CACHE}/lung_donor.pkl"); T7 = pd.read_csv("/tmp/outputs/tables/T7_lung_group_comparisons_donor_level.csv")
order = ["COVID- non-pneumonia", "COVID- pneumonia", "COVID+ pneumonia"]; gl = ["non-pneumonia\n(COVID−)\nn=5", "pneumonia\n(COVID−)\nn=10", "pneumonia\n(COVID+)\nn=16"]; gc = [GREY, BLUE, RED]
fig, axs = plt.subplots(2, 3, figsize=(14, 8.6)); rng = np.random.default_rng(3)
panels = [("IL33_epi", "IL-33, basal airway epithelium"), ("IL33_endo", "IL-33, endothelium"), ("IL33_vsmc", "IL-33, vascular smooth muscle"), ("NE", "Neutrophil elastase"), ("EDN", "Eosinophil-derived neurotoxin")]
for ax, (m, ttl), letter in zip(axs.flat, panels, "ABCDE"):
    for i, (g_, c) in enumerate(zip(order, gc)):
        v = don[don.group == g_][m].dropna(); nb = don[don.group == g_].loc[v.index, "n_blocks"]
        ax.scatter(i + rng.uniform(-.16, .16, len(v)), v, s=18 + 9 * nb, c=c, alpha=.7, edgecolor="k", lw=.4); ax.plot([i - .28, i + .28], [v.mean()] * 2, c="k", lw=2)
    ax.set_xticks(range(3)); ax.set_xticklabels(gl, fontsize=8); ax.set_ylabel("IHC score (donor mean)"); ax.set_ylim(-0.3, 7.6)
    t = T7[T7.marker == ttl].set_index("comparison")
    p1 = t.loc["COVID+ pneumonia vs COVID- pneumonia", "donor_level_permutation_p"]; p2 = t.loc["pneumonia-labelled (any) vs non-pneumonia", "donor_level_permutation_p"]; pb = t.loc["COVID+ vs all COVID-", "NAIVE_block_level_p"]; pd_ = t.loc["COVID+ vs all COVID-", "donor_level_permutation_p"]
    ax.set_title(f"{letter}  {ttl}", loc="left")
    ax.text(0.02, 0.985, f"COVID+ vs COVID− pneumonia: p = {p1:.2f}\nany pneumonia vs non-pneumonia: p = {p2:.3f}\nCOVID+ vs all COVID−: p = {pd_:.3f} by donor (by block, not valid: {pb:.3f})", transform=ax.transAxes, fontsize=7, va="top")
    if m.startswith("IL33"): ax.axhline(5.5, c="k", ls=":", lw=.6); ax.text(1.0, 5.58, "top of scale", fontsize=6.5, ha="center", va="bottom")
    ax.set_yticks(range(0, 6))
ax = axs[1, 2]
for g_, c in zip(order, gc):
    d_ = don[don.group == g_]; ax.scatter(d_.NE, d_.IL33_endo, s=18 + 9 * d_.n_blocks, c=c, alpha=.7, edgecolor="k", lw=.4, label=g_)
rho, p = stats.spearmanr(don.NE, don.IL33_endo); sl = np.polyfit(don.NE, don.IL33_endo, 1); xx = np.array([1.8, 4.7]); ax.plot(xx, sl[0] * xx + sl[1], c="k", lw=1)
ax.set_xlabel("Neutrophil elastase score (donor mean)"); ax.set_ylabel("IL-33, endothelium (donor mean)"); ax.legend(fontsize=7, frameon=False, loc="lower left")
ax.set_title(f"F  More neutrophils, less endothelial IL-33\n    (Spearman rho = {rho:.2f}, p = {p:.3f}, 31 donors)", loc="left")
fig.suptitle("Figure 3. Post-mortem lung, one point per donor (size = number of blocks; bar = group mean): IL-33 is abundant in every group and not higher in COVID-19 lung", fontsize=11, y=1.0)
fig.tight_layout(); fig.savefig(f"{FIG}/Fig3_postmortem_lung.png", bbox_inches="tight"); plt.close(fig)

# =============================================================== FIGURE 4: why the delivered p-values cannot be used alone
fig, axs = plt.subplots(1, 2, figsize=(13.5, 5.2))
ax = axs[0]
ok = ann.medSE.notna()
ax.scatter(ann.AveExpr[ok], ann.medSE[ok], s=3, c="#c8c8c8", lw=0, rasterized=True)
bad = ann.SE_ratio > 5; ax.scatter(ann.AveExpr[bad], ann.medSE[bad], s=9, c=ORANGE, lw=0, label=f"standard error >5× expected (n={int(bad.sum())})")
labs = ["SELE", "VCAM1", "CXCL8", "CXCL1", "CCL2", "PTX3", "IL1RL1", "ICAM1", "CDH5", "CD93", "VWF", "KRT8", "AKR1C2", "GAPDH", "PECAM1", "XBP1"]
txt = [ax.text(ann.AveExpr[i], ann.medSE[i], ann.symbol[i], fontsize=7.5) for i in ann.index[ann.symbol.isin(labs)]]
ax.set_yscale("log"); adjust_text(txt, ax=ax, arrowprops=dict(arrowstyle="-", lw=.4, color="k"))
ax.set_xlabel("average log2 expression across all 114 libraries (4 cell types)"); ax.set_ylabel("standard error of a contrast (median over 26 contrasts, log2 units)")
ax.set_title("A  One pooled model across four cell types: lineage markers and the most\n    IL-33-responsive genes get standard errors 5× to >10,000× too large", loc="left"); ax.legend(fontsize=7.5, frameon=False, loc="upper right")
ax = axs[1]
genes = ["SELE", "VCAM1", "CXCL8", "CXCL1", "CCL2", "PTX3", "IL1RL1", "ICAM1", "IL6", "CSF3", "CCL20"]
g = D[sym.isin(genes)].drop_duplicates("symbol").set_index("symbol").loc[genes]
xx = np.arange(len(g)); ax.bar(xx, g.IL33_6h, color=[ORANGE if q > 0.05 else BLUE for q in g.q_IL33_6h])
for i, (s_, r_) in enumerate(g.iterrows()): ax.text(i, r_.IL33_6h + .25, f"FDR\n{r_.q_IL33_6h:.2f}" if r_.q_IL33_6h >= 0.005 else "FDR\n<0.001", ha="center", fontsize=7.5)
ax.set_xticks(xx); ax.set_xticklabels(g.index, rotation=45, ha="right"); ax.set_ylabel("IL-33 vs vehicle, HUVEC 6 h (log2FC)"); ax.set_ylim(0, 13.5)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=ORANGE, label="fails FDR 0.05 in the delivered table"), Patch(color=BLUE, label="passes")], fontsize=7.5, frameon=False, loc="upper right")
ax.set_title("B  Consequence: the canonical endothelial-activation genes 'fail' significance\n    despite 3- to 2,400-fold changes that AX-1177 fully reverses", loc="left")
fig.suptitle("Figure 4. A limitation of the delivered RNA-seq statistics (effect sizes are sound; p-values for ~300 genes are not)", fontsize=11, y=1.02)
fig.tight_layout(); fig.savefig(f"{FIG}/Fig4_rnaseq_statistics_caveat.png", bbox_inches="tight"); plt.close(fig)
print("figures written")
