"""
06_tables_xlsx.py  -  AX-1177 portfolio audit: curated biomarker table (T3) and one Excel workbook with all supporting tables
Run:  micromamba run -n singlecell python 06_tables_xlsx.py
"""
import glob, os
import numpy as np, pandas as pd
CACHE = "/tmp/work/cache"; TAB = "/tmp/outputs/tables"
D = pd.read_pickle(f"{CACHE}/rnaseq_gene_table.pkl"); Dg = D.drop_duplicates("symbol").set_index("symbol")
s = pd.read_pickle(f"{CACHE}/serum_annotated.pkl")

def rna(g):
    r = Dg.loc[g]
    fold = lambda v: f"{2**v:,.0f}x" if v >= 3.32 else f"{2**v:.1f}x"
    if r.IL33_6h < 1:      # not induced by IL-33 in endothelium
        return (f"not induced ({fold(r.IL33_6h)})", "-", f"not induced ({fold(r.IL33_24h)})", "-", "-")
    rev = f"{r.pct_revIso_6h:.0f}%" if r.pct_revIso_6h <= 110 else "complete (>100%: near-zero baseline counts)"
    hg = f"{2**(-r.G_revIso_6h):,.0f}x lower" if r.G_revIso_6h <= -3.32 else (f"{2**(-r.G_revIso_6h):.1f}x lower" if r.G_revIso_6h < -0.3 else "no change")
    q = "unusable (SE inflated)" if r.SE_ratio > 5 else ("<0.001" if r.q_IL33_6h < 0.001 else f"{r.q_IL33_6h:.3f}")
    return (fold(r.IL33_6h), rev, fold(r.IL33_24h), hg, q)
def ser(g):
    x = s[s.gene == g].sort_values("p.value")
    if len(x) == 0: return ("not on the panels / not delivered", "", "", "")
    r = x.iloc[0]; extra = f" ({len(x)} panels, OR {x.OR.min():.2f}-{x.OR.max():.2f})" if len(x) > 1 else ""
    return (r.assay + extra, f"{r.OR:.2f} ({r.l95:.2f}-{r.u95:.2f})", f"{r['p.value']:.2g}", f"{r['adj.p.value']:.3f}")
rows = [
 ("IL1RL1", "sST2 (soluble ST2, IL-33 decoy receptor)", "Patient enrichment / stratification (prognostic). Exploratory PD.", "Not target engagement, not yet predictive: it is a decoy and rises with many stimuli. Needs a validated cut-off."),
 ("IL6", "IL-6", "Prognostic covariate; distal PD (non-specific).", "Clinical assay exists. Also driven by TNF/IL-1."),
 ("CXCL8", "IL-8", "Exploratory PD panel member.", "Part of an 'IL-33 endothelial response score'."),
 ("TNFRSF11B", "OPG", "Exploratory PD panel member.", ""),
 ("PTX3", "PTX3", "Exploratory PD panel member.", "RNA-seq p-value unreliable; effect consistent in 3 contrasts. Confirm at protein level."),
 ("CCL20", "CCL20", "Exploratory PD panel member.", ""),
 ("CCL7", "MCP-3 (CCL7)", "Exploratory PD panel member.", "Very low transcript counts in vitro - confirm."),
 ("IL18R1", "IL-18R1", "Exploratory PD panel member.", "Transient in vitro (6 h >> 24 h)."),
 ("SELE", "soluble E-selectin", "Endothelium-specific, mechanism-proximal PD.", "Top induced gene; serum association nominal only (FDR 0.09). RNA-seq p-value unreliable."),
 ("F3", "tissue factor", "Exploratory PD (pro-thrombotic arm).", "Serum association nominal (FDR 0.051)."),
 ("VCAM1", "soluble VCAM-1", "In vitro / ex vivo PD only.", "Not prognostic in serum."),
 ("ICAM1", "soluble ICAM-1", "In vitro / ex vivo PD only.", "Not prognostic in serum."),
 ("CSF3", "G-CSF", "In vitro / ex vivo potency and PD read-out only.", "Strong, sustained in vitro; not prognostic in serum."),
 ("CSF2", "GM-CSF", "In vitro / ex vivo potency and PD read-out only.", "Not on the serum panels."),
 ("CXCL1", "CXCL1", "In vitro / ex vivo PD only.", "Not prognostic in serum (2 panels). RNA-seq p-value unreliable."),
 ("(IL-33 protein)", "IL-33 (free/total; reduced/oxidised) and IL-33:sST2 complex", "Target engagement; candidate predictive marker.", "NO DATA: assay result not delivered. A sensitive assay on the banked sera is the first gate."),
 ("HGF", "HGF", "Generic severity covariate only.", "Strongest serum protein, but not IL-33-inducible in endothelium."),
 ("IL5", "IL-5 (and type-2 markers generally)", "Not recommended for this indication.", "Type-2 arm flat in serum; tissue IL-5R-alpha tracks neutrophils, not eosinophils."),
]
out = []
for g, name, role, note in rows:
    fc6, rev6, fc24, hg, q = rna(g) if g in Dg.index else ("", "", "", "", "")
    a, orci, p, fdr = ser(g) if g != "(IL-33 protein)" else ("on the Inflammation panel that was run; not in the delivered results", "", "", "")
    out.append({"marker": name, "gene": g, "IL-33 induction HUVEC 6 h": fc6, "% reversed by AX-1177 (vs isotype), 6 h": rev6, "IL-33 induction HUVEC 24 h": fc24, "AX-1177 effect in HGMEC 6 h (IL-33 present)": hg,
                "FDR of IL-33 effect in delivered RNA-seq table": q, "serum assay": a, "serum OR (95% CI) for ICU/ventilation/death": orci, "serum p": p, "serum FDR": fdr, "proposed role": role, "caveat": note})
T3 = pd.DataFrame(out); T3.to_csv(f"{TAB}/T3_biomarker_shortlist_with_roles.csv", index=False)
pd.set_option("display.width", 300); pd.set_option("display.max_colwidth", 48); print(T3.drop(columns=["caveat"]).to_string())

# merge the two parts of the integrity log
parts = sorted(glob.glob(f"{TAB}/T9_data_integrity_log_part*.csv"))
if parts:      # written by 01_load_data.py and 03_serum.py
    logs = pd.concat([pd.read_csv(f) for f in parts], ignore_index=True); logs.to_csv(f"{TAB}/T9_data_integrity_log.csv", index=False)
    for f in parts: os.remove(f)
else:
    logs = pd.read_csv(f"{TAB}/T9_data_integrity_log.csv")

readme = pd.DataFrame({"sheet": ["T1", "T2", "T2b", "T2c", "T3", "T3b", "T4", "T5", "T5b", "T6", "T7", "T7b", "T8", "T9", "T10", "T10b"],
 "content": ["RNA-seq: every delivered contrast (26) - number of genes changed",
             "RNA-seq: 137-gene core IL-33 signature (induced >=4x in HUVEC at 6 h, >=80% reversed by AX-1177 in both contrasts, reversed in HGMEC), with kinetic class and PD tier",
             "RNA-seq: completeness of neutralisation in HUVEC, by gene set and timepoint",
             "RNA-seq: reversal of the core signature by vascular bed and timepoint",
             "Biomarker shortlist with proposed role in patients and the evidence for each",
             "Core-signature genes whose protein is measured on the serum panels, with clinical association",
             "Serum: all 1,094 delivered assays, gene mapping, Wald z, biology class flags, link to RNA-seq signature",
             "Serum: prognostic signal by biology class (gene level)",
             "Serum: is the IL-33 endothelial signature enriched among prognostic proteins?",
             "Lung: donor-level table (31 donors) incl. pathology text and re-classification used in sensitivity analysis",
             "Lung: group comparisons at donor level (permutation p, bootstrap CI) with the naive block-level p shown for contrast",
             "Lung: donor-level model adjusted for acute pathology and age",
             "RNA-seq: large IL-33 effects whose p-values are unusable because of inflated standard errors in the pooled model",
             "Data-integrity log: hidden rows/columns/filters, label and denominator inconsistencies, and how each was handled",
             "RNA-seq: antibody-alone contrasts - summary", "RNA-seq: antibody-alone contrasts - every FDR<0.05 gene, flagged"]})
files = {"T1": "T1_rnaseq_contrast_summary", "T2": "T2_IL33_core_signature_137_genes", "T2b": "T2b_neutralisation_summary_HUVEC", "T2c": "T2c_reversal_by_bed_and_time", "T3": "T3_biomarker_shortlist_with_roles",
         "T3b": "T3b_core_signature_proteins_measured_in_serum", "T4": "T4_serum_all_assays_annotated", "T5": "T5_serum_biology_class_summary", "T5b": "T5b_IL33_signature_enrichment_among_prognostic_proteins",
         "T6": "T6_lung_donor_level_table", "T7": "T7_lung_group_comparisons_donor_level", "T7b": "T7b_lung_adjusted_model", "T8": "T8_large_effects_masked_by_inflated_SE", "T9": "T9_data_integrity_log",
         "T10": "T10_antibody_alone_summary", "T10b": "T10b_antibody_alone_all_FDR_hits"}
guide = pd.DataFrame([
 ("T1, T10", "contrast", "IL33_<cell>_<time> = IL-33 vs vehicle; Ab_vs_Iso = AX-1177 vs isotype antibody, no IL-33; AbIL33_vs_IL33 = IL-33 + AX-1177 vs IL-33 alone; AbIL33_vs_IsoIL33 = IL-33 + AX-1177 vs IL-33 + isotype (primary reversal contrast); Ab_vs_DMSO / Ab_vs_PBS = AX-1177 vs vehicle in the epithelial lines"),
 ("T1", "FDR05 / up / down", "genes with delivered adj.P.Val < 0.05, and their direction"),
 ("T1", "FDR05_and_2fold", "FDR < 0.05 and at least 2-fold (|log2FC| >= 1)"),
 ("T1", "FDR05_but_lt_1p23fold", "FDR < 0.05 but smaller than 1.23-fold (|log2FC| < 0.3): statistically significant, biologically small"),
 ("T1", "FDR05_expressed_and_1p5fold", "FDR < 0.05, average log2 expression >= 2 and at least 1.5-fold"),
 ("T2, T3b, T4 (rna_ prefix)", "IL33_6h, IL33_24h", "log2 fold change, IL-33 vs vehicle, HUVEC"),
 ("T2", "pct_rev_6h", "% of the IL-33 log2 fold change removed by AX-1177, measured against IL-33 alone (shares the IL-33 arm with the induction contrast)"),
 ("T2, T3b, T4", "pct_revIso_6h, pct_revIso_24h", "% of the IL-33 log2 fold change removed by AX-1177, measured against IL-33 + isotype (independent samples; primary)"),
 ("T2", "resid_6h", "log2 fold change of IL-33 + AX-1177 vs vehicle (derived by adding two delivered contrasts); 0 = back to baseline"),
 ("T2, T3b, T4", "G_revIso_6h, G_revIso_24h", "HGMEC: log2 fold change of IL-33 + AX-1177 vs IL-33 + isotype (negative = AX-1177 lowers the gene)"),
 ("T2", "maxabs_Ab_alone_endo", "largest |log2FC| of AX-1177 alone vs isotype across the four endothelial antibody-alone contrasts"),
 ("T2, T8", "AveExpr", "average log2 expression over all 114 libraries (all four cell types), as delivered"),
 ("T2, T8", "SE_ratio", "standard error of the gene (median over contrasts) divided by the standard error expected at that expression level; > 5 means the delivered p-value is unusable"),
 ("T2", "q_IL33_6h, q_revIso_6h", "delivered adj.P.Val for IL-33 vs vehicle and for the primary reversal contrast"),
 ("T2", "PD_tier", "A = induced and reversed at 6 h and 24 h, in both endothelial types, unaffected by antibody alone; B = 6 h only, both types, antibody-inert; C = 6 h, both types"),
 ("T2", "kinetic_class", "early/transient = 24 h effect < 35% of the 6 h effect (log scale); sustained = >= 70%; otherwise intermediate"),
 ("T4", "composite_endpoint_0 / _1", "as delivered; read here as the fraction of samples missing or below detection in patients without / with the endpoint (56 and 44 patients)"),
 ("T4", "wald_z", "log(odds ratio) divided by its standard error; used for ranking because odds ratios are not standardised"),
 ("T4", "class: ...", "membership of the curated biology classes summarised in T5"),
 ("T4", "IL33_signature_broad / strict_6h / core_both_beds", "whether the protein's gene is in the IL-33 endothelial signature at three stringencies (see T5b)"),
 ("T6", "acute_pneumonia_or_ALI_on_pathology, DAD_or_hyaline_membranes, pulmonary_thromboemboli", "read by hand from the free-text pathology column; used only in the sensitivity analysis"),
 ("T7", "donor_level_permutation_p", "permutation test on donor means (valid unit of analysis)"),
 ("T7", "NAIVE_block_level_p", "Mann-Whitney test treating every tissue block as independent; shown only to illustrate the pseudo-replication - do not use"),
 ("T7b", "b_covid, b_acute, b_age_per_decade", "donor-level linear model: score ~ SARS-CoV-2 + acute pneumonia/lung injury on pathology + age"),
], columns=["sheet", "column", "meaning"])
with pd.ExcelWriter("/tmp/outputs/AX-1177_supporting_tables.xlsx", engine="openpyxl") as xw:
    readme.to_excel(xw, sheet_name="README", index=False)
    guide.to_excel(xw, sheet_name="COLUMN_GUIDE", index=False)
    for sh, f in files.items():
        d = pd.read_csv(f"{TAB}/{f}.csv"); d.to_excel(xw, sheet_name=sh, index=False)
    for ws in xw.book.worksheets:
        ws.freeze_panes = "A2"
        for col in ws.columns:
            w = max(len(str(c.value)) if c.value is not None else 0 for c in col[:60]); ws.column_dimensions[col[0].column_letter].width = min(max(10, w + 2), 70)
print("workbook written:", "/tmp/outputs/AX-1177_supporting_tables.xlsx"); print(logs[["file", "item"]].to_string())
