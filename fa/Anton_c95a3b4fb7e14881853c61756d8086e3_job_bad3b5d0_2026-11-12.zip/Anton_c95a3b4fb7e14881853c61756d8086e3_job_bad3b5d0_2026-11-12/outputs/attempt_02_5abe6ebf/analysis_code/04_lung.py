"""
04_lung.py  -  AX-1177 portfolio audit: post-mortem lung immunohistochemistry
74 histology blocks from 31 donors. The unit of inference is the DONOR (blocks from one donor are not independent).
All IHC columns are used, including the 12 columns hidden in the delivered sheet (IL-33 x3, eosinophil granule proteins, basophils).

Run:  micromamba run -n singlecell python 04_lung.py
"""
import os, warnings
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
warnings.filterwarnings("ignore")
CACHE = "/tmp/work/cache"; TAB = "/tmp/outputs/tables"
df = pd.read_pickle(f"{CACHE}/lung_blocks.pkl")
markers = ["IL33_epi", "IL33_endo", "IL33_vsmc", "NE", "IL5Ra_duplexNE", "IL5Ra_duplexTryp", "TRYPTASE", "EPX", "EDN", "MBP", "BASO_2D7"]
nice = {"IL33_epi": "IL-33, basal airway epithelium", "IL33_endo": "IL-33, endothelium", "IL33_vsmc": "IL-33, vascular smooth muscle", "NE": "Neutrophil elastase",
        "IL5Ra_duplexNE": "IL-5R-alpha (duplex with NE)", "IL5Ra_duplexTryp": "IL-5R-alpha (duplex with tryptase)", "TRYPTASE": "Mast-cell tryptase", "EPX": "Eosinophil peroxidase",
        "EDN": "Eosinophil-derived neurotoxin", "MBP": "Major basic protein", "BASO_2D7": "Basophils (2D7)"}
# donor-level table
agg = {m: (m, "mean") for m in markers}
don = df.groupby(["group", "donor"]).agg(n_blocks=("xl_row", "size"), age=("Age", "first"), sex=("Gender", "first"), sars_cov_2=("SARS-Cov-2", "first"),
                                         lung_conditions=("notes", lambda x: "; ".join(v for v in x.dropna())), HE_eos_frac=("HE_eos", "mean"), **agg).reset_index()
# pathology-text re-classification (manual read of the 'Pathology' free text; see T6 for the text itself)
acute = {'1130':1,'1138':1,'1149':1,'1159':1,'1165':1,'1910':1,'1905':0,'1970':0,'1968':0,'1961':0,
         '2035':1,'2044':1,'2045':1,'2049':1,'2040':1,'2043':1,'2067':0,'2072':1,'2073':1,'2075':1,'2101':0,'2105':1,'2108':1,'2110':1,'2113':1,'2060':1,
         '1861':0,'1944':0,'1956':1,'1965':0,'1976':1}
dad = ['2044','2049','2040','2043','2072','2108','2110']; thromb = ['2035','2040','2113','2060']
don["acute_pneumonia_or_ALI_on_pathology"] = don.donor.map(acute)
don["DAD_or_hyaline_membranes"] = don.donor.isin(dad).astype(int); don["pulmonary_thromboemboli"] = don.donor.isin(thromb).astype(int)
don["covid"] = (don.group == "COVID+ pneumonia").astype(int)
for cond in ["COPD", "Asthma"]: don[cond] = don.lung_conditions.str.contains(cond)
path = df[df.Pathology.notna()].groupby("donor").Pathology.first()
don["pathology_text"] = don.donor.map(path)
don.to_pickle(f"{CACHE}/lung_donor.pkl")
don.drop(columns=["covid"]).round(3).to_csv(f"{TAB}/T6_lung_donor_level_table.csv", index=False)
print(don.groupby("group").agg(donors=("donor", "size"), blocks=("n_blocks", "sum"), age_median=("age", "median"), acute_path=("acute_pneumonia_or_ALI_on_pathology", "sum"),
                               DAD=("DAD_or_hyaline_membranes", "sum"), thromboemboli=("pulmonary_thromboemboli", "sum")).to_string())

rng = np.random.default_rng(7)
def perm(a, b, n=20000):
    a = np.asarray(a.dropna()); b = np.asarray(b.dropna()); obs = a.mean() - b.mean(); pool = np.concatenate([a, b]); k = 0
    for _ in range(n):
        rng.shuffle(pool); k += abs(pool[:len(a)].mean() - pool[len(a):].mean()) >= abs(obs) - 1e-12
    return obs, (k + 1) / (n + 1)
def boot(a, b, n=10000):
    a = np.asarray(a.dropna()); b = np.asarray(b.dropna())
    return np.percentile([rng.choice(a, len(a)).mean() - rng.choice(b, len(b)).mean() for _ in range(n)], [2.5, 97.5])
P = don[don.group == "COVID+ pneumonia"]; N = don[don.group == "COVID- pneumonia"]; C = don[don.group == "COVID- non-pneumonia"]
comps = {"COVID+ pneumonia vs COVID- pneumonia": (P, N), "COVID+ vs all COVID-": (P, pd.concat([N, C])), "pneumonia-labelled (any) vs non-pneumonia": (pd.concat([P, N]), C)}
rows = []
for m in markers + ["HE_eos_frac"]:
    kw = stats.kruskal(P[m].dropna(), N[m].dropna(), C[m].dropna()).pvalue
    for nm, (A, B) in comps.items():
        obs, p = perm(A[m], B[m]); lo, hi = boot(A[m], B[m]); mw = stats.mannwhitneyu(A[m].dropna(), B[m].dropna()).pvalue
        # naive block-level p for the same comparison (pseudo-replicated) - shown only as a warning
        ba = df[df.donor.isin(A.donor)][m] if m in df else pd.Series(dtype=float); bb = df[df.donor.isin(B.donor)][m] if m in df else pd.Series(dtype=float)
        pb = stats.mannwhitneyu(ba.dropna(), bb.dropna()).pvalue if len(ba.dropna()) and len(bb.dropna()) else np.nan
        rows.append(dict(marker=nice.get(m, "Eosinophils apparent on H&E (fraction of blocks)"), comparison=nm, donors_a=int(A[m].notna().sum()), donors_b=int(B[m].notna().sum()),
                         mean_a=A[m].mean(), mean_b=B[m].mean(), difference=obs, ci95_low=lo, ci95_high=hi, donor_level_permutation_p=p, donor_level_MannWhitney_p=mw,
                         kruskal_3group_p=kw, NAIVE_block_level_p=pb))
T7 = pd.DataFrame(rows); T7.round(4).to_csv(f"{TAB}/T7_lung_group_comparisons_donor_level.csv", index=False)
pd.set_option("display.width", 260); pd.set_option("display.max_rows", 200)
print(T7[["marker", "comparison", "mean_a", "mean_b", "difference", "ci95_low", "ci95_high", "donor_level_permutation_p", "NAIVE_block_level_p"]].round(3).to_string())

print("\nAdjusted donor-level model: score ~ SARS-CoV-2 + acute pneumonia/ALI on pathology + age (per decade)")
rows = []
for m in markers:
    d = don[[m, "covid", "acute_pneumonia_or_ALI_on_pathology", "age"]].dropna().rename(columns={"acute_pneumonia_or_ALI_on_pathology": "acute"})
    fit = smf.ols(f"{m} ~ covid + acute + age", d).fit()
    rows.append(dict(marker=nice[m], b_covid=fit.params["covid"], p_covid=fit.pvalues["covid"], b_acute=fit.params["acute"], p_acute=fit.pvalues["acute"], b_age_per_decade=10 * fit.params["age"], p_age=fit.pvalues["age"]))
T7b = pd.DataFrame(rows); print(T7b.round(3).to_string()); T7b.round(4).to_csv(f"{TAB}/T7b_lung_adjusted_model.csv", index=False)

print("\nMixed model on blocks with donor random intercept (COVID+ vs all COVID-):")
df["covid"] = (df.group == "COVID+ pneumonia").astype(int)
for m in ["IL33_endo", "IL33_vsmc", "IL33_epi"]:
    d = df[[m, "covid", "donor"]].dropna(); md = smf.mixedlm(f"{m} ~ covid", d, groups=d["donor"]).fit()
    icc = md.cov_re.iloc[0, 0] / (md.cov_re.iloc[0, 0] + md.scale)
    print(f"  {nice[m]}: b={md.params['covid']:.2f} (SE {md.bse['covid']:.2f}), p={md.pvalues['covid']:.3f}; within-donor ICC={icc:.2f}")

print("\nDonor-level Spearman correlations:")
for a, b in [("IL33_endo", "NE"), ("IL33_epi", "NE"), ("IL33_vsmc", "NE"), ("IL33_endo", "EPX"), ("IL33_epi", "EPX"), ("IL33_epi", "EDN"), ("IL33_endo", "IL33_vsmc"), ("IL33_endo", "age"), ("IL33_vsmc", "age"),
             ("IL5Ra_duplexNE", "NE"), ("IL5Ra_duplexTryp", "NE"), ("IL5Ra_duplexNE", "EPX"), ("IL5Ra_duplexTryp", "EPX"), ("EPX", "EDN")]:
    x = don[[a, b]].dropna(); r, p = stats.spearmanr(x[a], x[b]); print(f"  {a} vs {b}: rho={r:+.2f}, p={p:.3g}, n={len(x)}")
print("\nIL-33 by recorded chronic lung condition (donor level):")
for cond in ["COPD", "Asthma"]:
    for m in ["IL33_epi", "IL33_endo", "EPX"]:
        a = don[don[cond]][m]; b = don[~don[cond]][m]; print(f"  {cond} yes (n={len(a)}) {a.mean():.2f} vs no (n={len(b)}) {b.mean():.2f}; MWU p={stats.mannwhitneyu(a, b).pvalue:.2f}  [{m}]")
print("\nCeiling: % of blocks at the top endothelial IL-33 value (5.5) by group:"); print((df.assign(top=df.IL33_endo == 5.5).groupby("group").top.mean() * 100).round(0).to_string())
print("Fisher, DAD in COVID+ vs COVID-:", stats.fisher_exact([[7, 9], [0, 15]])[1].round(4), "| thromboemboli:", stats.fisher_exact([[4, 12], [0, 15]])[1].round(3))
print("blocks with tissue RNA ID available:", df["Tissue RNA"].notna().sum(), "from donors:", df[df["Tissue RNA"].notna()].groupby("group").donor.nunique().to_dict())
