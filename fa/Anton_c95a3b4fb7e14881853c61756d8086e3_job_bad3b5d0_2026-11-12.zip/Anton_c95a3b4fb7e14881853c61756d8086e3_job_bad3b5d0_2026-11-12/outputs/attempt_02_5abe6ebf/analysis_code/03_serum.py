"""
03_serum.py  -  AX-1177 portfolio audit: clinical serum proteomics (Olink Target 96, 13 panels)
100 hospitalised COVID-19 patients (pre-vaccination, single centre), serum at enrolment.
Composite endpoint = ICU admission, invasive ventilation or death within 30 days. Logistic regression per assay, adjusted for age, sex, NEWS2.

Run:  micromamba run -n singlecell python 03_serum.py
"""
import os, warnings
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
warnings.filterwarnings("ignore")
CACHE = "/tmp/work/cache"; TAB = "/tmp/outputs/tables"
s = pd.read_pickle(f"{CACHE}/serum_raw.pkl")
s["rank"] = np.arange(1, len(s) + 1)
s["panel_short"] = s.panel.str.replace("Olink Target 96 ", "").str.replace(r"\(v\.\d+\)", "", regex=True)
log = []

# ---------------------------------------------------------------- A. assay name -> gene symbol (panel suffix stripped; vendor aliases resolved)
suffixes = ['-CVDIII', '-ONCII', '-CVDII', '-INFI', '-NEUI', '-IMO', '-CRE', '-NEX', '-ODA', '-MET']
def strip_suffix(a):
    for suf in suffixes:
        if a.endswith(suf): return a[:-len(suf)]
    return a
alias = {'ST2':'IL1RL1','IL-1RT2':'IL1R2','IL-1RT1':'IL1R1','MCP-3':'CCL7','MCP-1':'CCL2','MCP-2':'CCL8','MCP-4':'CCL13','EN-RAGE':'S100A12','OPG':'TNFRSF11B','CTSL1':'CTSL',
 'TF':'F3','vWF':'VWF','IL-4RA':'IL4R','IL-18R1':'IL18R1','U-PAR':'PLAUR','uPA':'PLAU','PAI':'SERPINE1','t-PA':'PLAT','TM':'THBD','IL8':'CXCL8','CASP-8':'CASP8','CASP-3':'CASP3',
 'HO-1':'HMOX1','HSP 27':'HSPB1','Gal-9':'LGALS9','Gal-3':'LGALS3','Gal-4':'LGALS4','Gal-1':'LGALS1','gal-8':'LGALS8','LOX-1':'OLR1','PAR-1':'F2R','PARP-1':'PARP1','PD-L2':'PDCD1LG2','PD-L1':'CD274',
 'PDGF subunit B':'PDGFB','PDGF subunit A':'PDGFA','PIgR':'PIGR','PSGL-1':'SELPLG','RAGE':'AGER','SCF':'KITLG','TIE2':'TEK','TRAIL-R2':'TNFRSF10B','TRAIL':'TNFSF10','TRANCE':'TNFSF11','TWEAK':'TNFSF12',
 'hOSCAR':'OSCAR','IgG Fc receptor II-b':'FCGR2B','KIM1':'HAVCR1','GT':'GGT1','GIF':'CBLIF','FS':'FST','Dkk-1':'DKK1','Dkk-4':'DKK4','CD40-L':'CD40LG','BMP-6':'BMP6','BMP-4':'BMP4','ADAM-TS13':'ADAMTS13','ADAM-TS 15':'ADAMTS15',
 'IL-1ra':'IL1RN','IL-27':'IL27','IL-17D':'IL17D','IL-17A':'IL17A','IL-17C':'IL17C','IL-17RA':'IL17RA','IL-18BP':'IL18BP','IL-6RA':'IL6R','IL2-RA':'IL2RA','IL-10RA':'IL10RA','IL-10RB':'IL10RB','IL-12B':'IL12B','IL-15RA':'IL15RA','IL-20RA':'IL20RA','IL-5R-alpha':'IL5RA',
 'GDF-2':'GDF2','GDF-15':'GDF15','GDF-8':'MSTN','GH':'GH1','FGF-21':'FGF21','FGF-19':'FGF19','FGF-5':'FGF5','FGF-BP1':'FGFBP1','AP-N':'ANPEP','BLM hydrolase':'BLMH','DLK-1':'DLK1','Ep-CAM':'EPCAM','ICAM-2':'ICAM2','ICAM 5':'ICAM5',
 'IGFBP-1':'IGFBP1','IGFBP-2':'IGFBP2','IGFBP-7':'IGFBP7','JAM-A':'F11R','JAM-B':'JAM2','LDL receptor':'LDLR','MMP-2':'MMP2','MMP-3':'MMP3','MMP-9':'MMP9','MMP-1':'MMP1','MMP-10':'MMP10','NT-proBNP':'NPPB','Notch 3':'NOTCH3','OPN':'SPP1',
 'PECAM-1':'PECAM1','PLC':'HSPG2','PSP-D':'SFTPD','SHPS-1':'SIRPA','TLT-2':'TREML2','TNF-R1':'TNFRSF1A','TNF-R2':'TNFRSF1B','TR':'TFRC','TR-AP':'ACP5','CSF-1':'CSF1','Flt3L':'FLT3LG','IFN-gamma':'IFNG','IFN-gamma-R1':'IFNGR1','LAP TGF-beta-1':'TGFB1',
 'LIF-R':'LIFR','NT-3':'NTF3','ST1A1':'SULT1A1','TGF-alpha':'TGFA','TNFB':'LTA','4E-BP1':'EIF4EBP1','Alpha-2-MRAP':'LRPAP1','ADAM 22':'ADAM22','ADAM 23':'ADAM23','ADAM 8':'ADAM8','CLM-1':'CD300LF','CLM-6':'CD300C','FcRL2':'FCRL2',
 'G-CSF':'CSF3','GCP5':'FOLH1B','GDNFR-alpha-3':'GFRA3','GFR-alpha-1':'GFRA1','GM-CSF-R-alpha':'CSF2RA','IL12':'IL12A','LAIR-2':'LAIR2','N-CDase':'ASAH2','N2DL-2':'ULBP2','NEP':'MME','Nr-CAM':'NRCAM','PDGF-R-alpha':'PDGFRA','SKR3':'ACVRL1',
 'Siglec-9':'SIGLEC9','THY 1':'THY1','TN-R':'TNR','sFRP-3':'FRZB',"5'-NT":'NT5E','CAIX':'CA9','CXL17':'CXCL17','CYR61':'CCN1','ESM-1':'ESM1','FR-alpha':'FOLR1','FR-gamma':'FOLR3','MAD homolog 5':'SMAD5','MIC-A/B':'MICA','MK':'MDK','MUC-16':'MUC16',
 'MetAP 2':'METAP2','PVRL4':'NECTIN4','SYND1':'SDC1','TFPI-2':'TFPI2','TGFR-2':'TGFBR2','VEGFR-2':'KDR','VEGFR-3':'FLT4','WISP-1':'CCN4','WIF-1':'WIF1','hK11':'KLK11','hK14':'KLK14','hK8':'KLK8','COL4A3BP':'CERT1','KIF1BP':'KIFBP',
 'FAM19A5':'TAFA5','NOV':'CCN3','MESDC2':'MESD','FUT3/FUT5':'FUT3','CD97':'ADGRE5','NEMO':'IKBKG','HAOX1':'HAO1','HB-EGF':'HBEGF'}
s["base"] = s.assay.map(strip_suffix); s["gene"] = s.base.map(lambda b: alias.get(b, b))
s["lnOR"] = np.log(s.OR); s["se"] = (np.log(s.u95) - np.log(s.l95)) / (2 * 1.959964); s["z"] = s.lnOR / s.se
s["FDR05"] = s["adj.p.value"] < 0.05

# ---------------------------------------------------------------- B. integrity checks
dup = s[s.gene.duplicated(keep=False)].sort_values(["gene", "rank"])
ndup_g = dup.gene.nunique()
conc = dup.groupby("gene").apply(lambda g: (np.sign(g.lnOR).nunique() == 1) or (g["p.value"].min() > 0.05)).mean()
log.append(("serum_proteomics.xlsx", "same protein on several panels",
            f"{len(s)} assay rows = {s.gene.nunique()} unique proteins; {ndup_g} proteins measured on 2-4 panels ({len(dup)} rows), e.g. IL6 x4, HGF x2, OPG x2. Direction concordant in {100*conc:.0f}% of them",
            "Useful internal replication (IL-6: OR 2.07-2.31 on four panels). Counts of 'significant assays' over-count proteins; gene-level (de-duplicated) numbers are reported alongside."))
N_bh = s["adj.p.value"].iloc[0] / s["p.value"].iloc[0]
log.append(("serum_proteomics.xlsx", "multiple-testing denominator",
            f"Delivered adjusted p-values are Benjamini-Hochberg over {N_bh:.0f} assays, but only {len(s)} rows were delivered: {N_bh-len(s):.0f} modelled assays are missing from the file (annex says adjustment was 'across all assays in the delivery')",
            "Delivered adj.p kept as is (conservative). The undelivered rows should be requested."))
# where do the undelivered assays sit? rows whose implied full-list rank is an integer are anchors
rf = s["p.value"].values * N_bh / s["adj.p.value"].values
anchor = np.abs(rf - np.round(rf)) < 1e-6
A = pd.DataFrame({"assay": s.assay.values, "p": s["p.value"].values, "adj": s["adj.p.value"].values, "deliv_rank": s["rank"].values, "full_rank": np.round(rf)})[anchor]
A["n_withheld_above"] = (A.full_rank - A.deliv_rank).astype(int)
n_w_fdr = int(A[A.adj < 0.05].n_withheld_above.max()); n_w_p05 = int(A[A.p < 0.05].n_withheld_above.max())
first = A[A.n_withheld_above >= 1].iloc[0]; prev = A[A.deliv_rank < first.deliv_rank].iloc[-1]
log.append(("serum_proteomics.xlsx", "undelivered assays include significant ones",
            f"From the rank arithmetic: {n_w_fdr} undelivered assays had FDR<0.05 and {n_w_p05} had nominal p<0.05; the strongest has p between {prev.p:.5f} and {first.p:.5f} (would rank about {int(first.full_rank)-1} of {N_bh:.0f})",
            "Identity unknown from the file."))
infl_full = ['ADA','ARTN','AXIN1','Beta-NGF','CASP-8','CCL11','CCL19','CCL20','CCL23','CCL25','CCL28','CCL3','CCL4','CD244','CD40','CD5','CD6','CD8A','CDCP1','CSF-1','CST5','CX3CL1','CXCL1','CXCL10','CXCL11','CXCL5','CXCL6','CXCL9','DNER','EN-RAGE','FGF-19','FGF-21','FGF-23','FGF-5','Flt3L','GDNF','HGF','IFN-gamma','IL-1 alpha','IL-10RA','IL-10RB','IL-12B','IL-13','IL-15RA','IL-17A','IL-17C','IL-18R1','IL-2','IL-20','IL-20RA','IL-22 RA1','IL-24','IL-2RB','IL-33','IL-4','IL-5','IL6','IL7','IL8','IL10','IL18','LAP TGF-beta-1','LIF','LIF-R','MCP-1','MCP-2','MCP-3','MCP-4','MMP-1','MMP-10','NRTN','NT-3','OPG','OSM','PD-L1','SCF','SIRT2','SLAMF1','ST1A1','STAMBP','TGF-alpha','TNF','TNFB','TNFRSF9','TNFSF14','TRAIL','TRANCE','TSLP','TWEAK','uPA','VEGFA','4E-BP1']
have = set(s[s.panel_short == "Inflammation"].base)
missing_infl = [a for a in infl_full if a not in have]
log.append(("serum_proteomics.xlsx", "IL-33 itself is absent",
            f"The Inflammation panel (v.3022) carries 92 assays incl. IL-33; {len(have)} were delivered. Not delivered: {', '.join(missing_infl)}",
            "No measurement of the drug target in patients is available. Every delivered assay has <10% missing values in both outcome groups, so these were presumably removed for low detectability. The only IL-33-axis analyte is the soluble decoy receptor ST2 (sST2; Cardiovascular III panel). The classic IL-33 effector cytokines IL-4, IL-5 (this panel) and IL-13 are also absent."))
m0 = s.composite_endpoint_0 * 56; m1 = s.composite_endpoint_1 * 44
okint = bool(np.abs(m0 - m0.round()).max() < 1e-9 and np.abs(m1 - m1.round()).max() < 1e-9)
log.append(("serum_proteomics.xlsx", "columns composite_endpoint_0 / _1", f"Not defined in the annex. All values are exact multiples of 1/56 and 1/44 (check={okint}); max {s.composite_endpoint_0.max():.3f} / {s.composite_endpoint_1.max():.3f}",
            "Read as per-group fraction of samples missing/below detection => 56 patients without and 44 with the composite endpoint."))
log.append(("serum_proteomics.xlsx", "effect-size scale", f"ORs are 'per log unit' of each assay, not per SD; e.g. CSF-1 OR {s.set_index('assay').OR['CSF-1']:.0f} (95% CI {s.set_index('assay').l95['CSF-1']:.1f}-{s.set_index('assay').u95['CSF-1']:.0f})",
            "OR magnitudes are not comparable between assays; ranking uses p / z."))
log.append(("serum_proteomics.xlsx", "one-sided result", f"{int(s.FDR05.sum())} assays FDR<0.05, of which {int((s.FDR05 & (s.OR > 1)).sum())} have OR>1; {100*(s['p.value']<0.05).mean():.0f}% of all assays have p<0.05",
            "A global 'sicker = higher' signal. A single protein's association (incl. sST2) is a severity marker, not evidence of mechanism. No adjustment for renal function, comorbidity, treatment or days since symptom onset."))
pd.DataFrame(log, columns=["file", "item", "finding", "consequence / how handled"]).to_csv(f"{TAB}/T9_data_integrity_log_part2.csv", index=False)
for l in log: print("-", l[1], "::", l[2])

# ---------------------------------------------------------------- C. biology classes (curated a priori; gene level)
classes = {
 'IL-33/ST2 axis & IL-1-family receptors': ['IL1RL1','IL1RL2','IL1R1','IL1R2','IL18R1','IL18','IL18BP','IL1B','IL1RN','AGER','EGFR','IRAK1','IRAK4'],
 'Type-2 / eosinophil / mast cell / basophil': ['IL5','IL5RA','CCL17','CCL11','CCL24','CCL13','CCL18','TPSAB1','RNASE3','IL4R','IL13RA1','IL17RB','HPGDS','FCER2','CLEC10A','SIGLEC6','HNMT','MILR1','KIT','KITLG','CD69'],
 'Neutrophil / myeloid activation': ['PRTN3','MPO','AZU1','CD177','LCN2','DEFA1','S100A12','PGLYRP1','RETN','CEACAM8','OSM','HGF','TREM1','FCAR','CLEC5A','MMP9','ARG1','FCGR3B','CXCL8','CXCL1','CXCL5','CXCL6','CSF3','PI3','CHI3L1','NCF2','SIGLEC9','LILRB4','CLEC4D'],
 'IL-6 / acute-phase / TNF axis': ['IL6','IL6R','OSMR','LIFR','SAA4','PTX3','TNFRSF11B','CSF1','CCL7','CCL20','CCL2','TNF','TNFRSF1A','TNFRSF1B','IL10','IFNG','CXCL10','CXCL9','CXCL11','IL15','CD274'],
 'Endothelial activation / injury / coagulation': ['SELE','SELP','VCAM1','ICAM1','ICAM2','PECAM1','CDH5','VWF','ANGPT2','ANGPT1','TEK','TIE1','ESM1','THBD','F3','TFPI','TFPI2','SERPINE1','PLAT','PLAU','PLAUR','FLT1','KDR','FLT4','VEGFA','CD93','ENG','SDC1','ESAM','EGFL7','NOS3','ADM','PROC','PGF','F2R','GP1BA','GP6','SELPLG','CD40LG','ADAMTS13','CLEC14A','ROBO1'],
 'Lung epithelial injury': ['AGER','SFTPD','SFTPA1','KRT19','SCGB3A2','WFDC2','MUC16','TFF3','TFF2','AREG','TGFA','CDH1','TACSTD2','MSLN','AGR2'],
 'Kidney injury / function': ['HAVCR1','CST3','IGFBP7','TFF3','REN','LCN2','TNFRSF1A','TNFRSF1B','AMBP','DPEP1','KIRREL2','PODXL','SPP1','EGF','MME','CD2AP'],
 'Cardiac stress / injury': ['NPPB','TNNI3','MB','FABP4','GDF15','IL1RL1','ADM','LGALS3','PAPPA'],
}
sg = s.sort_values("p.value").drop_duplicates("gene")          # best assay per protein
rows = []
for cl, genes in classes.items():
    x = sg[sg.gene.isin(genes)]
    rows.append({"class": cl, "proteins_measured": len(x), "FDR<0.05": int(x.FDR05.sum()), "pct_FDR<0.05": round(100 * x.FDR05.mean(), 0), "nominal_p<0.05": int((x["p.value"] < 0.05).sum()),
                 "median_OR": round(x.OR.median(), 2), "FDR-significant proteins": ", ".join(x[x.FDR05].assay)})
rows.append({"class": "ALL PROTEINS (background)", "proteins_measured": len(sg), "FDR<0.05": int(sg.FDR05.sum()), "pct_FDR<0.05": round(100 * sg.FDR05.mean(), 0),
             "nominal_p<0.05": int((sg["p.value"] < 0.05).sum()), "median_OR": round(sg.OR.median(), 2), "FDR-significant proteins": ""})
T5 = pd.DataFrame(rows); T5.to_csv(f"{TAB}/T5_serum_biology_class_summary.csv", index=False); print(T5.drop(columns="FDR-significant proteins").to_string())
for cl, genes in classes.items(): s["class: " + cl] = s.gene.isin(genes)

# ---------------------------------------------------------------- D. link to the in vitro IL-33 / AX-1177 signature
D = pd.read_pickle(f"{CACHE}/rnaseq_gene_table.pkl"); Dg = D.drop_duplicates("symbol").set_index("symbol")
link = ["IL33_6h", "pct_rev_6h", "pct_revIso_6h", "IL33_24h", "pct_revIso_24h", "G_revIso_6h", "G_revIso_24h", "PD_tier", "kinetic_class", "q_IL33_6h", "SE_ratio", "AveExpr"]
for c in link: s["rna_" + c] = s.gene.map(Dg[c])
s["in_rnaseq"] = s.gene.isin(Dg.index)
broad = ((Dg.IL33_6h >= 1) & (Dg.rev_6h <= -0.5 * Dg.IL33_6h) & (Dg.revIso_6h <= -0.5 * Dg.IL33_6h)) | ((Dg.IL33_24h >= 1) & (Dg.rev_24h <= -0.5 * Dg.IL33_24h) & (Dg.revIso_24h <= -0.5 * Dg.IL33_24h))
strict6 = (Dg.IL33_6h >= 2) & (Dg.pct_rev_6h >= 80) & (Dg.pct_revIso_6h >= 80)
core = Dg.PD_tier != ""
s["IL33_signature_broad"] = s.gene.map(broad).fillna(False).astype(bool); s["IL33_signature_strict_6h"] = s.gene.map(strict6).fillna(False).astype(bool); s["IL33_core_both_beds"] = s.gene.map(core).fillna(False).astype(bool)
sg = s[s.in_rnaseq].sort_values("p.value").drop_duplicates("gene")
print(f"\n[D] proteins mapped to an RNA-seq gene: {len(sg)}; FDR<0.05: {int(sg.FDR05.sum())} ({100*sg.FDR05.mean():.1f}%)")
rows = []
for nm, col in [("IL-33-induced >=2x and >=50% reversed by AX-1177 (6 h or 24 h)", "IL33_signature_broad"), ("IL-33-induced >=4x and >=80% reversed at 6 h", "IL33_signature_strict_6h"), ("...and also reversed in glomerular endothelium (core)", "IL33_core_both_beds")]:
    f = sg[col]; a = int((f & sg.FDR05).sum()); b = int((f & ~sg.FDR05).sum()); c = int((~f & sg.FDR05).sum()); d = int((~f & ~sg.FDR05).sum())
    OR, p = stats.fisher_exact([[a, b], [c, d]]); mw = stats.mannwhitneyu(sg.z[f], sg.z[~f])
    rows.append({"IL-33 signature definition": nm, "proteins_in_set": int(f.sum()), "prognostic_in_set": a, "pct_in_set": round(100 * a / f.sum(), 1), "pct_outside_set": round(100 * c / (c + d), 1),
                 "Fisher_OR": round(OR, 2), "Fisher_p": round(p, 3), "rank_test_p (all z-scores)": round(mw.pvalue, 3)})
TDx = pd.DataFrame(rows); print(TDx.to_string()); TDx.to_csv(f"{TAB}/T5b_IL33_signature_enrichment_among_prognostic_proteins.csv", index=False)
for N in [20, 50]:
    top = sg.head(N); k = int(top.IL33_signature_strict_6h.sum()); K = int(sg.IL33_signature_strict_6h.sum())
    print(f"   top {N} proteins: {k} in strict 6-h signature (expected {N*K/len(sg):.1f}); hypergeometric p={stats.hypergeom.sf(k-1, len(sg), K, N):.3f}: {top[top.IL33_signature_strict_6h].assay.tolist()}")
s.to_pickle(f"{CACHE}/serum_annotated.pkl")
out = s.drop(columns=["base", "lnOR", "se"]).rename(columns={"z": "wald_z"})
out.round(5).to_csv(f"{TAB}/T4_serum_all_assays_annotated.csv", index=False)
sel = s[s.IL33_core_both_beds].sort_values("rank")[["rank", "panel_short", "assay", "gene", "OR", "l95", "u95", "p.value", "adj.p.value", "rna_IL33_6h", "rna_pct_revIso_6h", "rna_IL33_24h", "rna_pct_revIso_24h", "rna_G_revIso_6h", "rna_PD_tier", "rna_kinetic_class"]]
sel.round(4).to_csv(f"{TAB}/T3b_core_signature_proteins_measured_in_serum.csv", index=False); print(sel.round(3).to_string())
print("\nKey rows:"); print(s[s.gene.isin(["IL1RL1", "HGF", "IL6", "PTX3", "TNFRSF11B", "IL18R1", "CCL20", "CCL7", "CXCL8", "SELE", "VCAM1", "ICAM1", "F3", "CSF3", "IL5", "CCL17", "CCL11", "TPSAB1", "IL5RA", "AGER"])][["rank", "panel_short", "assay", "OR", "l95", "u95", "p.value", "adj.p.value"]].round(4).to_string())
