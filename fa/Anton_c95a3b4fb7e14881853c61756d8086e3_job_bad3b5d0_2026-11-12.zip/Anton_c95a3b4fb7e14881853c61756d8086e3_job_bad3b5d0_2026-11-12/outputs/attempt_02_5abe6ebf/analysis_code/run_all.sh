#!/usr/bin/env bash
# Re-runs the whole analysis from the four delivered files (about 5 min; the first run reads the 123 MB contrasts workbook).
# Scripts 01-06 use the "singlecell" environment; 07 (PDF) uses "chem". Intermediate caches go to /tmp/work/cache.
set -euo pipefail
cd "$(dirname "$0")"
for s in 01_load_data.py 02_rnaseq.py 03_serum.py 04_lung.py 05_figures.py 06_tables_xlsx.py; do
  echo "=== $s"; micromamba run -n singlecell python "$s" > "/tmp/work/${s%.py}.log" 2>&1 || { echo "FAILED: $s"; tail -5 "/tmp/work/${s%.py}.log"; exit 1; }
done
echo "=== 07_build_pdf.py"; micromamba run -n chem python 07_build_pdf.py > /tmp/work/07_build_pdf.log 2>&1 || { echo "FAILED: 07_build_pdf.py"; exit 1; }
echo "all done"
