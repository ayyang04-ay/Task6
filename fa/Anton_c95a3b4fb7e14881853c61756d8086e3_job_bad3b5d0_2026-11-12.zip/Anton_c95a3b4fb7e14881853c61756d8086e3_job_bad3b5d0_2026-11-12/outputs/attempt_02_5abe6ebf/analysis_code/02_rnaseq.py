"""
02_rnaseq.py  -  AX-1177 portfolio audit: in vitro transcriptomics
Uses every delivered contrast (26), not only the one left visible by the spreadsheet filter.

Key design facts (methods annex):
  IL-33red 30 ng/mL (1.66 nM); AX-1177 (=Compound_47) or isotype IC119 10 ug/mL (68.5 nM); added together, no pre-incubation;
  HUVEC (P2, one donor) and HGMEC (glomerular, P5, one donor); A549/MCF7 received antibody only (no IL-33).
  One pooled limma-voom model across all 114 libraries; AveExpr is the mean over all 114 libraries.

Run:  micromamba run -n singlecell python 02_rnaseq.py
"""
import os, warnings
import numpy as np, pandas as pd
from scipy import stats, optimize
warnings.filterwarnings("ignore")
CACHE = "/tmp/work/cache"; TAB = "/tmp/outputs/tables"
allc = pd.read_pickle(f"{CACHE}/rnaseq_long.pkl")
order = list(dict.fromkeys(allc.c))
allc["SE"] = (allc.logFC / allc.t).abs()
L = allc.pivot(index="ensembl", columns="c", values="logFC")[order]
T = allc.pivot(index="ensembl", columns="c", values="t")[order]
Q = allc.pivot(index="ensembl", columns="c", values="adj.P.Val")[order]
P = allc.pivot(index="ensembl", columns="c", values="P.Value")[order]
S = allc.pivot(index="ensembl", columns="c", values="SE")[order]
ann = allc.drop_duplicates("ensembl").set_index("ensembl")[["symbol", "gene_name", "AveExpr"]]

# ---------------------------------------------------------------- A. contrast summary
rows = []
for c in order:
    sig = Q[c] < 0.05
    rows.append(dict(contrast=c, n_genes=len(L), FDR05=int(sig.sum()), up=int((sig & (L[c] > 0)).sum()), down=int((sig & (L[c] < 0)).sum()),
                     FDR05_and_2fold=int((sig & (L[c].abs() >= 1)).sum()), FDR05_but_lt_1p23fold=int((sig & (L[c].abs() < 0.3)).sum()),
                     FDR05_expressed_and_1p5fold=int((sig & (ann.AveExpr >= 2) & (L[c].abs() >= 0.585)).sum()),
                     max_abs_log2FC=round(L[c].abs().max(), 2)))
T1 = pd.DataFrame(rows); T1.to_csv(f"{TAB}/T1_rnaseq_contrast_summary.csv", index=False)
print(T1.to_string())

# ---------------------------------------------------------------- B. is the pooled model trustworthy gene-by-gene?
# total df per gene, recovered from (t, p): 85.13 = 76 residual + 9.13 prior for well-behaved genes; ~75 for genes flagged as variance outliers
allc["score"] = (allc.t.abs() - 3).abs()
sub = allc.loc[allc.groupby("ensembl").score.idxmin(), ["ensembl", "t", "P.Value"]]
def df_of(t, p):
    if abs(t) < 0.3 or not (0 < p < 1): return np.nan
    try: return optimize.brentq(lambda d: 2 * stats.t.sf(abs(t), d) - p, 0.5, 1e6)
    except Exception: return np.nan
ann["df_total"] = pd.Series([df_of(t, p) for t, p in zip(sub.t, sub["P.Value"])], index=sub.ensembl.values)
ann["medSE"] = S.median(axis=1)
normal = ann[(ann.df_total > 84)]
bins = np.arange(-5.5, 14, 0.5)
trend = normal.groupby(pd.cut(normal.AveExpr, bins)).agg(med=("medSE", "median"), n=("medSE", "size"))
trend = trend.med.where(trend.n >= 20).ffill()      # expected SE falls with expression; above the last well-populated bin carry the last value forward (conservative)
ann["expSE"] = [trend.get(iv, np.nan) for iv in pd.cut(ann.AveExpr, bins)]
ann["SE_ratio"] = ann.medSE / ann.expSE
print("\n[B] genes with reduced df (variance outliers):", int((ann.df_total < 84).sum()), "| no usable t in any contrast:", int(ann.df_total.isna().sum()),
      "| median SE >5x expected:", int((ann.SE_ratio > 5).sum()), "| >10x:", int((ann.SE_ratio > 10).sum()))
il6, il24 = L["IL33_HUVEC_6h"], L["IL33_HUVEC_24h"]
T8 = ann[(ann.SE_ratio > 5) & ((il6.abs() >= 1.5) | (il24.abs() >= 1.5))].copy()
for c in ["IL33_HUVEC_6h", "AbIL33_vs_IL33_HUVEC_6h", "AbIL33_vs_IsoIL33_HUVEC_6h", "AbIL33_vs_IsoIL33_HGMEC_6h", "IL33_HUVEC_24h", "AbIL33_vs_IsoIL33_HUVEC_24h"]:
    T8["log2FC " + c] = L[c]; T8["t " + c] = T[c]; T8["adjP " + c] = Q[c]
T8 = T8.sort_values("log2FC IL33_HUVEC_6h", ascending=False)
T8.round(3).to_csv(f"{TAB}/T8_large_effects_masked_by_inflated_SE.csv")
print(T8[["symbol", "AveExpr", "medSE", "expSE", "SE_ratio", "log2FC IL33_HUVEC_6h", "t IL33_HUVEC_6h", "adjP IL33_HUVEC_6h", "log2FC AbIL33_vs_IsoIL33_HUVEC_6h"]].round(2).to_string())

# ---------------------------------------------------------------- C. gene-level table with derived quantities (HUVEC)
D = pd.DataFrame({"symbol": ann.symbol, "AveExpr": ann.AveExpr, "SE_ratio": ann.SE_ratio, "df_total": ann.df_total})
for tp in ["6h", "24h"]:
    il = L[f"IL33_HUVEC_{tp}"]; r = L[f"AbIL33_vs_IL33_HUVEC_{tp}"]; ri = L[f"AbIL33_vs_IsoIL33_HUVEC_{tp}"]
    D[f"IL33_{tp}"] = il; D[f"q_IL33_{tp}"] = Q[f"IL33_HUVEC_{tp}"]
    D[f"rev_{tp}"] = r; D[f"revIso_{tp}"] = ri; D[f"q_revIso_{tp}"] = Q[f"AbIL33_vs_IsoIL33_HUVEC_{tp}"]
    D[f"resid_{tp}"] = il + r                      # (IL-33 + AX-1177) vs vehicle
    D[f"IL33iso_{tp}"] = il + r - ri               # (IL-33 + isotype) vs vehicle
    D[f"pct_rev_{tp}"] = 100 * (-r / il)           # % of the IL-33 log2FC removed, vs IL-33 alone (shares the IL-33 arm)
    D[f"pct_revIso_{tp}"] = 100 * (-ri / il)       # same, vs IL-33 + isotype (independent arms)  <- primary
    D[f"G_rev_{tp}"] = L[f"AbIL33_vs_IL33_HGMEC_{tp}"]; D[f"G_revIso_{tp}"] = L[f"AbIL33_vs_IsoIL33_HGMEC_{tp}"]; D[f"q_G_revIso_{tp}"] = Q[f"AbIL33_vs_IsoIL33_HGMEC_{tp}"]
ab_endo = ["Ab_vs_Iso_HUVEC_6h", "Ab_vs_Iso_HUVEC_24h", "Ab_vs_Iso_HGMEC_6h", "Ab_vs_Iso_HGMEC_24h"]
D["maxabs_Ab_alone_endo"] = L[ab_endo].abs().max(axis=1)

# ---------------------------------------------------------------- D. how completely does AX-1177 neutralise IL-33 in HUVEC?
print("\n[D] Neutralisation in HUVEC (isotype-controlled contrast; residual = IL-33+AX-1177 vs vehicle)")
rows = []
for tp in ["6h", "24h"]:
    il = D[f"IL33_{tp}"]; q = D[f"q_IL33_{tp}"]
    sets = {"induced >=4x, FDR<0.01, expressed (AveExpr>0)": (il >= 2) & (q < 0.01) & (D.AveExpr > 0),
            "induced >=2x, FDR<0.01, well expressed (AveExpr>2)": (il >= 1) & (q < 0.01) & (D.AveExpr > 2),
            "repressed >=2x, FDR<0.01, well expressed (AveExpr>2)": (il <= -1) & (q < 0.01) & (D.AveExpr > 2),
            "induced >=4x, FDR<0.01, any expression": (il >= 2) & (q < 0.01)}
    for nm, m in sets.items():
        pr = 100 * (-D.loc[m, f"revIso_{tp}"] / D.loc[m, f"IL33iso_{tp}"])     # % inhibition relative to the isotype arm
        rr = 100 * D.loc[m, f"resid_{tp}"] / il[m]
        rows.append(dict(timepoint=tp, gene_set=nm, n=int(m.sum()), median_IL33_log2FC=il[m].median(), median_residual_log2FC=D.loc[m, f"resid_{tp}"].median(),
                         pct_residual_median=rr.median(), pct_inhibition_vs_isotype_median=pr.median(), pct_inhibition_IQR_low=pr.quantile(.25), pct_inhibition_IQR_high=pr.quantile(.75)))
TD = pd.DataFrame(rows); print(TD.round(2).to_string()); TD.round(3).to_csv(f"{TAB}/T2b_neutralisation_summary_HUVEC.csv", index=False)
for tp in ["6h", "24h"]:
    m = (D[f"IL33_{tp}"].abs() >= 1) & (D[f"q_IL33_{tp}"] < 0.01) & (D.AveExpr > 0)
    r = stats.pearsonr(D.loc[m, f"IL33_{tp}"], D.loc[m, f"revIso_{tp}"]); sl = np.polyfit(D.loc[m, f"IL33_{tp}"], D.loc[m, f"revIso_{tp}"], 1)
    print(f"   HUVEC {tp}: IL-33 effect vs AX-1177 reversal (isotype-controlled), {int(m.sum())} expressed genes changed >=2x: r={r[0]:.3f}, slope={sl[0]:.2f}")

# ---------------------------------------------------------------- E. antibody alone (16 contrasts, 4 cell types)
print("\n[E] Antibody alone")
abc = [c for c in order if c.startswith("Ab_vs")]
core_up = (D.IL33_6h >= 2) & (D.q_IL33_6h < 0.01) & (D.AveExpr > 0)
rows = []; sigsets = {}
for c in abc:
    sig = Q[c] < 0.05; sigsets[c] = set(Q.index[sig])
    rows.append(dict(contrast=c, FDR05=int(sig.sum()), of_which_near_zero_counts_AveExpr_lt0=int((sig & (ann.AveExpr < 0)).sum()),
                     of_which_expressed_but_lt_1p5fold=int((sig & (ann.AveExpr >= 2) & (L[c].abs() < 0.585)).sum()),
                     expressed_and_ge_1p5fold=int((sig & (ann.AveExpr >= 2) & (L[c].abs() >= 0.585)).sum()),
                     median_log2FC_of_IL33_induced_genes=round(L.loc[core_up, c].median(), 3)))
TE = pd.DataFrame(rows); print(TE.to_string())
indep = lambda a, b: (a.split("_")[3], a.split("_")[4]) != (b.split("_")[3], b.split("_")[4])   # different cell line or timepoint => no shared libraries
rep = {g for i, a in enumerate(abc) for b in abc[i + 1:] if indep(a, b) for g in sigsets[a] & sigsets[b]}
rep_expr = [g for g in rep if ann.AveExpr[g] >= 2]
print("   genes FDR<0.05 in >=2 antibody-alone contrasts that share no libraries:", len(rep), "| of these expressed (AveExpr>=2):", len(rep_expr),
      [(ann.symbol[g], [f"{c}:{L.loc[g, c]:+.2f}" for c in abc if g in sigsets[c]]) for g in rep_expr])
TE.to_csv(f"{TAB}/T10_antibody_alone_summary.csv", index=False)
hits = []
for c in abc:
    x = pd.DataFrame({"contrast": c, "symbol": ann.symbol, "log2FC": L[c], "t": T[c], "adjP": Q[c], "AveExpr": ann.AveExpr, "SE_ratio_vs_expected": S[c] / ann.expSE})[Q[c] < 0.05]
    x["flag"] = np.where(x.AveExpr < 0, "near-zero counts", np.where(x.log2FC.abs() < 0.585, "<1.5-fold (tiny SE artefact)", "expressed & >=1.5-fold"))
    hits.append(x)
pd.concat(hits).round(4).to_csv(f"{TAB}/T10b_antibody_alone_all_FDR_hits.csv")

# ---------------------------------------------------------------- F. HGMEC vs HUVEC, 6 h vs 24 h
print("\n[F] Reversal of the HUVEC 6-h IL-33 core signature (induced >=4x, FDR<0.01) across beds/timepoints (isotype-controlled contrasts)")
core273 = (D.IL33_6h >= 2) & (D.q_IL33_6h < 0.01)
rows = []
for nm, col, qcol in [("HUVEC 6 h", "revIso_6h", "q_revIso_6h"), ("HUVEC 24 h", "revIso_24h", "q_revIso_24h"), ("HGMEC 6 h", "G_revIso_6h", "q_G_revIso_6h"), ("HGMEC 24 h", "G_revIso_24h", "q_G_revIso_24h")]:
    x = D.loc[core273, col]
    rows.append(dict(condition=nm, n_core_genes=int(core273.sum()), median_reversal_log2FC=x.median(), pct_genes_reversed_ge2fold=100 * (x <= -1).mean(),
                     pct_genes_reversed_ge2fold_and_FDR05=100 * ((x <= -1) & (D.loc[core273, qcol] < 0.05)).mean(), genome_wide_FDR05=int((D[qcol] < 0.05).sum())))
TF = pd.DataFrame(rows); print(TF.round(2).to_string()); TF.round(3).to_csv(f"{TAB}/T2c_reversal_by_bed_and_time.csv", index=False)
r = stats.pearsonr(D.loc[core273, "revIso_6h"], D.loc[core273, "G_revIso_6h"]); sl = np.polyfit(D.loc[core273, "revIso_6h"], D.loc[core273, "G_revIso_6h"], 1)
print(f"   HGMEC 6h vs HUVEC 6h reversal on core: r={r[0]:.2f}, slope={sl[0]:.2f}")
e6 = (D.IL33_6h >= 2) & (D.pct_revIso_6h >= 70) & (D.pct_rev_6h >= 70); e24 = (D.IL33_24h >= 2) & (D.pct_revIso_24h >= 70) & (D.pct_rev_24h >= 70)
print(f"   HUVEC genes induced >=4x AND >=70% reversed in both contrasts: 6h={int(e6.sum())}, 24h={int(e24.sum())}, both={int((e6 & e24).sum())}; median(24h/6h log2FC) among 6h set={ (D.IL33_24h[e6] / D.IL33_6h[e6]).median():.2f}")

# Is the weak HGMEC 24-h reversal a fading IL-33 response or a fading antibody? Genes still IL-33-driven at 24 h in HUVEC ("sustained")
# are still lowered by AX-1177 in HGMEC at 24 h; transient ones are not => the response has faded, the antibody has not.
kin = np.where(D.IL33_24h < 0.35 * D.IL33_6h, "early/transient", np.where(D.IL33_24h >= 0.7 * D.IL33_6h, "sustained", "intermediate"))
for k in ["early/transient", "intermediate", "sustained"]:
    m = e6 & (kin == k)
    print(f"   {k:16s} n={int(m.sum()):3d}: HGMEC 24h reversal median log2FC {D.G_revIso_24h[m].median():+.2f}; >=2-fold lower in {100*(D.G_revIso_24h[m] <= -1).mean():.0f}%")
print("   sustained vs transient, Mann-Whitney p =", f"{stats.mannwhitneyu(D.G_revIso_24h[e6 & (kin == 'sustained')], D.G_revIso_24h[e6 & (kin == 'early/transient')]).pvalue:.1e}",
      "| Spearman(HUVEC 24h IL-33 effect, HGMEC 24h reversal) =", round(stats.spearmanr(D.IL33_24h[e6], D.G_revIso_24h[e6])[0], 2))

# ---------------------------------------------------------------- G. candidate pharmacodynamic (PD) signature
a_ = D.IL33_6h >= 2                                              # induced >=4-fold at 6 h
b_ = (D.pct_rev_6h >= 80) & (D.pct_revIso_6h >= 80)              # >=80% reversed vs IL-33 alone AND vs IL-33+isotype
c_ = (D.G_rev_6h <= -1) & (D.G_revIso_6h <= -1)                  # reversed >=2-fold in HGMEC in both contrasts (second vascular bed)
d_ = (D.IL33_24h >= 1) & (D.rev_24h <= -0.5 * D.IL33_24h) & (D.revIso_24h <= -0.5 * D.IL33_24h)   # still induced and reversed at 24 h
e_ = D.maxabs_Ab_alone_endo < 1                                  # antibody alone does nothing (<2-fold) in either endothelial line at either time
core = a_ & b_ & c_
D["PD_tier"] = np.where(core & d_ & e_, "A: 6h+24h, both beds, antibody-inert", np.where(core & e_, "B: 6h, both beds, antibody-inert", np.where(core, "C: 6h, both beds", "")))
D["kinetic_class"] = np.where((D.IL33_6h >= 2) & (D.IL33_24h < 0.35 * D.IL33_6h), "early/transient",
                       np.where((D.IL33_6h >= 2) & (D.IL33_24h >= 0.7 * D.IL33_6h), "sustained", np.where(D.IL33_6h >= 2, "intermediate", "")))
print(f"\n[G] induced >=4x at 6h: {int(a_.sum())}; and >=80% reversed (both contrasts): {int((a_ & b_).sum())}; and reversed in HGMEC: {int(core.sum())}; tier A: {int((core & d_ & e_).sum())}")
D.to_pickle(f"{CACHE}/rnaseq_gene_table.pkl")
pd.to_pickle(dict(L=L, T=T, Q=Q, P=P, S=S, ann=ann), f"{CACHE}/rnaseq_wide.pkl")
cols = ["symbol", "PD_tier", "kinetic_class", "IL33_6h", "pct_rev_6h", "pct_revIso_6h", "resid_6h", "IL33_24h", "pct_revIso_24h", "G_revIso_6h", "G_revIso_24h", "maxabs_Ab_alone_endo", "AveExpr", "q_IL33_6h", "q_revIso_6h", "SE_ratio"]
D.loc[core, cols].sort_values("IL33_6h", ascending=False).round(3).to_csv(f"{TAB}/T2_IL33_core_signature_137_genes.csv")
print(D.loc[core, cols].sort_values("IL33_6h", ascending=False).head(25).round(2).to_string())
