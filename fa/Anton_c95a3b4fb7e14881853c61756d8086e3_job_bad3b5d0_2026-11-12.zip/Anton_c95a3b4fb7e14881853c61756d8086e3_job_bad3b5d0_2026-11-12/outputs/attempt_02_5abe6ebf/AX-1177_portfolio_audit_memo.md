# AX-1177 (anti-IL-33 antibody): portfolio audit position

Prepared from the four delivered data files and the methods annex only. Every number was recomputed from those files, including content that is hidden in the spreadsheets as delivered (section 9). Scripts, tables and figures are in this folder.

Abbreviations used throughout: **sST2** = soluble ST2, the circulating decoy receptor for IL-33; **HUVEC** = umbilical-vein endothelial cells; **HGMEC** = kidney glomerular endothelial cells; **FDR** = false-discovery rate (multiple-testing-adjusted p-value); **PD** = pharmacodynamic (a marker that shows the drug is having its biological effect); **type-2** = the allergic-type immune response (eosinophils, mast cells, IL-5, IL-13) through which IL-33 is usually thought to act.

## 1. Recommendation

**Keep AX-1177, but not as a "severe viral lower respiratory infection" asset.** The data support the molecule; they do not support that label.

I recommend the committee:

1. retires "viral" as the organising idea for this asset;
2. re-scopes it to **severe pneumonia with a neutrophil-driven inflammatory response, selected by high sST2, whatever the pathogen**; and
3. holds spending to a two-stage de-risking package (section 6) with kill criteria agreed now.

How sure I am: **high** confidence that the antibody does its job in cells; **moderate-to-high** confidence that "viral" is the wrong frame; **low** confidence, because it has not been tested, that IL-33 actually drives disease in these patients. The third point is why this is a gated keep and not an advance.

If the committee's rule is that an asset must already hold evidence for its stated indication, AX-1177 does not pass today. Section 8 says what would be dropped and why.

## 2. The case for keeping it

**1. The antibody works, completely and cleanly (Figure 1).**

- IL-33 switches on a large inflammatory programme in human endothelial cells: 4,031 genes change at 6 h (1,068 by at least 2-fold), including E-selectin (2,367-fold), VCAM-1 (427-fold), G-CSF (319-fold), IL-8 (291-fold) and IL-6 (56-fold).
- AX-1177 removes it. Across the 82 well-detected genes that IL-33 induces at least 4-fold, a median of 98.5% of the induction is gone (interquartile range 95–102%), measured against a matched control antibody that does not bind IL-33 (the isotype control). E-selectin falls from 2,367-fold to 1.2-fold; IL-6 from 56-fold to 0.9-fold.
- This was a demanding test: antibody and IL-33 were added together, with no pre-incubation.
- The same programme is reversed in kidney glomerular endothelium at 6 h, at about half the magnitude (1,460 genes; correlation with the HUVEC result r = 0.72).
- The antibody alone does nothing reproducible in any of four cell types (16 comparisons). Each comparison yields 14–73 nominally significant genes. Of these, 78% are transcripts at near-zero counts, 16% are abundant genes moving by a median of 9%, and the few others are isolated calls that are not significant at the other timepoint in the same cells. The IL-33-responsive genes do not move.

**2. The pathway is visible in patients (Figure 2).**

- In 100 hospitalised COVID-19 patients, sST2 at enrolment is the second-strongest of 1,094 assays for predicting intensive care, ventilation or death: odds ratio 3.0 per log unit (95% CI 1.8–5.0), FDR 0.007, after adjustment for age, sex and early-warning score.
- Seven proteins whose genes IL-33 induces in endothelium, and AX-1177 switches off, are also prognostic at FDR < 0.05: IL-6 (on all four panels that carry it, odds ratio 2.1–2.3), OPG, PTX3, IL-18R1, CCL20, MCP-3 and IL-8.

**3. All three datasets point at the same biology: neutrophil-driven inflammation.**

- *Cells:* the genes IL-33 induces most strongly in endothelium are the machinery for recruiting neutrophils (G-CSF, GM-CSF, IL-8, CXCL1, E-selectin, ICAM-1), and AX-1177 abolishes their induction.
- *Serum:* of the eight biology classes examined, neutrophil-activation proteins are the most over-represented among prognostic proteins: 12 of 29 (41%) against 15% for all other proteins (odds ratio 3.9, p = 0.0008).
- *Lung:* neutrophil elastase is the dominant marker of pneumonia tissue (score 3.6 against 2.5 in non-pneumonia, p = 0.004) and does not differ by COVID status (p = 0.94).

**4. The open questions can be answered largely with material already in hand, and they are the ones that decide the asset.** IL-33 itself has never been measured in our patients, and no lung cell has been challenged with it. The first gate uses banked sera and data already in the archive. Dropping now would be a decision on missing data, not on negative data.

## 3. Why the current indication does not hold

1. **Nothing in the data is virus-specific.** In post-mortem lung, COVID-positive and COVID-negative pneumonia cannot be told apart on any of the 11 markers scored (all p ≥ 0.15; 16 vs 10 donors, so only large differences were detectable). The serum cohort is COVID-19 only, with no other virus and no non-viral comparator. The cell experiments contain no virus.
2. **The target is not raised in infected lung (Figure 3).** IL-33 staining is strong in every group, including non-pneumonia controls. In COVID-positive lung it is unchanged in airway epithelium (4.41 vs 4.35, p = 0.87) and trends *lower* in blood vessels (endothelium 4.81 vs 5.19, p = 0.16).
3. **IL-33 itself is missing from the patient data.** The inflammation panel that was run carries an IL-33 assay; it is not in the delivered results (section 9). The only IL-33-axis measurement is sST2, the decoy.
4. **sST2 is a severity marker, not proof of mechanism.** 178 assays are significant and 176 of them point the same way, so the cohort shows a general "sicker is higher" pattern. Taken as a whole, the IL-33 endothelial signature is no more prognostic than any other set of proteins (17.3% vs 17.2%; odds ratio 1.01, p = 1.0).
5. **No lung cell was ever exposed to IL-33.** The one lung line (A549) received antibody only. The responsive cells came from umbilical vein and kidney, one donor each. Only the reduced form of IL-33 was used, so the antibody's stated binding to oxidised IL-33 is untested here.
6. **The usual rationale for this drug class finds little support.** In serum, type-2 markers (IL-5, eotaxins, CCL17, tryptase) are flat: 1 of 21 is prognostic, and as a group they are less associated with outcome than the average protein (p = 0.007). In lung, eosinophil granule proteins are higher in pneumonia than in non-pneumonia tissue (eosinophil-derived neurotoxin by 1.3 score points, p = 0.005), but at low levels (mean 1.6, against 3.6 for neutrophil elastase), equally in COVID-positive and COVID-negative pneumonia, and with no relation to IL-33 staining.

## 4. What indication the data point at

**Severe pneumonia with a neutrophil-driven (not type-2) inflammatory response, in patients selected by high sST2, irrespective of pathogen.** In practice this is the hyper-inflammatory end of severe pneumonia and early acute lung injury. It is a re-scoping of the current indication from pathogen-defined to host-response-defined, not a move to a different disease area. In trial terms: hospitalised adults with severe pneumonia, enriched for high sST2 at admission, with progression to intensive care, ventilation or death as the outcome. That is the population and endpoint in which our serum data were generated, without the COVID-only restriction. The "irrespective of pathogen" part rests on the absence of any virus-specific signal, not on positive evidence in non-viral patients; question 5 in section 6.1 tests it.

| Question | Cells (RNA-seq) | Patient serum | Lung tissue | Verdict |
|---|---|---|---|---|
| Does AX-1177 neutralise IL-33? | Yes: ~100% in HUVEC at 6 h; same genes reversed in HGMEC | Not tested | Not tested | Established in vitro |
| Is IL-33 raised or active in disease? | Not applicable | IL-33 not delivered; sST2 (decoy) ranks 2nd | Not raised; trends lower in vessels | **Unknown: the first gate** |
| Is the biology neutrophil-driven? | Top IL-33-induced genes are neutrophil-recruitment signals | Neutrophil proteins 41% prognostic vs 15% (p = 0.0008) | Neutrophil elastase higher in pneumonia (p = 0.004) | Yes, in all three |
| Is it type-2 (eosinophil, mast cell)? | Not testable: no immune cells were studied | 1 of 21 prognostic | Eosinophil proteins modestly raised in pneumonia but unrelated to IL-33 staining; mast cells unchanged | Little support |
| Is it virus-specific? | No virus in the system | COVID-19 only | COVID+ and COVID− pneumonia indistinguishable | No evidence |
| Is it kidney or general vascular? | Works in glomerular endothelium at 6 h, half the size, faded by 24 h | Kidney-injury and endothelial proteins at background (2/16, 3/42) | IL-33 staining is strongest in endothelium | Hypothesis only |

The re-scoped population contains the current one. What changes is the selection rule (host response, not pathogen) and the claim (neutrophil-driven inflammation, not antiviral or type-2 biology).

The link that is *not* yet shown is that IL-33 is what drives the neutrophil response in patients. The serum data are compatible with it and do not prove it. Proteins released *by* neutrophils are prognostic (8 of 17 granule and cell-surface proteins), but of the five neutrophil-recruiting signals that IL-33 induces in endothelium and that were measured in serum, only IL-8 is; G-CSF, CXCL1, CXCL5 and CXCL6 are not. Other cytokines, notably IL-1 and TNF, are also known to induce the same endothelial genes (established biology, not tested in our data).

**Secondary option, hypothesis only:** kidney microvascular inflammation. The only support is the 6-hour result in glomerular endothelium from one donor. There are no kidney patient data, and if this were pursued MCP-1 (CCL2) and VCAM-1 are the markers our data would back.

## 5. Challenges the committee may raise, and the answers

| Challenge | Answer from our data |
|---|---|
| "sST2 ranks 2nd. Doesn't that validate the target?" | It validates sST2 as a risk marker. sST2 is the decoy that binds IL-33, it is known to rise with many inflammatory stimuli (established biology, not from our data), and 16% of everything measured is also significant. Other soluble cytokine receptors rise with it (IL-18R1, IL-1 receptor type 2 and IL-4 receptor α are all prognostic at FDR < 0.05), which fits a general inflammatory signal rather than an IL-33-specific one. It is not explained by cardiac strain (NT-proBNP odds ratio 1.2, p = 0.05–0.17). We use it for what it is proven to do: find high-risk patients. |
| "The RNA-seq table says E-selectin and VCAM-1 are not significant." | A statistical artefact (Figure 4). One model was fitted across four very different cell types, and about 300 genes received standard errors 5 to over 10,000 times too large. The effects (2,367-fold, 427-fold) replicate in three separate comparisons and both endothelial cell types. A re-fit per cell type from the archived counts fixes this. |
| "Antibody alone changes dozens of genes. Off-target?" | No. Of 632 gene-level calls across 16 comparisons, 78% are transcripts at near-zero counts and 16% are abundant genes moving by a median of 9%, with implausibly small standard errors from the same artefact. Only 11 genes recur in a second independent comparison, all in those two categories and several in opposite directions. |
| "Does it stop working by 24 h in kidney cells?" | Probably not, but it cannot be measured directly: the comparison of IL-33 against control in HGMEC was not delivered (no vehicle arm). Two things point to the IL-33 response fading rather than the antibody. In HUVEC the main inflammatory programme is still fully neutralised at 24 h. And in HGMEC at 24 h, AX-1177 still lowers the genes whose induction is sustained in HUVEC (median 1.9-fold) but not the transient ones (p < 0.001). |
| "IL-33 is lower in COVID lung vessels, p = 0.01. Is that IL-33 being released?" | That p-value counts tissue blocks, and 24 of the 49 COVID-positive blocks come from three donors. By donor it is p = 0.05–0.16 and it weakens further after adjusting for age. Release is one explanation; loss of IL-33 from activated endothelium is another. Not a finding to present. |
| "Isn't blocking neutrophil recruitment risky in an infection?" | Yes, and it is the main safety question. The programme AX-1177 switches off includes G-CSF, GM-CSF and interferon-response genes. Host-defence read-outs must be in the first in vivo study. |

## 6. Forward plan

### 6.1 What the next studies have to establish

| # | Question | Study | Proposed pass criterion (agree before unblinding) |
|---|---|---|---|
| 1 | Is the target there? | Sensitive IL-33 assay (free and sST2-bound; reduced and oxidised) on the 100 banked enrolment sera, and on airway fluid where banked, since the lung is where our data place IL-33. Retrieve the 100 undelivered assay results. | IL-33 quantifiable in at least half of samples, and either associated with the outcome or clearly higher in sST2-high patients |
| 2 | Is it doing anything? | Apply patient serum (sST2-high vs sST2-low) to endothelial cells with AX-1177 or isotype; read the marker panel at 6 h | AX-1177 removes a pre-specified share (suggest ≥ 30%) of serum-induced activation in sST2-high samples |
| 3 | Does the pharmacology hold in lung tissue and under realistic conditions? | Lung microvascular endothelium and airway epithelium, at least 3 donors each; dose-response for both IL-33 and antibody (only 30 ng/mL and 10 µg/mL were tested); time course from 1 to 24 h; antibody added *after* IL-33; oxidised IL-33; protein and neutrophil-adhesion read-outs | Concentration giving 90% inhibition is achievable; effect survives delayed addition |
| 4 | Is it specific, and safe to block? | TNF and IL-1β as control stimuli; infection models (viral and bacterial) with pathogen-clearance read-outs | No effect on TNF/IL-1β responses; no loss of pathogen control |
| 5 | Can we pick the patients? | Patient-level re-analysis for an sST2 cut-off; independent cohort that includes non-COVID pneumonia | sST2 (with or without IL-6) predicts outcome outside COVID-19 |

Three actions need no new laboratory work and should start immediately: re-fit the RNA-seq per cell type and extract the missing comparisons (IL-33 against control in HGMEC; antibody against vehicle); obtain the undelivered serum assays and patient-level values; have the lung slides re-read blind by two readers against true normal lung, scoring nuclear and extracellular IL-33 separately. In addition, 22 of the lung blocks already have extracted RNA (identifiers are in the file), which could be used to measure IL-33, ST2 and the marker panel in tissue.

### 6.2 Biomarkers, and what each could do in patients

| Marker | Evidence in our data | Role in patients |
|---|---|---|
| **sST2** (serum) | 2nd of 1,094; odds ratio 3.0 (1.8–5.0); FDR 0.007. Its gene is induced 3-fold by IL-33 in HUVEC and reversed by AX-1177 | **Enrichment and stratification** (prognostic). Exploratory PD. Not proof of target engagement and not yet predictive of response |
| **IL-6** (serum) | Prognostic on 4 of 4 panels (odds ratio 2.1–2.3); induced 56-fold by IL-33, fully reversed, both cell types | Prognostic covariate and **PD** marker (not specific to IL-33) |
| **IL-8, OPG, PTX3, CCL20, MCP-3, IL-18R1** (serum) | Each prognostic at FDR < 0.05 and each IL-33-induced and AX-1177-reversed in both endothelial types | Exploratory **PD panel** ("IL-33 response score") |
| **Soluble E-selectin** (serum) | Most strongly induced gene (2,367-fold), 98% reversed; serum association nominal only (odds ratio 2.1, FDR 0.09) | Endothelium-specific, mechanism-proximal **PD** |
| **G-CSF, GM-CSF, CXCL1, VCAM-1, ICAM-1** | Very large, reversed effects in cells; not prognostic in serum (GM-CSF not measured) | Cell-based and ex vivo potency read-outs only; not for patient selection |
| **IL-33 and IL-33:sST2 complex** | None: not in the delivered data | **Target engagement** and candidate **predictive** marker. Assay must be built; this is gate 1 |
| Tissue IL-33 staining; IL-5Rα; type-2 markers; HGF | Not discriminating; IL-5Rα tracks neutrophils (rho 0.89) not eosinophils (rho 0.12); HGF is the top serum protein but is not IL-33-induced | Not recommended |

### 6.3 Sampling timepoint

- **Cells: 6 hours.** The response is largest there and the reversal is readable in both cell types. By 24 h the IL-33 effect has fallen to a median of 40% of its 6-hour size (log scale), the number of usable genes (induced at least 4-fold and at least 70% reversed) falls from 216 to 85, and in HGMEC the readable window has almost closed (5% of signature genes still significantly reversed, against 47% at 6 h). Use 24 h only as a secondary point for the sustained markers (G-CSF, GM-CSF, CXCL5, CXCL6) and for secreted protein, which needs time to accumulate.
- **Patients: enrolment, before dosing.** This is the only timepoint at which our markers are shown to carry prognostic information. Because the cell response is fast and short-lived, the first on-treatment sample should be early (within 24 hours of dosing).
- **Avoid** late or post-mortem tissue as a read-out of IL-33 activity.

### 6.4 Gates and kill criteria

- **Gate 1 (questions 1–2 plus the three no-cost actions).** Advance if IL-33 is measurable and linked to outcome or to sST2, *or* patient serum drives AX-1177-reversible endothelial activation.
- **Kill:** if IL-33 is undetectable or unrelated to outcome in serum and airway fluid *and* serum-induced activation is not AX-1177-sensitive, stop the acute lung indication. Keep the kidney option alive only if the re-fit shows a robust glomerular response and an external kidney cohort exists; otherwise out-license or terminate.
- **Gate 2 (questions 3–5).** Advance to a clinical plan only if lung-cell pharmacology, specificity and host-defence safety all pass.

## 7. Considered and ruled out

| Considered | Outcome | Why |
|---|---|---|
| Keep as severe *viral* infection | Ruled out as framed | Section 3: no virus-specific signal, target not raised, target unmeasured |
| Chronic airway disease (asthma, COPD, pulmonary fibrosis) | Not supported by our data | No type-2 system tested; type-2 serum markers flat; IL-33 staining unrelated to eosinophil markers (rho −0.1 to −0.2) or to recorded COPD (11 donors, p = 0.21), asthma (6 donors, p = 0.34) or pulmonary fibrosis (3 donors, p = 0.12). Not disproven: these datasets were not built to test it |
| Kidney or general vascular disease | Kept as hypothesis only | One donor, one timepoint, no patient data; kidney-injury serum markers at background |
| Cardiac indication (sST2 is a heart-failure marker) | Not supported | Cardiac-strain markers are weak or absent here (NT-proBNP odds ratio 1.2, p = 0.05–0.17; troponin I p = 0.11) |
| Thrombosis angle | Noted, not pursued | IL-33 induces tissue factor 50-fold (reversed); thromboemboli in 4/16 COVID+ vs 0/15 COVID− donors (p = 0.10); serum tissue factor FDR 0.051. Suggestive only |
| Reading only the visible spreadsheet views | Rejected | The visible views omit the IL-33 tissue data and 23 of 24 RNA-seq comparisons |
| Selecting genes by FDR alone | Rejected | It discards E-selectin, VCAM-1, IL-8, CXCL1, MCP-1, PTX3 and sST2's own gene |
| Treating tissue blocks as independent | Rejected | Turns p = 0.05–0.16 into p = 0.01 |
| Ranking serum proteins by odds ratio | Rejected | Odds ratios are per log unit, not standardised (CSF-1: 90, CI 4–1,900) |
| Using the IL-33 signature enrichment as supporting evidence | Not claimed | Null overall. A stricter 34-protein core trends (29% vs 17%, p = 0.06), and 4 signature proteins sit in the top 20, but these cuts were chosen after seeing the data |

## 8. If the committee drops it: what is being dropped, and why

*What:* a human IgG1 that fully and selectively neutralises IL-33 signalling in two human endothelial cell types and has no activity of its own in four cell types.

*Why:* no evidence that its target is raised or active in the intended patients (unmeasured in serum, not raised in lung); the one prognostic axis marker is a non-specific decoy; no lung-cell, infection-model or in vivo efficacy data; and the type-2 biology that usually justifies this class finds little support in this population.

*What would reverse the decision:* a positive result on questions 1 and 2 in section 6.1.

## 9. What the committee should know about the data package

- **Hidden content.** The lung spreadsheet hides 12 columns, including all three IL-33 staining columns. The serum sheet hides two rows and the lower confidence bound. The RNA-seq workbook has a filter showing 1 of 24 comparisons per sheet, and its two sheets ("6h", "24h") are identical copies of the full table. Everything was unhidden and used.
- **IL-33 is not in the serum file, and neither are about 100 other assays.** The 13 panels carry 1,196 assays; the adjusted p-values were computed over 1,194; 1,094 were delivered. Four of the undelivered ones were significant. The annex says adjustment was across the delivered assays.
- **RNA-seq p-values are unreliable for about 300 genes**; effect sizes are sound. Replicates are wells from one donor per cell type, not independent donors, and the two endothelial types differ in passage number (2 vs 5), so differences between them cannot be attributed to the vascular bed. There is one antibody concentration (about 40-fold molar excess over IL-33), so potency is not characterised.
- **Lung scoring.** One reader, blinding not stated. 53% of blocks sit at the top of the endothelial IL-33 scale, so an increase could not have been seen. The "non-pneumonia" controls are not normal lung (two have pulmonary fibrosis, one fungal infection, two acute pneumonitis or organising pneumonia), and 6 of 26 "pneumonia" donors have no acute pneumonia in the pathology text.
- **Two readings are mine, not stated in the files:** that the serum columns `composite_endpoint_0/_1` are per-group missing-value fractions (implying 44 events in 100 patients), and that IL-33 was dropped for low detectability. Both should be confirmed with the data owners.

## Figures

![Figure 1](figures/Fig1_invitro_pharmacology.png)

![Figure 2](figures/Fig2_serum_proteomics.png)

![Figure 3](figures/Fig3_postmortem_lung.png)

![Figure 4](figures/Fig4_rnaseq_statistics_caveat.png)

## Appendix: how the numbers were produced

**RNA-seq.** All 26 delivered comparisons ("contrasts") were used: 2 in the HUVEC file, 24 in the contrasts workbook. "Reversal" is the comparison of IL-33 + AX-1177 against IL-33 + isotype antibody, which shares no samples with the IL-33-versus-vehicle comparison. Percentage inhibition is the share of the IL-33 log2 fold change removed. "Well-detected" means average log2 expression above 0 across the 114 libraries. The 137-gene core signature requires at least 4-fold induction in HUVEC at 6 h, at least 80% reversal against both IL-33 alone and IL-33 + isotype, and at least 2-fold reversal in HGMEC in both contrasts. Standard errors were recovered as log2 fold change divided by t, and compared with the trend for well-behaved genes at the same expression level. At 24 h in HUVEC a small interferon-type signal remains after AX-1177 (about 77% reversed, against about 100% for the main inflammatory programme); its origin cannot be resolved without the antibody-versus-vehicle contrast, which was not delivered.

**Serum.** Delivered odds ratios, confidence intervals and adjusted p-values were used as given. Assay names were mapped to gene symbols by hand (table in `analysis_code/03_serum.py`); 27 proteins appear on two to four panels and agree in every case. Biology classes were curated by me from the assay list. Enrichment tests are Fisher's exact tests at the protein level.

**Lung.** Scores were averaged within donor (31 donors) and compared by permutation test and Mann-Whitney test; confidence intervals are bootstrap. A sensitivity analysis re-classified donors from the free-text pathology and adjusted for age. Block-level p-values are shown only to illustrate what happens when repeated blocks from one donor are treated as independent samples.

**Files in this folder**

| File | Content |
|---|---|
| `AX-1177_portfolio_audit_memo.md` / `.pdf` | This memo |
| `AX-1177_supporting_tables.xlsx` | README, column guide and 16 supporting tables (contrast summary, core signature, biomarker shortlist, all serum assays annotated, lung donor table and tests, data-integrity log) |
| `figures/` | Figures 1–4 |
| `tables/` | The same tables as CSV |
| `analysis_code/` | Scripts 01–07 and `run_all.sh`; re-runs everything from the four delivered files |
