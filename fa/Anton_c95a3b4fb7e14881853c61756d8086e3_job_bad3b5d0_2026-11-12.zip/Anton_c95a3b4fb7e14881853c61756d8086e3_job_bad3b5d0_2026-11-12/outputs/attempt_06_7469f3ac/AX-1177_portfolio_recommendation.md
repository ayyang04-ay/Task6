# AX-1177 (anti-IL-33 antibody): portfolio audit recommendation and forward plan

Basis: the four delivered data files and the methods annex, and nothing else. No external, literature or competitor data were used. Every number can be regenerated with the scripts in `analysis/`; supporting tables are in `tables/`, figures in `figures/`.

Terms: AX-1177 appears in the files as Compound_47; HUVEC, human umbilical-vein endothelial cells; HGMEC, human glomerular microvascular endothelial cells; IC119, the isotype control antibody; sST2, the soluble form of the IL-33 receptor measured in serum; FDR, false-discovery-rate-adjusted P value; OR, odds ratio; NEWS2, the early-warning score recorded at enrolment; IQR, interquartile range; LRTI, lower respiratory tract infection.

---

## 1. Recommendation

**Keep AX-1177, conditionally. Re-scope the indication and release only a gated work package.**

- **Keep**: the antibody does what it is meant to do, cleanly, and the receptor of its target is one of the two strongest predictors of deterioration in our patient cohort.
- **Re-scope**: the data do not support the current label, severe lower respiratory *viral* infection, as written. Nothing we hold is virus-specific and nothing supports a type-2 (eosinophilic) mechanism. The data point at a host-response phenotype: IL-33-driven endothelial activation with neutrophilic inflammation in severe pneumonia, marked by high soluble ST2 (sST2), and not confined to viral disease.
- **Gate**: the central link is missing. We have no measurement of IL-33 itself in patients and no evidence that blocking it changes a disease outcome. The data justify holding the asset. They do not yet justify advancing it. The advance-or-drop decision belongs after step 2 of the plan (section 5).

---

## 2. The case for keeping (what our data establish)

| # | Finding | Evidence |
|---|---|---|
| 1 | **AX-1177 neutralises IL-33 in human endothelium, essentially completely.** | HUVEC, 6 h: IL-33 changes 4,031 genes (FDR < 0.05). Of the 235 most robustly regulated genes (moderated t beyond ±8), 232 (99%) are significantly reversed by AX-1177 against the isotype control; at a looser threshold (t beyond ±5) it is 363 of 397 (91%). For the 220 strongest induced genes the median reversal is 101% (IQR 97–105%). What is left of the IL-33 effect with AX-1177 present is 0.01 log2 units (median). The antibody was added at the same time as IL-33 with no pre-incubation, a harder test than pre-mixing. Fig. 1A. |
| 2 | **The effect is on-target and the antibody is otherwise silent.** | Across all genes significant in both contrasts, 2,884 move in the opposite direction and 12 in the same. AX-1177 alone, in four cell types and 16 contrasts, returns 14–73 genes per contrast, which is the noise floor of this pipeline: six expressed genes in total change more than 1.4-fold and none repeats. The NF-κB gene set scores +3.1 with IL-33 and −3.1 when AX-1177 is added; with AX-1177 alone it stays between −1.2 and +1.5 in all 16 contrasts. Fig. 5A. |
| 3 | **It holds in a second, microvascular endothelium.** | Glomerular endothelial cells (HGMEC), 6 h: 186 of the same 235 genes (79%) are significantly reversed. The core NF-κB feedback genes move by a median 79% of the HUVEC amount. Fig. 1C. |
| 4 | **What IL-33 switches on in endothelium is a neutrophil-recruiting, adhesive, pro-coagulant programme, not a type-2 one.** | NF-κB hallmark set: enrichment score +3.13 with IL-33, −3.07 with AX-1177 (HUVEC), −3.65 (HGMEC). Induced and removed: G-CSF (*CSF3*, 320-fold), GM-CSF (*CSF2*), CXCL2/3/5/6, CCL20 (590-fold), IL-6 (56-fold), tissue factor (*F3*, 50-fold). No type-2 gene is induced (eotaxin-3, periostin, TSLP unchanged; IL-5, IL-13, eotaxin-1 not detected). Fig. 2. |
| 5 | **In patients, the IL-33 receptor marks those who deteriorate.** | 100 hospitalised SARS-CoV-2 patients, 44 of whom reached ICU, ventilation or death (count inferred from the file): serum sST2 has odds ratio 3.02 per log unit (95% CI 1.83–5.01; P = 1.7 × 10⁻⁵; FDR 0.007), independent of age, sex and NEWS2. It ranks second of 1,094 assays and is one of only two proteins (with HGF) that survive Bonferroni correction. Fig. 3. |
| 6 | **The lung holds a large IL-33 store, scored highest in endothelium, and it is depleted where neutrophils accumulate.** | 31 donors: endothelial IL-33 scores at least 4 of a maximum 5.5 in 30 of 31 donors, higher than basal epithelium (P = 0.0006). Within the same lung, blocks with more neutrophil elastase carry less endothelial IL-33 (within-donor r = −0.55, P = 0.0002). Fig. 4. |

The three data sets line up on one axis. IL-33 makes endothelium produce neutrophil growth factors and chemoattractants; neutrophil-activation proteins are over-represented among the serum predictors of deterioration (11 of 22 at FDR < 5%, against 16% of all assays and 1 of 23 type-2 markers; classes assigned by protein function, lists in Table T3b); and neutrophil elastase is what separates pneumonia from non-pneumonia lungs (P = 0.007). That coherence is circumstantial, not causal.

---

## 3. Where the case is weak (questions to expect)

| Challenge | What our data say |
|---|---|
| "You have not shown IL-33 is raised or active in these patients." | Correct, and this is the main gap. IL-33 is one of 15 Inflammation-panel assays missing from the serum table. sST2 is the soluble decoy form of the receptor, so a high level does not show that IL-33 is signalling; its relatives, soluble IL-1 receptor 2 and IL-18 receptor 1, are raised as well (both FDR 0.018), which looks like general shedding of this receptor family. As a class, the proteins IL-33 induces in endothelium are no more outcome-associated than any other (13 of 64 against 143 of 848; P = 0.49). In cells the response also fades on its own (37% of the 6 h change is left at 24 h), so sustained disease would need sustained IL-33 release, which we have not shown. |
| "Where is the endothelial signal in patients?" | Thin. The neutrophil half of the hypothesis shows in serum; the endothelial half does not. Of 34 circulating endothelial-activation and coagulation markers, four reach FDR < 5% (PTX3, VEGF-A, uPAR, von Willebrand factor), which is no more than the 16% background. E-selectin is borderline (FDR 0.09); VCAM-1 and ICAM-1 are not associated. The endothelial case rests on the cell data and on where IL-33 sits in the lung. |
| "IL-33 is not higher in infected lung." | Correct. Donor-level endothelial scores are 4.8 (COVID+), 5.2 (COVID− pneumonia), 5.4 (no pneumonia); P = 0.11. Over half of all blocks sit at the top of the scale, so the assay could only ever show loss. Loss where neutrophils are dense fits release of stored IL-33 from damaged cells, but equally fits down-regulation or cell death. |
| "Is any of this specific to viral infection?" | No. COVID+ and COVID− pneumonia are indistinguishable on every tissue read-out (IL-33 in three compartments, neutrophils, eosinophils, mast cells; all P ≥ 0.15). The serum cohort contains one virus only. |
| "The cell work is not lung, one donor, one dose." | Correct. Umbilical-vein and glomerular endothelium, one donor each, three wells. One antibody concentration at a 41-fold molar excess over IL-33, added at the same time as IL-33. RNA only. Reduced IL-33 only. HGMEC had no vehicle arm; the lung epithelial line never received IL-33. |
| "No in-vivo efficacy; and you would block neutrophil recruitment during an infection." | Correct on both counts. Nine of 16 COVID+ donors had acute bronchopneumonia and one had Aspergillus, so host defence is a real liability to test. |
| "Are the statistics sound?" | The delivered single-model statistics have two defects (section 9). They do not change findings 1–3, which rest on hundreds of genes and independent contrasts. They do hide four of the largest effects: E-selectin, VCAM-1, IL-8 and CXCL1 are not called significant, yet each changes more than 8-fold in the expected direction in all five independent endothelial contrasts. Seventeen genes do that; in 56 combinations of antibody-alone contrasts none does. These four are almost certainly real but need the re-fit before use. |

---

## 4. What indication the data point at

| Positioning | Support in our data | Against, or missing | Verdict |
|---|---|---|---|
| **Severe pneumonia with acute respiratory failure, not restricted to viral cause, selected by high sST2 (endothelial–neutrophilic phenotype)** | sST2 and neutrophil-activation proteins predict outcome; neutrophils high in COVID+ and COVID− pneumonia alike; IL-33 store in lung vessels; AX-1177 blocks the endothelial programme | Causality unproven; IL-33 unmeasured; no lung endothelium; no in-vivo data; pathogens of the COVID− pneumonia donors not recorded | **Lead hypothesis** |
| Severe *viral* LRTI as a virus-defined disease (current label) | sST2 prognostic in a SARS-CoV-2 cohort | No virus-specific feature in tissue; one virus; no viral read-out in cells | Not supported as virus-specific; absorbed into the row above |
| Type-2 / eosinophilic airway disease | None | Serum IL-5 OR 1.00, eotaxin 0.98–1.08, TARC 0.85; eosinophil staining low-grade (mean 1.8 of 5) and unrelated to IL-33; no type-2 gene induced | Ruled out on our data |
| Renal microvascular inflammation | Glomerular endothelium responds; AX-1177 active at 6 h | One donor, no vehicle arm, little effect at 24 h; no renal tissue or patients | Option only; needs new data |
| Chronic airway disease (COPD) | Donors with a COPD note: epithelial IL-33 4.7 vs 4.3 | P = 0.21; no cohort | No evidence either way |
| Cardiac | sST2 | NT-proBNP and troponin I not associated at FDR 5% | Not supported |

This is a re-scoping more than a repurposing: the same acute-care setting, defined by host response instead of by virus, and broader in aetiology. The only genuinely different indication the data open is renal microvascular disease, and that rests on one cell experiment.

---

## 5. What the next studies have to establish

The next studies have to establish four things, none of which the current data show:

1. that IL-33 itself is present and active in the patients we would treat;
2. that AX-1177 blocks it at achievable exposure, in lung vessels, once signalling has begun;
3. that high sST2 identifies patients who respond, not only patients who are sicker;
4. that blocking IL-33 improves lung injury in vivo without weakening host defence.

The steps below are ordered by cost. Durations are planning assumptions.

**Step 0. Use what we already own (about 4–6 weeks, no new wet work).**
- Re-fit the RNA-seq per cell line from the archived counts; confirm or drop the variance-inflated genes; extract the undelivered IL-33 + IC119 vs IC119 contrasts.
- Retrieve the 100 serum assays that were analysed but not delivered (IL-33 among them) and the patient-level data: sST2 discrimination and cut-off, independence from IL-6, effect of cardiac and renal comorbidity and treatment.
- Retrieve the lung RNA that appears to exist for 22 donors; have IL-33 re-scored by a second, blinded reader on a scale that is not saturated.
- Pull affinity, potency and species cross-reactivity from the biologics file.

**Step 1. Is the pharmacology real at relevant exposure, in lung cells, after the insult has started? (about 3 months, in vitro)**
- Dose-response (IC50, IC90) of AX-1177 against a titration of IL-33, read on the 6 h panel and on secreted protein.
- Antibody added 15 min, 1 h and 3 h after IL-33, not only together with it.
- Human pulmonary microvascular endothelium from at least three donors, with a vehicle arm; HGMEC repeated with a vehicle arm; primary bronchial epithelium with IL-33.
- Oxidised and cell-derived IL-33, not only the recombinant reduced form.
- Function: neutrophil adhesion and transmigration, barrier integrity, tissue-factor activity.

**Step 2. Is IL-33 actually present and active in the patients we would treat? (about 3–6 months, stored samples)**
- High-sensitivity IL-33 (free, total, and IL-33:sST2 complex) on the stored enrolment sera, if volume remains, analysed with the same model as the delivered table.
- Patient serum, high- versus low-sST2, applied to lung endothelium with and without AX-1177: does it drive the panel, and does AX-1177 stop it?
- A second cohort that includes non-COVID viral and bacterial pneumonia, with serial samples.

**Step 3. Does blocking IL-33 help in vivo without costing host defence? (after steps 1–2)**
- Viral and bacterial pneumonia models with dosing after onset: neutrophil influx, vascular leak, lung injury, survival, and pathogen clearance.

**Proposed stop rules (to be agreed in advance).**
- Step 1: less than 80% reversal of the panel in lung endothelium in two of three donors, or IC90 above achievable exposure, or no activity when added 1 h after IL-33.
- Step 2: IL-33 unquantifiable or unrelated to outcome, *and* patient serum does not produce an AX-1177-sensitive endothelial response.
- Step 3: no benefit with post-onset dosing, or higher pathogen burden or mortality.

---

## 6. Biomarkers, sampling time, and role in patients

**Sampling timepoint: 6 h after stimulation** for the cell-based read-out.
- The response is largest at 6 h (4,031 genes against 1,836 at 24 h); by 24 h the strongest genes retain a median 37% of their 6 h log2 fold change.
- Neutralisation is cleanest at 6 h (101% median reversal against 85% at 24 h).
- The glomerular cells are only informative at 6 h (79% of robust genes reversed, against 22% at 24 h).
- A 24 h supernatant is worth adding only to confirm secreted protein.

**For patients, the only timepoint our data validate is enrolment (before dosing).** On-treatment timing has to be established in step 2.

| Marker | In our cells (HUVEC 6 h: IL-33, then + AX-1177; log2) | In our patients (OR per log unit, FDR) | Can it go into patients, and as what |
|---|---|---|---|
| **sST2** | *IL1RL1* +1.6, −1.7 at 6 h only; not significant | 3.02, FDR 0.007 | **Yes. Enrichment and stratification at enrolment (prognostic).** Whether it predicts response is untested. Not yet a pharmacodynamic marker. |
| **IL-6** | +5.8, −6.0; persists at 24 h; reversed in HGMEC | 2.07–2.31 on four panels, FDR 0.012–0.019 | **Yes. Pharmacodynamic marker and prognostic covariate.** Not IL-33-specific, so only interpretable against a control arm. |
| **CCL20** | +9.2, −9.8; persists at 24 h | 1.83, FDR 0.020 | Yes, exploratory pharmacodynamic marker. |
| **OPG** (*TNFRSF11B*) | +4.8, −5.0 | 4.40–6.77 on two panels, FDR 0.014–0.020 | Yes, exploratory pharmacodynamic marker. |
| IL-18R1, CSF-1, MCP-3, IL-1β | +3.6, +2.9, +2.2, +3.6; all reversed | FDR 0.018–0.046 | Exploratory pharmacodynamic markers. |
| IL-8, E-selectin, VCAM-1 | +8.2, +11.2, +8.7; reversed. Not significant in the delivered model, but replicated more than 8-fold in all five independent contrasts | IL-8 FDR 0.023; E-selectin 0.091; VCAM-1 0.61 | Pharmacodynamic candidates once step 0 confirms them; IL-8 first. |
| Tissue factor | +5.6, −5.5; significant | 3.02, FDR 0.051 | Exploratory; links the mechanism to coagulation. |
| PTX3 | +2.2, −2.3 at 6 h; not significant and not sustained at 24 h | 11.6, FDR 0.012 | Prognostic. Dependence on IL-33 unconfirmed. |
| G-CSF, GM-CSF, CXCL2/3/5/6 | +5.3 to +10.3; fully reversed; the most robust signals | G-CSF, CXCL5, CXCL6 not associated; others not on the panels | Cell and animal studies: yes. Patients: mechanism read-out only, not prognostic. |
| IL-33 (free, total, complex with sST2) | Not measured | Not delivered | **Target-engagement marker. The assay has to be built; this is the priority gap.** |
| HGF and neutrophil-activation proteins | Not IL-33-regulated in endothelium | HGF 4.99, FDR 0.004 | Disease-activity covariates, not AX-1177 markers. |
| 54-gene endothelial panel (e.g. *NFKBIA*, *TNFAIP3*, *TRAF1*) | All criteria met (Table T2a) | Intracellular | Potency and mechanism assay only. Not for patients. |
| Tissue IL-33 staining; eosinophil or type-2 markers | Saturated, not disease-associated; type-2 null | Type-2 null | **Do not use** for selection or response. |

---

## 7. What I considered and ruled out

**Indications.** Type-2 airway disease, a virus-specific label, cardiac disease and COPD (section 4).

**Alternative explanations of the cell data.**
- Endotoxin in the IL-33 preparation: ruled out, because an anti-IL-33 antibody removes the response and the isotype does not.
- Fc or isotype effect: ruled out. The derived isotype contrast is at noise level and AX-1177 alone is silent.
- Off-target activity of AX-1177: ruled out at transcript level in four cell types.
- IL-33-induced genes that escape the antibody: looked for; the 198 apparent non-reversed genes are low-abundance, marginal, and evenly split up and down, as expected from a 5% false-discovery rate. Three of 235 robust genes are not reversed.
- A real antibody effect on proliferation genes in HGMEC: a shift of about 10–15% that changes direction between cell lines; treated as plate-to-plate variation, flagged for the repeat.

**Ways of reading the data that I rejected.**
- Counting tissue blocks instead of donors: this makes IL-33 "significantly lower" (P = 0.017) and eosinophils "significantly higher" (P = 0.001–0.025) in COVID+ lungs. Per donor, none holds (P = 0.052, 0.09–0.38).
- Taking the tissue group labels at face value: eight of 31 donors have a label that the pathology text does not support. A re-classification from the text leaves the IL-33 and neutrophil conclusions unchanged and removes the apparent eosinophil difference between pneumonia and non-pneumonia lungs.
- Ranking genes by fold change alone, or by FDR alone, in the RNA-seq tables.
- Ranking serum proteins by odds ratio; they are per log unit and not comparable between assays.
- Reading the HGMEC 55% median reversal as partial neutralisation: without a vehicle arm it may equally be a smaller IL-33 response.
- Reading sST2 as proof that IL-33 drives severity.

---

## 8. If the committee drops it: what we are dropping and why

- **What:** a human IgG1 that, at 10 µg/mL, fully and specifically neutralises reduced IL-33 in umbilical-vein endothelium and strongly suppresses the same programme in glomerular endothelium, with no detectable activity of its own; plus a biomarker hypothesis (sST2-high, neutrophilic severe pneumonia) that our own patient data support.
- **Why it would be defensible:** there is no in-house evidence that IL-33 is elevated or active in the target patients, none that blocking it alters disease, no potency or in-vivo data in the package, and a plausible infection-risk liability. The current label is not supported as virus-specific.
- **What would be left undone:** steps 0–2 above, which are the cheapest way to find out whether the drop was right. Step 0 costs no new experiments.

---

## 9. Things in the files the committee should know about

Full list with handling: `tables/T5_data_integrity_log.csv`.

- **Hidden content in three of the four workbooks.** Opened in Excel, the files show far less than they contain. RNA-seq: a saved filter hides 96% of rows, leaving one contrast of 24 visible per sheet; the sheets named "6h" and "24h" are identical copies that each contain both timepoints. Post-mortem: all 15 score columns are hidden, including the three IL-33 columns. Serum: the confidence-limit columns and two rows (the second HGF and IL-6 assays) are hidden. Everything hidden was read and used here.
- **RNA-seq statistics.** One model was fitted across four unrelated cell types. For 274 genes the implied standard error is more than five times that of comparable genes, so E-selectin (2,400-fold), VCAM-1, IL-8 and CXCL1 are not called significant although they replicate in every endothelial contrast. In the other direction, 2–13% changes in very abundant genes reach extreme significance. AveExpr is an average over all 114 libraries and cannot be used as a filter.
- **Serum table.** The adjusted P values were computed over 1,194 assays; 1,094 were delivered. At least four undelivered assays had FDR < 0.05. IL-33, IL-4, IL-13 and TSLP are among those missing (IL-5 is reported from one panel only). Two columns are undocumented; they imply 56 patients without and 44 with the endpoint. The cohort is one centre, one virus, pre-vaccination, one sample per patient, and we hold summary statistics only.
- **Serum specificity.** 82% of assays have an odds ratio above 1 and 176 of 178 significant assays are risk-increasing: sicker patients have more of almost everything.
- **Post-mortem sheet.** 74 rows are blocks from 31 donors. The scale runs to 5.5, not 5, and endothelial IL-33 is at the maximum in 53% of blocks. No "non-pneumonia" donor has normal lungs. All donors are white and aged 64–98.
- **Not in the dump.** Affinity and potency, any in-vivo, pharmacokinetic or toxicology data, patient-level serum data, count matrices.

---

## Files

| File | Content |
|---|---|
| `figures/Fig1_IL33_signature_reversal.png` | IL-33 response against AX-1177 effect, HUVEC and HGMEC, 6 h and 24 h |
| `figures/Fig2_PD_biomarker_panel.png` | Candidate markers: cell data beside patient serum data |
| `figures/Fig3_serum_proteomics.png` | All serum assays; forest plot by marker class |
| `figures/Fig4_postmortem_lung.png` | Donor-level tissue scores; within-lung IL-33 against neutrophils; block versus donor P values |
| `figures/Fig5_rnaseq_statistics_QC.png` | Noise floor of the pipeline; variance-inflated genes |
| `tables/T1_rnaseq_contrast_summary.csv` | All 26 contrasts: genes called, checks on the delivered statistics |
| `tables/T2a_invitro_PD_panel.csv` | 54-gene panel plus variance-inflated candidates, all statistics |
| `tables/T2b_IL33_signature_all_genes.csv` | Every IL-33-responsive gene with reversal in both cell types |
| `tables/T2c_nfkb_core_module.csv`, `T2d_gene_set_enrichment.csv` | NF-κB core genes; gene-set enrichment for all contrasts |
| `tables/T3a_serum_all_assays_with_invitro_bridge.csv` | 1,094 assays mapped to genes and joined to the cell data |
| `tables/T3b_serum_marker_classes.csv` | Marker classes used in section 2 and Fig. 3 |
| `tables/T4a_postmortem_donor_level.csv`, `T4b_postmortem_group_tests.csv` | Donor-level scores; block-level, donor-level and text-reclassified tests |
| `tables/T5_data_integrity_log.csv` | 27 data issues, consequence, and how each was handled |
| `analysis/00`–`07` scripts | Reproduce every table and figure from the delivered files; `07` re-computes and asserts every number quoted in this memo |
