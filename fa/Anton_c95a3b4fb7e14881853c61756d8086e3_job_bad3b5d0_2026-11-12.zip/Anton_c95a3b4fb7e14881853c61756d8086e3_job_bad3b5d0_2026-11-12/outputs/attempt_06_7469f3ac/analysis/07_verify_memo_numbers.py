#!/usr/bin/env python
"""AX-1177 portfolio audit -- step 7: every number quoted in the memo, recomputed and asserted.
Run after steps 0-6:  micromamba run -n singlecell python 07_verify_memo_numbers.py"""
import json, numpy as np, pandas as pd
from scipy import stats
C = '/tmp/outputs/analysis/cache'
R1 = json.load(open(f'{C}/results_rnaseq.json')); R2 = json.load(open(f'{C}/results_serum.json')); R3 = json.load(open(f'{C}/results_postmortem.json')); RG = json.load(open(f'{C}/results_gsea.json'))
ann, W = pd.read_pickle(f'{C}/rnaseq_wide.pkl'); lfc, t, q = W['logFC'], W['t'], W['adj.P.Val']
G = pd.read_pickle(f'{C}/rnaseq_gene_table.pkl'); meta = pd.read_pickle(f'{C}/rnaseq_contrasts_meta.pkl')
D = pd.read_pickle(f'{C}/pm_donor.pkl'); pm = pd.read_pickle(f'{C}/pm_block.pkl'); S = pd.read_pickle(f'{C}/serum_bridge.pkl')
ok = []
ka_pre = R2['key_assays']
def chk(label, value, expect, tol=None):
    good = (value == expect) if tol is None else abs(value - expect) <= tol
    ok.append(good); print(('OK   ' if good else 'FAIL ') + f'{label}: computed {value!r}; memo {expect!r}')
g = lambda s_: ann.index[ann.symbol == s_][0]
# ---- section 2
chk('IL-33 genes FDR<0.05, HUVEC 6 h', R1['DE_counts']['IL33_HUVEC_6']['n'], 4031)
chk('IL-33 genes FDR<0.05, HUVEC 24 h', R1['DE_counts']['IL33_HUVEC_24']['n'], 1836)
for tp, cell, n_exp, k_exp in [('6', 'HUVEC', 235, 232), ('6', 'HGMEC', 235, 186), ('24', 'HUVEC', 46, 45), ('24', 'HGMEC', 46, 10)]:
    il, rv = f'IL33_HUVEC_{tp}', f'AXIL33_v_ICIL33_{cell}_{tp}'
    rob = (q[il] < .05) & (lfc[il].abs() > 1) & (t[il].abs() > 8)
    cnt = rob & (q[rv] < .05) & (np.sign(lfc[rv]) != np.sign(lfc[il]))
    chk(f'robust genes (|t|>8) {tp} h', int(rob.sum()), n_exp); chk(f'  counter-regulated by AX-1177 in {cell} {tp} h', int(cnt.sum()), k_exp)
rob5 = (q['IL33_HUVEC_6'] < .05) & (lfc['IL33_HUVEC_6'].abs() > 1) & (t['IL33_HUVEC_6'].abs() > 5)
chk('robust genes (|t|>5) 6 h and reversed', (int(rob5.sum()), int((rob5 & (q['AXIL33_v_ICIL33_HUVEC_6'] < .05) & (np.sign(lfc['AXIL33_v_ICIL33_HUVEC_6']) != np.sign(lfc['IL33_HUVEC_6']))).sum())), (397, 363))
rob6 = (q['IL33_HUVEC_6'] < .05) & (lfc['IL33_HUVEC_6'].abs() > 1) & (t['IL33_HUVEC_6'].abs() > 8)
chk('robust genes not significantly reversed, HUVEC 6 h', int((rob6 & ~(q['AXIL33_v_ICIL33_HUVEC_6'] < .05)).sum()), 3)
r = R1['reversal']['6']['hc_up_HUVEC_vs_isotype']
chk('n strongest induced genes', r['n'], 220); chk('median reversal % 6 h', round(100 * r['median_reversal']), 101); chk('IQR low', round(100 * r['q25']), 97); chk('IQR high', round(100 * r['q75']), 105)
r = R1['reversal']['24']['hc_up_HUVEC_vs_isotype']; chk('median reversal % 24 h', round(100 * r['median_reversal']), 85)
chk('median reversal % HGMEC 6 h', round(100 * R1['reversal']['6']['hc_up_HGMEC_vs_isotype']['median_reversal']), 55)
chk('residual vs vehicle 6 h (log2)', round(R1['reversal']['6']['residual_vs_vehicle_hc_up']['median'], 2), 0.01)
c = R1['reversal']['6']['concordance_HUVEC']; chk('mirrored genes', c['up_then_down'] + c['down_then_up'], 2884); chk('same-direction genes', c['discordant'], 12)
chk('antibody-alone range', tuple(R1['antibody_alone_nFDR05_range']), (14, 73))
alone = [x for x in lfc.columns if x.startswith('AX_v_')]
n_expr = sum(int(((q[x] < .05) & (ann.AveExpr > 2) & (lfc[x].abs() > .5)).sum()) for x in alone); chk('expressed genes >1.4-fold across 16 antibody-alone contrasts', n_expr, 6)
chk('NF-kB NES antibody-alone within +-1.5', round(max(abs(RG['alone_NFKB_range'][0]), abs(RG['alone_NFKB_range'][1])), 1) <= 1.5, True)
chk('NF-kB core HGMEC/HUVEC median %', round(100 * R1['nfkb_core_HGMEC_over_HUVEC']['median_6h']), 79)
nf = RG['t']['TNFA_SIGNALING_VIA_NFKB']; chk('NES IL-33', nf['IL33_HUVEC_6'], 3.13, .02); chk('NES AX HUVEC', nf['AXIL33_v_ICIL33_HUVEC_6'], -3.07, .03); chk('NES AX HGMEC', nf['AXIL33_v_ICIL33_HGMEC_6'], -3.65, .03)
for s_, fold in [('CSF3', 320), ('CCL20', 590), ('IL6', 56), ('F3', 50), ('SELE', 2400)]:
    chk(f'{s_} fold induction', float(2 ** lfc.loc[g(s_), 'IL33_HUVEC_6']), fold, tol=fold * .03)
for s_ in ['CCL26', 'POSTN', 'TSLP']: chk(f'{s_} not induced (FDR>0.5)', bool(q.loc[g(s_), 'IL33_HUVEC_6'] > .5), True)
for s_ in ['IL5', 'IL13', 'CCL11']: chk(f'{s_} absent from gene universe', int((ann.symbol == s_).sum()), 0)
st = R2['ST2']; chk('sST2 OR', round(st['OR'], 2), 3.02); chk('sST2 CI low', round(st['l95'], 2), 1.83); chk('sST2 CI high', round(st['u95'], 2), 5.01); chk('sST2 P', float(f"{st['p']:.1e}"), 1.7e-5); chk('sST2 FDR', round(st['FDR'], 4), 0.0075); chk('sST2 rank', st['rank'], 2)
chk('assays delivered', R2['n_assays_delivered'], 1094); chk('Bonferroni survivors', sorted(R2['bonferroni_survivors']), ['HGF', 'HGF-ONCII', 'ST2'])
chk('patients with endpoint', R2['implied_n_with_endpoint'], 44); chk('patients without endpoint', R2['implied_n_without_endpoint'], 56)
chk('endothelial IL-33 donor mean >=4', int((D.IL33_endo_v >= 4).sum()), 30); chk('endo vs epi Wilcoxon P', round(R3['endo_vs_epi_wilcoxon_p'], 4), 0.0006)
w = R3['within_donor']['IL33_endo_v~NE_num_v']; chk('within-donor r', round(w['r_within'], 2), -0.55); chk('within-donor P', round(w['p'], 4), 0.0002)
chk('neutrophil set FDR<5%', (R2['sets']['Neutrophil activation / granule']['n_FDR05'], R2['sets']['Neutrophil activation / granule']['n']), (11, 22))
chk('type-2 set FDR<5%', (R2['sets']['Type-2 / eosinophil / mast cell']['n_FDR05'], R2['sets']['Type-2 / eosinophil / mast cell']['n']), (1, 23))
T = R3['group_tests']; chk('NE pneumonia vs non-pneumonia P', round(T['NE_num_v']['donor_p_pneumonia_vs_nonpneumonia'], 3), 0.007)
chk('FDR<5% rate over all assays %', round(100 * R2['n_FDR05'] / R2['n_assays_delivered']), 16)
es = R2['sets']['Endothelial activation / coagulation']; chk('endothelial/coagulation set FDR<5%', (es['n_FDR05'], es['n']), (4, 34))
chk('endothelial FDR<5% assays', sorted(S[S.assay.isin(['PTX3', 'VEGFA-INFI', 'U-PAR', 'vWF', 'VEGFA-ONCII', 'SELE', 'VCAM1', 'ICAM1'])].query('`adj.p.value` < 0.05').assay.tolist()), ['PTX3', 'U-PAR', 'VEGFA-INFI', 'vWF'])
chk('E-selectin FDR', round(ka_pre['SELE']['FDR'], 2), 0.09); chk('VCAM1 / ICAM1 FDR > 0.2', min(ka_pre['VCAM1']['FDR'], ka_pre['ICAM1']['FDR']) > .2, True)
# ---- section 3
chk('Inflammation-panel assays absent', len(R2['inflammation_panel_assays_absent']), 15); chk('IL-33 among them', 'IL-33' in R2['inflammation_panel_assays_absent'], True)
e = R2['enrichment']; chk('enrichment counts', (e['hits_in_set'], e['n_IL33_induced_reversed'], e['hits_outside'], e['n_outside']), (13, 64, 143, 848)); chk('enrichment P', round(e['fisher_p'], 2), 0.49)
chk('endothelial IL-33 means', tuple(round(T['IL33_endo_v'][k], 1) for k in ['mean_COVIDpos', 'mean_COVIDneg_pneumonia', 'mean_COVIDneg_nonpneumonia']), (4.8, 5.2, 5.4)); chk('KW P', round(T['IL33_endo_v']['donor_KW_p'], 2), 0.11)
chk('blocks at ceiling %', round(100 * R3['frac_blocks_at_ceiling_5p5']['IL33_endo']), 53)
chk('min P COVID+ vs COVID- pneumonia over all tissue read-outs >= 0.15', min(v['donor_p_COVIDpos_vs_COVIDneg_pneumonia'] for v in T.values()) >= 0.15, True)
chk('molar excess', round(R1['molar']['molar_excess']), 41)
chk('COVID+ donors with acute bronchopneumonia', 9, 9)   # manual read of pathology text, see 03_postmortem.py
rp = R1['replication']['3']; chk('genes >8-fold in all five independent contrasts', rp['n_genes'], 17); chk('  of which not significant in delivered model', rp['not_significant'], ['CXCL1', 'CXCL8', 'SELE', 'VCAM1']); chk('  null: max over 56 antibody-alone combinations', (rp['null_combinations'], rp['null_max']), (56, 0))
chk('sIL-1R2 and sIL-18R1 FDR', (round(ka_pre['IL-1RT2']['FDR'], 3), round(ka_pre['IL-18R1']['FDR'], 3)), (0.018, 0.018))
# ---- section 4
ka = R2['key_assays']
chk('IL-5 OR', round(ka['IL5-IMO']['OR'], 2), 1.00); chk('eotaxin ORs', (round(S[S.assay == 'CCL11-IMO'].OR.iloc[0], 2), round(ka['CCL11-INFI']['OR'], 2)), (0.98, 1.08)); chk('TARC OR', round(ka['CCL17']['OR'], 2), 0.85)
chk('EPX mean grade', round(R3['grade_means_block']['EPX_ihc_g'], 1), 1.8)
cp = R3['COPD_note']; chk('COPD epi IL-33', (round(cp['IL33_epi_yes'], 1), round(cp['IL33_epi_no'], 1)), (4.7, 4.3)); chk('COPD P', round(cp['p'], 2), 0.21)
chk('NT-proBNP / troponin FDR > 0.05', min(ka['NT-proBNP-MET']['FDR'], ka['NT-proBNP-CVDIII']['FDR'], float(S[S.assay == 'TNNI3']['adj.p.value'].iloc[0])) > .05, True)
# ---- section 6
chk('24 h / 6 h log2FC ratio %', round(100 * R1['decay']['median_ratio_24_over_6']), 37)
kg = R1['key_genes']
for s_, a, b in [('IL1RL1', 1.6, -1.7), ('IL6', 5.8, -6.0), ('CCL20', 9.2, -9.8), ('TNFRSF11B', 4.8, -5.0)]:
    chk(f'{s_} IL-33 / AX log2FC', (round(kg[s_]['IL33_6_logFC'], 1), round(kg[s_]['AX_HUVEC_6_logFC'], 1)), (a, b))
chk('IL18R1, CSF1, CCL7, IL1B log2FC', tuple(round(kg[s_]['IL33_6_logFC'], 1) for s_ in ['IL18R1', 'CSF1', 'CCL7', 'IL1B']), (3.6, 2.9, 2.2, 3.6))
chk('CXCL8, PTX3, SELE, F3, VCAM1 log2FC', tuple(round(kg[s_]['IL33_6_logFC'], 1) for s_ in ['CXCL8', 'PTX3', 'SELE', 'F3', 'VCAM1']), (8.2, 2.2, 11.2, 5.6, 8.7))
chk('F3 and PTX3 AX-1177 log2FC', (round(kg['F3']['AX_HUVEC_6_logFC'], 1), round(kg['PTX3']['AX_HUVEC_6_logFC'], 1)), (-5.5, -2.3)); chk('PTX3 not sustained at 24 h (log2FC<1)', kg['PTX3']['IL33_24_logFC'] < 1, True); chk('IL1RL1 24 h log2FC < 0.5', kg['IL1RL1']['IL33_24_logFC'] < .5, True)
chk('VCAM1 serum FDR', round(ka['VCAM1']['FDR'], 2), 0.61); chk('TF serum OR', round(ka['TF']['OR'], 2), 3.02); chk('PTX3 serum OR', round(ka['PTX3']['OR'], 1), 11.6)
chk('IL-6 serum OR range', (round(min(ka[a]['OR'] for a in ['IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO']), 2), round(max(ka[a]['OR'] for a in ['IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO']), 2)), (2.07, 2.31))
chk('IL-6 serum FDR range', (round(min(ka[a]['FDR'] for a in ['IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO']), 3), round(max(ka[a]['FDR'] for a in ['IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO']), 3)), (0.012, 0.019))
chk('CCL20 serum', (round(ka['CCL20']['OR'], 2), round(ka['CCL20']['FDR'], 3)), (1.83, 0.020)); chk('OPG serum ORs', (round(ka['OPG-CVDIII']['OR'], 2), round(ka['OPG-INFI']['OR'], 2)), (4.40, 6.77))
chk('OPG FDRs', (round(ka['OPG-INFI']['FDR'], 3), round(ka['OPG-CVDIII']['FDR'], 3)), (0.014, 0.020))
chk('IL-18R1 / MCP-3 / CSF-1 / IL1B FDR', tuple(round(ka[a]['FDR'], 3) for a in ['IL-18R1', 'MCP-3', 'CSF-1', 'IL1B']), (0.018, 0.020, 0.037, 0.046))
chk('IL8 / PTX3 / SELE / TF FDR', tuple(round(ka[a]['FDR'], 3) for a in ['IL8', 'PTX3', 'SELE', 'TF']), (0.023, 0.012, 0.091, 0.051))
chk('G-CSF, CXCL5, CXCL6 not associated (FDR>0.3)', min(ka[a]['FDR'] for a in ['G-CSF', 'CXCL5', 'CXCL6']) > .3, True)
chk('HGF serum', (round(ka['HGF']['OR'], 2), round(ka['HGF']['FDR'], 3)), (4.99, 0.004)); chk('HGF not IL-33-induced (FDR>0.5)', bool(q.loc[g('HGF'), 'IL33_HUVEC_6'] > .5), True)
chk('core panel size', R1['core_panel_funnel']['se_ok'], 54)
# ---- section 7
il, a, b = 'IL33_HUVEC_6', 'AXIL33_v_ICIL33_HUVEC_6', 'AXIL33_v_IL33_HUVEC_6'
Sg = (q[il] < .05) & (lfc[il].abs() > 1); ra, rb = -lfc[a] / lfc[il], -lfc[b] / lfc[il]
nr = Sg & (ra < .5) & (rb < .5); chk('apparent non-reversed genes', int(nr.sum()), 198); chk('  of which up / down', (int((nr & (lfc[il] > 0)).sum()), int((nr & (lfc[il] < 0)).sum())), (107, 91)); chk('  median AveExpr < 0', bool(ann.AveExpr[nr].median() < 0), True)
chk('block-level P: IL-33 endo', round(T['IL33_endo_v']['block_p_COVIDpos_vs_allCOVIDneg'], 3), 0.017); chk('block-level P: EDN, EPX', (round(T['EDN_ihc_g']['block_p_COVIDpos_vs_allCOVIDneg'], 3), round(T['EPX_num_v']['block_p_COVIDpos_vs_allCOVIDneg'], 3)), (0.001, 0.025))
chk('donor-level P: IL-33 endo, EDN, EPX', (round(T['IL33_endo_v']['donor_p_COVIDpos_vs_allCOVIDneg'], 3), round(T['EDN_ihc_g']['donor_p_COVIDpos_vs_allCOVIDneg'], 2), round(T['EPX_num_v']['donor_p_COVIDpos_vs_allCOVIDneg'], 2)), (0.052, 0.09, 0.38))
chk('label/text mismatches', len(R3['label_vs_text_mismatch_donors']), 8)
chk('EDN pneumonia vs non-pneumonia: by label significant, by text not', (T['EDN_ihc_g']['donor_p_pneumonia_vs_nonpneumonia'] < .05, T['EDN_ihc_g']['text_p_acute_vs_none'] > .05), (True, True))
# ---- section 9
HID = json.load(open(f'{C}/hidden_content.json')); pmh = HID['AX-1177_postmortem_lung.xlsx::Sheet1']; seh = HID['AX-1177_serum_proteomics.xlsx::sort by adj p value']
chk('post-mortem hidden columns', (len(pmh['hidden_columns']), pmh['n_columns']), (16, 28)); chk('  IL-33 columns hidden', all(c in [h[0] for h in pmh['hidden_columns']] for c in 'XYZ'), True)
chk('  all 15 score columns L-Z hidden', [h[0] for h in pmh['hidden_columns']][1:], list('LMNOPQRSTUVWXYZ'))
chk('serum hidden columns', [h[1] for h in seh['hidden_columns']], ['l95', 'u95']); chk('serum hidden rows', sorted(v[1] for v in seh['hidden_rows'].values()), ['HGF-ONCII', 'IL6-ONCII'])
chk('hidden rows %', round(100 * meta['6h']['hidden_rows'] / meta['6h']['rows']), 96); chk('SE-inflated genes', R1['SE_inflation']['n_gt5x'], 274)
chk('BH denominator', R2['BH_denominator_implied_by_top_row'], 1194); chk('undelivered FDR<0.05 assays (at least)', R2['undelivered_assays_with_FDR_lt_0p05'], 4)
chk('OR>1 %', round(100 * R2['frac_OR_gt1']), 82); chk('FDR hits', (R2['n_FDR05_risk_increasing'], R2['n_FDR05']), (176, 178))
chk('donors / blocks', (R3['n_donors'], R3['n_blocks']), (31, 74)); chk('age range', (R3['age']['min'], R3['age']['max']), (64.0, 98.0)); chk('tissue RNA ids', R3['n_blocks_with_tissue_RNA_id'], 22)
chk('tiny-effect extreme significance examples', (round(100 * (2 ** abs(lfc.loc[g('YWHAZ'), 'AX_v_DMSO_MCF7_6']) - 1)), round(100 * (2 ** abs(lfc.loc[g('DYNC1H1'), 'AX_v_IC_HUVEC_24']) - 1))), (2, 13))
print(f'\n{sum(ok)} of {len(ok)} checks passed')
