#!/usr/bin/env python
"""AX-1177 portfolio audit -- step 5b: pull the gene-set numbers quoted in the memo out of T2d."""
import json, pandas as pd
G = pd.read_csv('/tmp/outputs/tables/T2d_gene_set_enrichment.csv')
H = G[G.collection == 'Hallmark']
key = ['IL33_HUVEC_6', 'AXIL33_v_ICIL33_HUVEC_6', 'AXIL33_v_ICIL33_HGMEC_6', 'IL33_HUVEC_24', 'AXIL33_v_ICIL33_HUVEC_24', 'AXIL33_v_ICIL33_HGMEC_24']
out = {}
for rk in ['t', 'logFC_AveExpr_gt0']:
    x = H[H.ranking == rk].pivot(index='pathway', columns='contrast', values='NES'); x.index = x.index.str.replace('HALLMARK_', '')
    out[rk] = {p: {c: round(float(x.loc[p, c]), 2) for c in key} for p in ['TNFA_SIGNALING_VIA_NFKB', 'INFLAMMATORY_RESPONSE', 'IL6_JAK_STAT3_SIGNALING', 'INTERFERON_GAMMA_RESPONSE', 'COAGULATION', 'E2F_TARGETS']}
xa = H[H.ranking == 't'].pivot(index='pathway', columns='contrast', values='NES'); xa.index = xa.index.str.replace('HALLMARK_', '')
alone = [c for c in xa.columns if c.startswith('AX_v_')]
out['alone_NFKB_range'] = [float(xa.loc['TNFA_SIGNALING_VIA_NFKB', alone].min()), float(xa.loc['TNFA_SIGNALING_VIA_NFKB', alone].max())]
out['alone_MYC_range'] = [float(xa.loc['MYC_TARGETS_V1', alone].min()), float(xa.loc['MYC_TARGETS_V1', alone].max())]
json.dump(out, open('/tmp/outputs/analysis/cache/results_gsea.json', 'w'), indent=1)
print('NF-kB NES:', out['t']['TNFA_SIGNALING_VIA_NFKB'], '| antibody-alone range:', [round(v, 2) for v in out['alone_NFKB_range']])
