#!/usr/bin/env python
"""AX-1177 portfolio audit -- step 0b: list what is hidden in the three small workbooks as saved
(hidden columns, hidden rows, filters).  The large contrasts workbook is handled in 00_load_data.py.
Run:  micromamba run -n singlecell python 00b_hidden_content.py"""
import json, openpyxl
from openpyxl.utils import get_column_letter
SRC = '/tmp/world/filesystem'; CACHE = '/tmp/outputs/analysis/cache'
out = {}
for f in ['AX-1177_postmortem_lung.xlsx', 'AX-1177_serum_proteomics.xlsx', 'AX-1177_rnaseq_huvec_il33.xlsx']:
    wb = openpyxl.load_workbook(f'{SRC}/{f}')
    for ws in wb.worksheets:
        hdr = {c.column: (str(c.value).strip() if c.value is not None else '') for c in ws[1]}
        hidden_cols = []
        for key, dim in ws.column_dimensions.items():
            if dim.hidden:
                for ci in range(dim.min, min(dim.max, ws.max_column) + 1):
                    hidden_cols.append((get_column_letter(ci), hdr.get(ci, '')))
        hidden_cols = sorted(set(hidden_cols), key=lambda x: openpyxl.utils.column_index_from_string(x[0]))
        hidden_rows = [r for r, dim in ws.row_dimensions.items() if dim.hidden and r <= ws.max_row]
        rows_content = {r: [ws.cell(r, c).value for c in range(1, 4)] for r in hidden_rows[:20]}
        out[f'{f}::{ws.title}'] = dict(n_columns=ws.max_column, hidden_columns=hidden_cols, n_hidden_rows=len(hidden_rows), hidden_rows=rows_content,
                                       visible_columns=[(get_column_letter(ci), hdr.get(ci, '')) for ci in range(1, ws.max_column + 1) if get_column_letter(ci) not in {h[0] for h in hidden_cols}])
json.dump(out, open(f'{CACHE}/hidden_content.json', 'w'), indent=1, default=str)
for k, v in out.items():
    print(k, '| hidden columns:', [f'{a} ({b[:40]})' for a, b in v['hidden_columns']], '| hidden rows:', v['hidden_rows'])
