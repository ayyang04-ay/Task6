#!/usr/bin/env python
"""
AX-1177 portfolio audit -- step 0: load the four delivered data files exactly as delivered.

Run:  micromamba run -n singlecell python 00_load_data.py
Reads  /tmp/world/filesystem/*  (read-only)
Writes /tmp/outputs/analysis/cache/*.pkl

Notes on things that are easy to get wrong (all handled here):
  * AX-1177_rnaseq_contrasts.xlsx has an Excel AutoFilter applied on both sheets: ~96% of rows are
    flagged hidden.  We parse the sheet XML directly so hidden rows are read.
  * The two sheets ("6h", "24h") each hold ALL 24 contrasts (both timepoints); they are duplicates
    with different filter/sort state.  The "6h" sheet also carries 419,520 empty rows.
  * AX-1177_postmortem_lung.xlsx: donor-level fields are only on the first block of each donor
    (merged cells), scores are strings such as "3+", "ND", "N/A", and one cell is a formula.
"""
import zipfile, re, os, sys, time
import xml.etree.ElementTree as ET
import numpy as np, pandas as pd, openpyxl

SRC = '/tmp/world/filesystem'
CACHE = '/tmp/outputs/analysis/cache'
os.makedirs(CACHE, exist_ok=True)
NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'

def col2idx(ref):
    n = 0
    for ch in ref:
        if ch.isalpha():
            n = n * 26 + (ord(ch) - 64)
    return n - 1

def read_big_xlsx(path):
    """Stream-parse every row of every sheet, including rows hidden by an AutoFilter."""
    z = zipfile.ZipFile(path)
    ss = []
    with z.open('xl/sharedStrings.xml') as f:
        for ev, el in ET.iterparse(f, events=('end',)):
            if el.tag == NS + 'si':
                ss.append(''.join(t.text or '' for t in el.iter(NS + 't')))
                el.clear()
    wb = ET.fromstring(z.read('xl/workbook.xml'))
    sheets = [s.get('name') for s in wb.iter(NS + 'sheet')]
    out, meta = {}, {}
    for i, name in enumerate(sheets, start=1):
        rows, hidden, filt = [], [], None
        with z.open(f'xl/worksheets/sheet{i}.xml') as f:
            for ev, el in ET.iterparse(f, events=('end',)):
                if el.tag == NS + 'row':
                    r = [None] * 11
                    for c in el:
                        ci = col2idx(c.get('r'))
                        v = c.find(NS + 'v')
                        if v is None or ci > 10:
                            continue
                        r[ci] = ss[int(v.text)] if c.get('t') == 's' else v.text
                    rows.append(r)
                    hidden.append(el.get('hidden') == '1')
                    el.clear()
                elif el.tag == NS + 'autoFilter':
                    filt = [f_.get('val') for f_ in el.iter(NS + 'filter')]
        df = pd.DataFrame(rows[1:], columns=rows[0])
        df['_hidden'] = hidden[1:]
        n_empty = int(df['Comparison'].isna().sum())
        df = df[df['Comparison'].notna()].copy()
        for c in ['logFC', 'AveExpr', 't', 'P.Value', 'adj.P.Val', 'B']:
            df[c] = pd.to_numeric(df[c])
        out[name] = df
        meta[name] = dict(rows=len(df), empty_rows=n_empty, hidden_rows=int(df['_hidden'].sum()),
                          visible_rows=int((~df['_hidden']).sum()), autofilter=filt,
                          visible_contrasts=sorted(df.loc[~df['_hidden'], 'Comparison'].unique()))
    return out, meta

if __name__ == '__main__':
    t0 = time.time()
    # ---------------- RNA-seq ----------------
    big, meta = read_big_xlsx(f'{SRC}/AX-1177_rnaseq_contrasts.xlsx')
    pd.to_pickle(meta, f'{CACHE}/rnaseq_contrasts_meta.pkl')
    a, b = big['6h'], big['24h']
    ka = a.set_index(['Comparison', 'ensembl']); kb = b.set_index(['Comparison', 'ensembl']).reindex(ka.index)
    identical = all(np.allclose(ka[c].values, kb[c].values, rtol=0, atol=0) for c in ['logFC', 't', 'P.Value', 'adj.P.Val', 'B', 'AveExpr'])
    print('sheet meta:', meta); print('sheets "6h" and "24h" carry identical data:', identical)
    hu = pd.read_excel(f'{SRC}/AX-1177_rnaseq_huvec_il33.xlsx', sheet_name=None)
    cols = ['Comparison', 'ensembl', 'logFC', 'AveExpr', 't', 'P.Value', 'adj.P.Val', 'B', 'symbol', 'entrez', 'gene_name']
    parts = [a[cols]]
    for sh, d in hu.items():
        d = d[cols].copy(); d['entrez'] = d['entrez'].map(lambda x: None if pd.isna(x) else str(int(x)))
        parts.append(d)
        print('HUVEC sheet', sh, '-> Comparison label in file:', d.Comparison.unique(), 'sorted by logFC desc:', d.logFC.is_monotonic_decreasing)
    L = pd.concat(parts, ignore_index=True)
    L.to_pickle(f'{CACHE}/rnaseq_long.pkl')
    pd.to_pickle(dict(identical_sheets=identical), f'{CACHE}/rnaseq_flags.pkl')
    # ---------------- serum ----------------
    s = pd.read_excel(f'{SRC}/AX-1177_serum_proteomics.xlsx')
    s.to_pickle(f'{CACHE}/serum.pkl')
    # ---------------- post-mortem ----------------
    wb = openpyxl.load_workbook(f'{SRC}/AX-1177_postmortem_lung.xlsx'); ws = wb.worksheets[0]
    names = ['sample_id', 'block_id', 'tissue_rna', 'donor_id2', 'lobe', 'disease_category', 'race', 'gender', 'age', 'sars', 'pathology', 'he_eos',
             'EPX_ihc', 'EDN_ihc', 'MBP_ihc', 'b2D7_ihc', 'IL5Ra_dupNE', 'NE_dupIL5Ra', 'IL5Ra_dupTryp', 'Tryp_dupIL5Ra', 'EPX_num', 'NE_num', 'Tryp_num',
             'IL33_epi', 'IL33_endo', 'IL33_vsm', 'notes', 'colAB']
    rows = []
    for r in range(2, ws.max_row + 1):
        d = dict(zip(names, [ws.cell(r, c).value for c in range(1, 29)])); d['xl_row'] = r; rows.append(d)
    pm = pd.DataFrame(rows); pm = pm[pm.block_id.notna()].copy()
    pm['n_merged_ranges'] = len(ws.merged_cells.ranges)
    pm.to_pickle(f'{CACHE}/postmortem_raw.pkl')
    print('post-mortem blocks:', len(pm), 'donors:', pm.sample_id.nunique(), 'merged ranges:', len(ws.merged_cells.ranges))
    print('done in %.0fs' % (time.time() - t0))
