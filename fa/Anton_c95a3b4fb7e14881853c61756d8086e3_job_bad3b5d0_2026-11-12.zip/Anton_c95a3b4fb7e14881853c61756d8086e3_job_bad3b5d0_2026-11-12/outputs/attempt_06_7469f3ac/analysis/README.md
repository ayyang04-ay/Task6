# AX-1177 portfolio audit: analysis code

Everything in `../AX-1177_portfolio_recommendation.md` is produced by these scripts from the five delivered files in `/tmp/world/filesystem/` (read-only). No other data source is used, except the MSigDB Hallmark and Reactome gene-set definitions shipped offline with the R package `msigdbr` 7.5.1 (step 05 only).

## Run order

```
bash run_all.sh        # about 8 minutes
```

| Step | Script | Environment | What it does |
|---|---|---|---|
| 00 | `00_load_data.py` | singlecell | Reads the four data files as delivered. Parses the large workbook's XML directly so rows hidden by the saved Excel filter are included. |
| 00b | `00b_hidden_content.py` | singlecell | Lists columns and rows hidden in the smaller workbooks as saved. |
| 01 | `01_rnaseq.py` | singlecell | Contrast-level QC; IL-33 signature; reversal by AX-1177; antibody-alone noise floor; implied-standard-error check; 54-gene panel. Writes T1, T2a–c. |
| 02 | `02_serum.py` | singlecell | Serum table QC (multiple-testing denominator, undelivered assays, duplicates); marker classes; join to the cell data; enrichment test. Writes T3a–b. |
| 03 | `03_postmortem.py` | singlecell | Donor-level tissue analysis; block-level comparison; re-classification from pathology text; within-donor association. Writes T4a–b. |
| 04 | `04_figures.py` | singlecell | Figures 1–5. |
| 05 | `05_gsea.R`, `05b_gsea_summary.py` | renv, singlecell | Pre-ranked gene-set enrichment (fgsea). Writes T2d and the enrichment scores quoted in the memo. |
| 06 | `06_data_integrity_log.py` | singlecell | Writes T5 (27 data issues, consequence, handling). |
| 07 | `07_verify_memo_numbers.py` | singlecell | Re-computes and asserts every number quoted in the memo. |
| 08 | `08_build_pdf.py` | core | Renders the memo and figures to PDF. |

`olink_to_hgnc.py` holds the hand-curated map from vendor assay labels to gene symbols (for example `ST2` is `IL1RL1`; `TF` is tissue factor `F3`, not transferrin).

`run_all.sh` writes its intermediates (about 100 MB) to `cache/`, which is not shipped. The numbers it computed on the delivered files are kept in `results/*.json` (one file per data set, plus `hidden_content.json`).

## Definitions used throughout

- **Contrast short names.** `IL33_HUVEC_6` is IL-33 vs vehicle in HUVEC at 6 h. `AXIL33_v_ICIL33_<cell>_<h>` is AX-1177 + IL-33 vs IC119 + IL-33 (the isotype-controlled neutralisation contrast). `AXIL33_v_IL33_<cell>_<h>` is AX-1177 + IL-33 vs IL-33 alone. `AX_v_<IC|PBS|DMSO>_<cell>_<h>` are antibody-alone contrasts.
- **Reversal fraction** is −(AX-1177 effect) / (IL-33 effect) on the log2 scale; 1.0 is complete neutralisation. It is computed against the isotype-controlled contrast, which shares no samples with the IL-33-vs-vehicle contrast. The contrast against IL-33 alone shares the IL-33 arm and is biased towards apparent reversal.
- **Robust IL-33-regulated genes**: FDR < 0.05, more than 2-fold, and moderated t beyond ±8 (or ±5 where stated).
- **Residual IL-33 effect with AX-1177 present** is (IL-33 vs vehicle) + (AX-1177 + IL-33 vs IL-33). This is exact because all contrasts come from one linear model.
- **Implied standard error** is |logFC / t|. `SE_inflation` is its ratio to the running median for genes of similar AveExpr.
- **Core panel criteria** (all required): induced at least 4-fold at 6 h with FDR < 0.01; at least 80% reversed in HUVEC at 6 h (FDR < 0.01 against both comparators); reversed at least 2-fold in HGMEC at 6 h (FDR < 0.05); still induced at least 2-fold and at least half reversed at 24 h (FDR < 0.05); not significant in any of the 16 antibody-alone contrasts; `SE_inflation` below 3.
- **Tissue analysis unit** is the donor. Donor values are the mean of that donor's blocks. Scores written `N+` are taken as N + 0.5, which is the file's own convention in its numeric columns.
- **Pathology-text classes** were assigned by reading each donor's diagnosis list (lung items only); the assignments are hard-coded in `03_postmortem.py` so they can be audited.

## Approximations to be aware of

- The derived isotype-effect contrasts (for example IC119 + IL-33 vs IL-33) use an averaged standard error, because the fitted model object was not delivered. They are used only to look for large effects.
- Serum marker classes (neutrophil activation, type-2, endothelial) were assigned from protein function, not from the data. The lists are in T3b.
- The PDF was generated programmatically and checked by text extraction only; no PDF renderer was available in the analysis environment.
