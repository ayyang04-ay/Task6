#!/usr/bin/env python
"""
AX-1177 portfolio audit -- step 2: clinical serum proteomics (per-assay logistic-regression summary statistics)
and the bridge to the in-vitro endothelial data.
Run after 01_rnaseq.py:  micromamba run -n singlecell python 02_serum.py
"""
import json, sys
import numpy as np, pandas as pd
from scipy import stats
sys.path.insert(0, '/tmp/outputs/analysis')
from olink_to_hgnc import OLINK2HGNC, base_name, OLINK_INFLAMMATION_92

CACHE = '/tmp/outputs/analysis/cache'; TAB = '/tmp/outputs/tables'
s = pd.read_pickle(f'{CACHE}/serum.pkl').copy()
RES = {}
s['rank_delivered'] = np.arange(1, len(s) + 1)
s['panel_short'] = s.panel.str.replace('Olink Target 96 ', '', regex=False).str.replace(r'\(v\.\d+\)', '', regex=True)
s['base'] = s.assay.map(base_name); s['hgnc'] = s.base.map(lambda b: OLINK2HGNC.get(b, b))
s['logOR'] = np.log(s.OR); s['se'] = (np.log(s.u95) - np.log(s.l95)) / (2 * 1.959964); s['z'] = s.logOR / s.se
s['p_wald'] = 2 * stats.norm.sf(s.z.abs())
RES['n_assays_delivered'] = int(len(s)); RES['n_panels'] = int(s.panel.nunique()); RES['n_unique_proteins_by_label'] = int(s.base.nunique())
RES['internal_consistency_max_abs_log10_p_ratio'] = float(np.abs(np.log10(s['p.value'] / s.p_wald)).max())
# group sizes implied by the two undocumented columns (values are multiples of 1/56 and 1/44)
inc0 = np.sort(s.composite_endpoint_0[s.composite_endpoint_0 > 0].unique())[0]; inc1 = np.sort(s.composite_endpoint_1[s.composite_endpoint_1 > 0].unique())[0]
RES['implied_n_without_endpoint'] = int(round(1 / inc0)); RES['implied_n_with_endpoint'] = int(round(1 / inc1))
RES['max_fraction_in_undocumented_columns'] = [float(s.composite_endpoint_0.max()), float(s.composite_endpoint_1.max())]
# BH denominator actually used
p = s['p.value'].values
def bh(p, N):
    return np.minimum.accumulate((p * N / np.arange(1, len(p) + 1))[::-1])[::-1]
N_implied = s['p.value'].iloc[0] / s['adj.p.value'].iloc[0] ** -1 if False else round(float(s['adj.p.value'].iloc[0] / s['p.value'].iloc[0]))
RES['BH_denominator_implied_by_top_row'] = int(N_implied)
RES['BH_max_abs_diff_if_1094'] = float(np.abs(bh(p, len(s)) - s['adj.p.value']).max())
s['implied_full_rank'] = s['p.value'] * N_implied / s['adj.p.value']
exact = (s.implied_full_rank - s.implied_full_rank.round()).abs() < 1e-6
s['n_undelivered_assays_ranked_above'] = np.where(exact, s.implied_full_rank.round() - s.rank_delivered, np.nan)
m = s.loc[exact, ['rank_delivered', 'adj.p.value', 'n_undelivered_assays_ranked_above']]
RES['n_rows_with_exact_rank'] = int(exact.sum())
RES['undelivered_assays_total_lower_bound'] = int(m.n_undelivered_assays_ranked_above.max())
RES['undelivered_assays_with_FDR_lt_0p05'] = int(m.loc[m['adj.p.value'] < 0.05, 'n_undelivered_assays_ranked_above'].max())
RES['first_undelivered_assay_between_delivered_ranks'] = [int(m.loc[m.n_undelivered_assays_ranked_above == 0, 'rank_delivered'].max()), int(m.loc[m.n_undelivered_assays_ranked_above >= 1, 'rank_delivered'].min())]
inflam = set(s.loc[s.panel_short == 'Inflammation', 'base'])
RES['inflammation_panel_assays_absent'] = [a for a in OLINK_INFLAMMATION_92 if a not in inflam and a.replace('IL-', 'IL') not in inflam]
# headline numbers
sig = s['adj.p.value'] < 0.05
RES['n_FDR05'] = int(sig.sum()); RES['n_FDR05_risk_increasing'] = int((sig & (s.OR > 1)).sum()); RES['n_FDR05_protective'] = int((sig & (s.OR < 1)).sum())
RES['frac_OR_gt1'] = float((s.OR > 1).mean()); RES['n_nominal_p05'] = int((s['p.value'] < .05).sum())
RES['bonferroni_survivors'] = s.loc[s['p.value'] < 0.05 / N_implied, 'assay'].tolist()
def row(a):
    r = s[s.assay == a].iloc[0]
    return dict(panel=r.panel_short, OR=float(r.OR), l95=float(r.l95), u95=float(r.u95), p=float(r['p.value']), FDR=float(r['adj.p.value']), z=float(r.z), rank=int(r.rank_delivered))
RES['ST2'] = row('ST2')
RES['duplicates'] = {b: {a: dict(OR=round(float(o), 2), FDR=round(float(f), 4)) for a, o, f in zip(g.assay, g.OR, g['adj.p.value'])} for b, g in s.groupby('base') if len(g) > 1}
RES['n_proteins_on_multiple_panels'] = len(RES['duplicates'])
SETS = {
 'IL-33 / IL-1-family receptor axis': ['ST2', 'IL-18R1', 'IL-1RT2', 'IL-1RT1', 'IL-1ra', 'IL1RL2', 'IL18-INFI', 'IL18-CVDII', 'IL-18BP', 'IL1B'],
 'Type-2 / eosinophil / mast cell': ['IL5-IMO', 'CCL11-INFI', 'CCL11-IMO', 'CCL17', 'CCL24', 'CCL18', 'MCP-4', 'RNASE3', 'TPSAB1', 'FCER2', 'KIT', 'SCF-INFI', 'SCF-CVDII', 'SCF-ONCII', 'IL-5R-alpha', 'IL-4RA', 'IL13RA1', 'SIGLEC6', 'HPGDS', 'CCL27', 'CCL28', 'IL17RB', 'SIGLEC10'],
 'Neutrophil activation / granule': ['HGF', 'HGF-ONCII', 'OSM', 'EN-RAGE', 'PRTN3', 'MPO', 'AZU1', 'LCN2', 'MMP-9', 'CEACAM8', 'DEFA1', 'PGLYRP1', 'RETN', 'CD177', 'TREM1', 'FCAR', 'CLEC5A', 'CLEC4D', 'PI3', 'CHI3L1', 'FCGR3B', 'TNFSF14'],
 'Endothelial activation / coagulation': ['SELE', 'VCAM1', 'ICAM1', 'ICAM-2', 'vWF', 'TM', 'ANGPT2', 'ANGPT1', 'ESM-1', 'TIE2', 'TIE1', 'PECAM-1', 'SYND1', 'CD93', 'CDH5', 'TF', 'TFPI', 'PAI', 't-PA', 'U-PAR', 'SELP', 'PTX3', 'ADM', 'ADAM-TS13', 'VEGFA-INFI', 'VEGFA-ONCII', 'FLT1', 'VEGFR-2', 'NOS3', 'LYVE1', 'ENG', 'ESAM', 'JAM-A', 'PAR-1'],
 'Cardiac / renal injury': ['NT-proBNP-MET', 'NT-proBNP-CVDIII', 'TNNI3', 'MB', 'FABP4', 'KIM1-CVDII', 'KIM1-ODA', 'CST3', 'REN', 'Gal-3', 'IGFBP-7'],
}
RES['sets'] = {}
rows = []
for k, lst in SETS.items():
    d = s[s.assay.isin(lst)]
    assert len(d) == len(lst), (k, set(lst) - set(d.assay))
    RES['sets'][k] = dict(n=int(len(d)), n_FDR05=int((d['adj.p.value'] < .05).sum()), n_p05=int((d['p.value'] < .05).sum()), median_z=float(d.z.median()))
    for r in d.sort_values('p.value').itertuples():
        rows.append(dict(set=k, assay=r.assay, panel=r.panel_short, OR=r.OR, l95=r.l95, u95=r.u95, z=r.z, p=r._6, FDR=r._7))
RES['all_assays_median_z'] = float(s.z.median())
pd.DataFrame(rows).to_csv(f'{TAB}/T3b_serum_marker_classes.csv', index=False)

# ----- bridge to the endothelial transcriptome -----
ann, W = pd.read_pickle(f'{CACHE}/rnaseq_wide.pkl')
G = pd.read_pickle(f'{CACHE}/rnaseq_gene_table.pkl')
sym2ens = ann.reset_index().sort_values('AveExpr', ascending=False).drop_duplicates('symbol').set_index('symbol').ensembl
s['ensembl'] = s.hgnc.map(sym2ens)
RES['n_assays_mapped_to_RNAseq_gene'] = int(s.ensembl.notna().sum())
keep = ['IL33_6_logFC', 'IL33_6_FDR', 'AX_HUVEC_6_logFC', 'AX_HUVEC_6_FDR', 'AX_HGMEC_6_logFC', 'AX_HGMEC_6_FDR', 'IL33_24_logFC', 'IL33_24_FDR', 'AX_HUVEC_24_logFC', 'AX_HUVEC_24_FDR', 'AX_HGMEC_24_logFC', 'reversal_frac_6h', 'SE_inflation', 'core_PD_panel', 'masked_candidate']
B = s.merge(G[keep], left_on='ensembl', right_index=True, how='left')
B['IL33_induced_and_reversed_6h'] = (B.IL33_6_logFC > 1) & (B.IL33_6_FDR < .05) & (B.AX_HUVEC_6_logFC < -1) & (B.AX_HUVEC_6_FDR < .05)
B.drop(columns=['logOR', 'se', 'p_wald', 'base']).to_csv(f'{TAB}/T3a_serum_all_assays_with_invitro_bridge.csv', index=False)
B.to_pickle(f'{CACHE}/serum_bridge.pkl')
# enrichment test at protein (gene) level
g = B[B.ensembl.notna()].groupby('hgnc').agg(z=('z', 'mean'), minFDR=('adj.p.value', 'min'), ind=('IL33_induced_and_reversed_6h', 'first'), up6=('IL33_6_logFC', 'first'), q6=('IL33_6_FDR', 'first'))
g['risk_hit'] = (g.minFDR < .05) & (g.z > 0)
a, b = g[g.ind], g[~g.ind]
ct = [[int(a.risk_hit.sum()), int((~a.risk_hit).sum())], [int(b.risk_hit.sum()), int((~b.risk_hit).sum())]]
RES['enrichment'] = dict(n_proteins=int(len(g)), n_IL33_induced_reversed=int(len(a)), hits_in_set=ct[0][0], hits_outside=ct[1][0], n_outside=int(len(b)),
                         fisher_OR=float(stats.fisher_exact(ct)[0]), fisher_p=float(stats.fisher_exact(ct)[1]), mean_z_in=float(a.z.mean()), mean_z_out=float(b.z.mean()),
                         mannwhitney_p=float(stats.mannwhitneyu(a.z, b.z).pvalue))
RES['overlap_proteins_FDR05'] = sorted(a.index[a.risk_hit].tolist())
RES['key_assays'] = {a_: row(a_) for a_ in ['HGF', 'IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO', 'OPG-INFI', 'OPG-CVDIII', 'CCL20', 'IL-18R1', 'MCP-3', 'CSF-1', 'IL8', 'TF', 'PTX3', 'SELE', 'ICAM1', 'VCAM1', 'G-CSF', 'CXCL1-INFI', 'CXCL1-CVDII', 'CXCL5', 'CXCL6', 'CX3CL1', 'TNF', 'IL1B', 'CTSS', 'IL5-IMO', 'CCL11-INFI', 'CCL17', 'TPSAB1', 'RNASE3', 'NT-proBNP-MET', 'NT-proBNP-CVDIII', 'vWF', 'IL-1RT2', 'IL-4RA']}
json.dump(RES, open(f'{CACHE}/results_serum.json', 'w'), indent=1)
print(json.dumps({k: v for k, v in RES.items() if k not in ('duplicates', 'key_assays')}, indent=1))
