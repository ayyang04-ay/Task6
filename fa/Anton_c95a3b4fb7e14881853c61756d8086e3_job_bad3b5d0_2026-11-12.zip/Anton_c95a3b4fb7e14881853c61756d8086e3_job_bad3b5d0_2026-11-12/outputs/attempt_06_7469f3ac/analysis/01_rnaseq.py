#!/usr/bin/env python
"""
AX-1177 portfolio audit -- step 1: in-vitro transcriptomics (limma contrast tables).
Run after 00_load_data.py:  micromamba run -n singlecell python 01_rnaseq.py
Outputs: tables/T1_*.csv, tables/T2_*.csv, cache/rnaseq_wide.pkl, cache/results_rnaseq.json
"""
import json, itertools, os
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

CACHE = '/tmp/outputs/analysis/cache'; TAB = '/tmp/outputs/tables'; os.makedirs(TAB, exist_ok=True)
L = pd.read_pickle(f'{CACHE}/rnaseq_long.pkl')
RES = {}

SHORT = {
 'IL33_vs_Nontreated_HUVEC_6_hrs': 'IL33_HUVEC_6', 'IL33_vs_Nontreated_HUVEC_24_hrs': 'IL33_HUVEC_24',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs': 'AXIL33_v_ICIL33_HUVEC_6', 'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs': 'AXIL33_v_ICIL33_HUVEC_24',
 'Compound_47_IL33_vs_IL33_HUVEC_6hrs': 'AXIL33_v_IL33_HUVEC_6', 'Compound_47_IL33_vs_IL33_HUVEC_24hrs': 'AXIL33_v_IL33_HUVEC_24',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs': 'AXIL33_v_ICIL33_HGMEC_6', 'Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs': 'AXIL33_v_ICIL33_HGMEC_24',
 'Compound_47_IL33_vs_IL33_HGMEC_6hrs': 'AXIL33_v_IL33_HGMEC_6', 'Compound_47_IL33_vs_IL33_HGMEC_24hrs': 'AXIL33_v_IL33_HGMEC_24',
 'Compound_47_vs_IC119_HUVEC_6hrs': 'AX_v_IC_HUVEC_6', 'Compound_47_vs_IC119_HUVEC_24hrs': 'AX_v_IC_HUVEC_24',
 'Compound_47_vs_IC119_HGMEC_6hrs': 'AX_v_IC_HGMEC_6', 'Compound_47_vs_IC119_HGMEC_24hrs': 'AX_v_IC_HGMEC_24',
 'Compound_47_vs_IC119_A549_6hrs': 'AX_v_IC_A549_6', 'Compound_47_vs_IC119_A549_24hrs': 'AX_v_IC_A549_24',
 'Compound_47_vs_IC119_MCF7_6hrs': 'AX_v_IC_MCF7_6', 'Compound_47_vs_IC119_MCF7_24hrs': 'AX_v_IC_MCF7_24',
 'Compound_47_vs_DMSO_A549_6hrs': 'AX_v_DMSO_A549_6', 'Compound_47_vs_DMSO_A549_24hrs': 'AX_v_DMSO_A549_24',
 'Compound_47_vs_DMSO_MCF7_6hrs': 'AX_v_DMSO_MCF7_6', 'Compound_47_vs_DMSO_MCF7_24hrs': 'AX_v_DMSO_MCF7_24',
 'Compound_47_vs_PBS_A549_6hrs': 'AX_v_PBS_A549_6', 'Compound_47_vs_PBS_A549_24hrs': 'AX_v_PBS_A549_24',
 'Compound_47_vs_PBS_MCF7_6hrs': 'AX_v_PBS_MCF7_6', 'Compound_47_vs_PBS_MCF7_24hrs': 'AX_v_PBS_MCF7_24'}
L['c'] = L.Comparison.map(SHORT); assert L.c.notna().all()
ann = L.drop_duplicates('ensembl').set_index('ensembl')[['symbol', 'entrez', 'gene_name', 'AveExpr']]
W = {v: L.pivot(index='ensembl', columns='c', values=v)[list(SHORT.values())] for v in ['logFC', 't', 'P.Value', 'adj.P.Val']}
lfc, t, p, q = W['logFC'], W['t'], W['P.Value'], W['adj.P.Val']
se = (lfc / t).abs()
pd.to_pickle((ann, W), f'{CACHE}/rnaseq_wide.pkl')
for k_, nm_ in [('t', 't'), ('logFC', 'logFC')]:          # ranking inputs for 05_gsea.R
    d_ = W[k_].copy(); d_.insert(0, 'symbol', ann.symbol); d_.insert(1, 'AveExpr', ann.AveExpr); d_.to_csv(f'{CACHE}/rnaseq_wide_{nm_}.csv')
RES['n_genes'] = int(len(ann)); RES['n_contrasts'] = int(lfc.shape[1])

# ---------- QC of the delivered statistics ----------
qc = []
for c in lfc.columns:
    bh = multipletests(p[c].values, method='fdr_bh')[1]
    m = (t[c].abs() > 1) & (t[c].abs() < 6)
    grid = np.linspace(40, 140, 1001)
    err = [np.nanmax(np.abs(np.log(2 * stats.t.sf(t[c][m].abs(), df)) - np.log(p[c][m]))) for df in grid]
    s = q[c] < 0.05
    qc.append(dict(contrast=c, comparison_label=[k for k, v in SHORT.items() if v == c][0],
                   n_FDR05=int(s.sum()), n_up=int((s & (lfc[c] > 0)).sum()), n_down=int((s & (lfc[c] < 0)).sum()),
                   n_FDR05_absLFC_gt1=int((s & (lfc[c].abs() > 1)).sum()),
                   n_FDR05_expressed_LFCgt0p5=int((s & (ann.AveExpr > 2) & (lfc[c].abs() > 0.5)).sum()),
                   frac_P_lt_0p05=float((p[c] < 0.05).mean()), n_P_lt_1e5=int((p[c] < 1e-5).sum()),
                   BH_recomputed_max_abs_diff=float(np.abs(bh - q[c].values).max()), implied_df=float(grid[int(np.argmin(err))])))
QC = pd.DataFrame(qc); QC.to_csv(f'{TAB}/T1_rnaseq_contrast_summary.csv', index=False)
alone = [c for c in lfc.columns if c.startswith('AX_v_')]
RES['antibody_alone_nFDR05_range'] = [int(QC[QC.contrast.isin(alone)].n_FDR05.min()), int(QC[QC.contrast.isin(alone)].n_FDR05.max())]
RES['antibody_alone_nFDR05_median'] = float(QC[QC.contrast.isin(alone)].n_FDR05.median())
RES['antibody_alone_expressed_LFC0p5_max'] = int(QC[QC.contrast.isin(alone)].n_FDR05_expressed_LFCgt0p5.max())
RES['implied_df_range'] = [float(QC.implied_df.min()), float(QC.implied_df.max())]
RES['DE_counts'] = {r.contrast: dict(n=r.n_FDR05, up=r.n_up, down=r.n_down, abs_lfc_gt1=r.n_FDR05_absLFC_gt1) for r in QC.itertuples()}

# reproducibility of antibody-alone hits across independent settings (cell line x time)
sig = {c: set(q.index[q[c] < 0.05]) for c in alone}
key = lambda c: tuple(c.split('_')[-2:])
rep = {}
for c in alone:
    for g in sig[c]:
        rep.setdefault(g, {}).setdefault(key(c), []).append(float(lfc.loc[g, c]))
multi = {g: v for g, v in rep.items() if len(v) >= 2}
same_dir_big = [ann.symbol[g] for g, v in multi.items()
                if len({np.sign(np.mean(x)) for x in v.values()}) == 1 and min(abs(np.mean(x)) for x in v.values()) > 0.5]
RES['antibody_alone_genes_sig_in_2plus_settings'] = len(multi)
RES['antibody_alone_genes_sig_2plus_same_direction_absLFC_gt0p5'] = same_dir_big

# ---------- IL-33 signature and its reversal ----------
def rev_summary(il, rv, mask):
    x, y = lfc[il][mask], lfc[rv][mask]; r = -y / x
    return dict(n=int(mask.sum()), median_reversal=float(r.median()), q25=float(r.quantile(.25)), q75=float(r.quantile(.75)),
                frac_ge_80pct=float((r >= .8).mean()), frac_lt_20pct=float((r < .2).mean()), pearson_r=float(np.corrcoef(x, y)[0, 1]),
                ols_slope=float(np.polyfit(x, y, 1)[0]))
RES['reversal'] = {}
for tp in ['6', '24']:
    il = f'IL33_HUVEC_{tp}'
    hc_up = (t[il] > 8) & (lfc[il] > 1)            # high-confidence induced genes
    hc_dn = (t[il] < -8) & (lfc[il] < -1)
    RES['reversal'][tp] = {
        'hc_up_HUVEC_vs_isotype': rev_summary(il, f'AXIL33_v_ICIL33_HUVEC_{tp}', hc_up),
        'hc_up_HUVEC_vs_IL33alone': rev_summary(il, f'AXIL33_v_IL33_HUVEC_{tp}', hc_up),
        'hc_up_HGMEC_vs_isotype': rev_summary(il, f'AXIL33_v_ICIL33_HGMEC_{tp}', hc_up),
        'hc_up_HGMEC_vs_IL33alone': rev_summary(il, f'AXIL33_v_IL33_HGMEC_{tp}', hc_up),
        'hc_down_HUVEC_vs_isotype': rev_summary(il, f'AXIL33_v_ICIL33_HUVEC_{tp}', hc_dn)}
    # directional concordance among FDR-significant genes
    for cell in ['HUVEC', 'HGMEC']:
        rv = f'AXIL33_v_ICIL33_{cell}_{tp}'
        A_up, A_dn = (q[il] < .05) & (lfc[il] > 0), (q[il] < .05) & (lfc[il] < 0)
        B_up, B_dn = (q[rv] < .05) & (lfc[rv] > 0), (q[rv] < .05) & (lfc[rv] < 0)
        RES['reversal'][tp][f'concordance_{cell}'] = dict(IL33_up=int(A_up.sum()), IL33_down=int(A_dn.sum()),
            up_then_down=int((A_up & B_dn).sum()), down_then_up=int((A_dn & B_up).sum()),
            discordant=int((A_up & B_up).sum() + (A_dn & B_dn).sum()))
    # residual IL-33 effect with antibody present: (IL33+AX) - vehicle = (IL33 - veh) + (IL33+AX - IL33); exact by linearity of contrasts
    resid = lfc[il] + lfc[f'AXIL33_v_IL33_HUVEC_{tp}']
    hc5 = (q[il] < .05) & (lfc[il] > 1) & (t[il] > 5)
    RES['reversal'][tp]['residual_vs_vehicle_hc_up'] = dict(n=int(hc5.sum()), median=float(resid[hc5].median()), q25=float(resid[hc5].quantile(.25)), q75=float(resid[hc5].quantile(.75)), n_resid_gt1=int((resid[hc5] > 1).sum()))
# decay 6h -> 24h
hc6 = (t['IL33_HUVEC_6'] > 8) & (lfc['IL33_HUVEC_6'] > 1)
RES['decay'] = dict(n=int(hc6.sum()), median_lfc_6h=float(lfc['IL33_HUVEC_6'][hc6].median()), median_lfc_24h=float(lfc['IL33_HUVEC_24'][hc6].median()),
                    median_ratio_24_over_6=float((lfc['IL33_HUVEC_24'][hc6] / lfc['IL33_HUVEC_6'][hc6]).median()),
                    n_still_2fold_FDR05_at_24h=int(((lfc['IL33_HUVEC_24'] > 1) & (q['IL33_HUVEC_24'] < .05))[hc6].sum()))
# NF-kB core module: HGMEC amplitude relative to HUVEC
core = ['NFKBIA', 'TNFAIP3', 'NFKB1', 'NFKB2', 'RELB', 'TRAF1', 'NFKBIZ', 'IRAK2', 'TIFA', 'BIRC3', 'ZC3H12A', 'TNIP1']
ids = [ann.index[ann.symbol == g][0] for g in core]
nf = pd.DataFrame({'symbol': core, 'IL33_HUVEC_6': lfc.loc[ids, 'IL33_HUVEC_6'].values, 'AX_HUVEC_6': lfc.loc[ids, 'AXIL33_v_ICIL33_HUVEC_6'].values,
                   'AX_HGMEC_6': lfc.loc[ids, 'AXIL33_v_ICIL33_HGMEC_6'].values, 'AX_HUVEC_24': lfc.loc[ids, 'AXIL33_v_ICIL33_HUVEC_24'].values,
                   'AX_HGMEC_24': lfc.loc[ids, 'AXIL33_v_ICIL33_HGMEC_24'].values})
nf['HGMEC_over_HUVEC_6'] = nf.AX_HGMEC_6 / nf.AX_HUVEC_6; nf['HGMEC_over_HUVEC_24'] = nf.AX_HGMEC_24 / nf.AX_HUVEC_24
RES['nfkb_core_HGMEC_over_HUVEC'] = dict(median_6h=float(nf.HGMEC_over_HUVEC_6.median()), min_6h=float(nf.HGMEC_over_HUVEC_6.min()), max_6h=float(nf.HGMEC_over_HUVEC_6.max()),
                                         median_24h=float(nf.HGMEC_over_HUVEC_24.median()))
nf.to_csv(f'{TAB}/T2c_nfkb_core_module.csv', index=False)

# ---------- variance artefact: implied SE = logFC / t ----------
huv = [c for c in lfc.columns if 'HUVEC' in c]
S = pd.DataFrame({'symbol': ann.symbol, 'AveExpr': ann.AveExpr, 'SE_HUVEC': se[huv].median(axis=1)}).sort_values('AveExpr')
S['SE_expected'] = np.exp(pd.Series(np.log(S.SE_HUVEC.values)).rolling(501, center=True, min_periods=50).median().values)
S['SE_inflation'] = S.SE_HUVEC / S.SE_expected
S = S.reindex(ann.index)
RES['SE_inflation'] = dict(n_gt5x=int((S.SE_inflation > 5).sum()), n_gt10x=int((S.SE_inflation > 10).sum()), n_gt100x=int((S.SE_inflation > 100).sum()),
                           max=float(S.SE_inflation.max()), max_gene=str(S.symbol[S.SE_inflation.idxmax()]))
S.to_pickle(f'{CACHE}/rnaseq_se.pkl')

# ---------- gene-level master table ----------
G = pd.DataFrame({'symbol': ann.symbol, 'gene_name': ann.gene_name, 'AveExpr_all114': ann.AveExpr,
    'IL33_6_logFC': lfc.IL33_HUVEC_6, 'IL33_6_t': t.IL33_HUVEC_6, 'IL33_6_FDR': q.IL33_HUVEC_6,
    'AX_HUVEC_6_logFC': lfc.AXIL33_v_ICIL33_HUVEC_6, 'AX_HUVEC_6_FDR': q.AXIL33_v_ICIL33_HUVEC_6,
    'AX_HUVEC_6_vsIL33alone_logFC': lfc.AXIL33_v_IL33_HUVEC_6, 'AX_HUVEC_6_vsIL33alone_FDR': q.AXIL33_v_IL33_HUVEC_6,
    'AX_HGMEC_6_logFC': lfc.AXIL33_v_ICIL33_HGMEC_6, 'AX_HGMEC_6_FDR': q.AXIL33_v_ICIL33_HGMEC_6,
    'IL33_24_logFC': lfc.IL33_HUVEC_24, 'IL33_24_t': t.IL33_HUVEC_24, 'IL33_24_FDR': q.IL33_HUVEC_24,
    'AX_HUVEC_24_logFC': lfc.AXIL33_v_ICIL33_HUVEC_24, 'AX_HUVEC_24_FDR': q.AXIL33_v_ICIL33_HUVEC_24,
    'AX_HGMEC_24_logFC': lfc.AXIL33_v_ICIL33_HGMEC_24, 'AX_HGMEC_24_FDR': q.AXIL33_v_ICIL33_HGMEC_24,
    'AXalone_min_FDR_16contrasts': q[alone].min(axis=1), 'AXalone_max_abs_logFC_endothelial': lfc[[c for c in alone if 'HUVEC' in c or 'HGMEC' in c]].abs().max(axis=1),
    'SE_inflation': S.SE_inflation})
G['reversal_frac_6h'] = -G.AX_HUVEC_6_logFC / G.IL33_6_logFC
G['reversal_frac_24h'] = -G.AX_HUVEC_24_logFC / G.IL33_24_logFC
G['residual_vs_vehicle_6h'] = lfc.IL33_HUVEC_6 + lfc.AXIL33_v_IL33_HUVEC_6
G['residual_vs_vehicle_24h'] = lfc.IL33_HUVEC_24 + lfc.AXIL33_v_IL33_HUVEC_24
# core in-vitro PD panel: pre-specified, all criteria must hold
c1 = (G.IL33_6_logFC >= 2) & (G.IL33_6_FDR < .01)
c2 = (G.reversal_frac_6h >= .8) & (G.AX_HUVEC_6_FDR < .01) & (G.AX_HUVEC_6_vsIL33alone_FDR < .01)
c3 = (G.AX_HGMEC_6_logFC <= -1) & (G.AX_HGMEC_6_FDR < .05)
c4 = (G.IL33_24_logFC >= 1) & (G.IL33_24_FDR < .05) & (G.AX_HUVEC_24_logFC <= -.5 * G.IL33_24_logFC) & (G.AX_HUVEC_24_FDR < .05)
c5 = G.AXalone_min_FDR_16contrasts > .05
c6 = G.SE_inflation < 3
G['core_PD_panel'] = c1 & c2 & c3 & c4 & c5 & c6
RES['core_panel_funnel'] = dict(induced_6h=int(c1.sum()), reversed_6h=int((c1 & c2).sum()), reversed_in_HGMEC_6h=int((c1 & c2 & c3).sum()),
                                persistent_24h=int((c1 & c2 & c3 & c4).sum()), silent_to_antibody_alone=int((c1 & c2 & c3 & c4 & c5).sum()), se_ok=int(G.core_PD_panel.sum()))
# "masked" responders: large, mirrored effects that the delivered model does not call significant
G['variance_inflated_responder'] = (G.SE_inflation > 5) & (G.IL33_6_logFC.abs() > 1.5) & (np.sign(G.IL33_6_logFC) != np.sign(G.AX_HUVEC_6_logFC)) & (G.AX_HUVEC_6_logFC.abs() > 1)
G['masked_candidate'] = G.variance_inflated_responder & (G.IL33_6_FDR >= .05)      # large mirrored effect that the delivered model does NOT call significant
RES['masked_candidates'] = sorted(G.symbol[G.masked_candidate].tolist()); RES['variance_inflated_but_significant'] = sorted(G.symbol[G.variance_inflated_responder & ~G.masked_candidate].tolist())
G.to_pickle(f'{CACHE}/rnaseq_gene_table.pkl')
G[G.core_PD_panel | G.variance_inflated_responder].sort_values(['variance_inflated_responder', 'IL33_6_logFC'], ascending=[True, False]).round(4).to_csv(f'{TAB}/T2a_invitro_PD_panel.csv')
G[(G.IL33_6_FDR < .05) | (G.IL33_24_FDR < .05)].sort_values('IL33_6_t', ascending=False).round(4).to_csv(f'{TAB}/T2b_IL33_signature_all_genes.csv')

# model-free replication: same direction and size in five contrasts that share no samples pairwise except within timepoint design
#   (IL-33 vs vehicle HUVEC 6 h and 24 h; AX-1177+IL-33 vs IC119+IL-33 in HUVEC 6 h, HUVEC 24 h and HGMEC 6 h)
RES['replication'] = {}
for thr in (1, 2, 3):
    Rm = (lfc.IL33_HUVEC_6 > thr) & (lfc.AXIL33_v_ICIL33_HUVEC_6 < -thr) & (lfc.AXIL33_v_ICIL33_HGMEC_6 < -thr) & (lfc.IL33_HUVEC_24 > thr) & (lfc.AXIL33_v_ICIL33_HUVEC_24 < -thr)
    sg = Rm & (q.IL33_HUVEC_6 < .05)
    al8 = ['AX_v_IC_HUVEC_6', 'AX_v_IC_HUVEC_24', 'AX_v_IC_HGMEC_6', 'AX_v_IC_HGMEC_24', 'AX_v_IC_A549_6', 'AX_v_IC_A549_24', 'AX_v_IC_MCF7_6', 'AX_v_IC_MCF7_24']
    null = []
    for combo in itertools.combinations(al8, 5):
        m_ = np.ones(len(lfc), bool)
        for c_, s_ in zip(combo, (1, -1, -1, 1, -1)): m_ &= (s_ * lfc[c_] > thr).values
        null.append(int(m_.sum()))
    RES['replication'][str(thr)] = dict(n_genes=int(Rm.sum()), n_FDR05=int(sg.sum()), not_significant=sorted(ann.symbol[Rm & ~sg].tolist()), null_combinations=len(null), null_max=int(max(null)), null_mean=float(np.mean(null)))
G['replicated_4fold_in_5_contrasts'] = (lfc.IL33_HUVEC_6 > 2) & (lfc.AXIL33_v_ICIL33_HUVEC_6 < -2) & (lfc.AXIL33_v_ICIL33_HGMEC_6 < -2) & (lfc.IL33_HUVEC_24 > 2) & (lfc.AXIL33_v_ICIL33_HUVEC_24 < -2)
G.to_pickle(f'{CACHE}/rnaseq_gene_table.pkl')
G[G.core_PD_panel | G.variance_inflated_responder].sort_values(['variance_inflated_responder', 'IL33_6_logFC'], ascending=[True, False]).round(4).to_csv(f'{TAB}/T2a_invitro_PD_panel.csv')
# key genes for the memo
keyg = ['CCL20', 'CSF3', 'CSF2', 'CXCL2', 'CXCL3', 'CXCL5', 'CXCL6', 'CX3CL1', 'IL6', 'TNFRSF11B', 'IL18R1', 'CSF1', 'CCL7', 'IL1B', 'F3', 'ICAM1', 'SELE', 'VCAM1', 'CXCL8', 'CXCL1', 'PTX3', 'IL1RL1', 'NFKBIA', 'TNFAIP3', 'TRAF1', 'IL33']
RES['key_genes'] = {}
for g in keyg:
    i = ann.index[ann.symbol == g][0]; r = G.loc[i]
    RES['key_genes'][g] = {k: (None if pd.isna(r[k]) else float(r[k])) for k in ['IL33_6_logFC', 'IL33_6_t', 'IL33_6_FDR', 'AX_HUVEC_6_logFC', 'AX_HUVEC_6_FDR', 'AX_HGMEC_6_logFC', 'AX_HGMEC_6_FDR', 'IL33_24_logFC', 'IL33_24_FDR', 'AX_HUVEC_24_logFC', 'AX_HGMEC_24_logFC', 'SE_inflation', 'reversal_frac_6h']}
# type-2 genes
RES['type2_genes'] = {g: (None if (ann.symbol == g).sum() == 0 else dict(IL33_6_logFC=float(G.loc[ann.index[ann.symbol == g][0], 'IL33_6_logFC']), IL33_6_FDR=float(G.loc[ann.index[ann.symbol == g][0], 'IL33_6_FDR'])))
                      for g in ['IL5', 'IL13', 'IL4', 'CCL11', 'CCL24', 'CCL26', 'CCL17', 'CCL22', 'TSLP', 'POSTN', 'IL9']}
# dose arithmetic from the annex
RES['molar'] = dict(antibody_nM=10e-6 / 146e3 * 1e9 * 1e3 / 1e3, IL33_nM=30e-9 / 18.1e3 * 1e9 * 1e3 / 1e3)
RES['molar']['antibody_nM'] = 10e-3 / 146e3 * 1e9      # 10 ug/mL = 10e-3 g/L ; /146e3 g/mol -> mol/L ; *1e9 -> nM
RES['molar']['IL33_nM'] = 30e-6 / 18.1e3 * 1e9         # 30 ng/mL = 30e-6 g/L
RES['molar']['molar_excess'] = RES['molar']['antibody_nM'] / RES['molar']['IL33_nM']
json.dump(RES, open(f'{CACHE}/results_rnaseq.json', 'w'), indent=1)
print(json.dumps(RES, indent=1)[:6000])
