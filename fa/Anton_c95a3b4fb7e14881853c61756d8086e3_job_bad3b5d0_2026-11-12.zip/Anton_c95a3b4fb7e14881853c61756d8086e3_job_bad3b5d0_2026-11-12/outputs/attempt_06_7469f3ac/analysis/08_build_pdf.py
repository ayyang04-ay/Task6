#!/usr/bin/env python
"""AX-1177 portfolio audit -- step 8: render the Markdown memo plus the five figures into one PDF.
Run:  micromamba run -n core python 08_build_pdf.py"""
import re, os
import matplotlib
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, NextPageTemplate, HRFlowable, KeepTogether

OUT = '/tmp/outputs'
fd = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
pdfmetrics.registerFont(TTFont('DV', f'{fd}/DejaVuSans.ttf')); pdfmetrics.registerFont(TTFont('DV-B', f'{fd}/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DV-I', f'{fd}/DejaVuSans-Oblique.ttf')); pdfmetrics.registerFont(TTFont('DV-BI', f'{fd}/DejaVuSans-BoldOblique.ttf'))
pdfmetrics.registerFont(TTFont('DV-M', f'{fd}/DejaVuSansMono.ttf'))
pdfmetrics.registerFontFamily('DV', normal='DV', bold='DV-B', italic='DV-I', boldItalic='DV-BI')
base = ParagraphStyle('base', fontName='DV', fontSize=8.4, leading=11.1, alignment=TA_LEFT, spaceAfter=3.5)
h1 = ParagraphStyle('h1', parent=base, fontName='DV-B', fontSize=14, leading=17, spaceAfter=8)
h2 = ParagraphStyle('h2', parent=base, fontName='DV-B', fontSize=11, leading=14, spaceBefore=8, spaceAfter=5, textColor=colors.HexColor('#1f3a5f'), keepWithNext=1)
bul = ParagraphStyle('bul', parent=base, leftIndent=12, bulletIndent=2, spaceAfter=2, bulletFontName='DV', bulletFontSize=8.4)
num = ParagraphStyle('num', parent=base, leftIndent=14, bulletIndent=0, spaceAfter=2, bulletFontName='DV', bulletFontSize=8.4)
cell = ParagraphStyle('cell', parent=base, fontSize=7.3, leading=9.3, spaceAfter=0)
cellh = ParagraphStyle('cellh', parent=cell, fontName='DV-B')
cap = ParagraphStyle('cap', parent=base, fontSize=8, leading=10.5, textColor=colors.HexColor('#333333'))

def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'`([^`]+)`', r'<font face="DV-M" size="7.2">\1</font>', t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'<i>\1</i>', t)
    return t

def md_table(lines, width):
    rows = [[c.strip() for c in ln.strip().strip('|').split('|')] for ln in lines if not re.match(r'^\|\s*-{2,}', ln)]
    ncol = len(rows[0])
    presets = {3: [.05, .27, .68] if rows[0][0] == '#' else [.30, .35, .35], 2: [.30, .70], 4: [.22, .26, .26, .26]}
    w = presets.get(ncol, [1 / ncol] * ncol)
    if ncol == 4 and rows[0][0] == 'Marker': w = [.19, .26, .21, .34]
    if ncol == 4 and rows[0][0] == 'Positioning': w = [.24, .29, .29, .18]
    if ncol == 2 and rows[0][0] == 'File': w = [.42, .58]
    data = [[Paragraph(inline(c), cellh if i == 0 else cell) for c in r] for i, r in enumerate(rows)]
    tb = Table(data, colWidths=[x * width for x in w], repeatRows=1)
    tb.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e8ecf1')), ('GRID', (0, 0), (-1, -1), .4, colors.HexColor('#b5bcc6')),
                            ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 4), ('RIGHTPADDING', (0, 0), (-1, -1), 4),
                            ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3)]))
    return tb

def build():
    W, H = A4; margin = 1.7 * cm; fw = W - 2 * margin
    LW, LH = landscape(A4)
    def footer(canvas, doc):
        canvas.saveState(); canvas.setFont('DV', 7); canvas.setFillColor(colors.HexColor('#666666'))
        w_ = canvas._pagesize[0]
        canvas.drawString(margin, 1.0 * cm, 'AX-1177 portfolio audit: recommendation and forward plan. Based only on the delivered AX-1177 data files.')
        canvas.drawRightString(w_ - margin, 1.0 * cm, f'page {doc.page}'); canvas.restoreState()
    doc = BaseDocTemplate(f'{OUT}/AX-1177_portfolio_recommendation.pdf', pagesize=A4, leftMargin=margin, rightMargin=margin, topMargin=1.6 * cm, bottomMargin=1.7 * cm,
                          title='AX-1177 portfolio audit: recommendation and forward plan', author='')
    doc.addPageTemplates([PageTemplate(id='portrait', frames=[Frame(margin, 1.7 * cm, fw, H - 3.3 * cm, id='p')], onPage=footer, pagesize=A4),
                          PageTemplate(id='landscape', frames=[Frame(1.2 * cm, 1.5 * cm, LW - 2.4 * cm, LH - 2.7 * cm, id='l')], onPage=footer, pagesize=landscape(A4))])
    story = []
    lines = open(f'{OUT}/AX-1177_portfolio_recommendation.md', encoding='utf-8').read().split('\n')
    i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith('# '): story.append(Paragraph(inline(ln[2:]), h1))
        elif ln.startswith('## '): story.append(Paragraph(inline(ln[3:]), h2))
        elif ln.strip() == '---': story.append(HRFlowable(width='100%', thickness=.5, color=colors.HexColor('#b5bcc6'), spaceBefore=3, spaceAfter=3))
        elif ln.startswith('|'):
            blk = []
            while i < len(lines) and lines[i].startswith('|'): blk.append(lines[i]); i += 1
            story.append(md_table(blk, fw)); story.append(Spacer(1, 5)); continue
        elif re.match(r'^- ', ln): story.append(Paragraph(inline(ln[2:]), bul, bulletText='•'))
        elif re.match(r'^\d+\. ', ln):
            n_, txt = ln.split('. ', 1); story.append(Paragraph(inline(txt), num, bulletText=n_ + '.'))
        elif ln.strip() == '': pass
        else: story.append(Paragraph(inline(ln), base))
        i += 1
    caps = [('Fig1_IL33_signature_reversal.png', 'Figure 1. Each dot is a gene. Horizontal axis: change caused by IL-33 in HUVEC. Vertical axis: change caused by adding AX-1177 to IL-33, against the isotype control plus IL-33. Dots on the dashed line are fully neutralised. HGMEC had no vehicle arm, so panels C and D borrow the horizontal axis from HUVEC. Source: Tables T1, T2a, T2b.'),
            ('Fig2_PD_biomarker_panel.png', 'Figure 2. Candidate pharmacodynamic markers. Left block: log2 fold changes in cells (asterisk: FDR < 0.05). Right: the same protein in patient serum, where it was measured. Group C genes show large mirrored effects that the delivered model does not call significant and need re-analysis. Source: Tables T2a, T3a.'),
            ('Fig3_serum_proteomics.png', 'Figure 3. Serum proteomics at enrolment. A: every delivered assay by panel. B: odds ratios for selected marker classes. Odds ratios are per log unit of each assay and are not comparable in size between assays. Source: Tables T3a, T3b.'),
            ('Fig4_postmortem_lung.png', 'Figure 4. Post-mortem lung. A to D: one dot per donor (mean of that donor\'s blocks). E: block scores centred on each donor\'s mean. F: the same comparison computed per block and per donor. Source: Tables T4a, T4b.'),
            ('Fig5_rnaseq_statistics_QC.png', 'Figure 5. Properties of the delivered RNA-seq statistics. A: genes called at FDR < 0.05 per contrast; antibody-alone contrasts mark the noise floor. B: genes whose implied standard error is more than five times that of genes of similar abundance (orange). Source: Table T1.')]
    for fn, c in caps:
        story += [NextPageTemplate('landscape'), PageBreak()]
        from PIL import Image as PI
        iw, ih = PI.open(f'{OUT}/figures/{fn}').size
        maxw, maxh = LW - 2.4 * cm, LH - 2.7 * cm - 1.6 * cm
        sc = min(maxw / iw, maxh / ih)
        story += [Image(f'{OUT}/figures/{fn}', width=iw * sc, height=ih * sc), Spacer(1, 4), Paragraph(c, cap)]
    doc.build(story)
    print('PDF written')
if __name__ == '__main__':
    build()
