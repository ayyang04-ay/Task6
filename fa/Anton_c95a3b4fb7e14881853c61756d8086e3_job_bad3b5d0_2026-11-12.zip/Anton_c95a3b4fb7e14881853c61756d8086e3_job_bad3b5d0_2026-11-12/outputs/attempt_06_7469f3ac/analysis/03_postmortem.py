#!/usr/bin/env python
"""
AX-1177 portfolio audit -- step 3: post-mortem lung immunohistochemistry.
Unit of inference is the DONOR (n=31), not the histology block (n=74).
Run after 00_load_data.py:  micromamba run -n singlecell python 03_postmortem.py
"""
import json, re, warnings
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
warnings.filterwarnings('ignore')
CACHE = '/tmp/outputs/analysis/cache'; TAB = '/tmp/outputs/tables'
pm = pd.read_pickle(f'{CACHE}/postmortem_raw.pkl').copy()
RES = {}

def num(v):
    """numeric value as recorded: 'N+' -> N+0.5 (the file's own convention in columns U-W), formula evaluated, ND/N/A -> NaN"""
    if v is None: return np.nan
    if isinstance(v, (int, float)): return float(v)
    s = str(v).strip()
    if s in ('N/A', 'ND', 'NA', ''): return np.nan
    if s.startswith('='): return float(eval(s[1:], {'__builtins__': {}}))
    m = re.match(r'^(\d)\+$', s)
    return float(m.group(1)) + 0.5 if m else float(s)
def grade(v):
    """ordinal grade 0-5 from '3+' strings"""
    if v is None: return np.nan
    m = re.match(r'^(\d)\+?$', str(v).strip())
    return float(m.group(1)) if m else np.nan

RES['formula_cells'] = {f'row{r.xl_row}_IL33_epi': r.IL33_epi for r in pm.itertuples() if isinstance(r.IL33_epi, str) and r.IL33_epi.startswith('=')}
for c in ['IL33_epi', 'IL33_endo', 'IL33_vsm', 'EPX_num', 'NE_num', 'Tryp_num']: pm[c + '_v'] = pm[c].map(num)
for c in ['EPX_ihc', 'EDN_ihc', 'MBP_ihc', 'b2D7_ihc', 'IL5Ra_dupNE', 'NE_dupIL5Ra', 'IL5Ra_dupTryp', 'Tryp_dupIL5Ra']: pm[c + '_g'] = pm[c].map(grade)
pm['he_eos_b'] = pm.he_eos.map({'Y': 1, 'N': 0})
pm['donor'] = pm.sample_id.astype(int).astype(str)
first = pm.groupby('donor')[['disease_category', 'race', 'gender', 'age', 'sars', 'pathology']].first()
for c in first.columns: pm[c + '_d'] = pm.donor.map(first[c])
pm['group'] = pm.disease_category_d.map({'COVID neg pneumonia': 'COVID- pneumonia', 'COVID pos pneumonia': 'COVID+ pneumonia', 'COVID neg non-pneumonia': 'COVID- non-pneumonia'})
pm['notes_d'] = pm.donor.map(pm.groupby('donor').notes.apply(lambda s: '; '.join(str(x) for x in s if x is not None)))
RES['n_blocks'] = int(len(pm)); RES['n_donors'] = int(pm.donor.nunique()); RES['n_blocks_without_group_label_in_file'] = int(pm.disease_category.isna().sum())
RES['blocks_per_group'] = pm.groupby('group').size().to_dict(); RES['donors_per_group'] = pm.groupby('group').donor.nunique().to_dict()
RES['blocks_per_donor'] = pm.groupby('donor').size().value_counts().sort_index().to_dict()
RES['value_range'] = {c: [float(pm[c + '_v'].min()), float(pm[c + '_v'].max())] for c in ['IL33_epi', 'IL33_endo', 'IL33_vsm', 'NE_num']}
RES['distinct_IL33_values'] = sorted(set(pm.IL33_epi_v.dropna()) | set(pm.IL33_endo_v.dropna()) | set(pm.IL33_vsm_v.dropna()))
RES['frac_blocks_at_ceiling_5p5'] = {c: float((pm[c + '_v'] == 5.5).mean()) for c in ['IL33_epi', 'IL33_endo', 'IL33_vsm']}
RES['frac_blocks_at_ceiling_endo_by_group'] = pm.groupby('group').IL33_endo_v.apply(lambda s: float((s == 5.5).mean())).to_dict()
RES['missing_cells'] = {c: int(pm[c + '_v'].isna().sum()) for c in ['IL33_epi', 'IL33_endo', 'IL33_vsm', 'NE_num', 'EPX_num', 'Tryp_num']}
RES['donors_missing_SARS_status'] = first.index[first.sars.isna()].tolist()
RES['n_blocks_with_tissue_RNA_id'] = int(pm.tissue_rna.notna().sum())

# pathology-text classification (manual read of every donor's diagnosis list; lung items only)
acute = {2072: 1, 2108: 1, 2105: 1, 2101: 0, 2075: 1, 2073: 1, 2067: 0, 2035: 1, 2049: 1, 2045: 1, 2044: 1, 2043: 1, 2040: 1, 2110: 1, 2060: 1, 2113: 1,
         1130: 1, 1165: 1, 1159: 1, 1149: 1, 1138: 1, 1910: 1, 1970: 0, 1968: 0, 1961: 0, 1905: 0, 1976: 1, 1956: 1, 1965: 0, 1861: 0, 1944: 0}
dad = {k: int(k in (2072, 2108, 2049, 2044, 2043, 2040, 2110)) for k in acute}
thromb = {k: int(k in (2035, 2040, 2060, 2113)) for k in acute}

meas = ['IL33_endo_v', 'IL33_epi_v', 'IL33_vsm_v', 'NE_num_v', 'EPX_num_v', 'EDN_ihc_g', 'MBP_ihc_g', 'b2D7_ihc_g', 'Tryp_num_v', 'IL5Ra_dupNE_g', 'he_eos_b']
D = pm.groupby('donor').agg(group=('group', 'first'), age=('age_d', 'first'), sex=('gender_d', 'first'), sars=('sars_d', 'first'), n_blocks=('block_id', 'size'),
                            notes=('notes_d', 'first'), **{m: (m, 'mean') for m in meas})
D['acute_pneumonia_in_pathology_text'] = D.index.astype(int).map(acute); D['DAD_or_ALI_in_text'] = D.index.astype(int).map(dad); D['thromboemboli_in_text'] = D.index.astype(int).map(thromb)
D['covid'] = (D.group == 'COVID+ pneumonia').astype(int)
D['label_text_mismatch'] = ((D.group == 'COVID- pneumonia') & (D.acute_pneumonia_in_pathology_text == 0)) | ((D.group == 'COVID- non-pneumonia') & (D.acute_pneumonia_in_pathology_text == 1)) | ((D.group == 'COVID+ pneumonia') & (D.acute_pneumonia_in_pathology_text == 0))
RES['label_vs_text_mismatch_donors'] = D.index[D.label_text_mismatch].tolist()
RES['DAD_ALI'] = dict(covid_pos=int(D.loc[D.covid == 1, 'DAD_or_ALI_in_text'].sum()), covid_neg=int(D.loc[D.covid == 0, 'DAD_or_ALI_in_text'].sum()),
                      fisher_p=float(stats.fisher_exact([[7, 9], [0, 15]])[1]))
RES['thromboemboli'] = dict(covid_pos=int(D.loc[D.covid == 1, 'thromboemboli_in_text'].sum()), covid_neg=int(D.loc[D.covid == 0, 'thromboemboli_in_text'].sum()),
                            fisher_p=float(stats.fisher_exact([[4, 12], [0, 15]])[1]))
RES['age'] = dict(min=float(D.age.min()), max=float(D.age.max()), median=float(D.age.median()), by_group=D.groupby('group').age.median().to_dict(), race=first.race.dropna().unique().tolist())
D.round(3).to_csv(f'{TAB}/T4a_postmortem_donor_level.csv'); D.to_pickle(f'{CACHE}/pm_donor.pkl'); pm.to_pickle(f'{CACHE}/pm_block.pkl')

def mw(a, b):
    a, b = a.dropna(), b.dropna()
    return float(stats.mannwhitneyu(a, b, alternative='two-sided').pvalue)
P, N1, N0 = D[D.group == 'COVID+ pneumonia'], D[D.group == 'COVID- pneumonia'], D[D.group == 'COVID- non-pneumonia']
bP, bN1, bN0 = pm[pm.group == 'COVID+ pneumonia'], pm[pm.group == 'COVID- pneumonia'], pm[pm.group == 'COVID- non-pneumonia']
rows = []
for m in meas:
    r = dict(measure=m, mean_COVIDpos=P[m].mean(), mean_COVIDneg_pneumonia=N1[m].mean(), mean_COVIDneg_nonpneumonia=N0[m].mean(),
             donor_KW_p=float(stats.kruskal(P[m].dropna(), N1[m].dropna(), N0[m].dropna()).pvalue),
             donor_p_COVIDpos_vs_COVIDneg_pneumonia=mw(P[m], N1[m]), donor_p_COVIDpos_vs_allCOVIDneg=mw(P[m], pd.concat([N1[m], N0[m]])),
             donor_p_pneumonia_vs_nonpneumonia=mw(pd.concat([P[m], N1[m]]), N0[m]),
             block_p_COVIDpos_vs_COVIDneg_pneumonia=mw(bP[m], bN1[m]), block_p_COVIDpos_vs_allCOVIDneg=mw(bP[m], pd.concat([bN1[m], bN0[m]])),
             block_p_pneumonia_vs_nonpneumonia=mw(pd.concat([bP[m], bN1[m]]), bN0[m]))
    # sensitivity: classes from the pathology text
    A = D[(D.covid == 1) & (D.acute_pneumonia_in_pathology_text == 1)][m]; Bn = D[(D.covid == 0) & (D.acute_pneumonia_in_pathology_text == 1)][m]; C = D[D.acute_pneumonia_in_pathology_text == 0][m]
    r.update(text_mean_COVIDpos_acute=A.mean(), text_mean_COVIDneg_acute=Bn.mean(), text_mean_no_acute=C.mean(),
             text_p_COVIDpos_vs_COVIDneg_acute=mw(A, Bn), text_p_acute_vs_none=mw(pd.concat([A, Bn]), C))
    rows.append(r)
T = pd.DataFrame(rows); T.round(4).to_csv(f'{TAB}/T4b_postmortem_group_tests.csv', index=False)
RES['group_tests'] = {r['measure']: {k: (None if pd.isna(v) else round(float(v), 4)) for k, v in r.items() if k != 'measure'} for r in rows}
RES['text_class_n'] = dict(COVIDpos_acute=int(((D.covid == 1) & (D.acute_pneumonia_in_pathology_text == 1)).sum()), COVIDneg_acute=int(((D.covid == 0) & (D.acute_pneumonia_in_pathology_text == 1)).sum()), no_acute=int((D.acute_pneumonia_in_pathology_text == 0).sum()))

# mixed models with donor random intercept (block-level data, correct unit handling)
RES['mixed'] = {}
for y in ['IL33_endo_v', 'IL33_epi_v', 'IL33_vsm_v', 'NE_num_v', 'EPX_num_v', 'EDN_ihc_g']:
    d = pm[pm.group != 'COVID- non-pneumonia'][[y, 'group', 'donor']].dropna().copy(); d['pos'] = (d.group == 'COVID+ pneumonia').astype(int)
    mm = smf.mixedlm(f'{y} ~ pos', d, groups=d['donor']).fit(reml=True)
    ci = mm.conf_int().loc['pos']
    RES['mixed'][y] = dict(COVIDpos_minus_COVIDneg_pneumonia=float(mm.params['pos']), ci_low=float(ci[0]), ci_high=float(ci[1]), p=float(mm.pvalues['pos']))

# within-donor association between IL-33 staining and neutrophil elastase across blocks
def rmcorr(d, x, y):
    d = d[['donor', x, y]].dropna(); d = d[d.groupby('donor')[x].transform('size') >= 2]
    xc = d[x] - d.groupby('donor')[x].transform('mean'); yc = d[y] - d.groupby('donor')[y].transform('mean')
    n, k = len(d), d.donor.nunique(); r = float(np.corrcoef(xc, yc)[0, 1]); dfree = n - k - 1
    return dict(r_within=r, p=float(2 * stats.t.sf(abs(r * np.sqrt(dfree / (1 - r ** 2))), dfree)), blocks=int(n), donors=int(k))
RES['within_donor'] = {f'{x}~{y}': rmcorr(pm, x, y) for x in ['IL33_endo_v', 'IL33_epi_v', 'IL33_vsm_v'] for y in ['NE_num_v', 'EPX_num_v', 'EDN_ihc_g', 'Tryp_num_v']}
RES['within_donor']['IL33_endo_v~NE_num_v (excluding the three 8-block donors)'] = rmcorr(pm[~pm.donor.isin(['2067', '2072', '2073'])], 'IL33_endo_v', 'NE_num_v')
RES['within_donor']['IL33_endo_v~NE_num_v (COVID+ only)'] = rmcorr(pm[pm.group == 'COVID+ pneumonia'], 'IL33_endo_v', 'NE_num_v')
RES['within_donor']['IL33_endo_v~NE_num_v (COVID- only)'] = rmcorr(pm[pm.group != 'COVID+ pneumonia'], 'IL33_endo_v', 'NE_num_v')
d = pm[['IL33_endo_v', 'NE_num_v', 'donor']].dropna(); mm = smf.mixedlm('IL33_endo_v ~ NE_num_v', d, groups=d['donor']).fit()
RES['mixed_IL33endo_on_NE'] = dict(slope=float(mm.params['NE_num_v']), p=float(mm.pvalues['NE_num_v']))
# age-adjusted donor-level sensitivity analysis (ordinary least squares on donor means)
RES['age_adjusted'] = {}
for y in ['IL33_endo_v', 'IL33_vsm_v', 'IL33_epi_v']:
    d_ = D[[y, 'covid', 'age']].dropna(); m_ = smf.ols(f'{y} ~ covid + age', d_).fit()
    RES['age_adjusted'][y] = dict(COVIDpos_minus_allCOVIDneg=float(m_.params['covid']), p=float(m_.pvalues['covid']), per_10_years=float(10 * m_.params['age']), p_age=float(m_.pvalues['age']))
# donor-level correlations
def sp(x, y):
    d = D[[x, y]].dropna(); r = stats.spearmanr(d[x].values, d[y].values); return dict(rho=float(r[0]), p=float(r[1]), n=int(len(d)))
RES['donor_spearman'] = {f'{x}~{y}': sp(x, y) for x, y in [('IL33_endo_v', 'NE_num_v'), ('IL33_endo_v', 'EPX_num_v'), ('IL33_endo_v', 'EDN_ihc_g'), ('IL33_endo_v', 'age'), ('IL33_vsm_v', 'age'), ('IL33_epi_v', 'age'), ('IL33_endo_v', 'IL33_vsm_v'), ('IL33_endo_v', 'IL33_epi_v'), ('IL5Ra_dupNE_g', 'NE_num_v'), ('IL33_epi_v', 'EPX_num_v')]}
RES['compartment_means_donor_level'] = {c: dict(mean=float(D[c].mean()), median=float(D[c].median())) for c in ['IL33_endo_v', 'IL33_epi_v', 'IL33_vsm_v']}
RES['endo_vs_epi_wilcoxon_p'] = float(stats.wilcoxon(D.IL33_endo_v, D.IL33_epi_v).pvalue)
RES['COPD_note'] = dict(n=int(D.notes.str.contains('COPD').sum()), IL33_epi_yes=float(D[D.notes.str.contains('COPD')].IL33_epi_v.mean()), IL33_epi_no=float(D[~D.notes.str.contains('COPD')].IL33_epi_v.mean()),
                        p=mw(D[D.notes.str.contains('COPD')].IL33_epi_v, D[~D.notes.str.contains('COPD')].IL33_epi_v))
RES['grade_means_block'] = {c: float(pm[c].mean()) for c in ['EPX_ihc_g', 'EDN_ihc_g', 'MBP_ihc_g', 'b2D7_ihc_g', 'NE_dupIL5Ra_g', 'Tryp_dupIL5Ra_g']}
json.dump(RES, open(f'{CACHE}/results_postmortem.json', 'w'), indent=1, default=str)
print(json.dumps(RES, indent=1, default=str)[:9000])
