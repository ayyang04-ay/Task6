#!/usr/bin/env Rscript
# AX-1177 portfolio audit -- step 5: pre-ranked gene-set enrichment (fgsea, MSigDB Hallmark via msigdbr 7.5.1, offline)
# Run after 01_rnaseq.py:  micromamba run -n renv Rscript 05_gsea.R
# Ranking statistic: moderated t (primary) and log2FC restricted to AveExpr>0 (sensitivity, because t is distorted for ~270 genes; see memo).
suppressMessages({library(fgsea); library(msigdbr); library(data.table)})
set.seed(1)
tt <- fread('/tmp/outputs/analysis/cache/rnaseq_wide_t.csv'); lf <- fread('/tmp/outputs/analysis/cache/rnaseq_wide_logFC.csv')
h <- as.data.table(msigdbr(species = "Homo sapiens", category = "H"))
react <- as.data.table(msigdbr(species = "Homo sapiens", category = "C2", subcategory = "CP:REACTOME"))
mk <- function(d) split(d$ensembl_gene, d$gs_name)
contrasts <- setdiff(colnames(tt), c('ensembl', 'symbol', 'AveExpr'))
key <- c('IL33_HUVEC_6', 'IL33_HUVEC_24', 'AXIL33_v_ICIL33_HUVEC_6', 'AXIL33_v_ICIL33_HUVEC_24', 'AXIL33_v_ICIL33_HGMEC_6', 'AXIL33_v_ICIL33_HGMEC_24')
res <- list()
for (cn in contrasts) {
  v <- tt[[cn]]; names(v) <- tt$ensembl
  r <- suppressWarnings(fgseaMultilevel(mk(h), v, minSize = 15, maxSize = 500, eps = 0)); r[, `:=`(contrast = cn, ranking = 't', collection = 'Hallmark', leadingEdge = NULL)]; res[[length(res) + 1]] <- r
  keep <- lf$AveExpr > 0; v2 <- lf[[cn]][keep]; names(v2) <- lf$ensembl[keep]
  r <- suppressWarnings(fgseaMultilevel(mk(h), v2, minSize = 15, maxSize = 500, eps = 0)); r[, `:=`(contrast = cn, ranking = 'logFC_AveExpr_gt0', collection = 'Hallmark', leadingEdge = NULL)]; res[[length(res) + 1]] <- r
  if (cn %in% key) {
    r <- suppressWarnings(fgseaMultilevel(mk(react), v, minSize = 15, maxSize = 500, eps = 0)); r[, `:=`(contrast = cn, ranking = 't', collection = 'Reactome', leadingEdge = NULL)]; res[[length(res) + 1]] <- r
  }
}
R <- rbindlist(res)
fwrite(R, '/tmp/outputs/tables/T2d_gene_set_enrichment.csv')
cat('done', nrow(R), 'rows\n')
