#!/usr/bin/env bash
# Reproduce every table, figure and quoted number from the delivered AX-1177 files.
set -euo pipefail
cd "$(dirname "$0")"
micromamba run -n singlecell python 00_load_data.py
micromamba run -n singlecell python 00b_hidden_content.py > /dev/null
micromamba run -n singlecell python 01_rnaseq.py > /dev/null
micromamba run -n singlecell python 02_serum.py > /dev/null
micromamba run -n singlecell python 03_postmortem.py > /dev/null
micromamba run -n renv Rscript 05_gsea.R
micromamba run -n singlecell python 05b_gsea_summary.py
micromamba run -n singlecell python 04_figures.py
micromamba run -n singlecell python 06_data_integrity_log.py
micromamba run -n singlecell python 07_verify_memo_numbers.py | tail -1
micromamba run -n core python 08_build_pdf.py
