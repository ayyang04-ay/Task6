#!/usr/bin/env python
"""AX-1177 portfolio audit -- step 4: figures.  Run after steps 0-3:  micromamba run -n singlecell python 04_figures.py"""
import json, sys
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
CACHE = '/tmp/outputs/analysis/cache'; FIG = '/tmp/outputs/figures'
import os; os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.titlesize': 10, 'axes.titleweight': 'bold', 'figure.dpi': 150, 'savefig.bbox': 'tight'})
ann, W = pd.read_pickle(f'{CACHE}/rnaseq_wide.pkl'); lfc, t, q = W['logFC'], W['t'], W['adj.P.Val']
G = pd.read_pickle(f'{CACHE}/rnaseq_gene_table.pkl')
R1 = json.load(open(f'{CACHE}/results_rnaseq.json')); R2 = json.load(open(f'{CACHE}/results_serum.json')); R3 = json.load(open(f'{CACHE}/results_postmortem.json'))
sym = ann.symbol
C_UP, C_DN, C_GREY, C_MASK = '#c0392b', '#2471a3', '#d5d8dc', '#e67e22'

# ------------------------------------------------------------------ Figure 1
fig, axes = plt.subplots(2, 2, figsize=(10.5, 9.4))
panels = [('6', 'HUVEC', 'A'), ('24', 'HUVEC', 'B'), ('6', 'HGMEC', 'C'), ('24', 'HGMEC', 'D')]
lab = ['SELE', 'VCAM1', 'CXCL8', 'CXCL1', 'CCL20', 'CSF3', 'CSF2', 'CXCL2', 'IL6', 'F3', 'ICAM1', 'CXCL6', 'TNFRSF11B']
def place_labels(ax, pts):
    """alternate labels right-above / left-below the point, ordered along the diagonal, to limit overlap"""
    pts = sorted(pts, key=lambda p_: p_[1])
    for k, (g, xx, yy, col) in enumerate(pts):
        if k % 2 == 0: off, ha = (14, 8), 'left'
        else: off, ha = (-14, -10), 'right'
        ax.annotate(g, (xx, yy), xytext=off, textcoords='offset points', fontsize=6.5, color=col, ha=ha, va='center',
                    arrowprops=dict(arrowstyle='-', lw=.4, color='#555555', shrinkA=0, shrinkB=2), zorder=6)
for (tp, cell, letter), ax in zip(panels, axes.ravel()):
    il, rv = f'IL33_HUVEC_{tp}', f'AXIL33_v_ICIL33_{cell}_{tp}'
    x, y = lfc[il], lfc[rv]
    robust = (q[il] < .05) & (x.abs() > 1) & (t[il].abs() > 5)          # robustly IL-33-regulated genes
    ax.scatter(x[~robust], y[~robust], s=2, c=C_GREY, rasterized=True, zorder=1)
    both = robust & (q[rv] < .05)
    ax.scatter(x[robust & ~both], y[robust & ~both], s=9, c='#566573', alpha=.8, rasterized=True, zorder=2)
    ax.scatter(x[both & (x > 0)], y[both & (x > 0)], s=9, c=C_UP, alpha=.75, rasterized=True, zorder=3)
    ax.scatter(x[both & (x < 0)], y[both & (x < 0)], s=9, c=C_DN, alpha=.75, rasterized=True, zorder=3)
    mk = G.masked_candidate & (x > 3)
    ax.scatter(x[mk], y[mk], s=38, facecolors='none', edgecolors=C_MASK, linewidths=1.3, zorder=4)
    ax.plot([-6, 12.5], [6, -12.5], ls='--', c='k', lw=.8, zorder=0); ax.axhline(0, c='k', lw=.4); ax.axvline(0, c='k', lw=.4)
    pts = []
    for g in lab:
        i = sym.index[sym == g][0]
        if abs(x[i]) > 3: pts.append((g, x[i], y[i], C_MASK if G.masked_candidate[i] else 'k'))
    place_labels(ax, pts)
    rs = R1['reversal'][tp][f'hc_up_{cell}_vs_isotype']; cc = R1['reversal'][tp][f'concordance_{cell}']
    n_rob = int(robust.sum()); n_cnt = int((both & (np.sign(x) != np.sign(y))).sum())
    rob8 = robust & (t[il].abs() > 8); n_rob8 = int(rob8.sum()); n_cnt8 = int((rob8 & (q[rv] < .05) & (np.sign(x) != np.sign(y))).sum())
    txt = (f"IL-33-regulated genes significantly reversed by AX-1177:\n|t|>8: {n_cnt8} of {n_rob8} ({100*n_cnt8/n_rob8:.0f}%);  |t|>5: {n_cnt} of {n_rob} ({100*n_cnt/n_rob:.0f}%)\n"
           f"strongest induced genes (t>8, n={rs['n']}): median\nreversal {100*rs['median_reversal']:.0f}% (IQR {100*rs['q25']:.0f}–{100*rs['q75']:.0f}%)")
    ax.text(.985, .985, txt, transform=ax.transAxes, fontsize=7, va='top', ha='right', bbox=dict(fc='white', ec='#aaaaaa', lw=.5, boxstyle='round,pad=0.3'), zorder=7)
    ax.set_xlim(-6, 12.5); ax.set_ylim(-13.5, 6)
    ax.set_xlabel(f'IL-33red vs vehicle, HUVEC {tp} h  (log2 fold change)')
    ax.set_ylabel(f'AX-1177 + IL-33 vs IC119 + IL-33, {cell} {tp} h  (log2 FC)')
    ax.set_title(f'{letter}  {cell}, {tp} h' + ('' if cell == 'HUVEC' else '  (x-axis: HUVEC response)'), loc='left', fontsize=9)
h = [Line2D([], [], marker='o', ls='', c=C_UP, ms=5, label='IL-33-induced (FDR<0.05, >2-fold, |t|>5), significantly changed by AX-1177'),
     Line2D([], [], marker='o', ls='', c=C_DN, ms=5, label='IL-33-repressed, significantly changed by AX-1177'),
     Line2D([], [], marker='o', ls='', c='#566573', ms=5, label='IL-33-regulated (|t|>5), AX-1177 effect not significant'),
     Line2D([], [], marker='o', ls='', mfc='none', mec=C_MASK, ms=7, label='large mirrored effect, but FDR≥0.05 in the delivered model (variance artefact, Fig. 5B)'),
     Line2D([], [], ls='--', c='k', lw=.8, label='complete neutralisation (y = −x)'),
     Line2D([], [], marker='o', ls='', c=C_GREY, ms=4, label='all other genes (26,210 in total)')]
fig.legend(handles=h, loc='lower center', ncol=2, fontsize=7.5, frameon=False, bbox_to_anchor=(.5, -.05))
fig.suptitle('Figure 1.  AX-1177 (10 µg/mL, added together with IL-33) mirrors away the IL-33 programme in human endothelium.\nHGMEC had no vehicle arm, so panels C–D compare the AX-1177 effect in HGMEC with the IL-33 response measured in HUVEC.', fontsize=9.5, fontweight='bold', y=1.0)
fig.tight_layout(rect=(0, .02, 1, .965)); fig.savefig(f'{FIG}/Fig1_IL33_signature_reversal.png', dpi=170); plt.close(fig)

# ------------------------------------------------------------------ Figure 2 (biomarker heat-map)
B = pd.read_pickle(f'{CACHE}/serum_bridge.pkl')
groups = [('A. Secreted / shed:\nmeasurable in blood', ['CCL20', 'CSF3', 'CSF2', 'CXCL2', 'CXCL3', 'CXCL5', 'CXCL6', 'CX3CL1', 'IL6', 'TNFRSF11B', 'IL18R1', 'CSF1', 'CCL7', 'IL1B', 'F3']),
          ('B. NF-κB feedback:\ncell assay only', ['NFKBIA', 'TNFAIP3', 'TRAF1', 'BIRC3', 'NFKBIZ']),
          ('C. Large mirrored effect,\nvariance-inflated in\ndelivered model: re-test', ['SELE', 'VCAM1', 'ICAM1', 'CXCL8', 'CXCL1', 'PTX3', 'IL1RL1'])]
cols = [('IL33_HUVEC_6', 'IL-33\nHUVEC\n6 h'), ('AXIL33_v_ICIL33_HUVEC_6', '+AX-1177\nHUVEC\n6 h'), ('AXIL33_v_ICIL33_HGMEC_6', '+AX-1177\nHGMEC\n6 h'),
        ('IL33_HUVEC_24', 'IL-33\nHUVEC\n24 h'), ('AXIL33_v_ICIL33_HUVEC_24', '+AX-1177\nHUVEC\n24 h'), ('AXIL33_v_ICIL33_HGMEC_24', '+AX-1177\nHGMEC\n24 h'),
        ('AX_v_IC_HUVEC_6', 'AX alone\nHUVEC\n6 h'), ('AX_v_IC_HGMEC_6', 'AX alone\nHGMEC\n6 h'), ('AX_v_IC_A549_6', 'AX alone\nA549\n6 h'), ('AX_v_IC_MCF7_6', 'AX alone\nMCF7\n6 h')]
serum_alias = {'CCL20': ['CCL20'], 'CSF3': ['G-CSF'], 'CXCL5': ['CXCL5'], 'CXCL6': ['CXCL6'], 'CX3CL1': ['CX3CL1'], 'IL6': ['IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO'], 'TNFRSF11B': ['OPG-INFI', 'OPG-CVDIII'],
               'IL18R1': ['IL-18R1'], 'CSF1': ['CSF-1'], 'CCL7': ['MCP-3'], 'IL1B': ['IL1B'], 'F3': ['TF'], 'SELE': ['SELE'], 'VCAM1': ['VCAM1'], 'ICAM1': ['ICAM1'], 'CXCL8': ['IL8'],
               'CXCL1': ['CXCL1-INFI', 'CXCL1-CVDII'], 'PTX3': ['PTX3'], 'IL1RL1': ['ST2']}
nice = {'IL18R1': 'IL-18R1', 'CSF1': 'CSF-1', 'IL6': 'IL-6', 'TNFRSF11B': 'OPG', 'CXCL1': 'CXCL1', 'CSF3': 'G-CSF', 'CCL7': 'MCP-3', 'F3': 'Tissue factor', 'CXCL8': 'IL-8', 'IL1RL1': 'sST2', 'SELE': 'E-selectin', 'IL1B': 'IL-1β'}
genes = [g for _, gl in groups for g in gl]
ids = [sym.index[sym == g][0] for g in genes]
M = lfc.loc[ids, [c for c, _ in cols]].values; Q = q.loc[ids, [c for c, _ in cols]].values
fig, ax = plt.subplots(figsize=(12.5, 9.6))
im = ax.imshow(M, cmap='RdBu_r', vmin=-10, vmax=10, aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        ax.text(j, i, f"{M[i, j]:+.1f}{'*' if Q[i, j] < .05 else ''}", ha='center', va='center', fontsize=7, color='white' if abs(M[i, j]) > 6 else 'black')
ax.set_xticks(range(len(cols))); ax.set_xticklabels([l for _, l in cols], fontsize=7); ax.xaxis.tick_top(); ax.tick_params(axis='x', length=0)
ax.set_yticks(range(len(genes))); ax.set_yticklabels(genes, fontsize=8, style='italic')
for s_ in ax.spines.values(): s_.set_visible(False)
y0 = 0
for name, gl in groups:
    ax.text(-2.15, y0 + len(gl) / 2 - .5, name, rotation=90, va='center', ha='center', fontsize=7.5, fontweight='bold', linespacing=1.25)
    y0 += len(gl)
    if y0 < len(genes): ax.axhline(y0 - .5, c='k', lw=1.2)
for xline in (2.5, 5.5): ax.axvline(xline, c='k', lw=1.2)
ax.text(len(cols) - .4, -1.0, 'Patient serum at enrolment (n=100): odds ratio per log unit\n[95% CI] for ICU / ventilation / death ≤30 d;  bold = FDR<5%', fontsize=7.5, va='bottom', ha='left', fontweight='bold')
for i, g in enumerate(genes):
    if g in serum_alias:
        rr = B[B.assay.isin(serum_alias[g])]; nm = nice.get(g, g)
        if len(rr) == 1:
            r = rr.iloc[0]; s_ = f"{nm}: {r.OR:.2f} [{r.l95:.2f}–{r.u95:.1f}], FDR {r['adj.p.value']:.3f}"; bold = r['adj.p.value'] < .05
        else:
            s_ = f"{nm}, {len(rr)} panels: {rr.OR.min():.2f}–{rr.OR.max():.2f}, FDR {rr['adj.p.value'].min():.3f}–{rr['adj.p.value'].max():.3f}"; bold = rr['adj.p.value'].max() < .05
        ax.text(len(cols) - .4, i, s_, fontsize=7, va='center', ha='left', fontweight='bold' if bold else 'normal', color='k' if bold else '#555555')
    else:
        ax.text(len(cols) - .4, i, 'not on the delivered serum panels' if g in ('CSF2', 'CXCL2', 'CXCL3') else 'intracellular: not a serum marker', fontsize=7, va='center', ha='left', color='#999999')
cax = fig.add_axes([.17, .045, .36, .012]); cb = fig.colorbar(im, cax=cax, orientation='horizontal'); cb.set_label('log2 fold change   (* FDR < 0.05 within contrast)', fontsize=8); cb.ax.tick_params(labelsize=7)
fig.suptitle('Figure 2.  Candidate pharmacodynamic markers: induced by IL-33, removed by AX-1177, untouched by AX-1177 alone', fontsize=10.5, fontweight='bold', x=.5, y=.995)
fig.subplots_adjust(left=.17, right=.66, top=.885, bottom=.085)
fig.savefig(f'{FIG}/Fig2_PD_biomarker_panel.png', dpi=170); plt.close(fig)

# ------------------------------------------------------------------ Figure 3 (serum)
s = B.copy(); s['mlp'] = -np.log10(s['p.value'])
fig = plt.figure(figsize=(12.5, 8.6)); gs = fig.add_gridspec(1, 2, width_ratios=[1.05, 1], wspace=.42)
ax = fig.add_subplot(gs[0])
pan = sorted(s.panel_short.unique()); rng = np.random.default_rng(1)
xpos = s.panel_short.map({p_: i for i, p_ in enumerate(pan)}) + rng.uniform(-.33, .33, len(s))
ax.scatter(xpos, s.mlp, s=7, c=np.where(s.OR > 1, '#aab7b8', '#d6dbdf'), rasterized=True)
t2 = ['IL5-IMO', 'CCL11-INFI', 'CCL11-IMO', 'CCL17', 'CCL24', 'CCL18', 'MCP-4', 'TPSAB1', 'FCER2', 'RNASE3', 'IL-5R-alpha', 'IL-4RA', 'IL13RA1', 'KIT', 'SIGLEC6', 'HPGDS', 'CCL27', 'CCL28', 'IL17RB', 'SIGLEC10', 'SCF-INFI', 'SCF-CVDII', 'SCF-ONCII']
pd_ = ['IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO', 'OPG-INFI', 'OPG-CVDIII', 'CCL20', 'IL-18R1', 'MCP-3', 'CSF-1', 'IL8', 'CTSS', 'IL1B']
neut = ['HGF', 'HGF-ONCII', 'OSM', 'PRTN3', 'CD177', 'RETN', 'FCAR', 'CLEC5A', 'EN-RAGE', 'LCN2']
for lst, col, mkr in [(t2, '#27ae60', 's'), (pd_, C_UP, 'o'), (neut, '#8e44ad', '^')]:
    m = s.assay.isin(lst); ax.scatter(xpos[m], s.mlp[m], s=26, c=col, marker=mkr, zorder=3, edgecolors='white', linewidths=.4)
m = s.assay == 'ST2'; ax.scatter(xpos[m], s.mlp[m], s=150, c='gold', marker='*', edgecolors='k', linewidths=.8, zorder=5)
lab_pts = [('ST2', 'sST2 (soluble IL-33 receptor)', (1.2, .55)), ('HGF', 'HGF', (.6, .25)), ('HGF-ONCII', 'HGF (2nd panel)', (.5, .3)), ('IL6', 'IL-6', (1.1, .25)), ('PTX3', 'PTX3', (.6, .25)),
           ('OPG-INFI', 'OPG', (1.5, .05)), ('CCL20', 'CCL20', (1.4, -.25)), ('IL-18R1', 'IL-18R1', (1.5, -.1)), ('IL5-IMO', 'IL-5', (.7, .3)), ('CCL17', 'CCL17 (TARC)', (.9, .35)), ('IL-4RA', 'sIL-4Rα', (-1.3, .45))]
for a_, txt_, (dx, dy) in lab_pts:
    r = s[s.assay == a_].iloc[0]
    ax.annotate(txt_, (xpos[r.name], r.mlp), xytext=(xpos[r.name] + dx, r.mlp + dy), fontsize=7, fontweight='bold' if a_ == 'ST2' else 'normal',
                arrowprops=dict(arrowstyle='-', lw=.5, color='#333333', shrinkA=0, shrinkB=3), va='center', zorder=6)
fdr_line = -np.log10(s.loc[s['adj.p.value'] < .05, 'p.value'].max()); bon = -np.log10(.05 / R2['BH_denominator_implied_by_top_row'])
ax.axhline(fdr_line, ls='--', c='k', lw=.7); ax.text(len(pan) - .5, fdr_line + .04, 'FDR 5%', fontsize=7, ha='right')
ax.axhline(bon, ls=':', c='k', lw=.9); ax.text(len(pan) - .5, bon + .04, f"Bonferroni (0.05 / {R2['BH_denominator_implied_by_top_row']:,} tests)", fontsize=7, ha='right')
ax.set_xticks(range(len(pan))); ax.set_xticklabels(pan, rotation=55, ha='right', fontsize=7.5); ax.set_ylabel('−log10 P  (logistic regression, adjusted for age, sex, NEWS2)')
ax.set_ylim(-.25, 7.3); ax.set_xlim(-.8, len(pan) - .2)
ax.set_title(f"A  {len(s):,} delivered assays; {R2['n_FDR05']} at FDR<5% ({R2['n_FDR05_risk_increasing']} risk-increasing)", loc='left', fontsize=9)
ax.legend(handles=[Line2D([], [], marker='*', ls='', mfc='gold', mec='k', ms=12, label='sST2'), Line2D([], [], marker='o', ls='', c=C_UP, ms=6, label='IL-33-inducible & AX-1177-reversible in endothelium'),
                   Line2D([], [], marker='^', ls='', c='#8e44ad', ms=6, label='neutrophil activation proteins'), Line2D([], [], marker='s', ls='', c='#27ae60', ms=6, label='type-2 / eosinophil / mast-cell markers'),
                   Line2D([], [], marker='o', ls='', c='#aab7b8', ms=5, label='all other assays')],
          fontsize=7, frameon=True, edgecolor='#cccccc', loc='upper left', ncol=1)
# forest
ax = fig.add_subplot(gs[1])
blocks = [('Target axis', ['ST2']),
          ('IL-33-inducible, AX-1177-reversible\nin endothelium (PD candidates)', ['IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO', 'OPG-INFI', 'OPG-CVDIII', 'CCL20', 'IL-18R1', 'MCP-3', 'IL8', 'TF', 'SELE', 'ICAM1', 'VCAM1', 'CX3CL1', 'TNF', 'G-CSF', 'CXCL1-INFI', 'CXCL5', 'CXCL6']),
          ('Type-2 / eosinophil /\nmast cell', ['IL5-IMO', 'CCL11-INFI', 'CCL17', 'CCL24', 'MCP-4', 'CCL18', 'TPSAB1', 'RNASE3', 'IL-5R-alpha', 'IL-4RA']),
          ('Neutrophil activation', ['HGF', 'OSM', 'PRTN3', 'CD177', 'RETN', 'EN-RAGE'])]
ypos = 0; yt, yl = [], []
for name, lst in blocks:
    ax.text(.052, ypos - .75, name, fontsize=7.5, fontweight='bold', va='bottom', ha='left')
    for a_ in lst:
        r = s[s.assay == a_].iloc[0]; sigf = r['adj.p.value'] < .05
        ax.plot([r.l95, r.u95], [ypos, ypos], c='k' if sigf else '#95a5a6', lw=1.2)
        ax.plot(r.OR, ypos, 'o' if a_ != 'ST2' else '*', c=('gold' if a_ == 'ST2' else ('k' if sigf else '#95a5a6')), mec='k', ms=11 if a_ == 'ST2' else 5)
        yt.append(ypos); yl.append(f"{a_}  (FDR {r['adj.p.value']:.3f})"); ypos += 1
    ypos += 1.6
ax.axvline(1, c='k', lw=.6); ax.set_xscale('log'); ax.set_xlim(.05, 30); ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=7); ax.invert_yaxis()
ax.set_xlabel('Odds ratio per log unit for ICU admission / invasive ventilation / death ≤30 d (95% CI)\nblack = FDR<5%;  ORs are per log unit, not per SD — compare significance, not size')
ax.set_title('B  What tracks outcome — and what does not', loc='left', fontsize=9)
fig.suptitle('Figure 3.  Hospitalised SARS-CoV-2 patients (n=100; 44 with the endpoint, a count inferred from the file): serum at enrolment', fontsize=10.5, fontweight='bold', y=.97)
fig.savefig(f'{FIG}/Fig3_serum_proteomics.png', dpi=170); plt.close(fig)

# ------------------------------------------------------------------ Figure 4 (post-mortem)
pm = pd.read_pickle(f'{CACHE}/pm_block.pkl'); D = pd.read_pickle(f'{CACHE}/pm_donor.pkl')
order = ['COVID- non-pneumonia', 'COVID- pneumonia', 'COVID+ pneumonia']; gc = {'COVID- non-pneumonia': '#7f8c8d', 'COVID- pneumonia': '#2e86c1', 'COVID+ pneumonia': '#c0392b'}
fig = plt.figure(figsize=(13, 9.6)); gs = fig.add_gridspec(2, 4, hspace=.62, wspace=.42, height_ratios=[1, 1.05])
T = R3['group_tests']
def strip(ax, col, title):
    for i, gname in enumerate(order):
        d = D[D.group == gname].sort_values(col); xj = i + np.linspace(-.24, .24, len(d))
        ax.scatter(xj, d[col], s=14 + 9 * d.n_blocks, c=gc[gname], alpha=.8, edgecolors='white', linewidths=.5, zorder=3)
        ax.plot([i - .32, i + .32], [d[col].mean()] * 2, c='k', lw=1.8, zorder=4)
    ax.axhline(5.5, ls=':', c='k', lw=.7)
    ax.set_xticks(range(3)); ax.set_xticklabels(['COVID−\nno pneum.\n(n=5)', 'COVID−\npneum.\n(n=10)', 'COVID+\npneum.\n(n=16)'], fontsize=7.5)
    ax.set_ylim(-.2, 5.9); ax.set_xlim(-.55, 2.55); ax.set_title(title, loc='left', fontsize=9)
    tt = T[col]
    ax.text(.5, -.27, f"Kruskal–Wallis p = {tt['donor_KW_p']:.2f}\nCOVID+ vs COVID− pneumonia p = {tt['donor_p_COVIDpos_vs_COVIDneg_pneumonia']:.2f}\npneumonia vs no pneumonia p = {tt['donor_p_pneumonia_vs_nonpneumonia']:.3f}",
            transform=ax.transAxes, fontsize=7, ha='center', va='top', linespacing=1.3)
for k, (col, ttl) in enumerate([('IL33_endo_v', 'A  IL-33, endothelium'), ('IL33_epi_v', 'B  IL-33, basal epithelium'), ('IL33_vsm_v', 'C  IL-33, vascular smooth muscle'), ('NE_num_v', 'D  Neutrophil elastase')]):
    ax = fig.add_subplot(gs[0, k]); strip(ax, col, ttl)
    if k == 0: ax.set_ylabel('donor mean score (one dot per donor;\ndot size ∝ blocks; dotted = scale maximum 5.5)', fontsize=8)
# E: within-donor, donor-centred
ax = fig.add_subplot(gs[1, 0:2])
d = pm[['donor', 'group', 'IL33_endo_v', 'NE_num_v']].dropna(); d = d[d.groupby('donor').donor.transform('size') >= 2].copy()
d['x'] = d.NE_num_v - d.groupby('donor').NE_num_v.transform('mean'); d['y'] = d.IL33_endo_v - d.groupby('donor').IL33_endo_v.transform('mean')
rng = np.random.default_rng(3)
for gname in order:
    dd = d[d.group == gname]; ax.scatter(dd.x + rng.uniform(-.04, .04, len(dd)), dd.y + rng.uniform(-.03, .03, len(dd)), s=26, c=gc[gname], alpha=.75, edgecolors='white', linewidths=.4, label=gname.replace('COVID-', 'COVID−'))
b1, b0 = np.polyfit(d.x, d.y, 1); xx = np.array([d.x.min(), d.x.max()]); ax.plot(xx, b0 + b1 * xx, c='k', lw=1.2)
ax.axhline(0, c='k', lw=.4); ax.axvline(0, c='k', lw=.4)
w = R3['within_donor']['IL33_endo_v~NE_num_v']; w2 = R3['within_donor']['IL33_endo_v~NE_num_v (excluding the three 8-block donors)']
ax.set_xlabel('Neutrophil elastase score of the block, relative to that donor\'s mean'); ax.set_ylabel('Endothelial IL-33 score of the block,\nrelative to that donor\'s mean')
ax.set_title("E  Within a lung: more neutrophils, less endothelial IL-33", loc='left', fontsize=9)
ax.text(.98, .97, f"within-donor r = {w['r_within']:.2f}, p = {w['p']:.4f}\n{w['blocks']} blocks from {w['donors']} donors with ≥2 blocks\nexcluding the three 8-block donors: r = {w2['r_within']:.2f}, p = {w2['p']:.4f}", transform=ax.transAxes, fontsize=7.5, ha='right', va='top',
        bbox=dict(fc='white', ec='#aaaaaa', lw=.5, boxstyle='round,pad=0.3'))
ax.legend(fontsize=7, frameon=False, loc='lower left')
# F: pseudo-replication table
ax = fig.add_subplot(gs[1, 2:4]); ax.axis('off')
rows = [('IL-33, endothelium', 'IL33_endo_v'), ('IL-33, vasc. smooth muscle', 'IL33_vsm_v'), ('IL-33, basal epithelium', 'IL33_epi_v'), ('Eosinophil peroxidase', 'EPX_num_v'), ('EDN (eosinophil)', 'EDN_ihc_g'), ('Neutrophil elastase', 'NE_num_v')]
neg = D[D.group != 'COVID+ pneumonia']
cell = [[n, f"{T[c]['mean_COVIDpos']:.2f}", f"{neg[c].mean():.2f}", f"{T[c]['block_p_COVIDpos_vs_allCOVIDneg']:.3f}", f"{T[c]['donor_p_COVIDpos_vs_allCOVIDneg']:.3f}"] for n, c in rows]
tb = ax.table(cellText=cell, colLabels=['', 'COVID+\n(16 donors)', 'COVID−\n(15 donors)', 'p, by block\n(n=74)', 'p, by donor\n(n=31)'], loc='center', cellLoc='center', colWidths=[.34, .165, .165, .165, .165])
tb.auto_set_font_size(False); tb.set_fontsize(7.5); tb.scale(1, 1.9)
for (r_, c_), ce in tb.get_celld().items():
    ce.set_edgecolor('#cccccc')
    if r_ == 0: ce.set_facecolor('#eaecee'); ce.set_text_props(fontweight='bold')
    if r_ > 0 and c_ == 3 and float(cell[r_ - 1][3]) < .05: ce.set_facecolor('#f5b7b1')
    if r_ > 0 and c_ == 4 and float(cell[r_ - 1][4]) < .05: ce.set_facecolor('#abebc6')
ax.set_title('F  Counting blocks instead of donors manufactures significance\n    (COVID+ vs all COVID−, Mann–Whitney; 3 donors supply 8 blocks each)', loc='left', fontsize=9)
fig.suptitle('Figure 4.  Post-mortem lung (31 donors, 74 blocks): IL-33 is abundant in every group, not higher with SARS-CoV-2,\nand locally lower where neutrophils accumulate', fontsize=10.5, fontweight='bold', y=.985)
fig.savefig(f'{FIG}/Fig4_postmortem_lung.png', dpi=170); plt.close(fig)

# ------------------------------------------------------------------ Figure 5 (QC)
QC = pd.read_csv('/tmp/outputs/tables/T1_rnaseq_contrast_summary.csv')
fig, axes = plt.subplots(1, 2, figsize=(13.5, 5.8), gridspec_kw=dict(width_ratios=[1.25, 1], wspace=.38))
ax = axes[0]
names = {'IL33_HUVEC_6': 'IL-33 vs vehicle · HUVEC 6h', 'IL33_HUVEC_24': 'IL-33 vs vehicle · HUVEC 24h', 'AXIL33_v_ICIL33_HUVEC_6': 'AX+IL-33 vs IC119+IL-33 · HUVEC 6h', 'AXIL33_v_ICIL33_HUVEC_24': 'AX+IL-33 vs IC119+IL-33 · HUVEC 24h',
         'AXIL33_v_ICIL33_HGMEC_6': 'AX+IL-33 vs IC119+IL-33 · HGMEC 6h', 'AXIL33_v_ICIL33_HGMEC_24': 'AX+IL-33 vs IC119+IL-33 · HGMEC 24h'}
show = list(names) + [c for c in QC.contrast if c.startswith('AX_v_')]
d = QC.set_index('contrast').loc[show]
colors = ['#c0392b', '#c0392b', '#1f618d', '#1f618d', '#2e86c1', '#2e86c1'] + ['#95a5a6'] * (len(show) - 6)
yy = np.arange(len(show))[::-1]
ax.barh(yy, d.n_FDR05, color=colors, alpha=.35); ax.barh(yy, d.n_FDR05_expressed_LFCgt0p5.clip(lower=.8), color=colors, height=.45)
ax.set_xscale('log'); ax.set_xlim(.8, 9000)
ax.set_yticks(yy); ax.set_yticklabels([names[c] if c in names else ('AX-1177 alone vs ' + {'IC': 'IC119'}.get(c.split('_')[2], c.split('_')[2]) + ' · ' + c.split('_')[3] + ' ' + c.split('_')[4] + 'h') for c in show], fontsize=7)
for y_, (n1, n2) in zip(yy, zip(d.n_FDR05, d.n_FDR05_expressed_LFCgt0p5)): ax.text(n1 * 1.12, y_, f'{n1:,}  ({n2:,})', va='center', fontsize=6.5)
ax.set_xlabel('genes at FDR < 0.05   (pale: all;  solid / in brackets: expressed genes [AveExpr>2] changing >1.4-fold)')
ax.set_title('A  Genes called per contrast. Antibody-alone contrasts = noise floor (14–73; none reproducible)', loc='left', fontsize=8.5)
ax = axes[1]
x, y = lfc['IL33_HUVEC_6'].abs(), t['IL33_HUVEC_6'].abs().clip(lower=1e-3)
infl = G.SE_inflation > 5
ax.scatter(x[~infl], y[~infl], s=3, c='#aab7b8', rasterized=True); ax.scatter(x[infl], y[infl], s=9, c=C_MASK, rasterized=True)
for g in ['SELE', 'VCAM1', 'CXCL1', 'CXCL8', 'PTX3', 'IL1RL1', 'ICAM1', 'PTGS2', 'CCL2', 'CSF2', 'CCL20', 'CXCL2', 'NFKBIA', 'TRAF1']:
    i = sym.index[sym == g][0]; off = {'IL1RL1': (14, -16), 'PTX3': (5, 4)}.get(g, (3, 3))
    ax.annotate(g, (x[i], y[i]), xytext=off, textcoords='offset points', fontsize=6.5, color=C_MASK if infl[i] else 'k', arrowprops=(dict(arrowstyle='-', lw=.5, color=C_MASK) if g == 'IL1RL1' else None))
ax.set_yscale('log'); ax.axhline(2, ls='--', c='k', lw=.6); ax.text(11.3, 2.15, '|t| = 2', fontsize=7, ha='right')
ax.set_xlabel('|log2 fold change|, IL-33 vs vehicle, HUVEC 6 h'); ax.set_ylabel('|moderated t| (log scale)')
ax.set_title(f"B  {R1['SE_inflation']['n_gt5x']} genes have implied SEs >5× their peers (orange):\n    SELE, VCAM1, CXCL8, CXCL1 reach only FDR 0.19–1.0 despite >250-fold changes", loc='left', fontsize=8.5)
fig.suptitle('Figure 5.  Two properties of the delivered single-model statistics that change how the tables must be read', fontsize=10.5, fontweight='bold', y=1.0)
fig.savefig(f'{FIG}/Fig5_rnaseq_statistics_QC.png', dpi=170); plt.close(fig)
print('figures written')
