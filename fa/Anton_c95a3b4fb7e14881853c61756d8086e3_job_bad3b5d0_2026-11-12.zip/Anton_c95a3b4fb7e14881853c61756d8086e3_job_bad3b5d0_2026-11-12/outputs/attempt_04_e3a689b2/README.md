# AX-1177 portfolio audit: outputs

Start with `AX-1177_portfolio_audit_memo.md` (or the PDF render of it). Everything else supports it.

| File | What it is |
|---|---|
| `AX-1177_portfolio_audit_memo.md` | The recommendation, the evidence, the indication, next studies, biomarkers, what was ruled out, and the data problems |
| `AX-1177_portfolio_audit_memo.pdf` | Same memo with figures embedded (built with `scripts/05_build_pdf.py`; layout checked only with a rough page preview, because no PDF viewer was available where it was built) |
| `AX-1177_portfolio_audit_memo.html` | Same memo as one self-contained web page (built with `scripts/06_build_html.py`) |
| `figures/fig1_neutralisation.png` | AX-1177 effect against IL-33 effect, HUVEC and HGMEC, 6 h and 24 h; antibody alone; reversal slopes for all contrasts |
| `figures/fig2_signature_heatmap.png` | The IL-33 endothelial programme gene by gene, its reversal, and the antibody-alone controls |
| `figures/fig3_biomarker_triage.png` | IL-33 induction in endothelium against outcome association in patients, protein by protein |
| `figures/fig4_serum_forest.png` | Serum proteins against the composite outcome, grouped by biological axis |
| `figures/fig5_postmortem_lung.png` | Lung immunohistochemistry at donor level, by group; within-lung neutrophil and IL-33 relation; sampling imbalance |
| `figures/fig6_rnaseq_qc.png` | Degenerate standard errors, void P values on the largest fold changes, and the noise floor in null contrasts |
| `tables/AX-1177_audit_tables.xlsx` | All tables in one workbook, with a README sheet; the same tables as CSV alongside |
| `tables/key_numbers.txt` | Every number quoted in the memo, recomputed from the delivered files |
| `scripts/` | Code; see below |

## Rerunning

```
cd scripts
python 01_build_intermediates.py     # parses the four workbooks (about 2 min; the contrasts workbook is 670 MB of XML)
python 02_key_numbers.py             # all quoted numbers -> tables/key_numbers.txt, T1, T4c
Rscript 02b_gsea_hallmark.R          # optional: Hallmark gene-set enrichment -> T6 (needs fgsea, msigdbr)
python 03_fig1_neutralisation.py     # ... and the other 03_fig*.py scripts
python 04_tables.py                  # remaining tables and the workbook
python 05_build_pdf.py ../AX-1177_portfolio_audit_memo.md ../AX-1177_portfolio_audit_memo.pdf
python 06_build_html.py ../AX-1177_portfolio_audit_memo.md ../AX-1177_portfolio_audit_memo.html
```

Paths default to `/tmp/world/filesystem` (inputs), `/tmp/work` (intermediates) and `/tmp/outputs`; override with `AX_RAW`, `AX_WORK`, `AX_OUT`.
Python needs pandas, numpy, scipy, statsmodels, openpyxl, matplotlib; the PDF step needs reportlab and the HTML step needs markdown.

## Conventions used throughout

- RNA-seq timepoint and contrast are read from the `Comparison` column. The two sheets of the contrasts workbook are identical and only one is used.
- Standard error of a log2 fold change is taken as |logFC / t|. Genes with a value above 2 in a cell line's contrasts are treated as having void P values there.
- Serum proteins measured on several panels are kept as separate assays for counting and collapsed to one protein (smallest P, mean z) when joined to the RNA-seq.
- Lung scores: "n+" is n + 0.5 (the workbook's own convention), "ND" and "N/A" are missing, donor fields are filled down from the donor's first block, and every test uses one value per donor.
