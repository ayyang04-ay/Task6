# AX-1177 (anti-IL-33 antibody): portfolio audit position

Prepared from the four delivered data files and the methods annex. Every number below is recomputed from those files. Where I lean on anything outside them (the vendor's Olink panel list, my grouping of markers into biological classes) I say so.

## 1. Recommendation

**Keep AX-1177, conditionally: re-scope the indication, and release no further development spend until Gates 0 and 1 are passed.**

- **Keep the molecule.** In our own data it does what an IL-33 neutraliser should do, and shows no activity of its own in the four cell types tested.
- **Retire the label "severe viral lower respiratory infection".** Our data do not show anything virus-specific. They point at a host-response state: acute, neutrophil-rich lung injury with endothelial activation, marked by high soluble ST2 (sST2). Viral infection is one cause of that state, and it is the only one we have patient data for, so it stays as the first cohort.
- **Release no IND-enabling spend yet.** The link between IL-33 and the disease is unproven. Gates 0 and 1 (section 5) settle it with small experiments and kill criteria agreed in advance. If Gate 1 is not funded or not passed, the right decision becomes drop.

| Why keep | Why only conditionally |
|---|---|
| **The pharmacology is clean.** Co-added at 10 µg/mL, AX-1177 reversed the endothelial response to IL-33 by a median 99.5% at 6 h and 83% at 24 h (335 and 104 robust IL-33-responsive genes). The isotype control had no such effect, and AX-1177 alone had no reproducible effect in four cell types. | **No evidence that IL-33 drives the disease.** IL-33 itself is missing from the serum table. sST2 is IL-33's decoy receptor, not IL-33, and 166 other proteins rise with severity too. IL-33-inducible endothelial products are no more likely to track outcome than any other protein (18% vs 17%). |
| **The axis shows up in patients.** sST2 at enrolment is one of only two proteins out of 1,063 that survive Bonferroni correction for ICU admission, ventilation or death (OR 3.0 per log unit, 95% CI 1.8 to 5.0, adjusted for age, sex and NEWS2). | **Nothing is virus-specific.** IL-33 staining is not higher in COVID-19 lung (it trends lower). COVID-negative pneumonia lungs carry the same IL-33 and neutrophil load. Secreted interferon markers do not track outcome. |
| **The target sits where the pathology is.** IL-33 is present at moderate to high levels in lung endothelium and basal epithelium in every one of 31 donors, and the programme it switches on in endothelium (neutrophil chemokines, IL-6, tissue factor) matches the neutrophil-rich, thrombotic lungs and the outcome-associated serum proteins. | **The package is narrow.** One concentration of antibody and of IL-33, added together; reduced IL-33 only; endothelium only, one donor per line; RNA only; no in vivo data. Some of the delivered statistics are defective (section 9). |

**Confidence.** High that AX-1177 neutralises IL-33 on endothelium at a saturating dose. Moderate to high that the viral framing is unsupported. Low, in either direction, on whether IL-33 drives severe pneumonia, which is why the recommendation is conditional.

## 2. What the data show

### 2.1 RNA-seq: AX-1177 neutralises IL-33 on endothelium and is inert alone (Figures 1, 2)

- **IL-33 response.** Reduced IL-33 (30 ng/mL) changed 4,031 genes in HUVEC at 6 h and 1,836 at 24 h (adj.P < 0.05). It is an NF-κB programme: neutrophil chemokines (CXCL1, 2, 3, 5, 6, 8), G-CSF, GM-CSF, M-CSF, IL-6, adhesion molecules, tissue factor up 50-fold and thrombomodulin halved. Hallmark gene-set analysis agrees: "TNFα signalling via NF-κB" ranks first (normalised enrichment score +3.0), followed by the interferon-response sets (+2.6). Type-2 effector genes (IL5, IL13, eotaxin-1 and -2, TARC) are not expressed in this system.
- **Neutralisation, HUVEC.** Against isotype + IL-33 (a contrast that shares no samples with IL-33 versus vehicle), the antibody effect mirrors the IL-33 effect: slope −0.93 (95% CI −0.96 to −0.89), r = −0.96; 99% of genes reverse direction and 93% are individually significant. At 24 h the median reversal is 83% against isotype + IL-33 and 96% against IL-33 alone.
- **Neutralisation, glomerular endothelium (HGMEC).** At 6 h AX-1177 reverses the same programme (1,460 genes; 90% of the robust ones are IL-33 genes in HUVEC; NFKBIA −2.6, TNFAIP3 −3.7 log2). By 24 h little is left (269 genes). HGMEC has no vehicle arm and no IL-33-versus-control contrast was delivered, so I cannot separate a transient HGMEC response from loss of neutralisation.
- **Antibody alone.** On the IL-33-responsive genes the slope is −0.01 to +0.08 in HUVEC, HGMEC, A549 and MCF7. Each of the 16 antibody-alone contrasts has 14 to 73 nominal hits out of 26,210 genes. Of the 632 in total, 78% sit at near-zero counts and 16% are shifts of at most 1.34-fold (median 1.09-fold) in highly expressed genes, where the pooled model reports very small errors. Only 11 genes recur in two independent sets of arms; the six that agree in direction are shifts under 1.15-fold (DOCK5, KRT8) or transcripts at near-zero counts.
- **Nothing beyond reversal.** With IL-33 present, 300 of the 330 antibody-responsive genes at 6 h (91%) are IL-33 genes moving back. None of the other 30 replicates at 24 h or in HGMEC.
- **Isotype control.** At 6 h, IC119 + IL-33 differs from IL-33 alone by 3% of the IL-33 effect in HUVEC and 0% in HGMEC. At 24 h the isotype arm sits 14% below IL-33 alone in HUVEC, which is why the two comparators give 83% and 96% reversal.
- **Timing.** The IL-33 signature falls to about one third of its 6 h amplitude by 24 h in HUVEC.
- **Dose context.** AX-1177 was at 68 nM against 1.7 nM IL-33, a 41-fold molar excess. This shows complete neutralisation at saturation. It says nothing about potency.

![Figure 1. AX-1177 neutralises the endothelial response to IL-33 and is inert alone.](figures/fig1_neutralisation.png)

![Figure 2. The IL-33 endothelial programme, its reversal, and the antibody-alone controls, gene by gene.](figures/fig2_signature_heatmap.png)

### 2.2 Serum proteomics: sST2 predicts deterioration, but as a prognostic marker (Figures 3, 4)

- **Cohort.** 100 patients hospitalised with COVID-19; 44 reached the composite endpoint (inferred from the table; the annex does not state it).
- **sST2.** OR 3.02 (1.83 to 5.01), P = 1.7 × 10⁻⁵, FDR 0.0075; second of 1,094 assays. Only HGF and sST2 pass Bonferroni.
- **What else tracks outcome.** IL-6 (measured on four panels, OR 2.1 to 2.3 on each), neutrophil proteins (PRTN3, CD177, LCN2, resistin), oncostatin M, PTX3, OPG, procalcitonin, suPAR and vWF.
- **A broad signal.** 178 assays (169 proteins) reach FDR < 0.05, and 176 of those assays (167 proteins) have OR > 1. Severe patients have more of almost everything, so a single association is weak evidence of mechanism.
- **What does not.** Type-2 markers: IL-5 OR 1.00, eotaxin-1 1.08, TARC 0.85, tryptase 1.07; the one exception is IL-4Rα (OR 2.7, FDR 0.02), which endothelium itself expresses. Secreted interferon markers: CXCL10 1.30 (P = 0.25), IFN-γ 1.03 (P = 0.78).
- **Bench-to-bedside overlap.** 19 proteins are both induced at least 2-fold by IL-33 in endothelium and outcome-associated: IL-6, CCL20, OPG, CSF-1, MCP-3, IL-18R1, IL-1β, cathepsin S and eight others with valid RNA statistics, plus sST2, IL-8 and PTX3 on fold change alone. As a class, however, IL-33-inducible proteins are not enriched among outcome proteins: 16 of 90 (18%) against 142 of 825 (17%), Fisher P = 0.88.
- **The target is absent.** Per the vendor's panel list, IL-33 is one of 15 Inflammation-panel assays missing from the delivered table, along with IL-4, IL-13 and TSLP. The adjusted P values were computed over 1,194 tests while 1,094 were delivered; at least four of the 100 undelivered assays would have been FDR-significant. No delivered assay has more than about 9% of values flagged in the two undocumented columns, which fits removal of poorly detected assays, but the annex does not say so.

![Figure 3. IL-33-inducible endothelial products against outcome association in patients.](figures/fig3_biomarker_triage.png)

![Figure 4. Serum proteins at enrolment and severe outcome, by biological axis.](figures/fig4_serum_forest.png)

### 2.3 Post-mortem lung: the target is there in every lung, and is not a COVID-19 feature (Figure 5)

- **Sample.** 31 donors aged 64 to 98, 74 blocks: 16 COVID-positive "pneumonia", 10 COVID-negative "pneumonia", 5 COVID-negative "non-pneumonia". All statistics are at donor level.
- **IL-33 is there in every lung.** Endothelium: median 5+ (the top score) in both COVID-negative groups, 4.8 in COVID-positive; lowest donor mean 3.0. Basal epithelium: medians 4.3 to 4.9 across the three groups; lowest donor mean 2.75.
- **Not higher in COVID-19.** Endothelial IL-33, COVID-positive minus COVID-negative pneumonia: −0.38 grade (95% CI −0.80 to +0.05; P = 0.16). Against all COVID-negative donors: −0.44 (P = 0.052). The data exclude a meaningful increase.
- **Neutrophils dominate; eosinophils are a minor component.** Neutrophil elastase averages 4.1 in both pneumonia groups against 3.0 in non-pneumonia (P = 0.007). Eosinophils are visible on H&E in 18 of 26 pneumonia donors and in none of the 5 non-pneumonia donors, but at low grade (eosinophil peroxidase 2.3; EDN and MBP about 2). They do not differ by COVID status (P 0.47 to 0.69) and do not track IL-33 staining (ρ = −0.10).
- **COVID-19 lungs show vascular injury.** Diffuse alveolar damage or acute lung injury in 7 of 16 and pulmonary thromboemboli in 4 of 16 COVID-positive donors, against 0 of 15 COVID-negative (my reading of the autopsy text).
- **Exploratory.** Within the same lung, the block with more neutrophils had less endothelial IL-33 in 7 donors, more in 1 and the same in 4 (mixed model −0.31 grade per neutrophil grade, P < 0.001). This fits release of stored IL-33 at inflamed sites, but staining loss cannot distinguish release from cell loss.

![Figure 5. Post-mortem lung immunohistochemistry at donor level.](figures/fig5_postmortem_lung.png)

## 3. What indication the data point at

**A host-response state, not a pathogen: hospitalised severe pneumonia at risk of respiratory failure, with high sST2 at enrolment, whatever the infectious cause.** The aim would be to prevent progression to ICU, ventilation or death, which is the endpoint our own cohort used.

Three observations also argue for treating at admission rather than in established respiratory failure: the prognostic signal is already present at enrolment; the IL-33 response in cells is fast and fades within a day; and stored IL-33 is lowest where neutrophil infiltration is heaviest.

The three datasets agree on four things:

1. **The cell is the endothelium.** It is the only cell type we exposed to IL-33, both endothelial lines responded, and endothelium carries the strongest and most uniform IL-33 staining in lung.
2. **The programme is neutrophil recruitment, IL-6 and coagulation.** That matches the tissue (neutrophil-rich, thrombotic) and the serum outcome markers.
3. **The virus is incidental.** COVID-negative pneumonia shows the same IL-33 reservoir and the same neutrophil load; outcome tracks procalcitonin and myeloid markers, not interferon markers.
4. **There is no type-2 signal to build on.** Eosinophils are a low-grade component of pneumonic lung with or without COVID-19 and do not track IL-33 staining; type-2 serum markers other than IL-4Rα do not track outcome; and the endothelial programme contains no type-2 effector genes.

What this does not establish: that sST2-high patients respond to IL-33 blockade; that non-COVID patients show the same serum pattern (we have no such serum); or that IL-33, rather than IL-1 or TNF which drive the same NF-κB programme, is responsible in patients.

| Option considered | Support in our data | Against, in our data | Verdict |
|---|---|---|---|
| Severe viral LRTI (current) | sST2 prognostic in COVID-19; clean pharmacology | No virus-specific signal in tissue or serum; one virus, one centre, pre-vaccination; AX-1177 also removes the interferon-type genes IL-33 induces in endothelium, a risk to test in infection | Keep only as the first cohort of the broader indication |
| sST2-high severe pneumonia, any pathogen | All of the above; tissue shows the same picture without COVID-19 | No non-COVID serum; no causal evidence | **Working indication, to be earned at Gate 1** |
| Type-2 or eosinophilic airway disease | IL-33 in basal epithelium; low-grade eosinophils in pneumonic lung | Eosinophils not COVID-specific and unrelated to IL-33 staining; type-2 serum markers flat except IL-4Rα; no type-2 cells tested | Not supported |
| COPD | Basal epithelial IL-33 in all donors, 11 with COPD; a faint trend to more basal-cell IL-33 with any chronic lung condition noted (4.65 vs 4.21, P = 0.08) | No difference by COPD status (P = 0.21); no airway pharmacology; no COPD cohort | Not supported yet; revisit if epithelial pharmacology is shown |
| Kidney (glomerular endothelium) | HGMEC responds at 6 h and AX-1177 blocks it | No vehicle arm, gone by 24 h, one donor; kidney injury markers weak (KIM-1 P = 0.03 to 0.07) | Not supported |
| Cardiac or vascular (sST2 as a heart marker; IL-33 in vessel wall) | None beyond sST2 | NT-proBNP and troponin I not significant (FDR 0.15 to 0.33); vascular IL-33 staining unrelated to recorded atherosclerosis or nephrosclerosis (P 0.68 to 0.95) | Not supported |
| Oncology (A549, MCF7) | None | No IL-33 arms in these lines; antibody inert | Ruled out |

## 4. Biomarkers, their roles, and when to sample

| Marker | Evidence in our data | Role | Into patients? |
|---|---|---|---|
| **sST2** (serum) | OR 3.02, FDR 0.0075; Bonferroni survivor. IL1RL1 transcript up 3-fold with IL-33 and reversed (point estimates only) | Enrichment and stratification at enrolment; prognostic covariate; exploratory pharmacodynamic marker | **Yes, now, as a stratifier.** It is prognostic, not yet predictive. Needs an absolute assay and a cut-off |
| **IL-6** (serum) | Four concordant assays. Transcript up 56-fold at 6 h, fully reversed; reversed in HGMEC | Pharmacodynamic response; prognostic covariate | **Yes.** Not specific to IL-33 |
| **IL-8, CCL20, OPG, CSF-1, MCP-3, IL-18R1, PTX3** (serum) | Each induced by IL-33, reversed by AX-1177, and FDR < 0.05 for outcome | Exploratory "IL-33 endothelial response" panel | **Yes, exploratory.** IL-8 and PTX3 transcript statistics need the refit |
| Tissue factor, PAI-1, E-selectin, MCP-1 (serum) | Induced and reversed; outcome P 0.008 to 0.048, FDR 0.05 to 0.15 | Mechanism (thrombo-inflammation) | Exploratory only |
| 29-gene transcript signature (NFKBIA, TNFAIP3, TRAF1, CXCL2, BIRC3, SOD2, C3, IL18R1 and others) | At least 4-fold up at 6 h, still 2-fold at 24 h, reversed, replicated in HGMEC, untouched by antibody alone | Potency and response read-out for cell assays, including the patient-serum assay in Gate 1 | No; it is a laboratory assay |
| CXCL1/2/3/5/6, G-CSF, GM-CSF, ICAM-1, VCAM-1 | Largest in vitro range, fully reversed; where a serum assay exists (CXCL1, CXCL5, CXCL6, G-CSF, ICAM-1, VCAM-1) not outcome-associated (P 0.11 to 0.95) | In vitro response only | No |
| HGF, oncostatin M, PRTN3, procalcitonin | Strong outcome markers; not IL-33-inducible in endothelium | Prognostic covariates | As covariates, not as response markers |
| IL-5, eotaxins, TARC, tryptase, CD23 | No association with outcome (ECP nominal only: P = 0.011, FDR 0.06) | None | No |
| **IL-33 and IL-33:sST2 complex** | **Not in our data** | Target engagement | **Must be built first** |

**Sampling timepoint.**

- **Cell assays: 6 h.** It has the larger signal (4,031 against 1,836 genes), complete reversal, and it is the only timepoint at which both endothelial beds respond. At 24 h the HUVEC signal is down to a third and the HGMEC signal is largely gone. Add supernatant protein at 6 and 24 h, and bracket with 1 to 2 h and 48 h in the next run.
- **Patients: serum at enrolment, before dosing.** This is the only timepoint our cohort supports, and it is where sST2 carried its signal. On-treatment sampling within 24 h, then days 2 to 3 and day 7, is my proposal based on the fast, transient in vitro response; it is not derived from patient data.

## 5. What the next studies have to establish

**Gate 0. Repair and recover (no new wet work).**

1. Refit the RNA-seq per cell line from the archived counts. This restores valid statistics for about 140 genes including SELE, VCAM1, CXCL8, CXCL1, CCL2, IL1RL1 and PTX3, and yields the missing HGMEC IL-33 contrasts.
2. Retrieve the 100 undelivered serum assays, above all IL-33, with detection rates. From patient-level data: sST2 discrimination beyond NEWS2, a cut-off, and whether sST2 travels with the IL-33 endothelial panel or with generic injury markers.
3. Blinded second read of the lung slides, and reconcile group labels with autopsy text.
4. Pull affinity, potency and species cross-reactivity from the biologics file, which was not part of this delivery; Gate 2 cannot be designed without them.

**Gate 1. Is IL-33 a driver in patient material, and does AX-1177 behave like a drug?**

1. **Patient-serum assay.** Serum from sST2-high and sST2-low patients on primary lung microvascular endothelium (at least three donors), with AX-1177 or isotype and with IL-1 and TNF blockade as comparators; 29-gene signature and secreted IL-6, IL-8 and CCL20 at 6 h. This measures the share of patient-driven endothelial activation that depends on IL-33.
2. **Target in patients.** Reduced and oxidised IL-33 and the IL-33:sST2 complex by a high-sensitivity assay in the same sera; ST2 staining on the existing lung blocks.
3. **Pharmacology.** Concentration-response; antibody added 0.5 to 4 h after IL-33; activity in the presence of sST2; specificity against IL-1β and TNF; oxidised IL-33 and primary airway epithelium; protein and functional read-outs (neutrophil adhesion, barrier, tissue-factor activity).

*Kill if* AX-1177 removes only a minor share of patient-serum-driven activation and IL-33 is undetectable or unrelated to sST2, or if activity is lost when the antibody is added an hour or two after IL-33. Thresholds to be fixed before the experiment.

**Gate 2. In vivo benefit without harm.** Therapeutic dosing in viral and non-viral lung-injury models, with pathogen load as a safety endpoint; an independent serum cohort that includes non-COVID pneumonia to replicate sST2 and fix the cut-off. Then a biomarker-stratified Phase 1b/2a.

## 6. What I considered and ruled out

- **sST2 as proof that IL-33 drives disease.** Ruled out; it is prognostic only, and the enrichment test is null.
- **A virus-specific rationale.** Not supported by tissue or serum.
- **A type-2 or eosinophilic positioning.** Not supported: eosinophils are present at low grade in pneumonic lung but are unrelated to COVID status or IL-33 staining, type-2 serum markers do not track outcome, and no type-2 cells were tested.
- **Kidney, cardiac and oncology repurposing.** No adequate support (section 3).
- **Off-target or agonist activity of AX-1177, and an isotype artefact.** Ruled out at transcript level in four cell types.
- **Loss of antibody effect by 24 h.** Ruled out in HUVEC; unresolved in HGMEC.
- **IL-33 up-regulation in COVID-19 lung.** Ruled out.
- **The block-level lung analysis.** Rejected: three donors supply 24 of 49 COVID-positive blocks, and block-level P = 0.017 becomes donor-level P = 0.052.
- **Ranking RNA-seq genes by fold change.** Rejected: the top rows of the delivered sheet (SELE, VCAM1, CXCL8, CXCL1) carry P values of 0.05 to 0.99 because of a model artefact. Their fold changes do replicate across independent arms (reversal 98 to 105%).
- **Ranking serum proteins by odds ratio.** Rejected: ORs are per log unit of each assay and are not comparable (CSF-1 OR 90, CI 4 to 1,933). I ranked by P and z.
- **HGF as an AX-1177 marker.** Rejected: the strongest outcome protein, but not IL-33-inducible in endothelium.

## 7. Challenges to expect, and the answers the data allow

- **"sST2 is high, so IL-33 is driving this."** Not shown. sST2 is prognostic; IL-33 was not reported; the class-level test is null. Gate 1 answers it.
- **"Your endothelial signature is generic NF-κB; IL-1 or TNF would do the same."** Correct, and we have no comparator arms. The patient-serum assay with IL-1 and TNF blockade alongside AX-1177 is designed for exactly this.
- **"Can we trust the RNA-seq, given the statistics?"** Yes for the headline. Reversal is seen in contrasts that share no samples, against two comparators, in two endothelial beds, across 335 genes. The defect affects about 140 genes and is fixable from the archived counts.
- **"IL-33 is lower in COVID-19 lung. Is the target gone?"** The stores are not higher, and may be depleted where inflammation is worst. That fits release, but staining cannot prove it. It argues for treating early.
- **"There are no in vivo data."** Correct. That is Gate 2, and it should include pathogen load, because AX-1177 also removes the interferon-type genes that IL-33 induces in endothelium.

## 8. If the committee drops it

We would be dropping a selective IL-33 neutraliser with clean in vitro pharmacology and a ready enrichment marker. We would not be dropping a validated respiratory-infection medicine, because we never had one: the disease link rests on one prognostic protein and one cell type, with no causal, virus-specific or in vivo evidence. That is a legitimate reason to stop. The case against stopping now is that Gates 0 and 1 are small and would turn the decision from a judgement into a result.

## 9. Data problems the committee should know about

| File | Problem | Consequence and fix |
|---|---|---|
| RNA-seq contrasts | Sheets "6h" and "24h" are the same 629,040 rows (all 24 contrasts, both timepoints) | Read the timepoint from the Comparison column, never the sheet name |
| RNA-seq | One model across four cell types gives impossible standard errors (up to 16,536 log2 units) for 139 genes in HUVEC contrasts, including SELE, VCAM1, CXCL8, CXCL1, CCL2, IL1RL1, PTX3; and implausibly small ones in A549 and MCF7 | P values for these genes are void; refit per cell line |
| RNA-seq | 14 to 73 false "hits" in every null contrast; AveExpr is a four-cell-line average | Use effect size, expression and replication, not adj.P alone |
| RNA-seq | HGMEC has no vehicle arm; no HGMEC IL-33 contrast delivered | Extract IL-33 + isotype versus isotype from the archived model |
| Serum | 100 tested assays not delivered, and IL-33 absent; adjusted P computed over 1,194 tests | Retrieve them |
| Serum | 27 proteins measured on two to four panels; two undocumented columns; two hidden rows and one hidden column | 178 significant assays are 169 proteins; duplicates agree (r = 0.98) |
| Lung | All IHC columns are hidden in the workbook; donor fields only on the first block; "n+" stored as n + 0.5, so the 0 to 5 scale runs to 5.5; 53% of endothelial scores at the ceiling | Handled in this analysis; note the ceiling |
| Lung | Labels disagree with autopsy text in 8 of 31 donors (4 of 10 COVID-negative "pneumonia" and 2 of 16 COVID-positive "pneumonia" donors have no acute pneumonia; 2 of 5 "non-pneumonia" donors have pneumonia or pneumonitis); one donor has no SARS-CoV-2 result; no normal lung; single reader | Conclusions unchanged when donors are reclassified by autopsy text |

![Figure 6. RNA-seq quality control.](figures/fig6_rnaseq_qc.png)

## 10. Limits of this analysis

I had summary tables only: no counts, no patient-level data, no slides, and nothing from the biologics file (affinity, potency, species cross-reactivity). The event count and the meaning of the two undocumented serum columns are inferences. The marker groupings in Figure 4 are my own. Public clinical experience with IL-33-pathway antibodies exists and belongs next to this memo, but I did not use it to reach the recommendation.

## Definitions

- **Robust IL-33-responsive gene.** adj.P < 0.01 and at least a 2-fold change for IL-33 versus vehicle in HUVEC at that timepoint, pooled AveExpr of 1 or more, and a standard error that is not degenerate (335 genes at 6 h, 104 at 24 h).
- **Reversal.** Minus the antibody log2 fold change divided by the IL-33 log2 fold change; 100% means the antibody arm is back at vehicle level.
- **Degenerate standard error.** |logFC / t| above 2 log2 units. More than 99% of gene-by-contrast values lie between 0.02 and 1.8; the rest run up to 36,723, which replicate variation cannot produce.
- **Outcome-associated.** FDR < 0.05 as delivered and OR > 1.
- **IHC scores.** 0 to 5, with "n+" stored as n + 0.5; donor value is the mean of that donor's blocks.

## Files

- `AX-1177_portfolio_audit_memo.pdf` and `.html`: this memo with the figures embedded.
- `figures/fig1_neutralisation.png` to `fig6_rnaseq_qc.png`: the six figures cited above.
- `tables/AX-1177_audit_tables.xlsx`: all supporting tables in one workbook; the same tables as CSV in `tables/`.
- `tables/key_numbers.txt`: every number quoted in this memo, recomputed from the delivered files.
- `scripts/`: the code that produced every number, table and figure; `README.md` explains how to rerun it.
