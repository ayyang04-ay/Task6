import importlib, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_P = importlib.import_module('00_paths'); WORK, OUT = _P.WORK, _P.OUT
from common import *
from scipy import stats
import warnings; warnings.filterwarnings('ignore')
out = os.path.join(OUT, 'tables') + os.sep
fl = pd.read_pickle(os.path.join(WORK, 'se_flags.pkl')); gm = pd.read_pickle(os.path.join(WORK, 'gene_master.pkl'))
M = pd.read_pickle(os.path.join(WORK, 'master_serum_rna.pkl')); S = pd.read_pickle(os.path.join(WORK, 'serum3.pkl'))
SE = (L/T).abs()

# ---- T0 contrast summary
rows=[]
desc = {'IL33vVeh_HUV6':'IL-33red vs vehicle, HUVEC 6 h','IL33vVeh_HUV24':'IL-33red vs vehicle, HUVEC 24 h',
 'C47IL33vIL33IC_HUV6':'AX-1177+IL-33 vs IC119+IL-33, HUVEC 6 h','C47IL33vIL33IC_HUV24':'AX-1177+IL-33 vs IC119+IL-33, HUVEC 24 h','C47IL33vIL33_HUV6':'AX-1177+IL-33 vs IL-33, HUVEC 6 h','C47IL33vIL33_HUV24':'AX-1177+IL-33 vs IL-33, HUVEC 24 h',
 'C47IL33vIL33IC_HGM6':'AX-1177+IL-33 vs IC119+IL-33, HGMEC 6 h','C47IL33vIL33IC_HGM24':'AX-1177+IL-33 vs IC119+IL-33, HGMEC 24 h','C47IL33vIL33_HGM6':'AX-1177+IL-33 vs IL-33, HGMEC 6 h','C47IL33vIL33_HGM24':'AX-1177+IL-33 vs IL-33, HGMEC 24 h'}
inv = {v:k for k,v in short.items()}
for c in L.columns:
    q=Q[c]; l=L[c]
    rows.append(dict(contrast_as_delivered=inv[c], short_name=c, description=desc.get(c, c.replace('C47v','AX-1177 alone vs ').replace('IC_','IC119, ').replace('DMSO_','DMSO, ').replace('PBS_','PBS, ')), n_genes=len(q),
        n_adjP_lt_0_05=int((q<0.05).sum()), n_up=int(((q<0.05)&(l>0)).sum()), n_down=int(((q<0.05)&(l<0)).sum()), n_adjP_lt_0_05_and_abs_log2FC_ge_1=int(((q<0.05)&(l.abs()>=1)).sum()),
        n_sig_with_pooled_AveExpr_lt_0=int(((q<0.05)&(ann.AveExpr<0)).sum()), n_sig_with_abs_log2FC_lt_0_5=int(((q<0.05)&(l.abs()<0.5)).sum()), n_genes_SE_gt_2=int((SE[c]>2).sum()), n_genes_SE_lt_0_02=int((SE[c]<0.02).sum())))
pd.DataFrame(rows).to_csv(out+'T0_rnaseq_contrast_summary.csv', index=False)

# ---- T2a transcript PD signature (tier A)
d = gm.copy()
A = d[(d.q_IL33_6<0.01)&(d.IL33_6>=2)&(d.q_IL33_24<0.05)&(d.IL33_24>=1)&(d.q_ab6<0.01)&(d.rev6>=0.8)&(d.q_ab24<0.05)&(d.rev24>=0.6)&(d.q_abHGM6<0.05)&(d.abHGM6<=-1)&(d.AveExpr>=0)&(~d.se_degenerate_HUVEC)&(d[['alone_HUV6','alone_HUV24','alone_HGM6','alone_HGM24']].abs().max(axis=1)<1)]
A = A.sort_values('t_IL33_6', ascending=False)
colsA = ['symbol','AveExpr','IL33_6','q_IL33_6','IL33_24','q_IL33_24','ab6','q_ab6','rev6','ab24','q_ab24','rev24','abHGM6','q_abHGM6','abHGM24','alone_HUV6','alone_HUV24','alone_HGM6','alone_HGM24']
ren = {'IL33_6':'log2FC_IL33_vs_vehicle_HUVEC_6h','q_IL33_6':'adjP_IL33_HUVEC_6h','IL33_24':'log2FC_IL33_vs_vehicle_HUVEC_24h','q_IL33_24':'adjP_IL33_HUVEC_24h','ab6':'log2FC_AX1177+IL33_vs_IC119+IL33_HUVEC_6h','q_ab6':'adjP_AX1177_HUVEC_6h','rev6':'fraction_reversed_HUVEC_6h',
       'ab24':'log2FC_AX1177+IL33_vs_IC119+IL33_HUVEC_24h','q_ab24':'adjP_AX1177_HUVEC_24h','rev24':'fraction_reversed_HUVEC_24h','abHGM6':'log2FC_AX1177+IL33_vs_IC119+IL33_HGMEC_6h','q_abHGM6':'adjP_AX1177_HGMEC_6h','abHGM24':'log2FC_AX1177+IL33_vs_IC119+IL33_HGMEC_24h',
       'alone_HUV6':'log2FC_AX1177_alone_vs_IC119_HUVEC_6h','alone_HUV24':'log2FC_AX1177_alone_vs_IC119_HUVEC_24h','alone_HGM6':'log2FC_AX1177_alone_vs_IC119_HGMEC_6h','alone_HGM24':'log2FC_AX1177_alone_vs_IC119_HGMEC_24h','AveExpr':'AveExpr_pooled_114_libraries'}
A[colsA].rename(columns=ren).to_csv(out+'T2a_transcript_PD_signature_29_genes.csv', index_label='ensembl')
print('signature genes:', len(A), ', '.join(A.symbol))

# ---- T2b protein biomarker candidates: all Olink proteins with RNA, annotated
m = M[M.in_rna].copy()
g2 = gm.drop_duplicates('symbol').set_index('symbol')
for c in ['rev6','rev24','abHGM24','q_abHGM24','max_abs_alone','se_degenerate_HUVEC','se_degenerate_HGMEC','q_ab24']:
    m[c] = m.symbol.map(g2[c])
m['IL33_inducible_ge2fold_valid_stats'] = ((m.IL33vVeh_HUV6_q<0.05)&(m.IL33vVeh_HUV6_lfc>=1)&~m.se_degenerate_HUVEC) | ((m.IL33vVeh_HUV24_q<0.05)&(m.IL33vVeh_HUV24_lfc>=1)&~m.se_degenerate_HUVEC)
m['IL33_inducible_point_estimate_only'] = m.se_degenerate_HUVEC & ((m.IL33vVeh_HUV6_lfc>=1)|(m.IL33vVeh_HUV24_lfc>=1))
m['reversed_by_AX1177_ge80pct_6h'] = (m.rev6>=0.8)
m['outcome_associated_FDR05'] = (m.adjp<0.05)&(m.OR>1)
def cls(r):
    ind = r.IL33_inducible_ge2fold_valid_stats or r.IL33_inducible_point_estimate_only
    if ind and r.outcome_associated_FDR05: return 'A: IL-33-inducible in endothelium AND outcome-associated in patients'
    if ind and r.p<0.05: return 'B: IL-33-inducible; nominal outcome association only (P<0.05, FDR>=0.05)'
    if ind: return 'C: IL-33-inducible; not outcome-associated (in vitro PD only)'
    if r.outcome_associated_FDR05: return 'D: outcome-associated; not IL-33-inducible in endothelium (prognostic context only)'
    return 'E: neither'
m['class'] = m.apply(cls, axis=1)
colsB = ['symbol','assay','panel','n_assays','OR','l95','u95','p','adjp','z','AveExpr','se_degenerate_HUVEC','IL33vVeh_HUV6_lfc','IL33vVeh_HUV6_q','IL33vVeh_HUV24_lfc','IL33vVeh_HUV24_q','C47IL33vIL33IC_HUV6_lfc','C47IL33vIL33IC_HUV6_q','rev6','C47IL33vIL33IC_HUV24_lfc','q_ab24','rev24','C47IL33vIL33IC_HGM6_lfc','C47IL33vIL33IC_HGM6_q','abHGM24','max_abs_alone','class']
renB = {'OR':'serum_OR_per_log_unit','l95':'serum_OR_l95','u95':'serum_OR_u95','p':'serum_P','adjp':'serum_FDR_as_delivered','z':'serum_Wald_z_mean_over_assays','n_assays':'n_Olink_assays_for_protein','AveExpr':'AveExpr_pooled','se_degenerate_HUVEC':'RNAseq_SE_degenerate_in_HUVEC_pvalues_void',
        'IL33vVeh_HUV6_lfc':'log2FC_IL33_HUVEC_6h','IL33vVeh_HUV6_q':'adjP_IL33_HUVEC_6h','IL33vVeh_HUV24_lfc':'log2FC_IL33_HUVEC_24h','IL33vVeh_HUV24_q':'adjP_IL33_HUVEC_24h','C47IL33vIL33IC_HUV6_lfc':'log2FC_AX1177+IL33_vs_IC119+IL33_HUVEC_6h','C47IL33vIL33IC_HUV6_q':'adjP_AX1177_HUVEC_6h','rev6':'fraction_reversed_HUVEC_6h',
        'C47IL33vIL33IC_HUV24_lfc':'log2FC_AX1177+IL33_vs_IC119+IL33_HUVEC_24h','q_ab24':'adjP_AX1177_HUVEC_24h','rev24':'fraction_reversed_HUVEC_24h','C47IL33vIL33IC_HGM6_lfc':'log2FC_AX1177+IL33_vs_IC119+IL33_HGMEC_6h','C47IL33vIL33IC_HGM6_q':'adjP_AX1177_HGMEC_6h','abHGM24':'log2FC_AX1177+IL33_vs_IC119+IL33_HGMEC_24h','max_abs_alone':'max_abs_log2FC_AX1177_alone_any_of_16_contrasts'}
mm = m.sort_values(['class','p'])[colsB].rename(columns=renB)
mm.to_csv(out+'T2b_serum_protein_x_endothelial_RNA_all_915_proteins.csv', index=False)
print(m['class'].value_counts().to_string())
print(m[m['class'].str.startswith('A')].sort_values('p')[['symbol','assay','OR','p','adjp','IL33vVeh_HUV6_lfc','IL33vVeh_HUV24_lfc','rev6','rev24','C47IL33vIL33IC_HGM6_lfc','se_degenerate_HUVEC']].round(3).to_string(index=False))
print(m[m['class'].str.startswith('B')].sort_values('p')[['symbol','assay','OR','p','adjp','IL33vVeh_HUV6_lfc','IL33vVeh_HUV24_lfc','rev6','rev24','C47IL33vIL33IC_HGM6_lfc','se_degenerate_HUVEC']].round(3).to_string(index=False))

# ---- T3 full annotated serum table (all 1094 assays)
S2 = S[['rank','panel','assay','symbol','OR','l95','u95','p.value','adj.p.value','z','composite_endpoint_0','composite_endpoint_1','in_rna']].copy()
S2['n_assays_same_protein'] = S2.groupby('symbol').assay.transform('size')
S2['hidden_row_in_delivered_file'] = S2.assay.isin(['HGF-ONCII','IL6-ONCII'])
S2['passes_Bonferroni_1194_tests'] = S2['p.value'] < 0.05/1194
S2 = S2.rename(columns={'rank':'delivered_rank','symbol':'gene_symbol_mapped','z':'Wald_z','in_rna':'gene_present_in_RNAseq_table','composite_endpoint_0':'undocumented_col_composite_endpoint_0_(multiples_of_1/56)','composite_endpoint_1':'undocumented_col_composite_endpoint_1_(multiples_of_1/44)'})
S2.to_csv(out+'T3b_serum_all_1094_assays_annotated.csv', index=False)

# ---- T5 degenerate SE genes
d5 = pd.DataFrame({'symbol':ann.symbol,'AveExpr_pooled':ann.AveExpr,'SE_degenerate_HUVEC':fl.infl_huv,'SE_degenerate_HGMEC':fl.infl_hgm,'SE_degenerate_A549':fl.infl_a549,'SE_degenerate_MCF7':fl.infl_mcf7,'SE_implausibly_small_A549':fl.defl_a549,'SE_implausibly_small_MCF7':fl.defl_mcf7,
   'median_SE_HUVEC_contrasts':SE[[c for c in SE.columns if 'HUV' in c]].median(axis=1),'median_SE_HGMEC_contrasts':SE[[c for c in SE.columns if 'HGM' in c]].median(axis=1),'median_SE_A549_contrasts':SE[[c for c in SE.columns if 'A549' in c]].median(axis=1),'median_SE_MCF7_contrasts':SE[[c for c in SE.columns if 'MCF7' in c]].median(axis=1),
   'log2FC_IL33_HUVEC_6h':L['IL33vVeh_HUV6'],'t_IL33_HUVEC_6h':T['IL33vVeh_HUV6'],'P_IL33_HUVEC_6h':P['IL33vVeh_HUV6'],'log2FC_AX1177+IL33_vs_IC119+IL33_HUVEC_6h':L['C47IL33vIL33IC_HUV6'],'log2FC_IL33_HUVEC_24h':L['IL33vVeh_HUV24'],'log2FC_AX1177+IL33_vs_IC119+IL33_HUVEC_24h':L['C47IL33vIL33IC_HUV24'],'log2FC_AX1177+IL33_vs_IC119+IL33_HGMEC_6h':L['C47IL33vIL33IC_HGM6']})
anyf = d5[['SE_degenerate_HUVEC','SE_degenerate_HGMEC','SE_degenerate_A549','SE_degenerate_MCF7','SE_implausibly_small_A549','SE_implausibly_small_MCF7']].any(axis=1)
d5[anyf].sort_values('median_SE_HUVEC_contrasts', ascending=False).to_csv(out+'T5_rnaseq_genes_with_degenerate_standard_errors.csv', index_label='ensembl')
print('degenerate list n=', anyf.sum())

# ---- T4 lung
don = pd.read_pickle(os.path.join(WORK, 'lung_donors.pkl')); blk = pd.read_pickle(os.path.join(WORK, 'lung_blocks.pkl'))
dd = don[['sample','cat','sex','age','sars','n_blocks','notes','acute_pneu','dad','thrombo','IL33_endo_num','IL33_epi_num','IL33_vsmc_num','NEn_num','EPXn_num','TRYPn_num','EDN_num','MBP_num','2D7_num','IL5Ra_NE_num','HE_eos_frac']].copy()
dd['label_vs_pathology'] = np.where(dd.cat.str.contains('non-pneumonia') & dd.acute_pneu, 'labelled non-pneumonia but acute pneumonia/pneumonitis in autopsy text', np.where(~dd.cat.str.contains('non-pneumonia') & ~dd.acute_pneu, 'labelled pneumonia but no acute pneumonia in autopsy text','consistent'))
dd = dd.rename(columns={'sample':'donor','cat':'disease_category_as_delivered','sars':'SARS_CoV_2_as_delivered','notes':'approved_lung_conditions_all_blocks','acute_pneu':'acute_pneumonia_or_ALI_in_autopsy_text','dad':'DAD_or_acute_lung_injury_in_autopsy_text','thrombo':'pulmonary_thromboemboli_in_autopsy_text',
   'IL33_endo_num':'IL33_endothelium_donor_mean','IL33_epi_num':'IL33_basal_epithelium_donor_mean','IL33_vsmc_num':'IL33_vascular_smooth_muscle_donor_mean','NEn_num':'neutrophil_elastase_donor_mean','EPXn_num':'eosinophil_peroxidase_donor_mean','TRYPn_num':'tryptase_donor_mean','EDN_num':'EDN_donor_mean','MBP_num':'MBP_donor_mean','2D7_num':'2D7_donor_mean','IL5Ra_NE_num':'IL5Ra_duplexNE_donor_mean','HE_eos_frac':'fraction_blocks_HE_eosinophils_apparent'})
dd.to_csv(out+'T4a_lung_donor_level.csv', index=False)
b = blk[['sample','block','lobe','cat_ff','sex_ff','age_ff','sars_ff','HE_eos','EPX','EDN','MBP','2D7','IL5Ra_NE','NE_dup','IL5Ra_T','Tryp_dup','EPXn_num','NEn_num','TRYPn_num','IL33_epi','IL33_epi_num','IL33_endo_num','IL33_vsmc_num','notes','xl_row']].rename(columns={'sample':'donor','cat_ff':'disease_category_filled','sex_ff':'sex_filled','age_ff':'age_filled','sars_ff':'SARS_CoV_2_filled','IL33_epi':'IL33_basal_epithelium_raw_cell','IL33_epi_num':'IL33_basal_epithelium','IL33_endo_num':'IL33_endothelium','IL33_vsmc_num':'IL33_vascular_smooth_muscle','EPXn_num':'EPX_numeric','NEn_num':'NE_numeric','TRYPn_num':'tryptase_numeric','xl_row':'excel_row'})
b.to_csv(out+'T4b_lung_block_level_cleaned.csv', index=False)
pass  # T4c is written by 02_key_numbers.py
print('done')

# ---- one workbook with everything
import glob
readme = pd.DataFrame({'sheet': ['T0_contrasts', 'T1_neutralisation', 'T2a_signature', 'T2b_protein_x_RNA', 'T3_serum_axes', 'T3b_serum_all', 'T4a_lung_donors', 'T4b_lung_blocks', 'T4c_lung_tests', 'T5_degenerate_SE', 'T6_hallmark_NES'],
  'content': ['RNA-seq: every delivered contrast, number of genes at adj.P<0.05, and how many of those are near-zero-count or trivially small effects',
              'RNA-seq: slope of the antibody effect on the IL-33 effect across robust IL-33-responsive genes (-1 = complete reversal), with bootstrap 95% CI, for every contrast',
              'RNA-seq: the 29-gene transcript signature proposed as the potency / response read-out for cell assays',
              'Bench-to-bedside: every Olink protein whose gene is in the RNA-seq table (915), with serum association and endothelial IL-33 / AX-1177 statistics, classed A to E',
              'Serum: the assays shown in Figure 4, by biological axis',
              'Serum: all 1,094 delivered assays with gene mapping, Wald z, duplicate-panel count, Bonferroni flag, hidden-row flag',
              'Lung: one row per donor (mean of blocks), with pathology coded from the autopsy text and a flag where it contradicts the group label',
              'Lung: one row per block after cleaning (donor fields filled down, "n+" -> n+0.5, ND / N/A -> missing)',
              'Lung: donor-level group comparisons (difference of means with bootstrap 95% CI, Mann-Whitney P)',
              'RNA-seq: genes whose standard errors are degenerate (SE>2 log2 units) or implausibly small (SE<0.02) in the pooled model, by cell line',
              'RNA-seq: Hallmark gene-set enrichment (normalised enrichment score) for every contrast; present only if the optional R step was run']})
files = {'T0_contrasts': 'T0_rnaseq_contrast_summary.csv', 'T1_neutralisation': 'T1_neutralisation_slopes.csv', 'T2a_signature': 'T2a_transcript_PD_signature_29_genes.csv', 'T2b_protein_x_RNA': 'T2b_serum_protein_x_endothelial_RNA_all_915_proteins.csv',
         'T3_serum_axes': 'T3_serum_axis_forest.csv', 'T3b_serum_all': 'T3b_serum_all_1094_assays_annotated.csv', 'T4a_lung_donors': 'T4a_lung_donor_level.csv', 'T4b_lung_blocks': 'T4b_lung_block_level_cleaned.csv',
         'T4c_lung_tests': 'T4c_lung_group_tests_donor_level.csv', 'T5_degenerate_SE': 'T5_rnaseq_genes_with_degenerate_standard_errors.csv', 'T6_hallmark_NES': 'T6_hallmark_gsea_NES_wide.csv'}
with pd.ExcelWriter(os.path.join(OUT, 'tables', 'AX-1177_audit_tables.xlsx'), engine='openpyxl') as xw:
    readme.to_excel(xw, sheet_name='README', index=False)
    for sh, fn in files.items():
        pth = os.path.join(OUT, 'tables', fn)
        if os.path.exists(pth): pd.read_csv(pth).to_excel(xw, sheet_name=sh, index=False)
    for ws in xw.book.worksheets:
        ws.freeze_panes = 'A2'
        for col in ws.columns:
            w = max(len(str(c.value)) if c.value is not None else 0 for c in col[:60])
            ws.column_dimensions[col[0].column_letter].width = min(max(10, w + 2), 70)
print('workbook written')
