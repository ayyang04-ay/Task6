"""Loads the intermediates written by 01_build_intermediates.py (wide logFC / t / P / adj.P matrices, annotation)."""
import importlib, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_P = importlib.import_module('00_paths'); WORK, OUT = _P.WORK, _P.OUT
import pandas as pd, numpy as np
pd.set_option('display.width',320); pd.set_option('display.max_columns',80); pd.set_option('display.max_rows',2000)
L = pd.read_pickle(os.path.join(WORK, 'wide_logFC.pkl')); T = pd.read_pickle(os.path.join(WORK, 'wide_t.pkl')); P = pd.read_pickle(os.path.join(WORK, 'wide_P.Value.pkl')); Q = pd.read_pickle(os.path.join(WORK, 'wide_adj.P.Val.pkl')); B = pd.read_pickle(os.path.join(WORK, 'wide_B.pkl'))
ann = pd.read_pickle(os.path.join(WORK, 'gene_ann.pkl'))
sym2ens = {}
for e,s in ann.symbol.items():
    sym2ens.setdefault(s, []).append(e)
short = {
 'IL33_vs_Nontreated_HUVEC_6_hrs':'IL33vVeh_HUV6',
 'IL33_vs_Nontreated_HUVEC_24_hrs':'IL33vVeh_HUV24',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs':'C47IL33vIL33IC_HUV6',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs':'C47IL33vIL33IC_HUV24',
 'Compound_47_IL33_vs_IL33_HUVEC_6hrs':'C47IL33vIL33_HUV6',
 'Compound_47_IL33_vs_IL33_HUVEC_24hrs':'C47IL33vIL33_HUV24',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs':'C47IL33vIL33IC_HGM6',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs':'C47IL33vIL33IC_HGM24',
 'Compound_47_IL33_vs_IL33_HGMEC_6hrs':'C47IL33vIL33_HGM6',
 'Compound_47_IL33_vs_IL33_HGMEC_24hrs':'C47IL33vIL33_HGM24',
 'Compound_47_vs_IC119_HUVEC_6hrs':'C47vIC_HUV6',
 'Compound_47_vs_IC119_HUVEC_24hrs':'C47vIC_HUV24',
 'Compound_47_vs_IC119_HGMEC_6hrs':'C47vIC_HGM6',
 'Compound_47_vs_IC119_HGMEC_24hrs':'C47vIC_HGM24',
 'Compound_47_vs_IC119_A549_6hrs':'C47vIC_A549_6',
 'Compound_47_vs_IC119_A549_24hrs':'C47vIC_A549_24',
 'Compound_47_vs_IC119_MCF7_6hrs':'C47vIC_MCF7_6',
 'Compound_47_vs_IC119_MCF7_24hrs':'C47vIC_MCF7_24',
 'Compound_47_vs_DMSO_A549_6hrs':'C47vDMSO_A549_6',
 'Compound_47_vs_DMSO_A549_24hrs':'C47vDMSO_A549_24',
 'Compound_47_vs_DMSO_MCF7_6hrs':'C47vDMSO_MCF7_6',
 'Compound_47_vs_DMSO_MCF7_24hrs':'C47vDMSO_MCF7_24',
 'Compound_47_vs_PBS_A549_6hrs':'C47vPBS_A549_6',
 'Compound_47_vs_PBS_A549_24hrs':'C47vPBS_A549_24',
 'Compound_47_vs_PBS_MCF7_6hrs':'C47vPBS_MCF7_6',
 'Compound_47_vs_PBS_MCF7_24hrs':'C47vPBS_MCF7_24',
}
order = list(short.keys())
for W in (L,T,P,Q,B):
    W.rename(columns=short, inplace=True)
order_s = [short[o] for o in order]
L = L[order_s]; T = T[order_s]; P = P[order_s]; Q = Q[order_s]; B = B[order_s]
def show(symbols, cols=None, what=('logFC','adjP')):
    cols = cols or order_s
    rows = []
    for s in symbols:
        for e in sym2ens.get(s, []):
            r = {'symbol': s, 'AveExpr': round(ann.AveExpr[e],2)}
            for c in cols:
                r[c] = '%+.2f%s' % (L.at[e,c], '***' if Q.at[e,c]<0.001 else '**' if Q.at[e,c]<0.01 else '*' if Q.at[e,c]<0.05 else '')
            rows.append(r)
    return pd.DataFrame(rows)
