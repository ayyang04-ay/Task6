import importlib, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_P = importlib.import_module('00_paths'); WORK, OUT = _P.WORK, _P.OUT
from common import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
plt.rcParams.update({'font.size':8.5,'font.family':'DejaVu Sans'})
fl = pd.read_pickle(os.path.join(WORK, 'se_flags.pkl'))
classes = [
 ('NF-κB pathway / feedback', ['NFKBIA','TNFAIP3','TRAF1','NFKB2','RELB','BIRC3','NFKBIZ']),
 ('Neutrophil chemokines', ['CXCL1','CXCL2','CXCL3','CXCL5','CXCL6','CXCL8']),
 ('Other chemokines', ['CCL2','CCL20','CX3CL1','CXCL10']),
 ('Cytokines / myeloid growth factors', ['IL6','LIF','CSF1','CSF2','CSF3','IL1A','IL1B','TNF']),
 ('Adhesion molecules', ['SELE','VCAM1','ICAM1']),
 ('Coagulation / fibrinolysis', ['F3','SERPINE1','PLAU','THBD']),
 ('IL-1-family receptors', ['IL1RL1','IL18R1','IL1R1']),
 ('Innate / complement / other', ['TLR2','C3','PTX3','TNFRSF11B','KYNU','SOD2','IRF1','IFIH1']),
]
cols = [('IL33vVeh_HUV6','IL-33'),('C47IL33vIL33IC_HUV6','+AX-1177'),('IL33vVeh_HUV24','IL-33'),('C47IL33vIL33IC_HUV24','+AX-1177'),
        ('C47IL33vIL33IC_HGM6','+AX-1177'),('C47IL33vIL33IC_HGM24','+AX-1177'),
        ('C47vIC_HUV6','HUVEC'),('C47vIC_HGM6','HGMEC'),('C47vIC_A549_6','A549'),('C47vIC_MCF7_6','MCF7')]
genes=[]; gclass=[]
for cname, gl in classes:
    for g in gl:
        e = sym2ens[g][0]; genes.append(e); gclass.append(cname)
mat = L.loc[genes, [c for c,_ in cols]].values
qm = Q.loc[genes, [c for c,_ in cols]].values
deg_h = fl.loc[genes,'infl_huv'].values; deg_g = fl.loc[genes,'infl_hgm'].values; deg_a = fl.loc[genes,'infl_a549'].values; deg_m = fl.loc[genes,'infl_mcf7'].values
fig, ax = plt.subplots(figsize=(12.6, 12.6))
norm = TwoSlopeNorm(vmin=-8, vcenter=0, vmax=8)
im = ax.imshow(np.clip(mat,-8,8), cmap='RdBu_r', norm=norm, aspect='auto')
for i in range(mat.shape[0]):
    for j in range(mat.shape[1]):
        cname = cols[j][0]
        degenerate = (deg_h[i] if 'HUV' in cname else deg_g[i] if 'HGM' in cname else deg_a[i] if 'A549' in cname else deg_m[i])
        star = '' if degenerate else ('*' if qm[i,j]<0.05 else '')
        txt = '%+.1f%s'%(mat[i,j], star)
        ax.text(j,i,txt, ha='center', va='center', fontsize=7, color='white' if abs(mat[i,j])>4.5 else 'black', fontstyle='italic' if degenerate else 'normal')
ylabels = [ann.symbol[e] + (' †' if (deg_h[i] or deg_g[i]) else '') for i,e in enumerate(genes)]
ax.set_yticks(range(len(genes))); ax.set_yticklabels(ylabels, fontsize=8)
ax.set_xticks(range(len(cols))); ax.set_xticklabels([c[1] for c in cols], fontsize=8)
ax.xaxis.tick_top()
# class separators and labels
pos=0
for cname, gl in classes:
    ax.axhline(pos-0.5, color='k', lw=.8)
    ax.text(len(cols)-0.4, pos+len(gl)/2-0.5, cname, va='center', ha='left', fontsize=8, fontweight='bold')
    pos+=len(gl)
ax.axhline(pos-0.5, color='k', lw=.8)
for x in [1.5,3.5,4.5,5.5]: ax.axvline(x, color='k', lw=1.2)
# group headers
hdr = [(0.5,'HUVEC 6 h'),(2.5,'HUVEC 24 h'),(4,'HGMEC\n6 h'),(5,'HGMEC\n24 h'),(7.5,'AX-1177 alone vs isotype,\nno IL-33, 6 h')]
for x,t in hdr: ax.text(x, -1.55, t, ha='center', va='bottom', fontsize=9, fontweight='bold')
ax.set_xlim(-0.5, len(cols)-0.5)
cb = fig.colorbar(im, ax=ax, orientation='horizontal', fraction=0.025, pad=0.02, aspect=40); cb.set_label('log2 fold change (clipped at ±8)')
fig.suptitle('IL-33red drives an NF-κB, neutrophil-recruiting, pro-coagulant endothelial programme;\nAX-1177 reverses it and does nothing on its own', fontsize=11, fontweight='bold', y=0.995)
fig.text(0.02,0.008,'Columns: "IL-33" = IL-33red vs vehicle; "+AX-1177" = (AX-1177 + IL-33red) vs (isotype IC119 + IL-33red). Numbers are log2FC from the delivered contrasts; * = adj.P<0.05 (BH within contrast).\n† / italic = gene whose standard errors are degenerate in the pooled model (SE > 2 log2 units): its p-values are void, point estimates are shown. HGMEC has no vehicle arm, so only antibody contrasts exist.\nType-2 effector genes (IL5, IL13, CCL11, CCL17, CCL24, CCL13) were not detectably expressed in any of the four cell lines (removed by the low-expression filter).', fontsize=7.6, color='#333333')
plt.tight_layout(rect=[0,0.045,0.80,0.965])
fig.savefig(os.path.join(OUT, 'figures/fig2_signature_heatmap.png'), dpi=180)
