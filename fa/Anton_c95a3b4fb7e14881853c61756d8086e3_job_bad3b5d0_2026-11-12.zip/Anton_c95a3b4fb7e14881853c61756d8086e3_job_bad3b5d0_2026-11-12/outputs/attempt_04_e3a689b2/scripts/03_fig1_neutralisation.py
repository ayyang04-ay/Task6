import importlib, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_P = importlib.import_module('00_paths'); WORK, OUT = _P.WORK, _P.OUT
from common import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
fl = pd.read_pickle(os.path.join(WORK, 'se_flags.pkl'))
rng = np.random.default_rng(1)
okse = ~fl['infl_huv'] & ~fl['defl_huv']
def robust_set(il):
    return (Q[il]<0.01)&(L[il].abs()>=1)&(ann.AveExpr>=1)&okse
def lowexp_set(il):
    return (Q[il]<0.01)&(L[il].abs()>=2)&(ann.AveExpr<1)&okse&(T[il].abs()>=8)
def slope_ci(x,y,n=2000):
    x=np.asarray(x); y=np.asarray(y)
    s = (x*y).sum()/(x*x).sum()
    idx = rng.integers(0,len(x),(n,len(x)))
    bs = (x[idx]*y[idx]).sum(1)/(x[idx]*x[idx]).sum(1)
    return s, np.percentile(bs,2.5), np.percentile(bs,97.5)

fig, axes = plt.subplots(2,3, figsize=(15,9.6), gridspec_kw={'width_ratios':[1,1,1.05]})
panels = [
 ('IL33vVeh_HUV6','C47IL33vIL33IC_HUV6','A  HUVEC, 6 h','IL-33 vs vehicle, HUVEC 6 h (log2FC)','AX-1177+IL-33 vs isotype+IL-33 (log2FC)'),
 ('IL33vVeh_HUV24','C47IL33vIL33IC_HUV24','B  HUVEC, 24 h','IL-33 vs vehicle, HUVEC 24 h (log2FC)','AX-1177+IL-33 vs isotype+IL-33 (log2FC)'),
 ('IL33vVeh_HUV6','C47IL33vIL33IC_HGM6','C  HGMEC, 6 h †','IL-33 vs vehicle, HUVEC 6 h (log2FC)','AX-1177+IL-33 vs isotype+IL-33, HGMEC (log2FC)'),
 ('IL33vVeh_HUV24','C47IL33vIL33IC_HGM24','D  HGMEC, 24 h †','IL-33 vs vehicle, HUVEC 24 h (log2FC)','AX-1177+IL-33 vs isotype+IL-33, HGMEC (log2FC)'),
 ('IL33vVeh_HUV6','C47vIC_HUV6','E  Antibody alone (no IL-33), HUVEC 6 h','IL-33 vs vehicle, HUVEC 6 h (log2FC)','AX-1177 vs isotype, no IL-33 (log2FC)'),
]
lab = {0:{'NFKBIA':(6,6),'TNFAIP3':(6,5),'CXCL2':(8,2),'CSF1':(-26,-10),'F3':(12,6),'IL6':(-24,-10),'CCL20':(10,2),'CSF2':(6,-8),'THBD':(6,8),'SELE':(-34,10),'VCAM1':(8,-6),'CXCL8':(-34,-2),'CXCL1':(-36,8)},
       1:{'NFKBIA':(6,6),'C3':(8,0),'KYNU':(8,-4),'CXCL6':(8,0),'CSF3':(8,0),'CXCL5':(-34,-6)}}
for k,(ax,(il,ab,title,xl,yl)) in enumerate(zip(axes.flat, panels)):
    bg = (ann.AveExpr>=1) & ~fl['infl_huv'] & ~fl['infl_hgm']
    ax.scatter(L.loc[bg,il], L.loc[bg,ab], s=3, c='#cfcfcf', alpha=.5, rasterized=True, linewidths=0)
    sel = robust_set(il); lo_ = lowexp_set(il)
    ax.scatter(L.loc[lo_,il], L.loc[lo_,ab], s=10, c='#9ecae1', alpha=.9, linewidths=0, label='strongly induced, near-zero baseline (%d)'%lo_.sum())
    x = L.loc[sel,il]; y = L.loc[sel,ab]
    ax.scatter(x, y, s=11, c='#1f77b4', alpha=.8, linewidths=0, label='robust IL-33 genes (%d)'%sel.sum())
    deg = fl['infl_huv'] & (L[il].abs()>=1)
    ax.scatter(L.loc[deg,il], L.loc[deg,ab], s=30, facecolors='none', edgecolors='#d62728', linewidths=1.0, label='degenerate-SE genes (%d)'%deg.sum())
    ax.plot([-6,13],[6,-13], ls='--', c='k', lw=.8, label='complete reversal' if k==0 else None); ax.axhline(0,c='k',lw=.4); ax.axvline(0,c='k',lw=.4)
    s,lo,hi = slope_ci(x,y); r = np.corrcoef(x,y)[0,1]; med = 100*(-(y/x)).median()
    ax.text(0.98,0.97,'slope %.2f [%.2f, %.2f]\nr = %.2f\nmedian reversal %.0f%%'%(s,lo,hi,r,med), transform=ax.transAxes, ha='right', va='top', fontsize=8.5, bbox=dict(fc='white', ec='#999999', lw=.5))
    ax.set_title(title, loc='left', fontsize=10, fontweight='bold'); ax.set_xlabel(xl); ax.set_ylabel(yl)
    ax.set_xlim(-5.5, 12.8); ax.set_ylim(-13.5, 6)
    for gname,off in lab.get(k, {}).items():
        for e in sym2ens.get(gname, []):
            ax.annotate(gname, (L.at[e,il], L.at[e,ab]), fontsize=7, xytext=off, textcoords='offset points', color='#222222', arrowprops=dict(arrowstyle='-', lw=.4, color='#666666'))
    if k==0:
        ax.legend(loc='lower left', fontsize=6.8, frameon=False, handletextpad=.2, borderaxespad=0.1, labelspacing=.25)
ax = axes.flat[5]
rows=[]
spec = [('HUVEC 6 h, vs isotype+IL-33','IL33vVeh_HUV6','C47IL33vIL33IC_HUV6','#1f77b4'),('HUVEC 6 h, vs IL-33 alone','IL33vVeh_HUV6','C47IL33vIL33_HUV6','#1f77b4'),
        ('HUVEC 24 h, vs isotype+IL-33','IL33vVeh_HUV24','C47IL33vIL33IC_HUV24','#1f77b4'),('HUVEC 24 h, vs IL-33 alone','IL33vVeh_HUV24','C47IL33vIL33_HUV24','#1f77b4'),
        ('HGMEC 6 h, vs isotype+IL-33 †','IL33vVeh_HUV6','C47IL33vIL33IC_HGM6','#17a2b8'),('HGMEC 6 h, vs IL-33 alone †','IL33vVeh_HUV6','C47IL33vIL33_HGM6','#17a2b8'),
        ('HGMEC 24 h, vs isotype+IL-33 †','IL33vVeh_HUV24','C47IL33vIL33IC_HGM24','#17a2b8'),('HGMEC 24 h, vs IL-33 alone †','IL33vVeh_HUV24','C47IL33vIL33_HGM24','#17a2b8'),
        ('Antibody alone: HUVEC 6 h','IL33vVeh_HUV6','C47vIC_HUV6','#7f7f7f'),('Antibody alone: HUVEC 24 h','IL33vVeh_HUV24','C47vIC_HUV24','#7f7f7f'),
        ('Antibody alone: HGMEC 6 h','IL33vVeh_HUV6','C47vIC_HGM6','#7f7f7f'),('Antibody alone: HGMEC 24 h','IL33vVeh_HUV24','C47vIC_HGM24','#7f7f7f'),
        ('Antibody alone: A549 6 h','IL33vVeh_HUV6','C47vIC_A549_6','#7f7f7f'),('Antibody alone: A549 24 h','IL33vVeh_HUV24','C47vIC_A549_24','#7f7f7f'),
        ('Antibody alone: MCF7 6 h','IL33vVeh_HUV6','C47vIC_MCF7_6','#7f7f7f'),('Antibody alone: MCF7 24 h','IL33vVeh_HUV24','C47vIC_MCF7_24','#7f7f7f')]
for i,(lb,il,ab,col) in enumerate(spec):
    sel = robust_set(il); s,lo,hi = slope_ci(L.loc[sel,il], L.loc[sel,ab])
    rows.append(dict(contrast=lb, il33_reference=il, n_genes=int(sel.sum()), slope=s, ci_lo=lo, ci_hi=hi, pearson_r=np.corrcoef(L.loc[sel,il], L.loc[sel,ab])[0,1], median_pct_reversal=100*(-(L.loc[sel,ab]/L.loc[sel,il])).median()))
    yy = len(spec)-1-i
    ax.plot([lo,hi],[yy,yy], c=col, lw=1.8); ax.plot(s,yy,'o',c=col, ms=5)
    ax.text(0.2, yy, '%.2f'%s, va='center', fontsize=8)
ax.set_yticks(range(len(spec))); ax.set_yticklabels([s[0] for s in spec][::-1], fontsize=8)
ax.axvline(0,c='k',lw=.6); ax.axvline(-1,c='k',lw=.8,ls='--'); ax.set_xlim(-1.2,0.4)
ax.set_xlabel('slope of antibody effect on IL-33 effect\n(−1 = complete reversal, 0 = none;\nbar = bootstrap 95% CI)')
ax.set_title('F  Reversal slope across all contrasts', loc='left', fontsize=10, fontweight='bold')
fig.suptitle('AX-1177 (10 µg/mL, co-added) neutralises the endothelial response to IL-33red (30 ng/mL) and is transcriptionally inert on its own', fontsize=12, fontweight='bold')
fig.text(0.01,0.004,'Robust IL-33-responsive genes: adj.P<0.01 and |log2FC|≥1 for IL-33 vs vehicle in HUVEC at the matching timepoint, pooled AveExpr≥1, standard error not degenerate. Light blue: adj.P<0.01, |log2FC|≥2, |t|≥8, pooled AveExpr<1.\n† HGMEC has no vehicle arm and no IL-33-vs-control contrast was delivered, so panels C, D and the HGMEC slopes confound the size of the HGMEC response with the degree of neutralisation.', fontsize=7.5, color='#333333')
plt.tight_layout(rect=[0,0.045,0.985,0.965])
fig.savefig(os.path.join(OUT, 'figures/fig1_neutralisation.png'), dpi=180)
# (the full version of this table is written by 02_key_numbers.py as tables/T1_neutralisation_slopes.csv)
