"""Optional: self-contained HTML render of the memo (figures embedded as base64). Needs the 'markdown' package.
Usage: python 06_build_html.py ../AX-1177_portfolio_audit_memo.md ../AX-1177_portfolio_audit_memo.html"""
import sys, os, re, base64, markdown
src, out = sys.argv[1], sys.argv[2]
base = os.path.dirname(os.path.abspath(src))
md = open(src, encoding='utf-8').read()
def embed(m):
    alt, path = m.group(1), os.path.join(base, m.group(2))
    b64 = base64.b64encode(open(path, 'rb').read()).decode()
    return '<figure><img alt="%s" src="data:image/png;base64,%s"/><figcaption>%s</figcaption></figure>' % (alt, b64, alt)
md = re.sub(r'!\[(.*?)\]\((.*?)\)', embed, md)
body = markdown.markdown(md, extensions=['tables', 'sane_lists'])
css = """
body{font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;max-width:1000px;margin:2em auto;padding:0 1.2em;line-height:1.5;color:#1b1b1b;font-size:15px}
h1{color:#12355b;font-size:1.7em} h2{color:#12355b;border-bottom:1px solid #cfd8e3;padding-bottom:.2em;margin-top:1.8em} h3{color:#1f4e79}
table{border-collapse:collapse;width:100%;margin:1em 0;font-size:.9em} th{background:#12355b;color:#fff;text-align:left}
th,td{border:1px solid #9aa5b1;padding:.45em .6em;vertical-align:top} tr:nth-child(even) td{background:#f3f6f9}
figure{margin:1.5em 0} img{max-width:100%} figcaption{font-style:italic;font-size:.9em;color:#333;margin-top:.3em} code{background:#f0f0f0;padding:0 .25em}
"""
html = '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>AX-1177 portfolio audit position</title><style>%s</style></head><body>%s</body></html>' % (css, body)
open(out, 'w', encoding='utf-8').write(html)
print('built', out, round(len(html)/1e6, 1), 'MB')
