"""Step 1. Parse the four delivered workbooks and build every intermediate table used downstream.
Run:  python 01_build_intermediates.py      (needs pandas, numpy, scipy, statsmodels, openpyxl)
Nothing here is modelled: it only reads, reshapes, flags and annotates the delivered numbers."""
import re, io, zipfile, html, importlib, sys, os, warnings
import numpy as np, pandas as pd
from scipy import stats
warnings.filterwarnings('ignore')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
P_ = importlib.import_module('00_paths'); RAW, WORK = P_.RAW, P_.WORK

# ----------------------------------------------------------------------------------------------
# 1. RNA-seq workbooks: streaming parser (the contrasts workbook is 2 x 336 MB of XML)
# ----------------------------------------------------------------------------------------------
row_re = re.compile(r'<row r="(\d+)"([^>]*?)(?:/>|>(.*?)</row>)', flags=re.S)
cell_re = re.compile(r'<c r="([A-Z]+)\d+"([^>]*?)(?:/>|>(?:<f>.*?</f>)?<v>(.*?)</v></c>)', flags=re.S)
COLS = 'ABCDEFGHIJK'
def read_shared(z):
    data = z.read('xl/sharedStrings.xml').decode('utf-8'); out = []
    for m in re.finditer(r'<si>(.*?)</si>|<si/>', data, flags=re.S):
        out.append(html.unescape(''.join(re.findall(r'<t[^>]*>(.*?)</t>', m.group(1) or '', flags=re.S))))
    return out
def parse_sheet(z, name, shared):
    cols = {c: [] for c in COLS}; rown = []; hidden = []
    with z.open(name) as fh:
        txt = io.TextIOWrapper(fh, encoding='utf-8'); tail = ''
        while True:
            chunk = txt.read(32*1024*1024)
            if not chunk: break
            chunk = tail + chunk; k = chunk.rfind('</row>')
            if k == -1: tail = chunk; continue
            proc, tail = chunk[:k+6], chunk[k+6:]
            for m in row_re.finditer(proc):
                r, attrs, body = m.groups()
                if not body: continue
                vals = dict.fromkeys(COLS, None)
                for cm in cell_re.finditer(body):
                    col, cattrs, val = cm.groups()
                    if val is None: continue
                    vals[col] = shared[int(val)] if 't="s"' in cattrs else (html.unescape(val) if ('t="str"' in cattrs or 't="e"' in cattrs) else float(val))
                rown.append(int(r)); hidden.append('hidden="1"' in attrs)
                for c in COLS: cols[c].append(vals[c])
    df = pd.DataFrame(cols); df['xl_row'] = rown; df['xl_hidden'] = hidden
    return df
def read_workbook(path):
    z = zipfile.ZipFile(path); shared = read_shared(z)
    sheets = re.findall(r'<sheet name="([^"]+)" sheetId="\d+" r:id="(rId\d+)"', z.read('xl/workbook.xml').decode())
    rels = {re.search(r'Id="(rId\d+)"', m.group(1)).group(1): re.search(r'Target="([^"]+)"', m.group(1)).group(1)
            for m in re.finditer(r'<Relationship ([^>]*)/>', z.read('xl/_rels/workbook.xml.rels').decode())}
    frames = []
    for sname, rid in sheets:
        tgt = rels[rid].lstrip('/'); tgt = tgt if tgt.startswith('xl/') else 'xl/' + tgt
        df = parse_sheet(z, tgt, shared); hdr = df.iloc[0, :11].tolist()
        df = df.iloc[1:].copy(); df.columns = hdr + ['xl_row', 'xl_hidden']; df['sheet'] = sname; frames.append(df)
    full = pd.concat(frames, ignore_index=True)
    for c in ['logFC', 'AveExpr', 't', 'P.Value', 'adj.P.Val', 'B']: full[c] = pd.to_numeric(full[c], errors='coerce')
    return full

print('parsing RNA-seq workbooks ...', flush=True)
huv = read_workbook(os.path.join(RAW, 'AX-1177_rnaseq_huvec_il33.xlsx'))
con = read_workbook(os.path.join(RAW, 'AX-1177_rnaseq_contrasts.xlsx'))
# the two sheets of the contrasts workbook are duplicates of each other: verify, then keep one
a = con[con.sheet == '6h']; b = con[con.sheet == '24h']
m = a.merge(b, on=['Comparison', 'ensembl'], suffixes=('_a', '_b'), how='outer', indicator=True)
assert (m['_merge'] == 'both').all() and all(np.allclose(m[c+'_a'], m[c+'_b']) for c in ['logFC', 't', 'P.Value', 'adj.P.Val', 'B'])
print('  contrasts workbook: sheets "6h" and "24h" are identical (%d rows each, %d contrasts)' % (len(a), a.Comparison.nunique()))
full = pd.concat([a.drop(columns=['sheet', 'xl_row', 'xl_hidden']), huv.drop(columns=['sheet', 'xl_row', 'xl_hidden'])], ignore_index=True)
short = {
 'IL33_vs_Nontreated_HUVEC_6_hrs': 'IL33vVeh_HUV6', 'IL33_vs_Nontreated_HUVEC_24_hrs': 'IL33vVeh_HUV24',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs': 'C47IL33vIL33IC_HUV6', 'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs': 'C47IL33vIL33IC_HUV24',
 'Compound_47_IL33_vs_IL33_HUVEC_6hrs': 'C47IL33vIL33_HUV6', 'Compound_47_IL33_vs_IL33_HUVEC_24hrs': 'C47IL33vIL33_HUV24',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs': 'C47IL33vIL33IC_HGM6', 'Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs': 'C47IL33vIL33IC_HGM24',
 'Compound_47_IL33_vs_IL33_HGMEC_6hrs': 'C47IL33vIL33_HGM6', 'Compound_47_IL33_vs_IL33_HGMEC_24hrs': 'C47IL33vIL33_HGM24',
 'Compound_47_vs_IC119_HUVEC_6hrs': 'C47vIC_HUV6', 'Compound_47_vs_IC119_HUVEC_24hrs': 'C47vIC_HUV24',
 'Compound_47_vs_IC119_HGMEC_6hrs': 'C47vIC_HGM6', 'Compound_47_vs_IC119_HGMEC_24hrs': 'C47vIC_HGM24',
 'Compound_47_vs_IC119_A549_6hrs': 'C47vIC_A549_6', 'Compound_47_vs_IC119_A549_24hrs': 'C47vIC_A549_24',
 'Compound_47_vs_IC119_MCF7_6hrs': 'C47vIC_MCF7_6', 'Compound_47_vs_IC119_MCF7_24hrs': 'C47vIC_MCF7_24',
 'Compound_47_vs_DMSO_A549_6hrs': 'C47vDMSO_A549_6', 'Compound_47_vs_DMSO_A549_24hrs': 'C47vDMSO_A549_24',
 'Compound_47_vs_DMSO_MCF7_6hrs': 'C47vDMSO_MCF7_6', 'Compound_47_vs_DMSO_MCF7_24hrs': 'C47vDMSO_MCF7_24',
 'Compound_47_vs_PBS_A549_6hrs': 'C47vPBS_A549_6', 'Compound_47_vs_PBS_A549_24hrs': 'C47vPBS_A549_24',
 'Compound_47_vs_PBS_MCF7_6hrs': 'C47vPBS_MCF7_6', 'Compound_47_vs_PBS_MCF7_24hrs': 'C47vPBS_MCF7_24'}
assert set(full.Comparison) == set(short), 'unexpected contrast names'
full['Comparison'] = full.Comparison.astype(str).map(short)
ann = full.drop_duplicates('ensembl')[['ensembl', 'symbol', 'entrez', 'gene_name', 'AveExpr']].set_index('ensembl')
ann.to_pickle(os.path.join(WORK, 'gene_ann.pkl'))
order = list(short.values())
W = {}
for v in ['logFC', 't', 'P.Value', 'adj.P.Val', 'B']:
    W[v] = full.pivot(index='ensembl', columns='Comparison', values=v)[order]
    W[v].to_pickle(os.path.join(WORK, f'wide_{v}.pkl'))
L, T, P, Q = W['logFC'], W['t'], W['P.Value'], W['adj.P.Val']
print('  genes: %d, contrasts: %d' % L.shape)

# degenerate standard errors (SE = |logFC / t|), by cell line
SE = (L / T).abs()
grp = {'huv': [c for c in SE if 'HUV' in c], 'hgm': [c for c in SE if 'HGM' in c], 'a549': [c for c in SE if 'A549' in c], 'mcf7': [c for c in SE if 'MCF7' in c]}
fl = pd.DataFrame({**{f'infl_{k}': (SE[v] > 2).any(axis=1) for k, v in grp.items()}, **{f'defl_{k}': (SE[v] < 0.02).any(axis=1) for k, v in grp.items()}})
fl.to_pickle(os.path.join(WORK, 'se_flags.pkl'))
print('  genes with SE>2 in HUVEC contrasts: %d; any contrast: %d; SE<0.02 anywhere: %d' % (fl.infl_huv.sum(), fl.filter(like='infl').any(axis=1).sum(), fl.filter(like='defl').any(axis=1).sum()))

ab_alone = [c for c in L if c.startswith('C47v')]
gm = pd.DataFrame({'symbol': ann.symbol, 'AveExpr': ann.AveExpr,
  'IL33_6': L['IL33vVeh_HUV6'], 'q_IL33_6': Q['IL33vVeh_HUV6'], 't_IL33_6': T['IL33vVeh_HUV6'], 'IL33_24': L['IL33vVeh_HUV24'], 'q_IL33_24': Q['IL33vVeh_HUV24'],
  'ab6': L['C47IL33vIL33IC_HUV6'], 'q_ab6': Q['C47IL33vIL33IC_HUV6'], 'ab24': L['C47IL33vIL33IC_HUV24'], 'q_ab24': Q['C47IL33vIL33IC_HUV24'],
  'abHGM6': L['C47IL33vIL33IC_HGM6'], 'q_abHGM6': Q['C47IL33vIL33IC_HGM6'], 'abHGM24': L['C47IL33vIL33IC_HGM24'], 'q_abHGM24': Q['C47IL33vIL33IC_HGM24'],
  'alone_HUV6': L['C47vIC_HUV6'], 'alone_HUV24': L['C47vIC_HUV24'], 'alone_HGM6': L['C47vIC_HGM6'], 'alone_HGM24': L['C47vIC_HGM24'],
  'max_abs_alone': L[ab_alone].abs().max(axis=1), 'min_q_alone': Q[ab_alone].min(axis=1), 'se_degenerate_HUVEC': fl.infl_huv, 'se_degenerate_HGMEC': fl.infl_hgm})
gm['rev6'] = -gm.ab6 / gm.IL33_6; gm['rev24'] = -gm.ab24 / gm.IL33_24
gm.to_pickle(os.path.join(WORK, 'gene_master.pkl'))

# ----------------------------------------------------------------------------------------------
# 2. Serum proteomics
# ----------------------------------------------------------------------------------------------
print('serum ...', flush=True)
S = pd.read_excel(os.path.join(RAW, 'AX-1177_serum_proteomics.xlsx'))      # pandas reads hidden rows/columns too
S['panel_s'] = S['panel'].str.replace('Olink Target 96 ', '').str.replace(r'\(v\.\d+\)', '', regex=True)
S['rank'] = np.arange(1, len(S) + 1)
S['logOR'] = np.log(S.OR); S['se'] = (np.log(S.u95) - np.log(S.l95)) / (2 * 1.96); S['z'] = S.logOR / S.se
for c in ['composite_endpoint_0', 'composite_endpoint_1']: S[c] = S[c].astype(float)
manual = {'ST2':'IL1RL1','IL-18R1':'IL18R1','MCP-3':'CCL7','OPG':'TNFRSF11B','CSF-1':'CSF1','IL8':'CXCL8','MCP-1':'CCL2','uPA':'PLAU','U-PAR':'PLAUR','PAI':'SERPINE1','TF':'F3','t-PA':'PLAT','TM':'THBD',
 'EN-RAGE':'S100A12','HO-1':'HMOX1','LOX-1':'OLR1','TRAIL':'TNFSF10','TRAIL-R2':'TNFRSF10B','TRANCE':'TNFSF11','TWEAK':'TNFSF12','IL-1ra':'IL1RN','IL-1RT1':'IL1R1','IL-1RT2':'IL1R2','IL-4RA':'IL4R','IL-6RA':'IL6R',
 'LAP TGF-beta-1':'TGFB1','MCP-2':'CCL8','MCP-4':'CCL13','SCF':'KITLG','Flt3L':'FLT3LG','PD-L1':'CD274','PD-L2':'PDCD1LG2','4E-BP1':'EIF4EBP1','CASP-8':'CASP8','CASP-3':'CASP3','Gal-9':'LGALS9','Gal-1':'LGALS1','Gal-3':'LGALS3','Gal-4':'LGALS4','gal-8':'LGALS8',
 'TNF-R1':'TNFRSF1A','TNF-R2':'TNFRSF1B','GDF-15':'GDF15','KIM1':'HAVCR1','NT-proBNP':'NPPB','PSP-D':'SFTPD','RAGE':'AGER','SYND1':'SDC1','ESM-1':'ESM1','PECAM-1':'PECAM1','ICAM-2':'ICAM2','vWF':'VWF','TIE2':'TEK','VEGFR-2':'KDR','VEGFR-3':'FLT4',
 'PDGF subunit A':'PDGFA','PDGF subunit B':'PDGFB','hOSCAR':'OSCAR','IgG Fc receptor II-b':'FCGR2B','CD40-L':'CD40LG','CTSL1':'CTSL','AP-N':'ANPEP','BLM hydrolase':'BLMH','Dkk-1':'DKK1','Dkk-4':'DKK4','FGF-19':'FGF19','FGF-21':'FGF21','FGF-5':'FGF5','FGF-BP1':'FGFBP1',
 'FR-alpha':'FOLR1','FR-gamma':'FOLR3','GFR-alpha-1':'GFRA1','GDNFR-alpha-3':'GFRA3','GM-CSF-R-alpha':'CSF2RA','G-CSF':'CSF3','HB-EGF':'HBEGF','HSP 27':'HSPB1','ICAM 5':'ICAM5','IFN-gamma':'IFNG','IFN-gamma-R1':'IFNGR1','IL-10RA':'IL10RA','IL-10RB':'IL10RB','IL-12B':'IL12B',
 'IL-15RA':'IL15RA','IL-17A':'IL17A','IL-17C':'IL17C','IL-17D':'IL17D','IL-17RA':'IL17RA','IL-18BP':'IL18BP','IL-20RA':'IL20RA','IL-27':'IL27','IL-5R-alpha':'IL5RA','IL2-RA':'IL2RA','IL12':'IL12A','JAM-A':'F11R','JAM-B':'JAM2','LAIR-2':'LAIR2','LDL receptor':'LDLR','LIF-R':'LIFR',
 'MAD homolog 5':'SMAD5','MIC-A/B':'MICA','MK':'MDK','MUC-16':'MUC16','N-CDase':'ASAH2','N2DL-2':'ULBP2','NEMO':'IKBKG','NEP':'MME','Notch 3':'NOTCH3','Nr-CAM':'NRCAM','NT-3':'NTF3','OPN':'SPP1','PAR-1':'F2R','PARP-1':'PARP1','PDGF-R-alpha':'PDGFRA','PIgR':'PIGR','PLC':'HSPG2',
 'PSGL-1':'SELPLG','SHPS-1':'SIRPA','Siglec-9':'SIGLEC9','SKR3':'ACVRL1','ST1A1':'SULT1A1','TGF-alpha':'TGFA','TGFR-2':'TGFBR2','THY 1':'THY1','TLT-2':'TREML2','TN-R':'TNR','TNFB':'LTA','TR':'TFRC','TR-AP':'ACP5','WISP-1':'CCN4','hK11':'KLK11','hK14':'KLK14','hK8':'KLK8',
 'sFRP-3':'FRZB','CAIX':'CA9','CD97':'ADGRE5','CLM-1':'CD300LF','CLM-6':'CD300C','COL4A3BP':'CERT1','CXL17':'CXCL17','CYR61':'CCN1','DLK-1':'DLK1','Ep-CAM':'EPCAM','FAM19A5':'TAFA5','FS':'FST','GH':'GH1','GIF':'CBLIF','GT':'GGT1','HAOX1':'HAO1','KIF1BP':'KIFBP','MESDC2':'MESD',
 'MetAP 2':'METAP2','NOV':'CCN3','PVRL4':'NECTIN4','Alpha-2-MRAP':'LRPAP1',"5'-NT":'NT5E','ADAM 22':'ADAM22','ADAM 23':'ADAM23','ADAM 8':'ADAM8','ADAM-TS 15':'ADAMTS15','ADAM-TS13':'ADAMTS13','BMP-4':'BMP4','BMP-6':'BMP6','FUT3/FUT5':'FUT3','GDF-2':'GDF2','GDF-8':'MSTN',
 'IGFBP-1':'IGFBP1','IGFBP-2':'IGFBP2','IGFBP-7':'IGFBP7','MMP-1':'MMP1','MMP-10':'MMP10','MMP-2':'MMP2','MMP-3':'MMP3','MMP-9':'MMP9','TFPI-2':'TFPI2','FcRL2':'FCRL2','LRMP':'IRAG2'}
alias = {'CERT1':'COL4A3BP','KIFBP':'KIF1BP','GCP5':'TUBGCP5','WIF-1':'WIF1','IRAG2':'LRMP','CCN4':'WISP1','CCN1':'CYR61','CCN3':'NOV','CCN5':'WISP2','TAFA5':'FAM19A5','MESD':'MESDC2','ELOA':'TCEB3','ADGRE5':'CD97','CBLIF':'GIF','KYAT1':'CCBL1','DDX58':'RIGI','NECTIN4':'PVRL4'}
base = lambda s: re.sub(r'-(INFI|IMO|CVDII|CVDIII|ONCII|CRE|ODA|MET|NEUI|NEX)$', '', s)      # Olink panel suffix on duplicated assays
symset = set(ann.symbol)
def to_symbol(assay):
    s = manual.get(base(assay), base(assay))
    return s if s in symset else (alias[s] if alias.get(s) in symset else s)
S['base'] = S.assay.map(base); S['symbol'] = S.assay.map(to_symbol); S['in_rna'] = S.symbol.isin(symset)
S.to_pickle(os.path.join(WORK, 'serum3.pkl'))
ratio = S['adj.p.value'].iloc[0] / S['p.value'].iloc[0]
print('  assays delivered: %d; unique proteins: %d; BH family size implied by row 1: %.1f' % (len(S), S.symbol.nunique(), ratio))

# protein-level table joined to the endothelial RNA-seq
prot = S.sort_values('p.value').groupby('symbol').agg(assay=('assay', 'first'), panel=('panel_s', 'first'), OR=('OR', 'first'), l95=('l95', 'first'), u95=('u95', 'first'),
        p=('p.value', 'first'), adjp=('adj.p.value', 'first'), z=('z', 'mean'), n_assays=('assay', 'size'), in_rna=('in_rna', 'first')).reset_index()
best = ann.sort_values('AveExpr', ascending=False).reset_index().drop_duplicates('symbol').set_index('symbol')['ensembl']
rows = []
for _, r in prot.iterrows():
    d = r.to_dict(); e = best.get(r.symbol)
    if e is not None:
        d.update(ensembl=e, AveExpr=ann.AveExpr[e])
        for c in ['IL33vVeh_HUV6', 'IL33vVeh_HUV24', 'C47IL33vIL33IC_HUV6', 'C47IL33vIL33IC_HUV24', 'C47IL33vIL33IC_HGM6', 'C47IL33vIL33IC_HGM24', 'C47vIC_HUV6', 'C47vIC_HUV24']:
            d[c + '_lfc'] = L.at[e, c]; d[c + '_t'] = T.at[e, c]; d[c + '_q'] = Q.at[e, c]
    rows.append(d)
pd.DataFrame(rows).to_pickle(os.path.join(WORK, 'master_serum_rna.pkl'))

# ----------------------------------------------------------------------------------------------
# 3. Post-mortem lung
# ----------------------------------------------------------------------------------------------
print('lung ...', flush=True)
import openpyxl
ws = openpyxl.load_workbook(os.path.join(RAW, 'AX-1177_postmortem_lung.xlsx')).worksheets[0]      # formulas kept as text on purpose
hdr = [c.value for c in ws[1]]; hdr[3] = 'D'; hdr[27] = 'AB'
names = ['sample','block','rna','D','lobe','cat','race','sex','age','sars','path','HE_eos','EPX','EDN','MBP','2D7','IL5Ra_NE','NE_dup','IL5Ra_T','Tryp_dup','EPXn','NEn','TRYPn','IL33_epi','IL33_endo','IL33_vsmc','notes','AB']
raw = pd.DataFrame([[c.value for c in r] for r in ws.iter_rows(min_row=2, max_row=ws.max_row)], columns=names)
raw['xl_row'] = np.arange(2, 2 + len(raw))
blk = raw[raw.block.notna()].copy(); blk['sample'] = blk['sample'].astype(str)
def grade(v):
    """'n+' -> n + 0.5 (the workbook's own convention); 'ND'/'N/A' -> missing; '=(2+4.5)/2' -> evaluated."""
    if v is None: return np.nan
    if isinstance(v, (int, float)): return float(v)
    s = str(v).strip()
    if s in ('ND', 'N/A', ''): return np.nan
    m = re.match(r'^(\d)\+$', s)
    if m: return float(m.group(1)) + 0.5
    if s.startswith('='):
        assert re.fullmatch(r'=\([\d.]+\+[\d.]+\)/[\d.]+', s), s
        return float(eval(s[1:]))
    return float(s)
for c in ['EPX','EDN','MBP','2D7','IL5Ra_NE','NE_dup','IL5Ra_T','Tryp_dup','EPXn','NEn','TRYPn','IL33_epi','IL33_endo','IL33_vsmc']:
    blk[c + '_num'] = blk[c].map(grade)
for c in ['cat', 'sex', 'age', 'sars', 'race', 'path']:      # donor-level fields sit on the first block only
    blk[c + '_ff'] = blk.groupby('sample')[c].transform(lambda x: x.ffill().bfill())
blk['notes_all'] = blk.groupby('sample')['notes'].transform(lambda x: ', '.join(sorted(set(', '.join([v for v in x if v]).split(', ')) - {''})))
blk['HE_eos_Y'] = (blk.HE_eos == 'Y').astype(float)
blk.to_pickle(os.path.join(WORK, 'lung_blocks.pkl'))
meas = ['IL33_epi_num','IL33_endo_num','IL33_vsmc_num','EPXn_num','NEn_num','TRYPn_num','EDN_num','MBP_num','2D7_num','IL5Ra_NE_num']
don = blk.groupby('sample', sort=False).agg(cat=('cat_ff','first'), sex=('sex_ff','first'), age=('age_ff','first'), sars=('sars_ff','first'), n_blocks=('block','size'), notes=('notes_all','first'), path=('path_ff','first'),
        **{k: (k, 'mean') for k in meas}, HE_eos_frac=('HE_eos_Y','mean'), IL33_endo_max=('IL33_endo_num','max'), IL33_endo_min=('IL33_endo_num','min')).reset_index()
# pathology coded by hand from the autopsy text (see memo section 9): acute pneumonia / acute lung injury, DAD, thromboemboli
acute = {'1130','1138','1149','1159','1165','1910','2035','2044','2045','2049','2040','2043','2072','2073','2075','2105','2108','2110','2113','2060','1956','1976'}
dad = {'2044','2049','2040','2043','2072','2108','2110'}; thr = {'2035','2040','2113','2060'}
don['acute_pneu'] = don['sample'].isin(acute); don['dad'] = don['sample'].isin(dad); don['thrombo'] = don['sample'].isin(thr)
don['covid'] = don.cat.str.contains('pos'); don['copd'] = don.notes.str.contains('COPD'); don['asthma'] = don.notes.str.contains('Asthma')
don.to_pickle(os.path.join(WORK, 'lung_donors.pkl'))
print('  donors: %d, blocks: %d' % (len(don), len(blk))); print(don.groupby('cat').agg(donors=('sample','size'), blocks=('n_blocks','sum')).to_string())
print('done')
