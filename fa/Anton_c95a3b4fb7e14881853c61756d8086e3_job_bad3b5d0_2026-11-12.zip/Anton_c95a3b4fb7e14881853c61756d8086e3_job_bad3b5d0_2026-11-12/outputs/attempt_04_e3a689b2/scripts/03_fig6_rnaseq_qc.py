import importlib, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_P = importlib.import_module('00_paths'); WORK, OUT = _P.WORK, _P.OUT
from common import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
fl = pd.read_pickle(os.path.join(WORK, 'se_flags.pkl'))
SE = (L/T).abs()
c = 'IL33vVeh_HUV6'
fig, axes = plt.subplots(1,3, figsize=(16.5,5.6), gridspec_kw={'width_ratios':[1,1,1.15]})
ax = axes[0]
deg = fl.infl_huv
ax.scatter(ann.AveExpr[~deg], SE.loc[~deg,c], s=2, c='#bdbdbd', alpha=.4, rasterized=True, linewidths=0)
ax.scatter(ann.AveExpr[deg], SE.loc[deg,c], s=14, c='#d62728', linewidths=0, label='degenerate SE (>2 log2 units):\n%d genes in HUVEC contrasts'%deg.sum())
ax.set_yscale('log'); ax.axhline(2, c='k', ls='--', lw=.7); ax.set_ylim(0.0015, 1e5)
for g,off in {'CD93':(-34,-3),'CXCL1':(-38,-3),'CDH5':(6,-3),'VWF':(6,-3),'SELE':(-30,-3),'VCAM1':(-40,-10),'CXCL8':(6,-10),'CCL2':(6,2),'IL1RL1':(-42,4),'PTX3':(6,4),'GAPDH':(6,-3),'XBP1':(6,-3)}.items():
    e = sym2ens[g][0]; ax.annotate(g, (ann.AveExpr[e], SE.at[e,c]), xytext=off, textcoords='offset points', fontsize=7.3)
ax.set_xlabel('AveExpr (log2-CPM averaged over all 114 libraries, 4 cell types)'); ax.set_ylabel('standard error of log2FC = |logFC / t|  (log scale)')
ax.set_title('A  Standard errors, IL-33 vs vehicle, HUVEC 6 h', loc='left', fontsize=10, fontweight='bold'); ax.legend(fontsize=7.5, loc='upper right', frameon=False, bbox_to_anchor=(1.0,1.0))
ax.text(0.98,0.03,'A log2 fold change cannot have an SE of 10–10,000:\nartefact of the pooled 4-cell-line fit, not biology', transform=ax.transAxes, ha='right', va='bottom', fontsize=7.8)
ax = axes[1]
p = -np.log10(P[c])
ax.scatter(L.loc[~deg,c], p[~deg], s=3, c='#bdbdbd', alpha=.5, rasterized=True, linewidths=0)
big = deg & (L[c].abs()>=1)
ax.scatter(L.loc[big,c], p[big], s=30, facecolors='none', edgecolors='#d62728', linewidths=1.2, label='degenerate-SE genes with |log2FC|≥1 (n=%d)'%big.sum())
for g,off in {'SELE':(-4,8),'VCAM1':(-10,14),'CXCL8':(-36,10),'CXCL1':(-8,8),'CCL2':(-6,8),'PTGS2':(-10,18),'IL1RL1':(-10,10),'PTX3':(4,16),'NFKBIA':(8,0),'CSF2':(8,4),'CXCL3':(8,4),'TRAF1':(8,0),'CCL20':(8,-6)}.items():
    e = sym2ens[g][0]; ax.annotate(g, (L.at[e,c], p[e]), xytext=off, textcoords='offset points', fontsize=7.3, arrowprops=dict(arrowstyle='-', lw=.4, color='#666666'))
ax.set_xlabel('log2 fold change, IL-33 vs vehicle, HUVEC 6 h'); ax.set_ylabel('−log10 P (as delivered)')
ax.set_title('B  Largest fold changes carry void p-values', loc='left', fontsize=10, fontweight='bold'); ax.legend(fontsize=7.5, loc='upper left', frameon=False, bbox_to_anchor=(0.0,0.93))
ax.text(0.02,0.80,'The delivered sheet is sorted by logFC; its top\nrows (SELE, VCAM1, CXCL8, CXCL1) have\nP = 0.05–0.99', transform=ax.transAxes, ha='left', va='top', fontsize=7.8)
ax.set_ylim(-3,66)
ax = axes[2]
abcols = [c_ for c_ in L.columns if c_.startswith('C47v')]
low=[]; tiny=[]; oth=[]
for c_ in abcols:
    s = Q[c_]<0.05
    l_ = (ann.AveExpr[s]<0).sum(); t_ = ((ann.AveExpr[s]>=0)&(L.loc[s,c_].abs()<0.5)).sum(); low.append(l_); tiny.append(t_); oth.append(s.sum()-l_-t_)
x = np.arange(len(abcols))
ax.bar(x, low, color='#9e9e9e', label='pooled AveExpr < 0 (near-zero counts)')
ax.bar(x, tiny, bottom=low, color='#fdae61', label='|log2FC| < 0.5 with implausibly small SE')
ax.bar(x, oth, bottom=np.array(low)+np.array(tiny), color='#2b83ba', label='other (none recur across timepoints or cell lines)')
ax.set_xticks(x); ax.set_xticklabels([c_.replace('C47v','vs ').replace('_',' ').replace('HUV','HUVEC ').replace('HGM','HGMEC ').replace('IC','isotype').replace('  ',' ')+' h' for c_ in abcols], rotation=60, ha='right', fontsize=7)
ax.set_ylabel('genes with adj.P < 0.05'); ax.set_ylim(0,125)
ax.set_title('C  Noise floor: AX-1177 alone (no IL-33), all 16 contrasts', loc='left', fontsize=10, fontweight='bold'); ax.legend(fontsize=7.5, loc='upper left', frameon=False)
ax.text(0.98,0.97,'14–73 "hits" per null contrast\nout of 26,210 genes; compare 4,031\nfor IL-33 vs vehicle (HUVEC 6 h)', transform=ax.transAxes, va='top', ha='right', fontsize=7.8)
fig.suptitle('RNA-seq quality control: what the pooled single-model fit does to the statistics', fontsize=11.5, fontweight='bold')
plt.tight_layout(rect=[0,0,1,0.95])
fig.savefig(os.path.join(OUT, 'figures/fig6_rnaseq_qc.png'), dpi=170)
