# Minimal Markdown-subset -> PDF (reportlab Platypus). Handles #/##/### headings, paragraphs, "- " bullets,
# "1. " numbered items, pipe tables, images, **bold**, *italic*, `code`.
import re, os, sys, html
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether, ListFlowable, ListItem, CondPageBreak
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
import matplotlib
fd = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data','fonts','ttf')
pdfmetrics.registerFont(TTFont('DV', os.path.join(fd,'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B', os.path.join(fd,'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DV-I', os.path.join(fd,'DejaVuSans-Oblique.ttf')))
pdfmetrics.registerFont(TTFont('DV-BI', os.path.join(fd,'DejaVuSans-BoldOblique.ttf')))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily('DV', normal='DV', bold='DV-B', italic='DV-I', boldItalic='DV-BI')

src, out = sys.argv[1], sys.argv[2]
base = os.path.dirname(os.path.abspath(src))
W, H = A4
LM = RM = 17*mm; TM = 16*mm; BM = 16*mm
fw = W - LM - RM
body = ParagraphStyle('body', fontName='DV', fontSize=9.2, leading=13, spaceAfter=5, alignment=TA_LEFT)
h1 = ParagraphStyle('h1', fontName='DV-B', fontSize=16, leading=20, spaceAfter=8, textColor=colors.HexColor('#12355b'), keepWithNext=1)
h2 = ParagraphStyle('h2', fontName='DV-B', fontSize=12.5, leading=16, spaceBefore=10, spaceAfter=5, textColor=colors.HexColor('#12355b'), keepWithNext=1)
h3 = ParagraphStyle('h3', fontName='DV-B', fontSize=10.3, leading=14, spaceBefore=7, spaceAfter=4, textColor=colors.HexColor('#1f4e79'), keepWithNext=1)
lead = ParagraphStyle('lead', parent=body, keepWithNext=1)      # a paragraph that is one bold line introduces what follows
bul = ParagraphStyle('bul', parent=body, leftIndent=0, spaceAfter=3)
cell = ParagraphStyle('cell', fontName='DV', fontSize=7.9, leading=10.4)
cellh = ParagraphStyle('cellh', fontName='DV-B', fontSize=7.9, leading=10.4, textColor=colors.white)
cap = ParagraphStyle('cap', fontName='DV-I', fontSize=8, leading=10.5, spaceAfter=8, textColor=colors.HexColor('#333333'))

def inline(t):
    t = html.escape(t, quote=False)
    t = re.sub(r'`([^`]+)`', r'<font face="DV" color="#444444">\1</font>', t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?![\*\w])', r'<i>\1</i>', t)
    return t

lines = open(src, encoding='utf-8').read().split('\n')
story = []; i = 0
def flush_list(items, ordered):
    if not items: return
    fl = ListFlowable([ListItem(Paragraph(inline(x), bul), leftIndent=14, bulletColor=colors.HexColor('#12355b')) for x in items],
                      bulletType='1' if ordered else 'bullet', bulletFontName='DV', bulletFontSize=8.5, leftIndent=14, start=None if ordered else '•')
    story.append(fl); story.append(Spacer(1,3))
while i < len(lines):
    ln = lines[i]
    if not ln.strip(): i += 1; continue
    if ln.startswith('# '):
        story.append(Paragraph(inline(ln[2:].strip()), h1)); i += 1; continue
    if ln.startswith('## '):
        story.append(CondPageBreak(38*mm)); story.append(Paragraph(inline(ln[3:].strip()), h2)); i += 1; continue
    if ln.startswith('### '):
        story.append(CondPageBreak(38*mm)); story.append(Paragraph(inline(ln[4:].strip()), h3)); i += 1; continue
    m = re.match(r'!\[(.*?)\]\((.*?)\)', ln.strip())
    if m:
        capt, path = m.group(1), os.path.join(base, m.group(2))
        iw, ih = ImageReader(path).getSize()
        w = fw; h = fw*ih/iw
        maxh = H - TM - BM - 30*mm
        if h > maxh: h = maxh; w = maxh*iw/ih
        story.append(KeepTogether([Image(path, width=w, height=h), Spacer(1,2), Paragraph(inline(capt), cap)]))
        i += 1; continue
    if ln.lstrip().startswith('|'):
        rows = []
        while i < len(lines) and lines[i].lstrip().startswith('|'):
            cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
            rows.append(cells); i += 1
        hdr = rows[0]; data = [r for r in rows[2:]]
        ncol = len(hdr)
        # column widths: proportional to max content length (bounded)
        plain = lambda x: re.sub(r'[*`]', '', x)
        mx = [max([len(plain(hdr[c]))] + [len(plain(r[c])) for r in data]) for c in range(ncol)]
        av = [sum([len(plain(r[c])) for r in data])/max(len(data),1) for c in range(ncol)]
        lens = [min(max((m + 2*a)/3.0, 8), 90) ** 0.75 for m,a in zip(mx, av)]
        tot = sum(lens); cw = [fw*l/tot for l in lens]
        # avoid very narrow columns
        minw = 17*mm
        cw = [max(c, minw) for c in cw]; sc = fw/sum(cw); cw = [c*sc for c in cw]
        tdata = [[Paragraph(inline(c), cellh) for c in hdr]] + [[Paragraph(inline(c), cell) for c in r] for r in data]
        t = Table(tdata, colWidths=cw, repeatRows=1)
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#12355b')),('VALIGN',(0,0),(-1,-1),'TOP'),
                               ('GRID',(0,0),(-1,-1),0.4,colors.HexColor('#9aa5b1')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white, colors.HexColor('#f3f6f9')]),
                               ('LEFTPADDING',(0,0),(-1,-1),3.5),('RIGHTPADDING',(0,0),(-1,-1),3.5),('TOPPADDING',(0,0),(-1,-1),2.5),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
        story.append(t); story.append(Spacer(1,7)); continue
    if re.match(r'^\s*- ', ln):
        items = []
        while i < len(lines) and re.match(r'^\s*- ', lines[i]):
            items.append(re.sub(r'^\s*- ', '', lines[i])); i += 1
        flush_list(items, False); continue
    if re.match(r'^\s*\d+\. ', ln):
        items = []
        while i < len(lines) and re.match(r'^\s*\d+\. ', lines[i]):
            items.append(re.sub(r'^\s*\d+\. ', '', lines[i])); i += 1
        flush_list(items, True); continue
    # paragraph (merge consecutive plain lines)
    para = [ln.strip()]; i += 1
    while i < len(lines) and lines[i].strip() and not re.match(r'^(#|\||!\[|\s*- |\s*\d+\. )', lines[i]):
        para.append(lines[i].strip()); i += 1
    txt = ' '.join(para)
    is_lead = bool(re.fullmatch(r'\*\*[^*]+\*\*', txt))
    if is_lead: story.append(CondPageBreak(30*mm))      # do not leave a one-line lead-in alone at the foot of a page
    story.append(Paragraph(inline(txt), lead if is_lead else body))

def footer(canvas, doc):
    canvas.saveState(); canvas.setFont('DV', 7); canvas.setFillColor(colors.HexColor('#666666'))
    canvas.drawString(LM, 9*mm, 'AX-1177 portfolio audit position — from delivered data files only')
    canvas.drawRightString(W-RM, 9*mm, 'Page %d' % doc.page); canvas.restoreState()
doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=LM, rightMargin=RM, topMargin=TM, bottomMargin=BM, title='AX-1177 portfolio audit position', author='')
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print('built', out)
