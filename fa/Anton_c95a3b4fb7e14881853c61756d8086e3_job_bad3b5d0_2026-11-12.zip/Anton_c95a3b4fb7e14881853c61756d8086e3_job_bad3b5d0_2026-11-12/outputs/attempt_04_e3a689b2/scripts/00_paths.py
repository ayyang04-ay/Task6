"""Shared paths. Override with environment variables AX_RAW, AX_WORK, AX_OUT."""
import os
RAW = os.environ.get('AX_RAW', '/tmp/world/filesystem')
WORK = os.environ.get('AX_WORK', '/tmp/work')
OUT = os.environ.get('AX_OUT', '/tmp/outputs')
for d in (WORK, OUT, os.path.join(OUT, 'figures'), os.path.join(OUT, 'tables')):
    os.makedirs(d, exist_ok=True)
