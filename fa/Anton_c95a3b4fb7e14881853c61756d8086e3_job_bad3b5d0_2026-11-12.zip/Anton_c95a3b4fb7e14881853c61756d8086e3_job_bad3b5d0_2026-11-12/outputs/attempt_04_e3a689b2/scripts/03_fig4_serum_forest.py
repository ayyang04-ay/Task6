import importlib, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_P = importlib.import_module('00_paths'); WORK, OUT = _P.WORK, _P.OUT
from common import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':8.5,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
df = pd.read_pickle(os.path.join(WORK, 'serum3.pkl')); gm = pd.read_pickle(os.path.join(WORK, 'gene_master.pkl')).drop_duplicates('symbol').set_index('symbol')
cats = [
 ('IL-33 axis and IL-1-family receptors', ['ST2','IL-18R1','IL-1RT2','IL1B','IL18-INFI','IL-1ra','IL1RL2','IL-1RT1']),
 ('IL-6 family / acute phase', ['IL6','OSM','PTX3','OPG-INFI','CALCA','CSF-1','LIF-R']),
 ('Neutrophil / myeloid activation', ['HGF','PRTN3','CD177','RETN','IL8','LCN2','EN-RAGE','MPO','G-CSF','CXCL1-INFI']),
 ('Endothelium / coagulation', ['U-PAR','vWF','TF','ANGPT2','FLT1','SELE','PAI','ICAM1','TM','VCAM1']),
 ('Chemokines induced by IL-33 in endothelium', ['MCP-3','CCL20','MCP-1-INFI','CX3CL1','CXCL5','CXCL6']),
 ('Type-2 / eosinophil / mast cell', ['IL-4RA','RNASE3','IL-5R-alpha','CCL17','MCP-4','CCL24','FCER2','TPSAB1','CCL11-INFI','IL5-IMO']),
 ('Interferon / antiviral (secreted)', ['CXCL9','IFNL1','CXCL11','CXCL10','IFN-gamma']),
]
nice = {'ST2':'sST2 (IL1RL1)','IL-18R1':'IL-18R1','IL-1RT2':'IL-1R2','IL18-INFI':'IL-18','IL-1RT1':'IL-1R1','IL1RL2':'IL-1RL2 (IL-36R)','IL1B':'IL-1β','IL6':'IL-6 (4 assays concordant)','OPG-INFI':'OPG (2 assays)','CALCA':'Procalcitonin (CALCA)','CSF-1':'CSF-1 (M-CSF)','HGF':'HGF (2 assays)','IL8':'IL-8 (CXCL8)','EN-RAGE':'S100A12 (EN-RAGE)','G-CSF':'G-CSF (CSF3)','CXCL1-INFI':'CXCL1 (2 assays)','TF':'Tissue factor (F3)','FLT1':'sFLT1','PAI':'PAI-1 (SERPINE1)','TM':'Thrombomodulin','MCP-3':'MCP-3 (CCL7)','MCP-1-INFI':'MCP-1 (CCL2; 2 assays)','IL-4RA':'IL-4Rα','RNASE3':'ECP (RNASE3)','IL-5R-alpha':'IL-5Rα','MCP-4':'MCP-4 (CCL13)','FCER2':'CD23 (FCER2)','TPSAB1':'Tryptase (TPSAB1)','CCL11-INFI':'Eotaxin-1 (CCL11; 2 assays)','IL5-IMO':'IL-5','IFN-gamma':'IFN-γ','IFNL1':'IFN-λ1','U-PAR':'suPAR','vWF':'vWF','SELE':'E-selectin','CCL17':'TARC (CCL17)','CCL24':'Eotaxin-2 (CCL24)'}
sym = df.set_index('assay').symbol
def il33_status(assay):
    s = sym[assay]
    if s not in gm.index: return 'nd'
    g = gm.loc[s]
    if g.se_degenerate_HUVEC and max(g.IL33_6, g.IL33_24)>=1: return 'pt'
    if ((g.q_IL33_6<0.05 and g.IL33_6>=1) or (g.q_IL33_24<0.05 and g.IL33_24>=1)): return 'yes'
    return 'no'
rows=[]
for c,al in cats:
    for a in al:
        r = df[df.assay==a].iloc[0]
        rows.append(dict(cat=c, assay=a, label=nice.get(a,a), OR=r.OR, lo=r.l95, hi=r.u95, p=r['p.value'], q=r['adj.p.value'], il33=il33_status(a)))
R = pd.DataFrame(rows)
R.to_csv(os.path.join(OUT, 'tables/T3_serum_axis_forest.csv'), index=False)
n = len(R) + len(cats) + 1
fig, ax = plt.subplots(figsize=(10.2, 0.205*n+1.9))
y = n; yt=[]; yl=[]
xmin, xmax = 0.3, 40
import matplotlib.transforms as mtransforms
trans = mtransforms.blended_transform_factory(ax.transAxes, ax.transData)
for c,al in cats:
    y -= 1; ax.text(-0.025, y, c, fontweight='bold', fontsize=8.8, va='center', ha='right', transform=trans)
    ax.axhline(y, color='#dddddd', lw=.6, zorder=0)
    if c.startswith('IL-33 axis'):
        y -= 1; ax.text(-0.025, y, 'IL-33 (the drug target)', fontsize=8, color='#b2182b', va='center', ha='right', transform=trans)
        ax.text(xmin*1.08, y, 'not in the delivered table (the assay is on the Inflammation panel)', fontsize=7.6, color='#b2182b', va='center', ha='left', fontstyle='italic')
    for a_ in al:
        y -= 1
        r = R[R.assay==a_].iloc[0]
        col = '#b2182b' if r.q<0.05 else ('#ef8a62' if r.p<0.05 else '#7f7f7f')
        lo, hi = max(r.lo,xmin*1.05), min(r.hi,xmax*0.95)
        ax.plot([lo,hi],[y,y], c=col, lw=1.4)
        if r.hi>xmax*0.95: ax.annotate('', xy=(xmax*0.97,y), xytext=(xmax*0.8,y), arrowprops=dict(arrowstyle='->', color=col, lw=1.2))
        mk = 'D' if r.il33 in ('yes','pt') else 'o'
        ax.plot(min(r.OR,xmax*0.9), y, mk, c=col, ms=6 if mk=='D' else 5, mfc='white' if r.il33=='pt' else col, mec=col, mew=1.2)
        ax.text(-0.025, y, r.label, fontsize=8, va='center', ha='right', transform=trans)
        ax.text(1.03, y, '%.2f (%.2f–%.2f)'%(r.OR, r.lo, r.hi) if r.hi<100 else '%.0f (%.1f–%.0f)'%(r.OR, r.lo, r.hi), fontsize=7.3, va='center', ha='left', transform=trans)
        ax.text(1.30, y, '%.2g'%r.p, fontsize=7.3, va='center', ha='left', transform=trans); ax.text(1.42, y, '%.2g'%r.q, fontsize=7.3, va='center', ha='left', fontweight='bold' if r.q<0.05 else 'normal', transform=trans)
ax.set_xscale('log'); ax.set_xlim(xmin, xmax); ax.set_ylim(y-0.8, n-0.3)
ax.axvline(1, c='k', lw=.7)
ax.set_yticks([])
ax.spines['left'].set_visible(False)
ax.set_xticks([0.5,1,2,4,8,16,32]); ax.set_xticklabels(['0.5','1','2','4','8','16','32'])
ax.set_xlabel('Odds ratio for ICU admission / invasive ventilation / death within 30 days, per log unit of serum protein\n(logistic regression adjusted for age, sex, NEWS2; 100 hospitalised COVID-19 patients; 44 events, inferred from the table)', fontsize=8)
ax.text(1.03, n-0.55, 'OR (95% CI)', fontsize=7.5, fontweight='bold', transform=trans); ax.text(1.30, n-0.55, 'P', fontsize=7.5, fontweight='bold', transform=trans); ax.text(1.42, n-0.55, 'FDR', fontsize=7.5, fontweight='bold', transform=trans)
from matplotlib.lines import Line2D
h = [Line2D([0],[0],marker='s',color='#b2182b',lw=1.4,ms=4,label='FDR < 0.05'),Line2D([0],[0],marker='s',color='#ef8a62',lw=1.4,ms=4,label='P < 0.05 but FDR ≥ 0.05'),Line2D([0],[0],marker='s',color='#7f7f7f',lw=1.4,ms=4,label='not significant'),
     Line2D([0],[0],marker='D',color='k',lw=0,ms=6,label='gene induced ≥2-fold by IL-33 in HUVEC and reversed by AX-1177'),Line2D([0],[0],marker='D',color='k',mfc='white',lw=0,ms=6,label='same, point estimate only (RNA-seq p-value void)'),Line2D([0],[0],marker='o',color='k',lw=0,ms=5,label='not IL-33-inducible / not expressed in the endothelial RNA-seq')]
fig.legend(handles=h, loc='lower center', ncol=2, fontsize=7.5, frameon=False, bbox_to_anchor=(0.5,0.005))
fig.suptitle('Serum proteins at enrolment and severe outcome in hospitalised COVID-19:\nsST2, IL-6, myeloid and endothelial markers associate; type-2 (bar IL-4Rα) and secreted interferon markers do not', fontsize=10, fontweight='bold', y=0.995)
plt.subplots_adjust(left=0.32, right=0.68, top=0.945, bottom=0.105)
fig.savefig(os.path.join(OUT, 'figures/fig4_serum_forest.png'), dpi=180)
print(R.round(3).to_string())
