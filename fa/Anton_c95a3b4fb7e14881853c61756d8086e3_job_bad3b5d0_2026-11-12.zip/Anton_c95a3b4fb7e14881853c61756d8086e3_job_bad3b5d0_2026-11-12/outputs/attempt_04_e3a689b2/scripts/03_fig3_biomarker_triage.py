import importlib, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_P = importlib.import_module('00_paths'); WORK, OUT = _P.WORK, _P.OUT
from common import *
from scipy import stats
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
M = pd.read_pickle(os.path.join(WORK, 'master_serum_rna.pkl')); fl = pd.read_pickle(os.path.join(WORK, 'se_flags.pkl'))
m = M[M.in_rna].copy()
m['deg'] = m.ensembl.map(fl.infl_huv)
m['x'] = m[['IL33vVeh_HUV6_lfc','IL33vVeh_HUV24_lfc']].max(axis=1)
m['x'] = np.where(m.IL33vVeh_HUV6_lfc.abs()>=m.IL33vVeh_HUV24_lfc.abs(), m.IL33vVeh_HUV6_lfc, m.IL33vVeh_HUV24_lfc)
m['x'] = m.IL33vVeh_HUV6_lfc
m['ind'] = ((m.IL33vVeh_HUV6_q<0.05)&(m.IL33vVeh_HUV6_lfc>=1)) | ((m.IL33vVeh_HUV24_q<0.05)&(m.IL33vVeh_HUV24_lfc>=1))
m['ind_pt'] = m.deg & ((m.IL33vVeh_HUV6_lfc>=1)|(m.IL33vVeh_HUV24_lfc>=1))
m['sev'] = (m.adjp<0.05)&(m.OR>1)
zthr = m.loc[m.adjp<0.05,'z'].abs().min()
fig, ax = plt.subplots(figsize=(10.5,7.2))
oth = ~(m.ind|m.ind_pt)
ax.scatter(m.x[oth&~m.sev], m.z[oth&~m.sev], s=8, c='#c9c9c9', linewidths=0, label='not IL-33-inducible, not outcome-associated (n=%d)'%(oth&~m.sev).sum())
ax.scatter(m.x[oth&m.sev], m.z[oth&m.sev], s=12, c='#f4a582', linewidths=0, label='outcome-associated (FDR<0.05), not IL-33-inducible in endothelium (n=%d)'%(oth&m.sev).sum())
ax.scatter(m.x[m.ind&~m.sev], m.z[m.ind&~m.sev], s=22, c='#92c5de', linewidths=0, label='IL-33-inducible in HUVEC (≥2-fold at 6 h or 24 h), not outcome-associated (n=%d)'%(m.ind&~m.sev).sum())
ax.scatter(m.x[m.ind&m.sev], m.z[m.ind&m.sev], s=46, c='#b2182b', edgecolors='k', linewidths=.5, label='IL-33-inducible AND outcome-associated (n=%d)'%(m.ind&m.sev).sum(), zorder=4)
ax.scatter(m.x[m.ind_pt], m.z[m.ind_pt], s=46, facecolors='none', edgecolors=np.where(m.sev[m.ind_pt],'#b2182b','#2166ac'), linewidths=1.3, label='IL-33-inducible by point estimate only (RNA-seq p-value void; n=%d)'%m.ind_pt.sum(), zorder=4)
ax.axhline(zthr, c='k', ls='--', lw=.7); ax.axvline(1, c='k', ls='--', lw=.7); ax.axhline(0,c='k',lw=.4)
ax.text(11.9, zthr+0.06, 'FDR 0.05', ha='right', fontsize=7.5)
lab = {'IL6':(6,6),'TNFRSF11B':(6,6),'IL18R1':(6,6),'CCL20':(6,6),'CCL7':(-34,6),'CSF1':(-38,8),'CTSS':(-30,6),'IL1B':(-30,-14),'IL1RL1':(-44,6),'PTX3':(6,6),'CXCL8':(6,6),'F3':(8,-6),'CXCL6':(6,-4),'CSF3':(6,4),'CXCL5':(6,-8),'TNFRSF9':(6,4),'CX3CL1':(6,4),'CXCL10':(6,-9),'CXCL1':(-40,-12),'TNF':(6,4),'CCL2':(10,8),'SELE':(6,4),'VCAM1':(10,-8),'ICAM1':(6,4),'HGF':(-30,4),'OSM':(-30,0),'IL1R2':(6,-4),'HDGF':(6,4),'SERPINE1':(6,-8)}
nm = {'IL1RL1':'sST2','TNFRSF11B':'OPG','CCL7':'MCP-3','CSF1':'CSF-1','CXCL8':'IL-8','F3':'tissue factor','CSF3':'G-CSF','CCL2':'MCP-1','SERPINE1':'PAI-1','IL1B':'IL-1β','IL6':'IL-6','SELE':'E-selectin'}
ms = m.set_index('symbol')
for g,off in lab.items():
    if g in ms.index:
        ax.annotate(nm.get(g,g), (ms.at[g,'x'], ms.at[g,'z']), xytext=off, textcoords='offset points', fontsize=7.5, arrowprops=dict(arrowstyle='-', lw=.4, color='#555555'))
tab = pd.crosstab(m.ind, m.sev); o,p = stats.fisher_exact(tab.values)
ax.text(0.985,0.03,'Is the IL-33-inducible endothelial secretome over-represented among outcome proteins?\nNo: %d/%d (%.0f%%) of IL-33-inducible vs %d/%d (%.0f%%) of other proteins are outcome-associated\n(Fisher OR %.2f, P=%.2f). After adjusting for transcript abundance and Olink panel: OR 1.3, P=0.48.'%(tab.loc[True,True], tab.loc[True].sum(), 100*tab.loc[True,True]/tab.loc[True].sum(), tab.loc[False,True], tab.loc[False].sum(), 100*tab.loc[False,True]/tab.loc[False].sum(), o, p), transform=ax.transAxes, ha='right', va='bottom', fontsize=8, bbox=dict(fc='white', ec='#999999', lw=.5))
ax.set_xlabel('IL-33red vs vehicle in HUVEC at 6 h, log2 fold change of the transcript (in vitro)')
ax.set_ylabel('Association of the serum protein with ICU / ventilation / death\n(Wald z, adjusted logistic model; patients)')
ax.set_xlim(-3.2,12); ax.set_ylim(-2.6,5.4)
ax.legend(loc='upper right', fontsize=7.3, frameon=True, framealpha=.95)
ax.set_title('Bridging bench to bedside: which IL-33-driven, AX-1177-reversible endothelial products also track outcome in patients?', fontsize=10, fontweight='bold', loc='left')
plt.tight_layout()
fig.savefig(os.path.join(OUT, 'figures/fig3_biomarker_triage.png'), dpi=180)
print(tab, o, p)
