"""Step 2. Recompute every number quoted in the memo and write them to tables/key_numbers.txt (the audit trail),
plus the donor-level lung tests (tables/T4c...) and the neutralisation table (tables/T1...)."""
import importlib, sys, os, re, itertools, warnings
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_P = importlib.import_module('00_paths'); WORK, OUT = _P.WORK, _P.OUT
from common import *
from scipy import stats
import statsmodels.formula.api as smf
warnings.filterwarnings('ignore')
out_lines = []
def say(*a):
    s = ' '.join(str(x) for x in a); print(s); out_lines.append(s)

fl = pd.read_pickle(os.path.join(WORK, 'se_flags.pkl'))
SE = (L / T).abs()
ok = ~fl.infl_huv & ~fl.defl_huv
rng = np.random.default_rng(1)
def robust(il): return (Q[il] < 0.01) & (L[il].abs() >= 1) & (ann.AveExpr >= 1) & ok
def slope_ci(x, y, n=4000):
    x = np.asarray(x); y = np.asarray(y); s = (x*y).sum()/(x*x).sum()
    idx = rng.integers(0, len(x), (n, len(x))); bs = (x[idx]*y[idx]).sum(1)/(x[idx]*x[idx]).sum(1)
    return s, np.percentile(bs, 2.5), np.percentile(bs, 97.5)

say('=' * 100); say('RNA-SEQ'); say('=' * 100)
say('genes per contrast: %d; contrasts: %d' % L.shape)
for c in ['IL33vVeh_HUV6', 'IL33vVeh_HUV24', 'C47IL33vIL33IC_HUV6', 'C47IL33vIL33IC_HUV24', 'C47IL33vIL33IC_HGM6', 'C47IL33vIL33IC_HGM24', 'C47IL33vIL33_HGM24']:
    say('  %-22s adj.P<0.05: %5d (up %d / down %d)' % (c, (Q[c] < 0.05).sum(), ((Q[c] < 0.05) & (L[c] > 0)).sum(), ((Q[c] < 0.05) & (L[c] < 0)).sum()))
say('molar ratio: AX-1177 %.1f nM (10 ug/mL, 146 kDa) vs IL-33 %.2f nM (30 ng/mL, 18.1 kDa) = %.1f-fold' % (10e-3/146e3*1e9, 30e-6/18.1e3*1e9, (10e-3/146e3)/(30e-6/18.1e3)))
for g in ['F3', 'THBD', 'IL6', 'IL1RL1', 'SERPINE1', 'NFKBIA', 'TNFAIP3', 'SELE', 'CXCL8']:
    e = sym2ens[g][0]; say('  %-8s IL-33 6h log2FC %+.2f (x%.1f; adj.P %.2g; P %.2g) | AX-1177 vs isotype %+.2f | HGMEC AX %+.2f' % (g, L.at[e, 'IL33vVeh_HUV6'], 2**L.at[e, 'IL33vVeh_HUV6'], Q.at[e, 'IL33vVeh_HUV6'], P.at[e, 'IL33vVeh_HUV6'], L.at[e, 'C47IL33vIL33IC_HUV6'], L.at[e, 'C47IL33vIL33IC_HGM6']))
say('type-2 effector genes present in the table:', {g: (g in sym2ens) for g in ['IL5', 'IL13', 'CCL11', 'CCL24', 'CCL17', 'CCL13', 'CCL26', 'IL4', 'TSLP']})

say('\n-- neutralisation (robust IL-33 genes: adj.P<0.01, |log2FC|>=1, AveExpr>=1, SE not degenerate) --')
rows = []
spec = [('HUVEC 6 h, vs isotype+IL-33', 'IL33vVeh_HUV6', 'C47IL33vIL33IC_HUV6'), ('HUVEC 6 h, vs IL-33 alone', 'IL33vVeh_HUV6', 'C47IL33vIL33_HUV6'),
        ('HUVEC 24 h, vs isotype+IL-33', 'IL33vVeh_HUV24', 'C47IL33vIL33IC_HUV24'), ('HUVEC 24 h, vs IL-33 alone', 'IL33vVeh_HUV24', 'C47IL33vIL33_HUV24'),
        ('HGMEC 6 h, vs isotype+IL-33 (HUVEC 6 h genes)', 'IL33vVeh_HUV6', 'C47IL33vIL33IC_HGM6'), ('HGMEC 6 h, vs IL-33 alone (HUVEC 6 h genes)', 'IL33vVeh_HUV6', 'C47IL33vIL33_HGM6'),
        ('HGMEC 24 h, vs isotype+IL-33 (HUVEC 24 h genes)', 'IL33vVeh_HUV24', 'C47IL33vIL33IC_HGM24'), ('HGMEC 24 h, vs IL-33 alone (HUVEC 24 h genes)', 'IL33vVeh_HUV24', 'C47IL33vIL33_HGM24')]
spec += [('Antibody alone: %s' % c.replace('C47vIC_', '').replace('_', ' '), 'IL33vVeh_HUV6' if c.endswith('6') else 'IL33vVeh_HUV24', c) for c in L if c.startswith('C47vIC')]
for lab, il, ab in spec:
    s = robust(il); x = L.loc[s, il]; y = L.loc[s, ab]; rev = -(y/x)
    sl, lo, hi = slope_ci(x, y)
    r = dict(contrast=lab, n_genes=int(s.sum()), n_up=int((x > 0).sum()), slope=sl, ci_lo=lo, ci_hi=hi, pearson_r=np.corrcoef(x, y)[0, 1], median_pct_reversal=100*rev.median(), q25=100*rev.quantile(.25), q75=100*rev.quantile(.75),
             pct_opposite_sign=100*(np.sign(x) != np.sign(y)).mean(), pct_opposite_and_adjP05=100*((np.sign(x) != np.sign(y)) & (Q.loc[s, ab] < 0.05)).mean())
    rows.append(r)
    say('  %-48s n=%3d slope %+.2f [%+.2f, %+.2f] r=%+.2f median reversal %5.1f%% (IQR %.0f to %.0f) opposite sign %.0f%%, individually significant %.0f%%' % (lab, r['n_genes'], sl, lo, hi, r['pearson_r'], r['median_pct_reversal'], r['q25'], r['q75'], r['pct_opposite_sign'], r['pct_opposite_and_adjP05']))
pd.DataFrame(rows).to_csv(os.path.join(OUT, 'tables', 'T1_neutralisation_slopes.csv'), index=False)
for il_, ab_ in [('IL33vVeh_HUV6', 'C47IL33vIL33IC_HUV6'), ('IL33vVeh_HUV24', 'C47IL33vIL33IC_HUV24')]:
    lo_ = (Q[il_] < 0.01) & (L[il_].abs() >= 2) & (ann.AveExpr < 1) & ok & (T[il_].abs() >= 8); rv = -(L.loc[lo_, ab_]/L.loc[lo_, il_])
    say('strongly induced from near-zero baseline (adj.P<0.01, |log2FC|>=2, |t|>=8, AveExpr<1), %s: n=%d, median reversal %.1f%% (IQR %.0f to %.0f)' % (il_, lo_.sum(), 100*rv.median(), 100*rv.quantile(.25), 100*rv.quantile(.75)))
tiny_rows = [(L.at[g_, c_], SE.at[g_, c_], ann.AveExpr[g_]) for c_ in [c for c in L if c.startswith('C47v')] for g_ in L.index[(Q[c_] < 0.05) & (ann.AveExpr >= 0) & (L[c_].abs() < 0.5)]]
tl = np.abs([r[0] for r in tiny_rows]); say('antibody-alone hits with AveExpr>=0 and |log2FC|<0.5: n=%d, median fold %.2f, max fold %.2f, AveExpr>=5 in %d' % (len(tl), 2**np.median(tl), 2**tl.max(), sum(r[2] >= 5 for r in tiny_rows)))
s6 = robust('IL33vVeh_HUV6'); x = L.loc[s6, 'IL33vVeh_HUV6']; y = L.loc[s6, 'IL33vVeh_HUV24']
say('signature decay: 24 h IL-33 effect on 6 h IL-33 effect, slope %.2f; median ratio %.2f' % ((x*y).sum()/(x*x).sum(), (y/x).median()))
for cl, tp, il in [('HUV', '6', 'IL33vVeh_HUV6'), ('HUV', '24', 'IL33vVeh_HUV24'), ('HGM', '6', 'IL33vVeh_HUV6'), ('HGM', '24', 'IL33vVeh_HUV24')]:
    s = robust(il); d = L.loc[s, f'C47IL33vIL33_{cl}{tp}'] - L.loc[s, f'C47IL33vIL33IC_{cl}{tp}']
    sl, lo, hi = slope_ci(L.loc[s, il], d); say('isotype effect, (IL-33+IC119) minus IL-33 alone, %s %s h: slope on IL-33 effect %+.3f [%+.3f, %+.3f]' % (cl, tp, sl, lo, hi))
# HGMEC robust antibody-responsive genes and overlap with HUVEC IL-33 genes
okh = ~fl.infl_hgm
sel = (Q['C47IL33vIL33IC_HGM6'] < 0.01) & (L['C47IL33vIL33IC_HGM6'].abs() >= 1) & (ann.AveExpr >= 1) & okh
both = sel & (Q['IL33vVeh_HUV6'] < 0.05) & (np.sign(L['IL33vVeh_HUV6']) == -np.sign(L['C47IL33vIL33IC_HGM6']))
say('HGMEC 6 h robust AX-1177-responsive genes: %d; IL-33-responsive in HUVEC in the opposite direction: %d (%.0f%%)' % (sel.sum(), both.sum(), 100*both.sum()/sel.sum()))
# beyond reversal?
a = 'C47IL33vIL33IC_HUV6'; absig = (Q[a] < 0.01) & (L[a].abs() >= 1) & (ann.AveExpr >= 1) & ok
ilr = (Q['IL33vVeh_HUV6'] < 0.05) & (np.sign(L['IL33vVeh_HUV6']) == -np.sign(L[a])); nov = absig & ~ilr; g = nov[nov].index
rep24 = ((Q.loc[g, 'C47IL33vIL33IC_HUV24'] < 0.05) & (np.sign(L.loc[g, 'C47IL33vIL33IC_HUV24']) == np.sign(L.loc[g, a]))).sum()
repH = ((Q.loc[g, 'C47IL33vIL33IC_HGM6'] < 0.05) & (np.sign(L.loc[g, 'C47IL33vIL33IC_HGM6']) == np.sign(L.loc[g, a]))).sum()
say('AX-1177-responsive genes with IL-33 present, HUVEC 6 h: %d; IL-33 genes reversing: %d (%.0f%%); other: %d, of which replicated at 24 h: %d, in HGMEC: %d' % (absig.sum(), (absig & ilr).sum(), 100*(absig & ilr).sum()/absig.sum(), nov.sum(), rep24, repH))
deg = fl.infl_huv & (L['IL33vVeh_HUV6'].abs() >= 1)
say('degenerate-SE genes with |log2FC|>=1 for IL-33 (HUVEC 6 h): %d: %s' % (deg.sum(), ', '.join('%s %+.1f -> %+.1f' % (ann.symbol[e], L.at[e, 'IL33vVeh_HUV6'], L.at[e, 'C47IL33vIL33IC_HUV6']) for e in deg[deg].index)))

say('\n-- antibody alone (16 contrasts) --')
ab = [c for c in L if c.startswith('C47v')]; sig = Q[ab] < 0.05
say('hits per contrast (adj.P<0.05): min %d, max %d; total %d' % (sig.sum().min(), sig.sum().max(), sig.values.sum()))
low = sum(int(((Q[c] < 0.05) & (ann.AveExpr < 0)).sum()) for c in ab); tiny = sum(int(((Q[c] < 0.05) & (ann.AveExpr >= 0) & (L[c].abs() < 0.5)).sum()) for c in ab); tot = int(sig.values.sum())
say('  pooled AveExpr<0: %d (%.0f%%); AveExpr>=0 and |log2FC|<0.5: %d (%.0f%%); other: %d (%.0f%%)' % (low, 100*low/tot, tiny, 100*tiny/tot, tot-low-tiny, 100*(tot-low-tiny)/tot))
def armset(c):
    m = re.match(r'C47v(IC|DMSO|PBS)_(HUV|HGM|A549_|MCF7_)(\d+)', c); return (m.group(2), m.group(3))
rec = []
for gi in sig.index[sig.sum(axis=1) >= 2]:
    sets = {}
    for c in ab:
        if sig.at[gi, c]: sets.setdefault(armset(c), []).append(L.at[gi, c])
    if len(sets) >= 2: rec.append((ann.symbol[gi], round(ann.AveExpr[gi], 2), len({np.sign(np.mean(v)) for v in sets.values()}) == 1, {k: [round(x, 2) for x in v] for k, v in sets.items()}))
say('genes significant in >=2 independent arm-sets: %d; same direction: %d' % (len(rec), sum(r[2] for r in rec)))
for r in rec: say('   ', r)
say('SE>2 genes: HUVEC %d, HGMEC %d, A549 %d, MCF7 %d; any %d; max SE %.0f. SE<0.02 genes: %d' % (fl.infl_huv.sum(), fl.infl_hgm.sum(), fl.infl_a549.sum(), fl.infl_mcf7.sum(), fl.filter(like='infl').any(axis=1).sum(), SE.values.max(), fl.filter(like='defl').any(axis=1).sum()))

say('\n' + '=' * 100); say('SERUM'); say('=' * 100)
S = pd.read_pickle(os.path.join(WORK, 'serum3.pkl')); M = pd.read_pickle(os.path.join(WORK, 'master_serum_rna.pkl'))
N = round(S['adj.p.value'].iloc[0] / S['p.value'].iloc[0])
say('assays delivered %d; unique proteins %d; BH family implied %d; undelivered %d' % (len(S), S.symbol.nunique(), N, N - len(S)))
sg = S[S['adj.p.value'] < 0.05]; say('FDR<0.05: %d assays / %d proteins; with OR>1: %d assays / %d proteins' % (len(sg), sg.symbol.nunique(), (sg.OR > 1).sum(), sg[sg.OR > 1].symbol.nunique()))
say('Bonferroni (0.05/%d): %s' % (N, S[S['p.value'] < 0.05/N].assay.tolist()))
say('event counts implied by the undocumented columns: smallest non-zero fractions %.6f (=1/%.0f) and %.6f (=1/%.0f); max fractions %.3f, %.3f' % (S.composite_endpoint_0[S.composite_endpoint_0 > 0].min(), 1/S.composite_endpoint_0[S.composite_endpoint_0 > 0].min(), S.composite_endpoint_1[S.composite_endpoint_1 > 0].min(), 1/S.composite_endpoint_1[S.composite_endpoint_1 > 0].min(), S.composite_endpoint_0.max(), S.composite_endpoint_1.max()))
p = S['p.value'].values; q = S['adj.p.value'].values; exc = N*p/q - np.arange(1, len(S)+1); bind = np.abs(exc - np.round(exc)) < 1e-6
mb = pd.Series(np.round(exc[bind]).astype(int), index=np.arange(1, len(S)+1)[bind])
say('undelivered assays ranked above delivered rank 175 (adj.P %.4f): %d; above rank 196 (adj.P %.4f): %d' % (q[174], mb[175], q[195], mb[196]))
for a in ['ST2', 'HGF', 'IL6', 'IL6-ONCII', 'IL6-CVDII', 'IL6-IMO', 'IL5-IMO', 'CCL11-INFI', 'CCL17', 'TPSAB1', 'IL-4RA', 'RNASE3', 'CXCL10', 'IFN-gamma', 'CALCA', 'CSF-1', 'KIM1-CVDII', 'KIM1-ODA', 'NT-proBNP-MET', 'NT-proBNP-CVDIII', 'TNNI3']:
    r = S[S.assay == a].iloc[0]; say('  %-16s OR %.2f (%.2f-%.2f) P=%.2g FDR=%.2g rank %d' % (a, r.OR, r.l95, r.u95, r['p.value'], r['adj.p.value'], r['rank']))
dup = S[S.duplicated('symbol', keep=False)]; pr = [(g.z.values[i], g.z.values[j]) for _, g in dup.groupby('symbol') for i in range(len(g)) for j in range(i+1, len(g))]
sym_pr = pr + [(b_, a_) for a_, b_ in pr]      # symmetrised, so the order within a pair does not matter
say('proteins on >1 panel: %d (%d assays); z concordance across %d pairs, symmetrised r=%.2f' % (dup.symbol.nunique(), len(dup), len(pr), np.corrcoef(*zip(*sym_pr))[0, 1]))
m = M[M.in_rna].copy(); m['deg'] = m.ensembl.map(fl.infl_huv)
m['ind'] = ((m.IL33vVeh_HUV6_q < 0.05) & (m.IL33vVeh_HUV6_lfc >= 1)) | ((m.IL33vVeh_HUV24_q < 0.05) & (m.IL33vVeh_HUV24_lfc >= 1))
m['ind_pt'] = m.deg & ((m.IL33vVeh_HUV6_lfc >= 1) | (m.IL33vVeh_HUV24_lfc >= 1)); m['sev'] = (m.adjp < 0.05) & (m.OR > 1)
tab = pd.crosstab(m.ind, m.sev); o, pv = stats.fisher_exact(tab.values)
say('proteins with RNA data: %d; IL-33-inducible (valid stats): %d; outcome-associated among them %d (%.1f%%) vs %d/%d (%.1f%%); Fisher OR %.2f P=%.2f' % (len(m), m.ind.sum(), tab.loc[True, True], 100*tab.loc[True, True]/m.ind.sum(), tab.loc[False, True], (~m.ind).sum(), 100*tab.loc[False, True]/(~m.ind).sum(), o, pv))
m['up6_small'] = ((m.IL33vVeh_HUV6_q < 0.05) & (m.IL33vVeh_HUV6_lfc > 0) & (m.IL33vVeh_HUV6_lfc < 1)).astype(int); m['up6_big'] = ((m.IL33vVeh_HUV6_q < 0.05) & (m.IL33vVeh_HUV6_lfc >= 1)).astype(int); m['dn6'] = ((m.IL33vVeh_HUV6_q < 0.05) & (m.IL33vVeh_HUV6_lfc < 0)).astype(int); m['sevi'] = m.sev.astype(int)
fit = smf.logit('sevi ~ up6_small + up6_big + dn6 + AveExpr + C(panel)', m).fit(disp=0)
say('adjusted for abundance and panel: >=2-fold induced OR %.2f (P=%.2f); <2-fold induced OR %.2f (P=%.2f)' % (np.exp(fit.params['up6_big']), fit.pvalues['up6_big'], np.exp(fit.params['up6_small']), fit.pvalues['up6_small']))
both = m[(m.ind | m.ind_pt) & m.sev].sort_values('p'); say('IL-33-inducible AND outcome-associated (%d): %s' % (len(both), ', '.join('%s%s' % (r.symbol, '*' if r.ind_pt and not r.ind else '') for r in both.itertuples())), ' (* = point estimate only)')

say('\n' + '=' * 100); say('LUNG'); say('=' * 100)
don = pd.read_pickle(os.path.join(WORK, 'lung_donors.pkl')); blk = pd.read_pickle(os.path.join(WORK, 'lung_blocks.pkl'))
say(don.groupby('cat').agg(donors=('sample', 'size'), blocks=('n_blocks', 'sum'), age_min=('age', 'min'), age_max=('age', 'max')).to_string())
say('label vs autopsy text: "pneumonia" groups without acute pneumonia: %s; "non-pneumonia" with pneumonia: %s' % (don[(~don.cat.str.contains('non')) & ~don.acute_pneu].groupby('cat').size().to_dict(), int((don.cat.str.contains('non') & don.acute_pneu).sum())))
say('DAD/ALI: COVID+ %d/16, COVID- %d/15; thromboemboli: COVID+ %d/16, COVID- %d/15' % (don[don.covid].dad.sum(), don[~don.covid].dad.sum(), don[don.covid].thrombo.sum(), don[~don.covid].thrombo.sum()))
Pn = 'COVID pos pneumonia'; Nn = 'COVID neg pneumonia'; Cn = 'COVID neg non-pneumonia'
meas = ['IL33_endo_num', 'IL33_epi_num', 'IL33_vsmc_num', 'NEn_num', 'EPXn_num', 'TRYPn_num', 'EDN_num', 'MBP_num', '2D7_num', 'IL5Ra_NE_num', 'HE_eos_frac']
say(don.groupby('cat')[meas].agg(['mean', 'median']).round(2).T.to_string())
rows = []; brng = np.random.default_rng(42)
def boot(a, b, n=20000):
    a = np.asarray(a.dropna()); b = np.asarray(b.dropna()); d = [brng.choice(a, len(a)).mean() - brng.choice(b, len(b)).mean() for _ in range(n)]
    return a.mean() - b.mean(), np.percentile(d, 2.5), np.percentile(d, 97.5)
for mm in meas:
    a = don.loc[don.cat == Pn, mm]; b = don.loc[don.cat == Nn, mm]; c = don.loc[don.cat == Cn, mm]; bn = don.loc[don.cat != Pn, mm]
    for lab, (x, y) in {'COVID+ pneumonia vs COVID- pneumonia': (a, b), 'COVID+ vs all COVID-': (a, bn), 'both pneumonia groups vs non-pneumonia': (pd.concat([a, b]), c)}.items():
        d, lo, hi = boot(x, y); pmw = stats.mannwhitneyu(x.dropna(), y.dropna()).pvalue
        rows.append(dict(measure=mm, comparison=lab, n1=int(x.notna().sum()), n2=int(y.notna().sum()), mean1=x.mean(), mean2=y.mean(), difference=d, ci_lo=lo, ci_hi=hi, P_mann_whitney=pmw))
R = pd.DataFrame(rows); R.to_csv(os.path.join(OUT, 'tables', 'T4c_lung_group_tests_donor_level.csv'), index=False)
say(R.round(3).to_string())
for mm in ['IL33_endo_num', 'IL33_vsmc_num']:
    x = blk[blk.cat_ff == Pn][mm].dropna(); y = blk[blk.cat_ff != Pn][mm].dropna(); say('block-level (pseudo-replicated) %s COVID+ vs all COVID-: P=%.3f' % (mm, stats.mannwhitneyu(x, y).pvalue))
say('endothelial IL-33 blocks at ceiling (5+): %d/%d' % ((blk.IL33_endo_num == 5.5).sum(), len(blk)))
say('H&E eosinophils apparent, donors with any positive block: pneumonia groups %d/%d; non-pneumonia %d/%d' % ((don[~don.cat.str.contains('non')].HE_eos_frac > 0).sum(), (~don.cat.str.contains('non')).sum(), (don[don.cat.str.contains('non')].HE_eos_frac > 0).sum(), don.cat.str.contains('non').sum()))
for a, b in [('IL33_endo_num', 'EPXn_num'), ('IL33_endo_num', 'NEn_num'), ('IL5Ra_NE_num', 'NEn_num'), ('IL5Ra_NE_num', 'EPXn_num')]:
    r, pv = stats.spearmanr(don[a], don[b], nan_policy='omit'); say('donor-level Spearman %s vs %s: rho=%.2f P=%.3g' % (a, b, r, pv))
say('COPD noted (n=%d) vs not (n=%d), basal epithelial IL-33: %.2f vs %.2f, P=%.2f' % (don.copd.sum(), (~don.copd).sum(), don[don.copd].IL33_epi_num.mean(), don[~don.copd].IL33_epi_num.mean(), stats.mannwhitneyu(don[don.copd].IL33_epi_num, don[~don.copd].IL33_epi_num).pvalue))
don['anycld'] = don.notes.str.contains('COPD|Asthma|Bronchitis|Fibrosis|Bronchiectasis')
say('any chronic lung condition noted (n=%d) vs none (n=%d), basal epithelial IL-33: %.2f vs %.2f, P=%.2f' % (don.anycld.sum(), (~don.anycld).sum(), don[don.anycld].IL33_epi_num.mean(), don[~don.anycld].IL33_epi_num.mean(), stats.mannwhitneyu(don[don.anycld].IL33_epi_num, don[~don.anycld].IL33_epi_num).pvalue))
tx = don.path.str.lower()
for lab_, fl_ in {'severe atherosclerosis in autopsy text': tx.str.contains(r'severe[^|\n]{0,40}atherosclero|atherosclero[^|\n]{0,30}severe'), 'nephrosclerosis / renal atrophy in autopsy text': tx.str.contains('nephrosclerosis|renal atrophy')}.items():
    say('%s (n=%d vs %d): IL-33 endothelium %.2f vs %.2f (P=%.2f); vascular smooth muscle %.2f vs %.2f (P=%.2f)' % (lab_, fl_.sum(), (~fl_).sum(), don[fl_].IL33_endo_num.mean(), don[~fl_].IL33_endo_num.mean(), stats.mannwhitneyu(don[fl_].IL33_endo_num, don[~fl_].IL33_endo_num).pvalue,
        don[fl_].IL33_vsmc_num.mean(), don[~fl_].IL33_vsmc_num.mean(), stats.mannwhitneyu(don[fl_].IL33_vsmc_num, don[~fl_].IL33_vsmc_num).pvalue))
sub = don[don.acute_pneu]
say('sensitivity, donors with acute pneumonia in autopsy text only: COVID+ n=%d vs COVID- n=%d; endothelial IL-33 %.2f vs %.2f (P=%.2f); NE %.2f vs %.2f (P=%.2f)' % (sub.covid.sum(), (~sub.covid).sum(), sub[sub.covid].IL33_endo_num.mean(), sub[~sub.covid].IL33_endo_num.mean(), stats.mannwhitneyu(sub[sub.covid].IL33_endo_num, sub[~sub.covid].IL33_endo_num).pvalue, sub[sub.covid].NEn_num.mean(), sub[~sub.covid].NEn_num.mean(), stats.mannwhitneyu(sub[sub.covid].NEn_num.dropna(), sub[~sub.covid].NEn_num.dropna()).pvalue))
# within-donor: neutrophil elastase vs IL-33
b = blk.rename(columns={'IL33_endo_num': 'endo', 'IL33_epi_num': 'epi', 'NEn_num': 'nel'}).merge(don[['sample', 'covid']], on='sample')
b['age'] = b.age_ff.astype(float); b['female'] = (b.sex_ff == 'F').astype(int); b['covid'] = b.covid.astype(int)
for yv in ['endo', 'epi']:
    sl = [np.polyfit(g['nel'], g[yv], 1)[0] for _, g in b.dropna(subset=[yv, 'nel']).groupby('sample') if len(g) >= 2 and g['nel'].nunique() > 1]
    neg = sum(s < -1e-9 for s in sl); pos = sum(s > 1e-9 for s in sl)
    say('within-donor slope of IL-33 (%s) on neutrophil elastase: donors %d; <0: %d, >0: %d, flat: %d; sign test P=%.3f' % (yv, len(sl), neg, pos, len(sl)-neg-pos, stats.binomtest(neg, neg+pos, 0.5).pvalue))
d = b.dropna(subset=['endo', 'nel']); fit = smf.mixedlm('endo ~ nel + covid + age + female', d, groups=d['sample']).fit(reml=True)
say('mixed model endothelial IL-33 ~ NE + COVID + age + sex + (1|donor): NE coefficient %.2f (P=%.2g); COVID %.2f (P=%.2f)' % (fit.params['nel'], fit.pvalues['nel'], fit.params['covid'], fit.pvalues['covid']))

# export the t matrix for the optional gene-set step (02b_gsea_hallmark.R)
tmx = T.copy(); tmx.insert(0, 'symbol', ann.symbol); tmx.insert(1, 'AveExpr', ann.AveExpr)
tmx['se_flag'] = (fl.filter(like='infl').any(axis=1) | fl.filter(like='defl').any(axis=1)).astype(int)
tmx.to_csv(os.path.join(WORK, 't_matrix.tsv'), sep='\t')
open(os.path.join(OUT, 'tables', 'key_numbers.txt'), 'w').write('\n'.join(out_lines) + '\n')
