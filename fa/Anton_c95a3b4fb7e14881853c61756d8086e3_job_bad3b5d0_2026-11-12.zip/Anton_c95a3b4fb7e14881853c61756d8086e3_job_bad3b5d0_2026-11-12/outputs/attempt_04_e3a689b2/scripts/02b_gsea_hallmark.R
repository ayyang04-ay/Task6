# Optional step 2b. Hallmark gene-set enrichment (fgsea) on the moderated t statistics of the delivered contrasts.
# Needs R with fgsea, data.table and msigdbr (7.5.1 used here, offline). Run after 01_build_intermediates.py + 02_key_numbers.py:
#   Rscript 02b_gsea_hallmark.R
# Genes with pooled AveExpr <= 0 or degenerate standard errors are left out of the ranking.
suppressMessages({library(fgsea); library(data.table); library(msigdbr)})
WORK <- Sys.getenv('AX_WORK', '/tmp/work'); OUT <- Sys.getenv('AX_OUT', '/tmp/outputs')
set.seed(1)
tm <- fread(file.path(WORK, 't_matrix.tsv'))
tm <- tm[AveExpr > 0 & se_flag == 0]
h <- as.data.table(msigdbr(species = 'Homo sapiens', category = 'H'))
sets <- split(h$ensembl_gene, sub('HALLMARK_', '', h$gs_name))
contrasts <- setdiff(colnames(tm), c('ensembl', 'symbol', 'AveExpr', 'se_flag'))
res <- rbindlist(lapply(contrasts, function(cn) {
  st <- tm[[cn]]; names(st) <- tm$ensembl; st <- st[is.finite(st)]
  r <- fgseaMultilevel(sets, st, minSize = 15, maxSize = 500, eps = 0, nPermSimple = 2000)
  data.table(contrast = cn, hallmark_set = r$pathway, NES = r$NES, P = r$pval, FDR = r$padj, n_genes = r$size)
}))
wide <- dcast(res, hallmark_set ~ contrast, value.var = 'NES')
setorderv(wide, 'IL33vVeh_HUV6', -1)
fwrite(res, file.path(OUT, 'tables', 'T6_hallmark_gsea_long.csv'))
fwrite(wide, file.path(OUT, 'tables', 'T6_hallmark_gsea_NES_wide.csv'))
cat('written', nrow(res), 'rows\n')
