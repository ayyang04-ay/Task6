import importlib, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_P = importlib.import_module('00_paths'); WORK, OUT = _P.WORK, _P.OUT
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
from scipy import stats
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
plt.rcParams.update({'font.size':8.5,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
df = pd.read_pickle(os.path.join(WORK, 'lung_blocks.pkl')); don = pd.read_pickle(os.path.join(WORK, 'lung_donors.pkl'))
order = ['COVID neg non-pneumonia','COVID neg pneumonia','COVID pos pneumonia']
short = {'COVID neg non-pneumonia':'COVID−\n"non-pneumonia"\n(n=5)','COVID neg pneumonia':'COVID−\n"pneumonia"\n(n=10)','COVID pos pneumonia':'COVID+\n"pneumonia"\n(n=16)'}
colr = {'COVID neg non-pneumonia':'#7f7f7f','COVID neg pneumonia':'#2c7fb8','COVID pos pneumonia':'#d7301f'}
rng = np.random.default_rng(3)
meas = [('IL33_endo_num','A  IL-33, endothelium'),('IL33_epi_num','B  IL-33, bronchial/bronchiolar\n    basal epithelium'),('IL33_vsmc_num','C  IL-33, vascular smooth muscle'),
        ('NEn_num','D  Neutrophil elastase'),('EPXn_num','E  Eosinophil peroxidase'),('TRYPn_num','F  Tryptase (mast cells)')]
fig = plt.figure(figsize=(14.5,9.2))
gs = fig.add_gridspec(2,4, width_ratios=[1,1,1,1.15], hspace=0.42, wspace=0.33)
P='COVID pos pneumonia'; N='COVID neg pneumonia'
for k,(m,title) in enumerate(meas):
    ax = fig.add_subplot(gs[k//3, k%3])
    for i,g in enumerate(order):
        b = df[df.cat_ff==g]
        ax.scatter(i + rng.uniform(-0.28,0.28,len(b)), b[m] + rng.uniform(-0.06,0.06,len(b)), s=9, c=colr[g], alpha=.22, linewidths=0)
        d = don[don.cat==g]
        jit = rng.uniform(-0.2,0.2,len(d))
        mism = (~d.acute_pneu.values) if 'non' not in g else d.acute_pneu.values   # label disagrees with pathology text
        ax.scatter(i+jit[~mism], d[m].values[~mism], s=34+10*d.n_blocks.values[~mism], c=colr[g], edgecolors='k', linewidths=.6, zorder=3)
        ax.scatter(i+jit[mism], d[m].values[mism], s=34+10*d.n_blocks.values[mism], facecolors='white', edgecolors=colr[g], linewidths=1.4, zorder=3)
        ax.plot([i-0.33,i+0.33],[d[m].median()]*2, c='k', lw=1.6, zorder=4)
    a = don.loc[don.cat==P,m].dropna(); b_ = don.loc[don.cat==N,m].dropna(); c_ = don.loc[don.cat!=P,m].dropna(); nn = don.loc[don.cat==order[0],m].dropna()
    p1 = stats.mannwhitneyu(a,b_).pvalue; p2 = stats.mannwhitneyu(a,c_).pvalue; p3 = stats.mannwhitneyu(pd.concat([a,b_]), nn).pvalue
    ax.set_xticks(range(3)); ax.set_xticklabels([short[g] for g in order], fontsize=7.6)
    ax.set_ylim(-0.4,7.7); ax.set_yticks([0,1,2,3,4,5,5.5]); ax.set_yticklabels(['0','1','2','3','4','5','5+'])
    ax.axhline(5.5, c='#bbbbbb', lw=.6, ls=':')
    ax.set_title(title, loc='left', fontsize=9.5, fontweight='bold')
    ax.text(0.5,0.985,'donor-level Mann–Whitney\nCOVID+ vs COVID− pneumonia: P=%.2f\nCOVID+ vs all COVID−: P=%.2f\nboth "pneumonia" groups vs non-pneumonia: P=%.3f'%(p1,p2,p3), transform=ax.transAxes, ha='center', va='top', fontsize=6.9, color='#222222')
    if k%3==0: ax.set_ylabel('IHC score (0–5; "n+" plotted as n+0.5)')
# G: within-donor NE vs IL-33 endothelium
ax = fig.add_subplot(gs[0,3])
d = df.dropna(subset=['NEn_num','IL33_endo_num']).copy()
multi = d.groupby('sample').filter(lambda g: len(g)>=2 and g['NEn_num'].nunique()>1)
for s,g in multi.groupby('sample', sort=False):
    g = g.sort_values('NEn_num'); c = colr[g.cat_ff.iloc[0]]
    gm = g.groupby('NEn_num').IL33_endo_num.mean()
    j = rng.uniform(-0.07,0.07)
    ax.plot(gm.index.values+j, gm.values+j, '-o', c=c, lw=1.3, ms=4, alpha=.85)
ax.set_xlabel('Neutrophil elastase score of the block'); ax.set_ylabel('IL-33 endothelium score of the block')
ax.set_xticks([1.5,2.5,3.5,4.5,5.5]); ax.set_xticklabels(['1+','2+','3+','4+','5+']); ax.set_yticks([2,3,4,5,5.5]); ax.set_yticklabels(['2','3','4','5','5+'])
ax.set_title('G  Same lung, different blocks:\n    more neutrophils, less endothelial IL-33', loc='left', fontsize=9.5, fontweight='bold')
ax.text(0.03,0.04,'each line = one donor (blocks averaged per NE score)\n12 donors with within-donor NE variation:\nslope <0 in 7, >0 in 1, flat in 4 (sign test P=0.07)\nmixed model: −0.31 IL-33 grade per NE grade, P<0.001\n(adjusted for COVID status, age, sex)', transform=ax.transAxes, fontsize=7, va='bottom')
# H: blocks per donor
ax = fig.add_subplot(gs[1,3])
dd = don.copy(); dd['grp'] = pd.Categorical(dd.cat, order); dd = dd.sort_values(['grp','n_blocks'], ascending=[True,False]).reset_index(drop=True)
ax.bar(range(len(dd)), dd.n_blocks, color=[colr[c] for c in dd.cat], edgecolor='k', linewidth=.4)
ax.set_xticks(range(len(dd))); ax.set_xticklabels(dd['sample'], rotation=90, fontsize=6)
ax.set_ylabel('histology blocks per donor'); ax.set_xlabel('donor')
ax.set_title('H  Unequal sampling: 3 donors supply\n    24 of the 49 COVID+ blocks', loc='left', fontsize=9.5, fontweight='bold')
ax.set_ylim(0,11.5); ax.set_yticks([0,2,4,6,8])
ax.text(0.03,0.98,'Endothelial IL-33, COVID+ vs all COVID−:\nblock-level test (pseudo-replicated): P=0.017\ndonor-level test: P=0.052', transform=ax.transAxes, fontsize=7.4, va='top')
h = [Line2D([0],[0],marker='o',color='w',markerfacecolor='#555555',markeredgecolor='k',ms=8,label='donor mean (size ∝ number of blocks)'),
     Line2D([0],[0],marker='o',color='w',markerfacecolor='white',markeredgecolor='#555555',mew=1.4,ms=8,label='donor whose autopsy text contradicts the group label (no acute pneumonia in a "pneumonia" group, or pneumonia in the "non-pneumonia" group)'),
     Line2D([0],[0],marker='o',color='w',markerfacecolor='#555555',alpha=.35,ms=4,label='individual blocks'),
     Line2D([0],[0],color='k',lw=1.6,label='group median of donor means')]
fig.legend(handles=h, loc='lower center', ncol=2, fontsize=7.8, frameon=False, bbox_to_anchor=(0.5,0.0))
fig.suptitle('Post-mortem lung (31 donors, 74 blocks): IL-33 is present in endothelium and basal epithelium whatever the diagnosis and is not higher in COVID-19;\nneutrophils dominate the pneumonic lungs and eosinophils are a minor component', fontsize=11, fontweight='bold', y=0.995)
plt.subplots_adjust(left=0.05, right=0.985, top=0.90, bottom=0.155)
fig.savefig(os.path.join(OUT, 'figures/fig5_postmortem_lung.png'), dpi=180)
