# AX-1177 (anti-IL-33 antibody) — portfolio audit memo

**Question.** Do we keep AX-1177 in the respiratory portfolio, and for what?

**Answer.** **Keep it — conditionally.** Keep the molecule, retire the "severe viral lower respiratory infection" label as the definition of the programme, and fund only a stage-gated evidence package with kill criteria agreed now.

**Basis.** Only the five delivered files: the methods annex, the two RNA-seq workbooks (26 contrasts, 26,210 genes each), the serum proteomics workbook (1,094 assays) and the post-mortem lung workbook (74 blocks, 31 donors). I re-analysed the delivered tables in full, including the rows, columns and contrasts that are hidden when the workbooks are opened (Section 8). Where I use general background knowledge rather than our data, it is marked *(background)*.

---

## 1. Recommendation and the case for it

### 1.1 What our data establish — the case for keeping

| # | Claim | Evidence in our data | Strength |
|---|---|---|---|
| 1 | **The antibody neutralises IL-33 completely in human endothelium** (at the one concentration tested) | IL-33 changes 4,031 genes in HUVEC at 6 h. 515 of them change at least 2-fold and are reversed at least 2-fold by AX-1177 in separately prepared libraries (the "core programme": 415 induced, 100 repressed). AX-1177 returns the core to baseline: slope of AX-1177 effect on IL-33 effect = −1.00, r = −0.97. Repeated at 24 h (155 genes, slope −0.90) and in a second, microvascular endothelial cell type (271 of the 515 genes also significant, same direction). | Strong |
| 2 | **It has no activity of its own** (transcriptome-wide, four cell types) | AX-1177 alone versus isotype, PBS or DMSO: no credible gene in 16 of 16 comparisons (4 cell types × 2 timepoints). The IL-33 programme does not move when antibody is given without IL-33 (median shift −0.02 to +0.07 log2). | Strong |
| 3 | **The target is in the diseased organ and its receptor predicts who deteriorates** | IL-33 protein stains in lung endothelium and airway basal epithelium of all 31 autopsy donors. Soluble ST2 (the circulating form of the IL-33 receptor) is the 2nd-strongest of 1,094 serum predictors of ICU admission, ventilation or death: OR 3.0 per log unit (95% CI 1.8–5.0), FDR 0.007, adjusted for age, sex and NEWS2. | Moderate — association only |
| 4 | **The drug's effect can be measured in people** | 13 proteins are IL-33-induced and AX-1177-reversed in endothelium *and* predict deterioration in serum. Eight are secreted or shed mediators: IL-6, OPG, IL-18R1, CCL20, MCP-3, IL-1β, M-CSF, cathepsin S. Soluble ST2 is a ready candidate for patient selection. | Moderate |

### 1.2 What our data do not establish — why the keep is conditional

| # | Gap | What the data actually show |
|---|---|---|
| 1 | **That IL-33 drives the disease** | IL-33 itself is not in the serum table. Lung IL-33 staining is not higher in COVID-19 (donor-level p = 0.76 epithelium, 0.05 endothelium and 0.07 smooth muscle — the last two in the *lower* direction). The 64 IL-33-programme proteins we can measure in serum are no more likely to predict outcome than any other protein (20% vs 17%, p = 0.50). |
| 2 | **That the pharmacology applies to the lung** | All IL-33 stimulation was done in endothelium from umbilical vein and kidney glomerulus. The only lung-derived cell (A549) never received IL-33. No experiment used a virus, an airway epithelial culture or an immune cell. |
| 3 | **Potency and a treatment window** | One antibody concentration, about 41-fold molar excess over IL-33 (10 µg/mL of a 146 kDa antibody against 30 ng/mL of an 18.1 kDa cytokine), added at the same moment as IL-33. No concentration–response and no delayed ("treatment-mode") dosing. The IL-33 response is fast and fades: the median induction of the 6 h genes falls from 4.0-fold to 1.7-fold by 24 h with no antibody present. |
| 4 | **Safety in infection** | The programme AX-1177 switches off includes interferon-response genes and the neutrophil growth factors GM-CSF and G-CSF. Whether that matters for pathogen control is untested. |
| 5 | **The "viral" qualifier** | No dataset tests it. The serum cohort is COVID-19 only; interferon and antiviral serum proteins do not track outcome; IL-33 staining and inflammatory-cell scores do not differ between COVID-positive and COVID-negative pneumonia lungs. |

### 1.3 The position in one paragraph

AX-1177 is a specific antibody whose mechanism has been demonstrated in vitro and can be measured, with a candidate patient-selection marker. Its disease hypothesis is unproven in any indication, and the questions that would prove or kill it are inexpensive: the first set needs no new laboratory work (Section 5, Gate 0). That combination — sound molecule, cheap decisive experiments — is the argument for keeping it on a short leash rather than dropping it or funding it as a viral-infection programme.

What the committee is asked to approve:

- retain AX-1177 in the portfolio;
- re-label the programme from "severe viral LRTI" to the biomarker-defined population in Section 4;
- release funding for Gate 0 and Gate 1 only, with a review at the Gate 0 read-out;
- adopt the stop criteria in Section 5 now.

### 1.4 If the committee decides to drop

What would be dropped: a specific, fully neutralising anti-IL-33 antibody with a reproducible 515-gene pharmacodynamic signature and a candidate enrichment marker. Why: not a flaw in the molecule, but the absence of any causal evidence that IL-33 drives severe respiratory infection — no ligand measurement, no disease model, no lung-cell pharmacology, and a clinical association (soluble ST2) that is prognostic but not specific to IL-33. The Gate 0 analyses below would still be worth running before the asset is archived, because they use data we already hold.

---

## 2. Evidence behind each statement

### 2.1 Pharmacology: RNA-seq, endothelial cells (Figure 1)

Design (annex): HUVEC and human glomerular microvascular endothelial cells (HGMEC), IL-33red 30 ng/mL, AX-1177 or isotype 10 µg/mL added together with IL-33, 6 h and 24 h, n = 3 per arm, 114 libraries in one batch.

- **Size of the IL-33 response.** HUVEC, 6 h: 4,031 genes at FDR < 0.05; 1,068 at least 2-fold. At 24 h: 1,836 and 512. The response is an NF-κB / interferon / IL-1-family programme (Hallmark "TNFα signalling via NF-κB" NES +2.97 at 6 h; "interferon-α response" +2.60).
- **What it contains.** Neutrophil and monocyte growth factors and chemokines (GM-CSF 1,258-fold, CXCL6 678-fold, CCL20 591-fold, CX3CL1 338-fold, G-CSF 319-fold), IL-6 (56-fold), tissue factor (50-fold) with thrombomodulin halved, IL-1α/β, complement C3. It contains no type-2 mediators (CCL26, periostin unchanged; eotaxins not expressed).
- **Reversal by AX-1177.** For the 515 core genes the AX-1177 effect mirrors the IL-33 effect (slope −1.00, r = −0.97). The two effects come from four different groups of libraries, so this is a replication, not a restatement. Picking genes from the IL-33-versus-vehicle contrast alone (407 genes, FDR < 10⁻⁴) gives slopes of −0.90 (against isotype + IL-33) and −0.95 (against IL-33 alone). With no significance filter at all, across 7,882 well-expressed genes, the two effects correlate r = 0.96.
- **24 h.** Slope −0.90 for the 155 core genes; −0.5 to −0.85 when genes are chosen from the IL-33 contrast alone, depending on the filter. Of the 133 induced core genes, 108 (81%) are at least 80% reversed (median 92%); at 6 h the figure is 382 of 415 (92%; median 102%). Two things account for the shortfall at 24 h. First, some genes differ between the vehicle arm and every other arm and are not IL-33-responsive at 6 h (for example KIF1A, FAM81A); the delivered contrasts cannot separate vehicle-arm noise from an AX-1177-insensitive effect for these. Second, a small group of interferon-type genes is only partly reversed: CXCL10 (43%), IFIT1 (38%), OASL (16%), with complement C3 at 71%.
- **Check with pre-defined gene sets** (no selection on our own data). NF-κB targets (Hallmark set): 99% reversed at 6 h, 88–99% at 24 h. Interferon-response genes: 92–96% at 6 h, 73–83% at 24 h. So the primary NF-κB wave is fully blocked, and a minority of the later interferon-type response persists. A brief exposure to IL-33 before the antibody captures it (there was no pre-incubation) could start a secondary loop; the Gate 1 time-course should test this.
- **Second cell type.** In HGMEC at 6 h the same genes reverse at about half the HUVEC magnitude (slope 0.56, r = 0.78; 271 of 515 significant). By 24 h the HGMEC signal has almost gone (20 of the 155 24 h core genes significant). No vehicle arm exists for HGMEC, so the IL-33 response there is inferred from the reversal. HGMEC were at passage 5 and HUVEC at passage 2, each from a single donor, so the difference in magnitude cannot be attributed to the vascular bed.
- **Isotype control is inert.** Isotype + IL-33 versus IL-33 alone shifts the core programme by at most 0.11 log2.

![Figure 1. RNA-seq pharmacology. A, B: IL-33 effect versus AX-1177 effect in HUVEC at 6 h and 24 h; blue = core programme; red circles = large effects whose model statistics are unreliable. C: the same reversal in glomerular microvascular endothelium. D: number of genes per contrast before and after an effect-size and expression filter.](figures/Fig1_pharmacology_rnaseq.png)

### 2.2 Specificity: antibody alone (Figure 1D, Figure 5B)

Sixteen comparisons of AX-1177 without IL-33 (HUVEC and HGMEC versus isotype; A549 and MCF7 versus isotype, PBS and DMSO; 6 h and 24 h) return 14–73 nominal hits each — 632 in total across 562 genes. None survives inspection:

- 516 are on/off noise in barely expressed genes (mean expression below 1 log2 unit, fold changes of 2 log2 or more);
- 94 are changes smaller than 0.3 log2 (under 23%) with implausibly small standard errors — for example AKR1C2 in A549, +0.11 log2 with t = 169;
- 22 are isolated, and none recurs as a credible effect in a second independent comparison.

No gene changes at least 2-fold at a meaningful expression level in any of the 16 comparisons. The apparent EGFR "hit" in A549 at 6 h (+0.16 log2 versus isotype) is absent against PBS (−0.01) and DMSO (+0.03), so it reflects the isotype arm, not AX-1177.

Ignoring p-values altogether, to guard against effects masked by the model problem described in Section 3: the antibody-alone effect is unrelated to the IL-33 effect (slope −0.01 to +0.02 across the 515 core genes in all four endothelial conditions), and the few genes that shift 2-fold in two settings (GFRA1, CYP1B1, SFN) move as much in null comparisons that contain no AX-1177.

![Figure 5. The model artefact. A: standard errors by expression level; flagged genes in red. B: every antibody-alone hit, by effect size. C: the classic endothelial-activation genes — effects replicate across independent arms while the reported standard errors are implausible.](figures/Fig5_model_artefact.png)

### 2.3 Patients: serum proteomics (Figure 2)

Cohort (annex): 100 patients hospitalised with PCR-confirmed SARS-CoV-2, single centre, pre-vaccination; serum at enrolment; composite endpoint of ICU admission, invasive ventilation or death within 30 days. The missing-value columns imply 44 patients reached the endpoint and 56 did not.

- **Soluble ST2** (assay "ST2", Cardiovascular III panel): OR 3.02 (1.83–5.01), p = 1.7 × 10⁻⁵, FDR 0.0075, rank 2 of 1,094 by p-value.
- **The whole panel is shifted.** 82% of assays have OR > 1; 178 pass FDR 5%, 176 of them in the harmful direction. Soluble ST2 is one of many proteins that are higher in patients who go on to deteriorate.
- **What separates patients who deteriorate** (assay groups curated by me from the delivered list): neutrophil activation proteins (17 of 39 at FDR < 0.05 against 16% overall; HGF is rank 1), myeloid cytokines (11 of 33; IL-6 on four panels, OR 2.1–2.3), epithelial injury and EGFR-ligand proteins (8 of 20), IL-1-family and related proteins (5 of 15: ST2, IL-18R1, IL-1R2, IL-1β, S100A12).
- **What does not:** type-2, eosinophil and mast-cell markers (1 of 23; IL-5 OR 1.00, eotaxin 1.08, TARC 0.85, tryptase 1.07); interferon and antiviral proteins (3 of 34; CXCL10 OR 1.30, p = 0.25; IFN-γ 1.03); endothelial-injury and coagulation markers as a class (3 of 54 — PTX3, VEGF-A, vWF; soluble E-selectin p = 0.02 but FDR 0.09; ICAM-1, VCAM-1, thrombomodulin not associated).
- **Not simply cardiac strain.** Soluble ST2 is a cardiac-stress marker *(background)*, but the cardiac markers measured alongside it are weak here: NT-proBNP OR 1.2 (p = 0.05 and 0.17 on two panels), troponin I OR 1.18 (p = 0.11).
- **Assays are reproducible.** Twenty-seven analytes were measured on more than one panel; their z-scores agree (r = 0.99 over 36 pairs).
- **Limits.** One centre, one virus, pre-vaccination. The models adjust for age, sex and NEWS2 only — not comorbidity, treatment or time since symptom onset. Only summary statistics were delivered, so no cut-point, discrimination or correlation between markers can be derived.

![Figure 2. Serum proteomics. A: odds ratios for the composite endpoint for selected assays, grouped by their relation to the IL-33 programme. B: distribution of association strength by protein family.](figures/Fig2_serum_proteomics.png)

### 2.4 Tissue: post-mortem lung (Figure 3)

Cohort: 31 donors (16 COVID-positive pneumonia, 10 COVID-negative pneumonia, 5 COVID-negative "non-pneumonia"), aged 64–98, all white; 74 blocks; one reader, semi-quantitative 0–5 scale.

- **IL-33 is abundant everywhere.** Donor median score: endothelium 5.5, basal epithelium 4.25, vascular smooth muscle 3.2. Thirty-nine of 74 blocks sit at the top endothelial grade. The scale is saturated, which limits every comparison below.
- **Not higher in COVID-19.** With the donor as the unit: epithelium p = 0.76; endothelium p = 0.05 and smooth muscle p = 0.07, both *lower* in COVID-positive donors, and both lose significance after adjusting for age and sex (p = 0.10). Treating the 74 blocks as independent would have given p = 0.017 and 0.007 — three COVID-positive donors contribute 24 of the 49 COVID-positive blocks.
- **COVID-positive and COVID-negative pneumonia are indistinguishable** on all eleven IHC readouts (every p ≥ 0.15). The pathology text does differ: diffuse alveolar damage is recorded in 7 of 16 COVID-positive donors and in none of 15 COVID-negative (p = 0.007). IL-33 scores are not significantly related to diffuse alveolar damage either (smooth-muscle IL-33 tends lower, p = 0.055).
- **Within a lung, less IL-33 where there are more neutrophils.** Block scores centred on the donor mean: endothelial IL-33 against neutrophil elastase r = −0.55 (within-donor permutation p = 0.03; 7 of 8 informative donors negative); epithelial IL-33 r = −0.47 (p = 0.03). Lower lobes have more neutrophil elastase (+0.46, p = 0.02) and less epithelial IL-33 (−0.49, p = 0.01) than upper lobes of the same donor. This is what release of a stored alarmin would look like, and equally what tissue destruction would look like. The data cannot tell them apart, and the finding is exploratory — one of several within-donor comparisons examined.
- **The infiltrate is neutrophil- and mast-cell-rich, not eosinophilic.** Neutrophil elastase exceeds eosinophil peroxidase in 30 of 31 donors. IL-33 staining is unrelated to any eosinophil marker. The IL-5Rα score follows neutrophil elastase (donor-level rho = 0.89), not eosinophil markers (rho = 0.12), so it should not be read as a type-2 signal.
- **Age matters.** Endothelial and smooth-muscle IL-33 rise with donor age (rho = 0.55 and 0.56, p = 0.001), so any group comparison has to adjust for it.
- **No healthy baseline.** The "non-pneumonia" group comprises idiopathic pulmonary fibrosis, coccidioidomycosis and organising pneumonia. Four of the ten "COVID-negative pneumonia" donors have no pneumonia in their pathology text.

![Figure 3. Post-mortem lung. A–C: IL-33 scores by group, one point per donor. D: within-donor relation between neutrophil elastase and endothelial IL-33. E: within-donor correlations of IL-33 with each inflammatory-cell marker. F: inflammatory-cell scores by group.](figures/Fig3_postmortem_lung.png)

### 2.5 Joining the datasets (Figure 4)

Of the 515 core genes, 64 encode a protein measured in serum. Thirteen of those predict deterioration at FDR < 0.05:

| Protein (gene) | IL-33 in HUVEC, 6 h | With AX-1177 (HUVEC / HGMEC, 6 h) | Still induced at 24 h? | Serum OR (95% CI) | Serum FDR |
|---|---|---|---|---|---|
| IL-6 | 56-fold | back to baseline / reversed | yes (7-fold, reversed) | 2.1–2.3 on four panels | 0.012–0.019 |
| OPG (TNFRSF11B) | 28-fold | baseline / reversed | yes (5-fold, reversed) | 6.8 (2.5–18.6); 4.4 (1.8–10.5) | 0.014; 0.020 |
| IL-18R1 | 12-fold | baseline / reversed | weakly (2.2-fold) | 6.1 (2.2–16.5) | 0.018 |
| CCL20 | 591-fold | baseline / reversed | yes (48-fold, reversed) | 1.83 (1.28–2.61) | 0.020 |
| MCP-3 (CCL7) | 4-fold | reversed / reversed | no | 1.72 (1.25–2.36) | 0.020 |
| IL-1β | 13-fold | baseline / reversed | yes (9-fold, reversed) | 2.45 (1.28–4.66) | 0.046 |
| M-CSF (CSF1) | 8-fold | baseline / reversed | weakly (1.7-fold) | 90 (4.2–1,933) — unstable | 0.037 |
| Cathepsin S | 4-fold | baseline / reversed | yes (5.5-fold, reversed) | 23 (2.7–200) — unstable | 0.037 |

The other five (B4GALT1, TRIM21, BIRC2, SERPINB8, VSTM1) are intracellular or membrane proteins and poor biomarker candidates.

Two cautions. First, thirteen of 64 is what chance would give (146 of 851 other proteins also pass; p = 0.50): **this is an overlap, not an enrichment**, and the serum data do not single out the IL-33 programme. Second, the strongest serum predictors — HGF, oncostatin M, proteinase 3, CD177, resistin, lipocalin-2 — are not endothelial IL-33 products at all (not expressed or not induced in our endothelial data).

![Figure 4. IL-33 inducibility in endothelium (x) against association with outcome in serum (y) for every serum protein with a matching gene.](figures/Fig4_triangulation.png)

---

## 3. Questions the committee is likely to ask

**"Isn't soluble ST2 just a marker of being sick?"** It may be. Most of the panel rises with severity. What sets it apart: rank 2 of 1,094 after adjustment for NEWS2, and it outperforms the cardiac markers measured with it. We claim prognosis, not causation, and propose it only as an enrichment marker to be tested.

**"Soluble ST2 is a decoy receptor. Do high levels mean IL-33 is already neutralised?"** Our data cannot answer that: there is no free IL-33 or IL-33:ST2 complex measurement. One relevant observation: the products IL-33 induces in endothelium that we can measure in serum (IL-6, OPG, IL-18R1, CCL20) run in the harmful direction in patients. This is the first thing Gate 0 and Gate 2 must settle.

**"IL-33 isn't raised in COVID lungs."** Correct, and we should not claim it is. IL-33 is a pre-formed store that is abundant in every lung we examined. What would matter is release, which immunohistochemistry of stored protein cannot measure. The within-lung inverse relation with neutrophils is compatible with release but does not prove it.

**"E-selectin, VCAM-1 and IL-8 top the spreadsheet but have adjusted p-values of 0.2–0.5."** A modelling artefact, not biology (Figure 5). One model was fitted across four unlike cell lines; standard errors are broken for 377 genes (1.4%), concentrated in lineage markers and very abundant genes. For E-selectin the IL-33 effect is +11.2 log2, the reversal in independent libraries is −11.0, the four matched null comparisons are within ±0.33 — and the reported standard error is 8.8. The same holds for VCAM-1, ICAM-1 (in HGMEC), IL-8, CXCL1, MCP-1, PTX3 and ST2 itself. These effects are almost certainly real, but their p-values cannot be cited in either direction until the model is re-fitted per cell line.

**"The antibody-alone contrasts have significant genes, including EGFR in lung epithelial cells."** The same artefact in reverse (Section 2.2). Nothing replicates and nothing exceeds 23% at a meaningful expression level.

**"Why endothelium?"** Because that is what was tested. IL-33 protein is strongest in lung endothelium, so the choice is reasonable, but serum endothelial-injury markers are not what separates patients who deteriorate, and no pulmonary endothelium was used. Mast cells, which are abundant in these lungs (tryptase score, donor median 3.5) and are classical IL-33 responders *(background)*, were not tested. The relevant responding cell in patients is an open question.

**"Could blocking IL-33 harm host defence?"** Open. IL-33 induces interferon-response genes and AX-1177 removes that induction (Hallmark interferon-α NES +2.60 with IL-33, −2.51 with AX-1177; CXCL10 118-fold, fully reversed). AX-1177 alone does not lower baseline interferon-response genes. An infection model is required before any infection indication.

---

## 4. Which indication do the data point at?

**Not a different disease area — a differently defined population.** Nothing in the data ties the biology to a virus, and nothing supports type-2 airway disease. The human data describe a host-response endotype:

> **Hyper-inflammatory acute respiratory failure in severe pneumonia — neutrophil-, IL-6- and IL-1-family-high, type-2-low — identified by high soluble ST2.**

COVID-19 is the only setting in which we have human data, so viral pneumonia remains the first place to test it. Whether non-viral pneumonia and ARDS share the endotype is a hypothesis the next studies must test, not a finding.

| Candidate | Serum (COVID-19 cohort) | Lung IHC | RNA-seq | Verdict |
|---|---|---|---|---|
| Severe viral LRTI, all-comers (current) | sST2 prognostic; antiviral markers are not; COVID-19 only | IL-33 not raised in COVID-19 | no virus, no lung cell stimulated | "Viral" is not what the data support; all-comers is too broad |
| **sST2-high hyper-inflammatory respiratory failure** | neutrophil, IL-6 and IL-1-family proteins predict outcome; sST2 rank 2 | neutrophil-rich infiltrate; IL-33 store present in all | IL-33 drives IL-6, G-CSF, GM-CSF, CXCL chemokines, tissue factor; fully reversed | **Best supported; still correlational** |
| Type-2 airway disease (asthma and related) | type-2 markers null (1 of 23) | eosinophil markers low and unrelated to IL-33 | no type-2 mediators induced | Not supported by these data |
| COPD / airway-epithelial mechanism | no COPD cohort; epithelial-injury and EGFR-ligand proteins (amphiregulin, TGF-α) do track outcome in COVID-19 (FDR 0.03–0.045) | basal-epithelial IL-33 numerically higher with a COPD history (11 donors; 4.68 vs 4.32, p = 0.21); nothing significant for COPD history or emphysema at autopsy (12 donors) on a saturated scale | airway epithelium never stimulated; oxidised IL-33, which AX-1177 also binds (annex), untested | Untested, not excluded; the Gate 1 epithelial work would inform it |
| Renal microvascular disease | kidney-injury markers weak (KIM-1 FDR 0.11–0.18) | not applicable | HGMEC respond at about half HUVEC magnitude; gone by 24 h | One in-vitro hint only |
| Thrombo-inflammatory vascular disease | tissue factor and vWF borderline (FDR 0.05); endothelial class not enriched | thromboemboli in 4 of 16 COVID-positive vs 0 of 15 (p = 0.10) | tissue factor 50-fold up, thrombomodulin halved, reversed | Hypothesis only |

---

## 5. What the next studies have to establish

The timings and thresholds below are my planning proposals, not values derived from the data.

**Gate 0 — re-analyse what we already hold (about 4–6 weeks, no new wet-lab work)**

| Must establish | How | Go / stop |
|---|---|---|
| The RNA-seq conclusions survive a correct model | Re-fit per cell line from the archived count matrix; extract the undelivered contrasts (isotype + IL-33 vs isotype; isotype vs vehicle; IL-33 effect in HGMEC) | Go if ≥ 90% of the 515 core genes are retained and the flagged genes (E-selectin, VCAM-1, IL-8, CXCL1, MCP-1, PTX3, ST2) are resolved |
| Soluble ST2 adds to clinical scoring and is not a proxy for IL-6 or neutrophil activation | Patient-level re-analysis of the 100 sera: discrimination over NEWS2, correlation structure, a usable cut-point | Stop if it adds nothing beyond NEWS2 + IL-6 |
| IL-33 itself was measured | Recover the 100 assays that were tested but not delivered (Section 8) | Informative either way |
| The IL-33 programme is present in diseased lung | Score the 515-gene signature in the lung-tissue RNA that appears to exist for 22 of the 31 donors ("Tissue RNA" IDs), against IL-33 IHC and neutrophil scores | Supportive if the signature tracks neutrophil elastase |

**Gate 1 — does AX-1177 work where and when it would have to? (about 3–4 months, in vitro)**

| Must establish | How | Go / stop |
|---|---|---|
| Potency at realistic exposure | Concentration–response for AX-1177 against a sub-maximal IL-33 dose; protein read-outs in supernatant | Go if ≥ 80% inhibition at a clinically achievable concentration |
| A treatment window | Add AX-1177 1, 2 and 4 h after IL-33; repeat-pulse IL-33 | Stop if < 30% suppression of the sustained genes when dosed after the trigger |
| Lung relevance | Human pulmonary microvascular endothelium from ≥ 3 donors; airway epithelial air–liquid cultures; reduced and oxidised IL-33 | Go if the core programme and its reversal reproduce in lung cells |
| A functional consequence | Neutrophil adhesion and transmigration on IL-33-activated endothelium; tissue-factor activity; barrier integrity | Go if AX-1177 normalises at least one function |

**Gate 2 — is the pathway active in patients, and is blocking it safe? (about 6–9 months)**

| Must establish | How | Go / stop |
|---|---|---|
| IL-33 is present and active in the target patients | High-sensitivity assays for IL-33 (reduced, oxidised, complexed with ST2) in banked sera and airway samples; bioassay — does patient serum induce the core signature in endothelium, and does AX-1177 block it? | **Stop if no AX-1177-sensitive IL-33 activity is detectable in sST2-high patients** |
| Soluble ST2 replicates, including outside COVID-19 | Independent cohorts: viral and non-viral pneumonia, ARDS | Stop if not prognostic in a second cohort |
| Blocking IL-33 changes disease, not just transcripts | In-vivo neutrophilic lung-injury model with a cross-reactive or surrogate antibody; read out the neutrophil signature seen in patients | Go if lung injury and neutrophil markers fall |
| Pathogen control is preserved | Viral and bacterial challenge with IL-33 blockade: pathogen load, interferon response | Stop if pathogen control is impaired |

Also request from the programme archive: the biologics file (affinity, potency, species cross-reactivity), the count matrix and fitted model, patient-level Olink data with clinical covariates and treatments, and the lung-tissue RNA dataset.

---

## 6. Biomarkers, their roles, and when to sample

### 6.1 Sampling timepoint

- **In vitro and ex vivo: 6 h for RNA.** The programme is 3.3 times larger than at 24 h (515 vs 155 core genes); reversal is complete (slope −1.00 vs −0.90); and it reproduces across both endothelial types at 6 h (53% of genes) but barely at 24 h (13%). Add 24 h for secreted protein, using only the sustained genes. With two timepoints we cannot locate the true peak, so the Gate 1 time-course should add 1, 3, 12 and 48 h.
- **Patients: enrolment (pre-dose) serum** for soluble ST2 and the panel — the only timepoint at which our clinical data show prognostic value. On-treatment timepoints cannot be set from our data.

### 6.2 Markers and roles

| Marker | In-vitro evidence (HUVEC 6 h; AX-1177) | Patient evidence (serum) | Role | Status |
|---|---|---|---|---|
| **Soluble ST2** | 3-fold up, reversed, HUVEC only, gone by 24 h; statistics unreliable | OR 3.0, FDR 0.007, rank 2 of 1,094 | **Patient selection / enrichment** | Into patients now as a stratifier to be validated. Not a pharmacodynamic marker on current evidence |
| **IL-6, OPG, IL-18R1, CCL20** | 12- to 591-fold up; reversed to baseline in both endothelial types; IL-6, OPG and CCL20 sustained at 24 h | all FDR ≤ 0.02 | **Pharmacodynamic / response** | Lead panel for patients. None is specific to IL-33 |
| MCP-3, IL-1β | reversed in both cell types | FDR 0.02; 0.046 | Pharmacodynamic, secondary | Low abundance |
| M-CSF, cathepsin S | reversed in both cell types | FDR 0.037, confidence intervals extremely wide | Exploratory | Serum estimates unstable |
| GM-CSF, G-CSF, CXCL5, CXCL6, CX3CL1, 4-1BB, CCL5, EBI3 | the largest and most reproducible in-vitro effects (GM-CSF 1,258-fold; CXCL5, CCL5, EBI3 and GM-CSF significant in all four endothelial conditions) | where measured, not prognostic (G-CSF OR 1.25, CXCL5 1.17, CXCL6 1.02, CCL5 0.89); GM-CSF and EBI3 not measured | **Proof-of-mechanism** in vitro, ex vivo and in first clinical studies | Not for patient selection or as efficacy surrogates |
| PTX3, IL-8, MCP-1, soluble E-selectin, ICAM-1, VCAM-1 | large effects replicated across independent arms; model statistics invalid | PTX3 OR 11.6 (FDR 0.012), IL-8 2.2 (0.023); MCP-1 and E-selectin borderline; ICAM-1, VCAM-1 not associated | Candidate pharmacodynamic markers | On hold until the re-fit and protein data; PTX3 and IL-8 first |
| Neutrophil-activation panel (HGF, oncostatin M, proteinase 3, CD177, resistin, lipocalin-2) | not endothelial IL-33 products | strongest family in serum (17 of 39; HGF rank 1) | **Disease activity / prognosis**; exploratory downstream response | Tests the IL-33 → neutrophil hypothesis: these should fall if it is true |
| IL-33 (free, total, reduced, oxidised) and IL-33:ST2 complex | not applicable | absent from our serum data | **Target engagement** | Assay must be built — the critical gap |
| Interferon-response score, pathogen load | IL-33 induces, AX-1177 removes | antiviral proteins not prognostic | Safety monitoring in infection | For Gate 2 and any infection trial |

---

## 7. What I considered and ruled out

| Considered | Outcome | Why |
|---|---|---|
| Type-2 / eosinophilic indication | Ruled out on these data | Serum type-2 markers null; eosinophil IHC low and unrelated to IL-33; no type-2 mediators in the IL-33 programme; IL-5Rα staining follows neutrophils. Caveat: acute pneumonia and endothelium are not where type-2 biology would show |
| A virus-specific mechanism | Not supported | Section 1.2, item 5 |
| COPD | Not supported, not excluded | IL-33 scores do not differ significantly by COPD history or emphysema (epithelium 4.68 vs 4.32, p = 0.21); no epithelial pharmacology; oxidised IL-33 untested |
| Renal or other microvascular repurposing | Hypothesis only | HGMEC response is weaker and gone by 24 h; no kidney tissue or renal outcome data |
| Cardiac explanation for soluble ST2 | Unlikely | NT-proBNP and troponin I are weak in the same models |
| Off-target or agonist activity of AX-1177 | Ruled out at transcriptome level | Section 2.2 |
| An EGFR-axis effect of AX-1177 in lung epithelium | Ruled out | Seen against isotype only, 12% change, flagged gene |
| Isotype control not inert | Ruled out | ≤ 0.11 log2 shift of the core programme |
| Incomplete neutralisation at 24 h | Largely ruled out | NF-κB targets are 88–99% reversed at 24 h. Interferon-type genes are 73–83% reversed (CXCL10, IFIT1, OASL least) and flagged for follow-up. Other apparent residuals cannot be separated from vehicle-arm noise |
| "IL-33 is lower in COVID-19 lungs" | Not claimed | Significant only if blocks are treated as independent; p = 0.10 after age and sex |
| E-selectin, VCAM-1, IL-8, CXCL1, MCP-1, PTX3 as validated biomarkers | Deferred | Standard errors invalid; effects look real |
| Soluble ST2 as a pharmacodynamic marker | Rejected for now | Transient, one cell type, unreliable statistics |
| Ranking serum proteins by odds ratio | Rejected | ORs are per log unit, not per SD; narrow-range assays give ORs of 20–90 with very wide intervals. Ranked by z / p instead |
| Gene-set shifts in antibody-alone contrasts (MYC, E2F, oxidative phosphorylation) | Dismissed as technical | Sub-0.1 log2, opposite directions in different cell lines and timepoints |

---

## 8. What the committee should know about the delivered files

1. **The workbooks open on partial views.** The contrasts workbook has two sheets, "6h" and "24h", that contain the same 629,040 rows; each is filtered to show one of the 24 contrasts, sorted by fold change. In that view three of the top seven genes (E-selectin, VCAM-1, IL-8) are statistically unsupported. The lung workbook hides all fifteen histology and IHC score columns, including the three IL-33 columns. The serum workbook hides the confidence-interval columns and two duplicate rows (HGF and IL-6 from the Oncology II panel).
2. **One model across four cell lines breaks the statistics for 377 genes** (Section 3, Figure 5). Fold changes are unaffected.
3. **The serum adjusted p-values were computed over 1,194 assays; 1,094 were delivered.** The 100 missing assays are spread across the p-value range, and twelve of the thirteen panels are short of the 92 assays a Target 96 panel carries *(background)*; the Inflammation panel has 77. IL-33 is, to my knowledge, one of that panel's analytes *(background)* and is not in the file. Re-adjusting over the 1,094 delivered changes nothing material (ST2 FDR 0.0068).
4. **Lung IHC scores exceed the stated scale.** The scale is 0–5; 39 blocks score 5.5 for endothelial IL-33. "N+" grades appear to have been converted to N + 0.5, and the IL-33 values look like averages of two sub-scores (one cell still holds the formula `=(2+4.5)/2`). The scores are ordinal and were analysed with rank-based and within-donor methods.
5. **Lung group labels do not match the pathology text** for seven donors (four "pneumonia" without pneumonia, three "non-pneumonia" with pneumonia or infection); one donor has no SARS-CoV-2 result recorded.
6. **Labelling.** The HUVEC workbook's sheets say "vs Vehicle" while the rows say "vs Nontreated".
7. **Single points of failure.** One donor per endothelial cell type; one IHC reader; one serum centre; no replication cohort.

---

## Appendix A. How the re-analysis was done

- **RNA-seq.** All 26 contrasts loaded (24 from the contrasts workbook, two from the HUVEC workbook); the two sheets of the contrasts workbook were confirmed identical. Checked: Benjamini–Hochberg adjustment reproduces within contrast; p-values match t with 85 degrees of freedom (76 residual plus prior). Standard error = logFC / t. Genes were flagged when the median standard error across contrasts exceeded five times the running median for their expression level, or when it varied more than 20-fold between contrasts. Contrasts not delivered were derived by subtraction (for example AX-1177 + IL-33 versus vehicle = [IL-33 vs vehicle] + [AX-1177 + IL-33 vs IL-33]). "Core programme" = FDR < 0.05 and |log2FC| ≥ 1 in both IL-33 versus vehicle and AX-1177 + IL-33 versus isotype + IL-33, with opposite sign. Gene-set enrichment: fgsea on Hallmark and Reactome sets (MSigDB 7.5.1), genes ranked by t.
- **Serum.** Wald z recomputed from OR and CI; Benjamini–Hochberg denominators reconstructed from the ratio of adjusted to raw p; assay names mapped to gene symbols by hand; assay themes curated by me from the delivered assay list (not blind to the results) and then tested for enrichment with Fisher's exact test.
- **Lung.** Donor-level fields filled from each donor's first block; "N+" grades read as N; one formula cell evaluated. Group comparisons on donor means (Mann–Whitney), with mixed models as a check. Within-donor associations on donor-centred scores, with permutation of scores within donor. Pathology features coded from the free text by keyword and checked by reading.

## Appendix B. Deliverables

- `AX-1177_portfolio_audit_memo.pdf` / `.docx` / `.md` — this memo (same content; PDF to read, DOCX to edit, Markdown source).
- `figures/Fig1–Fig5` — pharmacology; serum; lung; triangulation; model artefact.
- `tables/AX-1177_supporting_tables.xlsx` — biomarker panel; core gene lists (6 h, 24 h); flagged genes; gene counts per contrast; antibody-alone hits; annotated serum table and protein-family summary; lung block- and donor-level tables; file-integrity findings.
- `scripts/` — the analysis code as run, with a README.
