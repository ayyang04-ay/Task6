import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 50)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); q = pd.read_parquet('q.parquet'); D = pd.read_parquet('derived.parquet'); fl = pd.read_parquet('se_flags.parquet')
ok = (ann.AveExpr>4)&(~fl.flag)
print('genes used:', ok.sum())
allc = pd.concat([lfc, D], axis=1)
cols = ['C47_v_IC_HUVEC_6h','C47_v_IC_HUVEC_24h','C47_v_IC_HGMEC_6h','C47_v_IC_HGMEC_24h','C47_v_IC_A549_6h','C47_v_IC_A549_24h','C47_v_IC_MCF7_6h','C47_v_IC_MCF7_24h',
        'IC_v_PBS_A549_6h','IC_v_PBS_A549_24h','IC_v_PBS_MCF7_6h','IC_v_PBS_MCF7_24h','DMSO_v_PBS_A549_6h','DMSO_v_PBS_A549_24h','DMSO_v_PBS_MCF7_6h','DMSO_v_PBS_MCF7_24h',
        'IL33IC_v_IL33_HUVEC_6h','IL33IC_v_IL33_HUVEC_24h','IL33IC_v_IL33_HGMEC_6h','IL33IC_v_IL33_HGMEC_24h','IL33_v_Veh_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HGMEC_6h']
X = allc.loc[ok, cols]
print('SD of logFC (well-expressed genes):'); print(X.std().round(3).to_string())
C = X.corr(method='spearman')
print(C.round(2).to_string())
# Does antibody alone move the IL-33 core signature? mean lfc of core up genes in antibody-alone contrasts
i6='IL33_v_Veh_HUVEC_6h'; c6='C47IL33_v_IL33IC_HUVEC_6h'
core_up = (q[i6]<0.05)&(q[c6]<0.05)&(lfc[i6]>=1)&(lfc[c6]<=-1)
core_dn = (q[i6]<0.05)&(q[c6]<0.05)&(lfc[i6]<=-1)&(lfc[c6]>=1)
print('core up n=%d, core down n=%d' % (core_up.sum(), core_dn.sum()))
rows=[]
for c in [x for x in allc.columns if x.startswith('C47_v_') or x.startswith('IC_v') or x.startswith('DMSO_v') or x.startswith('IL33IC_v_IL33')]:
    u = allc.loc[core_up&(ann.AveExpr>0), c]; d = allc.loc[core_dn&(ann.AveExpr>0), c]; bg = allc.loc[(ann.AveExpr>0)&~core_up&~core_dn, c]
    rows.append((c, u.median(), d.median(), bg.median(), stats.mannwhitneyu(u, bg).pvalue, stats.mannwhitneyu(d, bg).pvalue))
print(pd.DataFrame(rows, columns=['contrast','median_lfc_coreUP','median_lfc_coreDOWN','median_bg','p_up_vs_bg','p_down_vs_bg']).to_string(float_format=lambda v: f'{v:.3g}'))
