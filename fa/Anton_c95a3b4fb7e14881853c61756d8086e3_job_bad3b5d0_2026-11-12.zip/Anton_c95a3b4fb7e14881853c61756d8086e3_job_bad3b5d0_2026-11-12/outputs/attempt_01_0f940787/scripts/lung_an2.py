import pandas as pd, numpy as np, re
from scipy import stats
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200); pd.set_option('display.max_columns', 40); pd.set_option('display.max_colwidth', 200)
df = pd.read_pickle('lung_blocks.pkl'); don = pd.read_pickle('lung_donors.pkl')
path = df.groupby('sample_id', sort=False)['pathology_d'].first()
don['path'] = path
def has(pat, s): return bool(re.search(pat, s or '', flags=re.I))
don['copd_note'] = don.notes.map(lambda s: 'COPD' in s)
don['asthma_note'] = don.notes.map(lambda s: 'Asthma' in s)
don['fibrosis_note'] = don.notes.map(lambda s: 'Fibrosis' in s)
don['any_note'] = don.notes.map(lambda s: len(s)>0)
don['emphysema_path'] = don.path.map(lambda s: has('emphysem', s))
don['copd_or_emph'] = don.copd_note | don.emphysema_path
don['fibrosis_path'] = don.path.map(lambda s: has('pulmonary fibrosis|diffuse fibrosis|lungs showing diffuse fibrosis|fibrotic stages', s))
don['DAD'] = don.path.map(lambda s: has('diffuse alveolar damage|hyalin(e)? membranes|acute lung injury', re.sub(r'no hyaline? membranes', '', s or '', flags=re.I)))
don['bronchopneumonia'] = don.path.map(lambda s: has('bronchopneumonia|bronchpneumonia', s))
don['any_pneumonia_text'] = don.path.map(lambda s: has('pneumonia|pneumonitis', s))
don['thromboemb'] = don.path.map(lambda s: has('thromboembol|pulmonary emboli|arterial thrombo|Thromboembolus', s))
don['nephrosclerosis'] = don.path.map(lambda s: has('nephroscleros|renal atrophy|nephritis|tubular', s))
don['MI_or_IHD'] = don.path.map(lambda s: has('myocardial infarct|ischemic heart', s))
don['severe_athero'] = don.path.map(lambda s: has('severe[^\n]*atheroscl|atheroscl[^\n]*severe', s))
feats = ['copd_note','asthma_note','fibrosis_note','emphysema_path','copd_or_emph','fibrosis_path','DAD','bronchopneumonia','any_pneumonia_text','thromboemb','nephrosclerosis','MI_or_IHD','severe_athero']
print(don[['cat','n_blocks','age','sex','notes']+feats].to_string())
print()
print(pd.crosstab(don.cat, don.any_pneumonia_text))
print(pd.crosstab(don.cat, don.copd_or_emph))
print(pd.crosstab(don.cat, don.DAD))
print()
rows=[]
for f in feats:
    for m in ['IL33_epi','IL33_endo','IL33_vsmc','NE','EPX','TRYP']:
        a = don.loc[don[f], m].dropna(); b = don.loc[~don[f], m].dropna()
        if len(a)>=3 and len(b)>=3:
            p_ = stats.mannwhitneyu(a,b).pvalue
            rows.append((f, m, len(a), len(b), a.mean(), b.mean(), a.median(), b.median(), p_))
r = pd.DataFrame(rows, columns=['feature','marker','n_yes','n_no','mean_yes','mean_no','med_yes','med_no','MWU_p'])
print(r.to_string(float_format=lambda x: f'{x:.3g}'))
print('n tests', len(r), ' min p', r.MWU_p.min())
# age, sex
for m in ['IL33_epi','IL33_endo','IL33_vsmc']:
    rho = stats.spearmanr(don.age, don[m], nan_policy='omit')
    a = don.loc[don.sex=='M', m]; b = don.loc[don.sex=='F', m]
    print(m, 'age rho=%.2f p=%.3f' % (rho.statistic, rho.pvalue), '| sex M mean %.2f F mean %.2f MWU p=%.3f' % (a.mean(), b.mean(), stats.mannwhitneyu(a,b).pvalue))
don.to_pickle('lung_donors2.pkl')
