import re, subprocess, os, shutil
src = '/tmp/outputs/AX-1177_portfolio_audit_memo.md'
md = open(src).read()
lines = md.split('\n')
out = []
i = 0
def cells(l): return [c.strip() for c in l.strip().strip('|').split('|')]
while i < len(lines):
    l = lines[i]
    if l.startswith('|') and i+1 < len(lines) and re.match(r'^\|[-| :]+\|$', lines[i+1].strip()):
        j = i
        tbl = []
        while j < len(lines) and lines[j].startswith('|'):
            tbl.append(lines[j]); j += 1
        rows = [cells(t) for k,t in enumerate(tbl) if k != 1]
        ncol = len(rows[0])
        w = []
        for c in range(ncol):
            mx = max(len(re.sub(r'[*`]', '', r[c])) if c < len(r) else 0 for r in rows)
            avg = sum(len(re.sub(r'[*`]', '', r[c])) if c < len(r) else 0 for r in rows)/len(rows)
            w.append(min(max(4, 0.5*mx + 0.5*avg), 70))
        tot = sum(w); dashes = [max(3, int(round(100*x/tot))) for x in w]
        out.append(tbl[0]); out.append('|' + '|'.join('-'*d for d in dashes) + '|'); out.extend(tbl[2:])
        i = j
    else:
        out.append(l); i += 1
pm = '\n'.join(out)
# pandoc title block
pm = re.sub(r'^# (.*)\n', r'---\ntitle: "\1"\n---\n', pm, count=1)
open('/tmp/outputs/_memo_pandoc.md','w').write(pm)
css = '''
body{font-family:Segoe UI,Helvetica,Arial,sans-serif;max-width:1050px;margin:2em auto;padding:0 1.2em;line-height:1.45;color:#1a1a1a;font-size:15px}
h1{font-size:1.7em;border-bottom:2px solid #333;padding-bottom:.2em} h2{font-size:1.3em;margin-top:1.8em;border-bottom:1px solid #bbb;padding-bottom:.15em} h3{font-size:1.08em;margin-top:1.3em}
table{border-collapse:collapse;width:100%;margin:1em 0;font-size:.88em} th,td{border:1px solid #bbb;padding:5px 7px;vertical-align:top;text-align:left} th{background:#eee}
blockquote{border-left:4px solid #1f77b4;margin:1em 0;padding:.4em 1em;background:#f3f8fc} img{max-width:100%} figcaption{font-size:.85em;color:#444;margin-bottom:1.2em} code{background:#f2f2f2;padding:1px 4px}
'''
open('/tmp/outputs/_memo.css','w').write(css)
os.chdir('/tmp/outputs')
r1 = subprocess.run(['micromamba','run','-n','renv','pandoc','_memo_pandoc.md','-f','markdown+pipe_tables+implicit_figures','-o','AX-1177_portfolio_audit_memo.docx','--resource-path=.','--reference-doc=/tmp/work/build/ref_custom.docx'], capture_output=True, text=True)
print('docx', r1.returncode, r1.stderr[-500:])
os.remove('_memo_pandoc.md'); os.remove('_memo.css')
