import openpyxl, pandas as pd, numpy as np, re
wb = openpyxl.load_workbook('/tmp/world/filesystem/AX-1177_postmortem_lung.xlsx')
ws = wb.worksheets[0]
hdr = [c.value for c in ws[1]]
rows = []
for r in ws.iter_rows(min_row=2, max_row=ws.max_row):
    vals = [c.value for c in r]
    if all(v is None for v in vals): continue
    rows.append([r[0].row]+vals)
cols = ['xl_row','sample_id','block_id','tissue_rna','sample_id_dup','lobe','disease_category','race','gender','age','sars_cov2','pathology',
        'HE_eos','EPX_raw','EDN_raw','MBP_raw','2D7_raw','IL5Ra_NEduplex_raw','NE_raw','IL5Ra_TRYPduplex_raw','TRYP_raw',
        'EPX_num','NE_num','TRYP_num','IL33_epi','IL33_endo','IL33_vsmc','notes','extra']
df = pd.DataFrame(rows, columns=cols)
print(df.shape)
# evaluate formula
def ev(v):
    if isinstance(v,str) and v.startswith('='):
        return eval(v[1:])
    return v
for c in ['IL33_epi','IL33_endo','IL33_vsmc','EPX_num','NE_num','TRYP_num']:
    df[c] = df[c].map(ev)
    df[c+'_flag'] = df[c].map(lambda v: v if isinstance(v,str) else None)
    df[c] = pd.to_numeric(df[c], errors='coerce')
def plus(v):
    if v is None: return np.nan
    if isinstance(v,(int,float)): return float(v)
    s = str(v).strip()
    if s in ('ND','N/A',''): return np.nan
    m = re.match(r'^(\d)\+$', s)
    if m: return float(m.group(1))
    raise ValueError(v)
for c in ['EPX_raw','EDN_raw','MBP_raw','2D7_raw','IL5Ra_NEduplex_raw','NE_raw','IL5Ra_TRYPduplex_raw','TRYP_raw']:
    df[c.replace('_raw','')] = df[c].map(plus)
df['sample_id'] = df.sample_id.astype(str).str.strip()
df['sample_id_dup'] = df.sample_id_dup.astype(str).str.strip()
print('sample id mismatch A vs D:', (df.sample_id!=df.sample_id_dup).sum())
# donor-level fill
donor_cols = ['disease_category','race','gender','age','sars_cov2','pathology']
first = df.groupby('sample_id', sort=False)[donor_cols].first()
notes = df.groupby('sample_id', sort=False)['notes'].agg(lambda x: '; '.join([str(v) for v in x if v is not None]))
n_notes = df.groupby('sample_id', sort=False)['notes'].agg(lambda x: sum(v is not None for v in x))
print('donors with >1 notes entries:', (n_notes>1).sum())
for c in donor_cols:
    df[c+'_d'] = df.sample_id.map(first[c])
df['notes_d'] = df.sample_id.map(notes)
df.to_pickle('lung_blocks.pkl')
don = df.groupby('sample_id', sort=False).agg(n_blocks=('block_id','size'), category=('disease_category_d','first'), sex=('gender_d','first'), age=('age_d','first'), sars=('sars_cov2_d','first'), notes=('notes_d','first'),
        first_row=('xl_row','min'))
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200); pd.set_option('display.max_columns', 40)
print(don.to_string())
print(don.groupby('category').agg(n_donors=('n_blocks','size'), n_blocks=('n_blocks','sum'), age_med=('age','median'), age_min=('age','min'), age_max=('age','max'), male=('sex', lambda x: (x=='M').sum())))
print('extra col values:', df.extra.dropna().tolist())
print('block id dup:', df.block_id.duplicated().sum())
print(df[['xl_row','sample_id','block_id','lobe','EPX','EPX_num','NE','NE_num','TRYP','TRYP_num','IL33_epi','IL33_endo','IL33_vsmc','IL33_epi_flag']].to_string())
