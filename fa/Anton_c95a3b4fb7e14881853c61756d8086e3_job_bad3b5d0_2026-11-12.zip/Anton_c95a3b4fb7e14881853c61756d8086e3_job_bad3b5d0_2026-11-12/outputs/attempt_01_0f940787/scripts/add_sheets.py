import pandas as pd, numpy as np
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); q = pd.read_parquet('q.parquet'); fl = pd.read_parquet('se_flags.parquet')
s = pd.read_csv('serum_annot.csv')
def g(sym): return ann.index[ann.symbol==sym][0]
i6, i24 = 'IL33_v_Veh_HUVEC_6h','IL33_v_Veh_HUVEC_24h'; hu6, hu24, hg6, hg24 = 'C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_6h','C47IL33_v_IL33IC_HGMEC_24h'
panel = [
 # (marker, gene, serum assays, role, status)
 ('Soluble ST2','IL1RL1',['ST2'],'Patient selection / enrichment (prognostic)','Into patients as a stratifier to be validated; not a PD marker on current evidence (transient, HUVEC only, RNA-seq statistics unreliable)'),
 ('IL-6','IL6',['IL6','IL6-ONCII','IL6-CVDII','IL6-IMO'],'Pharmacodynamic / response (lead panel)','Mechanism-linked and outcome-linked; not specific to IL-33'),
 ('OPG','TNFRSF11B',['OPG-INFI','OPG-CVDIII'],'Pharmacodynamic / response (lead panel)','Mechanism-linked and outcome-linked'),
 ('IL-18R1','IL18R1',['IL-18R1'],'Pharmacodynamic / response (lead panel)','Shed receptor; kinetics unknown'),
 ('CCL20','CCL20',['CCL20'],'Pharmacodynamic / response (lead panel)','Largest dynamic range of the outcome-linked set'),
 ('MCP-3 (CCL7)','CCL7',['MCP-3'],'Pharmacodynamic, secondary','Low expression; 6 h only'),
 ('IL-1beta','IL1B',['IL1B'],'Pharmacodynamic, secondary','Low abundance in serum'),
 ('M-CSF (CSF1)','CSF1',['CSF-1'],'Exploratory','Serum OR estimate unstable (very wide CI)'),
 ('Cathepsin S','CTSS',['CTSS'],'Exploratory','Serum OR estimate unstable (very wide CI); significant in all four endothelial conditions'),
 ('Tissue factor (F3)','F3',['TF'],'Exploratory (thrombo-inflammation)','Transient (6 h); serum FDR 0.051'),
 ('GM-CSF (CSF2)','CSF2',[],'Proof-of-mechanism PD (in vitro / ex vivo / first-in-human)','Largest in-vitro effect; not measured in serum'),
 ('G-CSF (CSF3)','CSF3',['G-CSF'],'Proof-of-mechanism PD','Not prognostic in serum'),
 ('CXCL5','CXCL5',['CXCL5'],'Proof-of-mechanism PD','Significant in all four endothelial conditions; not prognostic in serum'),
 ('CXCL6','CXCL6',['CXCL6'],'Proof-of-mechanism PD','Significant in all four endothelial conditions; not prognostic in serum'),
 ('CX3CL1','CX3CL1',['CX3CL1'],'Proof-of-mechanism PD','Serum p = 0.054'),
 ('4-1BB (TNFRSF9)','TNFRSF9',['TNFRSF9'],'Proof-of-mechanism PD','Not prognostic in serum'),
 ('CCL5','CCL5',['CCL5'],'Proof-of-mechanism PD','Significant in all four endothelial conditions; not prognostic in serum'),
 ('EBI3 (IL-27/IL-35 subunit)','EBI3',['IL-27'],'Proof-of-mechanism PD','Significant in all four endothelial conditions; serum IL-27 assay not prognostic'),
 ('PTX3','PTX3',['PTX3'],'Candidate PD - ON HOLD','Effect replicated across independent arms but RNA-seq standard errors invalid; strong serum association'),
 ('IL-8 (CXCL8)','CXCL8',['IL8'],'Candidate PD - ON HOLD','As above'),
 ('MCP-1 (CCL2)','CCL2',['MCP-1-INFI','MCP-1-CVDIII'],'Candidate PD - ON HOLD','As above; serum borderline'),
 ('Soluble E-selectin','SELE',['SELE'],'Candidate PD - ON HOLD','As above; serum FDR 0.09'),
 ('Soluble ICAM-1','ICAM1',['ICAM1'],'Candidate PD - ON HOLD','Significant in HUVEC, SE inflated; not prognostic in serum'),
 ('Soluble VCAM-1','VCAM1',['VCAM1'],'Candidate PD - ON HOLD','SE invalid; not prognostic in serum'),
 ('CXCL1','CXCL1',['CXCL1-INFI','CXCL1-CVDII'],'Candidate PD - ON HOLD','SE invalid; not prognostic in serum'),
 ('HGF','HGF',['HGF','HGF-ONCII'],'Disease activity / prognosis; exploratory downstream response','Not an endothelial IL-33 product; strongest serum predictor'),
 ('Oncostatin M','OSM',['OSM'],'Disease activity / prognosis; exploratory downstream response','Not an endothelial IL-33 product'),
 ('Proteinase 3','PRTN3',['PRTN3'],'Disease activity / prognosis; exploratory downstream response','Not an endothelial IL-33 product'),
 ('CD177','CD177',['CD177'],'Disease activity / prognosis; exploratory downstream response','Not an endothelial IL-33 product'),
 ('Resistin','RETN',['RETN'],'Disease activity / prognosis; exploratory downstream response','Not an endothelial IL-33 product'),
 ('Lipocalin-2','LCN2',['LCN2'],'Disease activity / prognosis; exploratory downstream response','Not an endothelial IL-33 product'),
]
rows=[]
for name, gene, assays, role, status in panel:
    i = g(gene)
    r = {'marker':name, 'gene':gene, 'proposed_role':role, 'status_caveat':status,
         'RNAseq_SE_unreliable':bool(fl.flag[i]), 'AveExpr_all114':round(ann.AveExpr[i],2),
         'IL33_HUVEC_6h_log2FC':round(lfc.loc[i,i6],2), 'IL33_HUVEC_6h_fold':round(2**lfc.loc[i,i6],1), 'IL33_HUVEC_6h_adjP':q.loc[i,i6],
         'AX1177_reversal_HUVEC_6h_log2FC':round(lfc.loc[i,hu6],2), 'AX1177_reversal_HUVEC_6h_adjP':q.loc[i,hu6],
         'AX1177_reversal_HGMEC_6h_log2FC':round(lfc.loc[i,hg6],2), 'AX1177_reversal_HGMEC_6h_adjP':q.loc[i,hg6],
         'IL33_HUVEC_24h_log2FC':round(lfc.loc[i,i24],2), 'IL33_HUVEC_24h_adjP':q.loc[i,i24],
         'AX1177_reversal_HUVEC_24h_log2FC':round(lfc.loc[i,hu24],2), 'AX1177_reversal_HUVEC_24h_adjP':q.loc[i,hu24],
         'AX1177_reversal_HGMEC_24h_log2FC':round(lfc.loc[i,hg24],2), 'AX1177_reversal_HGMEC_24h_adjP':q.loc[i,hg24]}
    if assays:
        sub = s[s.assay.isin(assays)].sort_values('p.value')
        r['serum_assays'] = '; '.join(sub.assay); r['serum_OR'] = '; '.join(f'{x:.2f}' for x in sub.OR); r['serum_95CI'] = '; '.join(f'{a:.2f}-{b:.3g}' for a,b in zip(sub.l95, sub.u95))
        r['serum_p'] = '; '.join(f'{x:.2g}' for x in sub['p.value']); r['serum_FDR'] = '; '.join(f'{x:.2g}' for x in sub['adj.p.value']); r['serum_rank_of_1094'] = '; '.join(str(x) for x in sub['rank'])
    else:
        r.update({'serum_assays':'not measured','serum_OR':'','serum_95CI':'','serum_p':'','serum_FDR':'','serum_rank_of_1094':''})
    rows.append(r)
P = pd.DataFrame(rows)
extra = pd.DataFrame([{'marker':'IL-33 (free / total; reduced / oxidised) and IL-33:ST2 complex','gene':'IL33','proposed_role':'Target engagement','status_caveat':'Absent from the delivered serum table; assay must be built - the critical gap','serum_assays':'not in delivered table'},
                      {'marker':'Interferon-response score / pathogen load','gene':'(gene set)','proposed_role':'Safety monitoring in infection','status_caveat':'IL-33 induces interferon-response genes in endothelium and AX-1177 removes the induction (Hallmark IFN-alpha NES +2.60 / -2.51)','serum_assays':'n/a'}])
P = pd.concat([P, extra], ignore_index=True)
integrity = pd.DataFrame([
 ('RNA-seq contrasts workbook','Two sheets ("6h", "24h") hold the same 629,040 rows (24 contrasts x 26,210 genes). Each sheet is auto-filtered to one contrast (Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs / _24hrs) and sorted by logFC; the other 23 contrasts are hidden rows.','In the visible 6 h view 3 of the top 7 genes (SELE, VCAM1, CXCL8) have adj.P 0.18-0.50','All 24 contrasts analysed'),
 ('RNA-seq model','One limma/voom model across 114 libraries and four cell lines (annex). Standard errors are unreliable for 377 genes (1.4%): median SE >5x expected for expression level or >20-fold range between contrasts. Enriched for lineage markers (11/27 endothelial, 8/11 MCF7, 10/14 A549 marker genes) and very abundant genes.','False negatives (SELE, VCAM1, CXCL8, CXCL1, CCL2, PTX3, IL1RL1...) and false positives (AKR1C2 t=169 for +0.11 log2)','Fold changes used; p-values of flagged genes not cited; replication across independent arms used instead; re-fit per cell line requested'),
 ('RNA-seq annotation','AveExpr is the mean over all 114 libraries, not per cell line','Expression filters are approximate for lineage-restricted genes','Noted'),
 ('RNA-seq HUVEC workbook','Sheet names say IL33_vs_Vehicle; Comparison column says IL33_vs_Nontreated','Comparator ambiguity (vehicle-treated vs untreated)','Treated as vehicle per annex'),
 ('RNA-seq design','No vehicle arm in HGMEC; IL-33-vs-baseline contrasts for HGMEC and isotype-vs-vehicle not delivered','IL-33 response in HGMEC inferred from reversal only','Derived contrasts computed where algebraically possible'),
 ('Serum workbook','Columns D-E (l95, u95) hidden; rows 4 and 16 (HGF-ONCII, IL6-ONCII) hidden','Confidence intervals and duplicate assays not visible on opening','All rows and columns analysed'),
 ('Serum multiplicity','adj.p.value reproduces Benjamini-Hochberg over 1,194 assays; 1,094 delivered. Missing assays are interleaved through the p-value ranking. Inflammation panel has 77 of 92 assays.','IL-33 (on the Inflammation panel, background knowledge) is not in the file; which assays were dropped and why is undocumented','Re-adjusted over 1,094 as a check (ST2 FDR 0.0068 vs 0.0075); originals reported'),
 ('Serum duplicates','27 analytes measured on 2-4 panels (58 rows) and tested separately','178 FDR<0.05 rows = 169 unique analytes; duplicates agree (z r = 0.99)','De-duplicated for enrichment tests'),
 ('Serum effect sizes','ORs are per log unit, not per SD','ORs not comparable between assays; narrow-range assays give OR 20-90 with very wide CIs (CSF-1, CTSS, SEMA4C...)','Ranked by Wald z / p'),
 ('Serum group sizes','composite_endpoint_0 / _1 columns are fractions with denominators 56 and 44','Implies 56 without and 44 with the endpoint (inferred, not stated)','Used as inferred'),
 ('Lung workbook','Columns D and L-Z hidden (all 15 histology/IHC score columns, including the three IL-33 columns)','Scores not visible on opening','All columns analysed'),
 ('Lung scale','Annex: 0-5 scale. IL-33 columns contain 5.5 (39 blocks endothelial, 16 epithelial) and quarter-point values; numeric columns equal N+0.5 for "N+" grades; one cell is a formula "=(2+4.5)/2"','Scores exceed the stated maximum; ordinal, saturated at the top','Rank-based and within-donor analyses; "N+" read as N for cell markers'),
 ('Lung replication','74 blocks from 31 donors; 3 COVID-positive donors contribute 24 of 49 COVID-positive blocks; donor-level fields only on first block','Treating blocks as independent inflates significance (e.g. endothelial IL-33 COVID+ vs COVID-: p = 0.017 by block, 0.05 by donor)','Donor is the unit of analysis'),
 ('Lung labels','4 of 10 "COVID neg pneumonia" donors have no pneumonia in the pathology text (1905, 1970, 1968, 1961); 3 of 5 "non-pneumonia" donors have pneumonia/pneumonitis/fungal infection (1976, 1956, 1944); donor 1905 has no SARS-CoV-2 result','Category labels are unreliable; no disease-free lung in the set','Sensitivity analyses on text-derived features'),
 ('Lung tissue RNA','"Tissue RNA" IDs (Zr4940_n) recorded for 22 donors','A lung-tissue RNA dataset appears to exist but was not delivered','Requested (Gate 0)'),
 ('Annex','Affinity, potency and binding data are "held in the programme biologics file"; count matrices and the fitted model are "retained in the programme archive"','Potency and re-fit not possible from this delivery','Requested'),
], columns=['file / topic','what was found','why it matters','how handled'])
path = '/tmp/outputs/tables/AX-1177_supporting_tables.xlsx'
with pd.ExcelWriter(path, engine='openpyxl', mode='a', if_sheet_exists='replace') as xw:
    P.to_excel(xw, sheet_name='Biomarker_panel', index=False)
    integrity.to_excel(xw, sheet_name='File_integrity', index=False)
wb = load_workbook(path)
# order sheets: README, Biomarker_panel first
order = ['README','Biomarker_panel','RNAseq_core_6h','RNAseq_core_24h','RNAseq_unreliable_SE','RNAseq_DEG_counts','AntibodyAlone_hits','Serum_all_annotated','Serum_themes','Lung_blocks_clean','Lung_donors','File_integrity']
wb._sheets = [wb[n] for n in order]
ws = wb['README']
ws.append(['Biomarker_panel','Proposed markers with in-vitro statistics (AX1177_reversal = Compound_47+IL33 vs IL33+IC119), serum statistics, proposed role and status'])
ws.append(['File_integrity','Findings about the delivered files (hidden rows/columns, model artefact, multiplicity, labels) and how each was handled'])
ws.append(['Definitions','log2FC: log2 fold change (1 = 2-fold). adjP / FDR: Benjamini-Hochberg adjusted p as delivered. AveExpr_all114: mean log2 expression across all 114 libraries (four cell lines). SE_unreliable_flag: standard error not trustworthy in the single-model fit - use fold change and cross-arm replication, not p.'])
for w in wb.worksheets:
    for c in w[1]:
        c.font = Font(bold=True); c.alignment = Alignment(wrap_text=True, vertical='top'); c.fill = PatternFill('solid', fgColor='DDDDDD')
    w.freeze_panes = 'A2'
    for idx, col in enumerate(w.columns, 1):
        mx = max((len(str(c.value)) if c.value is not None else 0) for c in col[:200])
        w.column_dimensions[get_column_letter(idx)].width = min(max(10, mx*0.9 if mx<40 else 45), 60)
for nm in ['README','File_integrity','Biomarker_panel']:
    for row in wb[nm].iter_rows(min_row=2):
        for c in row: c.alignment = Alignment(wrap_text=True, vertical='top')
wb.save(path)
print(P[['marker','IL33_HUVEC_6h_fold','AX1177_reversal_HUVEC_6h_log2FC','serum_OR','serum_FDR','proposed_role']].to_string())
