import pandas as pd, numpy as np, re
from scipy import stats
import statsmodels.formula.api as smf
import warnings; warnings.filterwarnings('ignore')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200); pd.set_option('display.max_columns', 40)
df = pd.read_pickle('lung_blocks.pkl')
df['cat'] = df.disease_category_d.map({'COVID neg pneumonia':'NegPneu','COVID pos pneumonia':'PosPneu','COVID neg non-pneumonia':'NegNonPneu'})
df = df.rename(columns={'2D7':'B2D7'})
il = ['IL33_epi','IL33_endo','IL33_vsmc']
cells = ['EPX','EDN','MBP','B2D7','NE','TRYP','IL5Ra_NEduplex','IL5Ra_TRYPduplex']
# 1) naive block-level spearman
print('Naive block-level Spearman (n blocks up to 74):')
rows=[]
for a in il:
    for b in cells+il:
        if a==b: continue
        x = df[[a,b]].dropna()
        r = stats.spearmanr(x[a], x[b])
        rows.append((a,b,len(x),r.statistic,r.pvalue))
print(pd.DataFrame(rows, columns=['il33','other','n','rho','p']).to_string(float_format=lambda x: f'{x:.3g}'))
# 2) within-donor (centered) correlation using donors with >=2 blocks
print()
print('Within-donor centred Pearson (donor means removed; donors with >=2 blocks):')
rows=[]
for a in il:
    for b in cells+il:
        if a==b: continue
        x = df[['sample_id',a,b]].dropna()
        x = x[x.groupby('sample_id')[a].transform('size')>=2]
        xa = x[a]-x.groupby('sample_id')[a].transform('mean'); xb = x[b]-x.groupby('sample_id')[b].transform('mean')
        nd = x.sample_id.nunique(); n = len(x)
        r = np.corrcoef(xa, xb)[0,1]
        dfree = n - nd - 1
        tt = r*np.sqrt(dfree/(1-r**2)); pp = 2*stats.t.sf(abs(tt), dfree)
        # donor-level sign: per-donor slope sign
        signs=[]
        for sid,g in x.groupby('sample_id'):
            if g[a].nunique()>1 and g[b].nunique()>1:
                signs.append(np.sign(np.polyfit(g[b], g[a], 1)[0]))
        signs = np.array(signs)
        rows.append((a,b,n,nd,r,pp,(signs>0).sum(),(signs<0).sum()))
print(pd.DataFrame(rows, columns=['il33','other','n_blocks','n_donors','r_within','p_within','donors_pos_slope','donors_neg_slope']).to_string(float_format=lambda x: f'{x:.3g}'))
# 3) mixed model: IL33 ~ NE + (1|donor)
print()
for a in il:
    for b in ['NE','EPX','TRYP']:
        x = df[['sample_id',a,b,'cat']].dropna()
        try:
            m = smf.mixedlm(f'{a} ~ {b}', x, groups=x['sample_id']).fit(reml=True)
            print(f'mixedlm {a} ~ {b} + (1|donor): beta={m.params[b]:.3f} se={m.bse[b]:.3f} p={m.pvalues[b]:.4f} n={len(x)}')
        except Exception as e:
            print(a,b,'ERR',e)
# 4) mixed model for COVID status with donor random effect and age
print()
x = df.copy(); x['covid'] = (x.cat=='PosPneu').astype(int); x['age'] = x.age_d.astype(float); x['female'] = (x.gender_d=='F').astype(int)
for a in il+['NE','EPX','EDN','MBP','TRYP']:
    y = x[['sample_id',a,'covid','age','female']].dropna()
    for f in [f'{a} ~ covid', f'{a} ~ covid + age + female']:
        try:
            m = smf.mixedlm(f, y, groups=y['sample_id']).fit(reml=True)
            print(f'mixedlm {f:40s}: covid beta={m.params["covid"]:.3f} se={m.bse["covid"]:.3f} p={m.pvalues["covid"]:.4f}' + (f' | age beta={m.params["age"]:.3f} p={m.pvalues["age"]:.4f}' if 'age' in m.params else ''))
        except Exception as e:
            print(a,'ERR',e)
# 5) donor-level OLS adjusting for age/sex
don = pd.read_pickle('lung_donors2.pkl'); don['covid'] = (don.cat=='PosPneu').astype(int); don['female']=(don.sex=='F').astype(int)
print()
for a in il:
    m = smf.ols(f'{a} ~ covid + age + female', don).fit()
    print(f'donor OLS {a}: covid beta={m.params["covid"]:.3f} p={m.pvalues["covid"]:.3f}; age beta={m.params["age"]:.3f} p={m.pvalues["age"]:.4f}; female beta={m.params["female"]:.3f} p={m.pvalues["female"]:.3f}; n={int(m.nobs)}')
print(don.groupby('cat')[['age']].describe())
print(stats.mannwhitneyu(don.loc[don.covid==1,'age'], don.loc[don.covid==0,'age']))
# ICC for IL33 scores
print()
for a in il+['NE','EPX','TRYP']:
    y = df[['sample_id',a]].dropna()
    m = smf.mixedlm(f'{a} ~ 1', y, groups=y['sample_id']).fit(reml=True)
    vb = float(m.cov_re.iloc[0,0]); vw = m.scale
    print(f'ICC {a}: between-donor var {vb:.3f}, within-donor var {vw:.3f}, ICC={vb/(vb+vw):.2f}')
