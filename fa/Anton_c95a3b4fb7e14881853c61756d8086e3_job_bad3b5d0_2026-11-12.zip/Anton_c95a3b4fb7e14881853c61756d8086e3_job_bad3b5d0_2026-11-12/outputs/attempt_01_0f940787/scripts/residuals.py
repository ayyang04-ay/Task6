import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
D = pd.read_parquet('derived.parquet'); fl = pd.read_parquet('se_flags.parquet')
sym = ann.symbol
# residual IL-33 effect under AX-1177: (C47+IL33) - Vehicle, approx SE = mean of SEs of the two component contrasts (each is a 3v3 contrast of similar precision)
for tp in ['6h','24h']:
    i = f'IL33_v_Veh_HUVEC_{tp}'; c = f'C47IL33_v_IL33_HUVEC_{tp}'; ci = f'C47IL33_v_IL33IC_HUVEC_{tp}'
    resid = lfc[i] + lfc[c]
    se_r = (se[i] + se[c])/2
    z = resid/se_r
    pz = 2*stats.t.sf(z.abs(), 85)
    ok = (~fl.flag)&(ann.AveExpr>-3)
    qz = pd.Series(np.nan, index=lfc.index); qz[ok] = multipletests(pz[ok], method='fdr_bh')[1]
    n_sig = ((qz<0.05)&(resid.abs()>=1)).sum()
    il = (q[i]<0.05)&(lfc[i].abs()>=1)&ok
    print(f'=== {tp}: genes with residual (C47+IL33 vs Veh) approx-FDR<0.05 & |lfc|>=1: {n_sig} (vs {il.sum()} IL33-responsive at same thresholds)')
    both = (qz<0.05)&(resid.abs()>=1)&il&(np.sign(resid)==np.sign(lfc[i]))
    print(f'    of the IL33-responsive genes, {both.sum()} retain a significant same-direction residual under AX-1177')
    tab = pd.DataFrame({'symbol':sym[both], 'Ave':ann.AveExpr[both].round(1), 'IL33':lfc.loc[both,i].round(2), 'C47_v_IL33':lfc.loc[both,c].round(2), 'C47_v_IL33IC':lfc.loc[both,ci].round(2), 'q_C47_v_IL33IC':q.loc[both,ci], 'resid':resid[both].round(2), 'z':z[both].round(1), 'q_resid':qz[both], 'pct_rev_vs_IL33IC':(-100*lfc.loc[both,ci]/lfc.loc[both,i]).round(0)})
    print(tab.sort_values('q_resid').head(45).to_string(float_format=lambda v: f'{v:.3g}'))
    # among antibody-alone: does C47 alone (vs IC119) shift these?
