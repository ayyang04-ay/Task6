import pandas as pd, numpy as np
pd.set_option('display.width', 320); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 60); pd.set_option('display.max_colwidth', 90)
f = pd.read_csv('fgsea_all.csv')
R = f[f.pathway.str.startswith('REACTOME')]
for rb in ['t','logFC']:
    P = R[R.rank_by==rb].pivot(index='pathway', columns='contrast', values='NES'); Q = R[R.rank_by==rb].pivot(index='pathway', columns='contrast', values='padj')
    cols = ['IL33_v_Veh_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HGMEC_6h','IL33_v_Veh_HUVEC_24h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_24h','C47_v_IC_HUVEC_6h','C47_v_IC_HUVEC_24h','C47_v_IC_HGMEC_6h','C47_v_IC_HGMEC_24h']
    for key in ['IL33_v_Veh_HUVEC_6h','IL33_v_Veh_HUVEC_24h']:
        top = P[key].sort_values(ascending=False).head(28).index.tolist() + P[key].sort_values().head(8).index.tolist()
        S = pd.DataFrame({c.replace('C47IL33_v_IL33IC','C47rev').replace('IL33_v_Veh','IL33').replace('C47_v_IC','C47alone'): [f'{P.loc[i,c]:+.2f}' + ('*' if Q.loc[i,c]<0.05 else ' ') for i in top] for c in cols}, index=[t.replace('REACTOME_','')[:70] for t in top])
        print(f'--- rank_by {rb}; top Reactome by {key}'); print(S.to_string())
