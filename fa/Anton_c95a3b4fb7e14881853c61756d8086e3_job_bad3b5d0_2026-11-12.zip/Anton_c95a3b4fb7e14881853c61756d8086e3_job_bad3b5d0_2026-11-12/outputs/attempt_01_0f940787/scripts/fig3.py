import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import stats
plt.rcParams.update({'font.size': 9, 'axes.titlesize': 9.5, 'axes.labelsize': 9})
df = pd.read_pickle('lung_blocks.pkl'); don = pd.read_pickle('lung_donors2.pkl')
df['cat'] = df.disease_category_d.map({'COVID neg pneumonia':'NegPneu','COVID pos pneumonia':'PosPneu','COVID neg non-pneumonia':'NegNonPneu'})
cats = ['NegNonPneu','NegPneu','PosPneu']; catlab = {'NegNonPneu':'COVID−\nnon-pneumonia\n(5 donors,\n10 blocks)','NegPneu':'COVID−\npneumonia\n(10 donors,\n15 blocks)','PosPneu':'COVID+\npneumonia\n(16 donors,\n49 blocks)'}
ccol = {'NegNonPneu':'#7f7f7f','NegPneu':'#1f77b4','PosPneu':'#d62728'}
fig, axes = plt.subplots(2, 3, figsize=(15, 10.5))
rs = np.random.RandomState(3)
def perm_p(x, a, b, B=5000, seed=11):
    rr = np.random.RandomState(seed)
    def wr(d):
        xa = d[a]-d.groupby('sample_id')[a].transform('mean'); xb = d[b]-d.groupby('sample_id')[b].transform('mean')
        return np.corrcoef(xa, xb)[0,1]
    obs = wr(x); n = 0
    groups = [g.index.values for _, g in x.groupby('sample_id')]
    vals = x[b].values.copy(); pos = {ix: k for k, ix in enumerate(x.index)}
    y = x.copy()
    for _ in range(B):
        v = vals.copy()
        for g in groups:
            idx = [pos[i] for i in g]; v[idx] = rr.permutation(vals[idx])
        y[b] = v
        if abs(wr(y)) >= abs(obs) - 1e-12: n += 1
    return (n+1)/(B+1)
for k,(m,title) in enumerate([('IL33_epi','IL-33, bronchial/bronchiolar basal epithelium'),('IL33_endo','IL-33, endothelium'),('IL33_vsmc','IL-33, vascular smooth muscle')]):
    ax = axes[0,k]
    for i,c in enumerate(cats):
        d = don[don['cat']==c]
        x = i + rs.uniform(-0.18,0.18,len(d))
        ax.scatter(x, d[m], s=16+9*d.n_blocks, c=ccol[c], alpha=0.75, edgecolors='k', linewidths=0.4)
        ax.plot([i-0.28,i+0.28],[d[m].median()]*2, c='k', lw=2)
    a = don.loc[don['cat']=='PosPneu', m].dropna(); b = don.loc[don['cat']!='PosPneu', m].dropna(); b2 = don.loc[don['cat']=='NegPneu', m].dropna()
    p1 = stats.mannwhitneyu(a,b).pvalue; p2 = stats.mannwhitneyu(a,b2).pvalue
    blk_a = df.loc[df['cat']=='PosPneu', m].dropna(); blk_b = df.loc[df['cat']!='PosPneu', m].dropna(); pb = stats.mannwhitneyu(blk_a, blk_b).pvalue
    ax.set_xticks(range(3)); ax.set_xticklabels([catlab[c] for c in cats], fontsize=7.5)
    ax.set_xlim(-0.6, 2.6); ax.set_ylim(-0.9, 6.3); ax.axhline(5, c='k', lw=0.5, ls=':')
    ax.text(2.58, 5.04, 'stated scale maximum = 5', fontsize=6, ha='right', va='bottom')
    ax.set_title(f'{"ABC"[k]}. {title}')
    ax.text(0.5, 0.02, f'Donor as unit: COVID+ vs all COVID− p={p1:.2f}; vs COVID− pneumonia p={p2:.2f}\nBlock as unit (pseudo-replicated): COVID+ vs COVID− p={pb:.3f}', transform=ax.transAxes, fontsize=7, va='bottom', ha='center', bbox=dict(fc='white', ec='#999999', lw=0.4))
    if k==0: ax.set_ylabel('donor mean IHC score (marker size ∝ number of blocks)')
    for sp in ['top','right']: ax.spines[sp].set_visible(False)
ax = axes[1,0]
x = df[['sample_id','IL33_endo','NE','cat']].dropna(); x = x[x.groupby('sample_id').IL33_endo.transform('size')>=2]
xa = x.NE - x.groupby('sample_id').NE.transform('mean'); ya = x.IL33_endo - x.groupby('sample_id').IL33_endo.transform('mean')
ax.scatter(xa + rs.uniform(-0.06,0.06,len(xa)), ya + rs.uniform(-0.04,0.04,len(ya)), s=24, c=[ccol[c] for c in x['cat']], alpha=0.7, edgecolors='k', linewidths=0.3)
b = np.polyfit(xa, ya, 1); xx = np.linspace(xa.min(), xa.max(), 10); ax.plot(xx, b[0]*xx+b[1], 'k-', lw=1.2)
r = np.corrcoef(xa, ya)[0,1]
pp = perm_p(x, 'IL33_endo', 'NE')
ax.axhline(0,c='k',lw=0.4); ax.axvline(0,c='k',lw=0.4)
ax.set_xlabel('neutrophil elastase score: block minus donor mean'); ax.set_ylabel('endothelial IL-33 score: block minus donor mean')
ax.set_title(f'D. Within a lung, blocks with more neutrophils show less IL-33\nwithin-donor r={r:.2f}, permutation p={pp:.2f} ({len(x)} blocks, {x.sample_id.nunique()} donors)')
for sp in ['top','right']: ax.spines[sp].set_visible(False)
ax = axes[1,1]
cells = [('NE','Neutrophil elastase'),('EPX','Eosinophil peroxidase'),('EDN','EDN (eosinophil)'),('MBP','MBP (eosinophil)'),('2D7','2D7 (basophil)'),('TRYP','Tryptase (mast cell)')]
res=[]
for comp in ['IL33_endo','IL33_epi']:
    for c,lab in cells:
        x = df[['sample_id',comp,c]].dropna(); x = x[x.groupby('sample_id')[comp].transform('size')>=2]
        xa = x[c]-x.groupby('sample_id')[c].transform('mean'); ya = x[comp]-x.groupby('sample_id')[comp].transform('mean')
        r = np.corrcoef(xa, ya)[0,1]; dfree = len(x)-x.sample_id.nunique()-1
        pp = perm_p(x, comp, c)
        res.append((comp, lab, r, np.sqrt((1-r**2)/dfree), pp))
R = pd.DataFrame(res, columns=['comp','lab','r','se','p'])
yy = np.arange(len(cells))[::-1]
for j,(comp,col,off,nm) in enumerate([('IL33_endo','#2ca02c',0.17,'endothelial IL-33'),('IL33_epi','#8c564b',-0.17,'epithelial IL-33')]):
    sub = R[R.comp==comp]
    ax.errorbar(sub.r, yy+off, xerr=1.96*sub.se, fmt='o', c=col, ms=5, lw=1.2, label=nm)
    for yi, (_, rr) in zip(yy, sub.iterrows()):
        ax.text(0.66, yi+off, f'p={rr.p:.2f}', fontsize=7, va='center', color=col)
ax.axvline(0, c='k', lw=0.5); ax.set_yticks(yy); ax.set_yticklabels([l for _,l in cells], fontsize=8)
ax.set_xlim(-0.9, 0.95); ax.set_xlabel('within-donor correlation with IL-33 score (±1.96 SE);\np from permuting scores among blocks within each donor')
ax.set_title('E. IL-33 staining tracks (inversely) with neutrophils,\nnot with eosinophil, basophil or mast-cell markers'); ax.legend(fontsize=7, loc='lower left')
for sp in ['top','right']: ax.spines[sp].set_visible(False)
ax = axes[1,2]
ms = [('NE','Neutrophil\nelastase'),('TRYP','Tryptase\n(mast cell)'),('EPX','EPX'),('EDN','EDN'),('MBP','MBP'),('2D7','2D7\n(basophil)')]
w = 0.26
for i,c in enumerate(cats):
    d = don[don['cat']==c]
    for j,(m,lab) in enumerate(ms):
        xpos = j + (i-1)*w
        ax.scatter(xpos + rs.uniform(-0.07,0.07,len(d)), d[m], s=13, c=ccol[c], alpha=0.6, edgecolors='none')
        ax.plot([xpos-0.11, xpos+0.11],[d[m].median()]*2, c='k', lw=1.8)
ax.set_xticks(range(len(ms))); ax.set_xticklabels([l for _,l in ms], fontsize=7.5)
ax.set_ylabel('donor mean IHC score (0–5)'); ax.set_ylim(-0.3, 6.2)
ax.legend(handles=[Line2D([0],[0], marker='o', color='w', markerfacecolor=ccol[c], markersize=6, label=catlab[c].split('\n(')[0].replace('\n',' ')) for c in cats], fontsize=7, loc='upper right')
ax.set_title('F. Infiltrate: neutrophils and mast cells > eosinophil markers;\nCOVID+ and COVID− pneumonia indistinguishable (all p ≥ 0.35)')
ax.text(3.0, 4.45, 'eosinophil markers', fontsize=7, ha='center'); ax.plot([1.6,4.4],[4.35,4.35], c='k', lw=0.6)
for sp in ['top','right']: ax.spines[sp].set_visible(False)
fig.tight_layout()
fig.savefig('/tmp/outputs/figures/Fig3_postmortem_lung.png', dpi=160)
