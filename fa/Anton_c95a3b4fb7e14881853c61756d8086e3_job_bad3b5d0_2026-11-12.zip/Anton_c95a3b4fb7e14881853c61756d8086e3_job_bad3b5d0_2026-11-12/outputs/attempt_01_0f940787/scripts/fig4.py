import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from plotutil import repel_labels
plt.rcParams.update({'font.size': 9, 'axes.titlesize': 10, 'axes.labelsize': 9})
s = pd.read_csv('serum_annot.csv'); fl = pd.read_parquet('se_flags.parquet')
s['se_log'] = (np.log(s.u95)-np.log(s.l95))/(2*1.959964); s['z'] = np.log(s.OR)/s.se_log
m = s[s.ens.notna()].copy()
m['flag'] = m.ens.map(fl.flag)
x = m.lfc_IL33_v_Veh_HUVEC_6h; y = m.z
rob = (m.q_IL33_v_Veh_HUVEC_6h<0.05)&(m.lfc_IL33_v_Veh_HUVEC_6h>=1)&(m.q_C47IL33_v_IL33IC_HUVEC_6h<0.05)&(m.lfc_C47IL33_v_IL33IC_HUVEC_6h<=-1)
unrel = m.flag & (m.lfc_IL33_v_Veh_HUVEC_6h>=1.5) & (m.lfc_C47IL33_v_IL33IC_HUVEC_6h<=-1.5) & ~rob
sig = m['adj.p.value']<0.05
fig, ax = plt.subplots(figsize=(11, 7.5))
oth = ~rob & ~unrel
ax.scatter(x[oth], y[oth], s=6, c='#cfcfcf', rasterized=True)
ax.scatter(x[rob&~sig], y[rob&~sig], s=26, facecolors='white', edgecolors='#1f77b4', linewidths=1.1)
ax.scatter(x[rob&sig], y[rob&sig], s=30, c='#1f77b4')
ax.scatter(x[unrel&~sig], y[unrel&~sig], s=30, facecolors='white', edgecolors='#e377c2', linewidths=1.3, marker='s')
ax.scatter(x[unrel&sig], y[unrel&sig], s=34, c='#e377c2', marker='s')
st = m.assay=='ST2'
ax.scatter(x[st], y[st], s=160, c='#d62728', marker='*', zorder=5)
zthr = m.loc[sig,'z'].abs().min()
ax.axhline(zthr, ls='--', c='k', lw=0.6); ax.text(11.4, zthr+0.05, 'FDR 5%', fontsize=7, ha='right')
ax.axhline(0, c='k', lw=0.4); ax.axvline(0, c='k', lw=0.4); ax.axvline(1, c='k', lw=0.4, ls=':')
pts=[]; cols=[]
lab = m[(unrel|st) | (rob & (sig | (m.lfc_IL33_v_Veh_HUVEC_6h>=4.2) | (m.assay.isin(['TF','uPA-INFI','IL15','PAI']))))].sort_values('z', ascending=False)
seen=set()
for _, r in lab.iterrows():
    if r.gene in seen: continue
    seen.add(r.gene)
    nm = r.assay.replace('-INFI','').replace('-CVDIII','').replace('-CVDII','').replace('-ONCII','').replace('-IMO','')
    pts.append((r.lfc_IL33_v_Veh_HUVEC_6h, r.z, nm)); cols.append('#d62728' if r.assay=='ST2' else ('#c2185b' if r.flag and r.assay!='ST2' and not (r.q_IL33_v_Veh_HUVEC_6h<0.05) else 'black'))
repel_labels(ax, pts, fontsize=7.5, colors=cols)
ax.set_xlabel('In vitro: IL-33red vs vehicle in HUVEC at 6 h (log2FC of the gene encoding the serum protein)\n(all highlighted genes are reversed by AX-1177)')
ax.set_ylabel('Clinic: Wald z for composite endpoint (serum at enrolment; adjusted for age, sex, NEWS2)')
ax.set_title('Which AX-1177-reversible endothelial IL-33 products also mark patients who deteriorate?\n13 of 64 measurable signature proteins reach FDR<0.05 vs 146 of 851 others (20% vs 17%, Fisher p=0.50): an overlap, not an enrichment')
ax.set_xlim(-3.2, 11.8)
handles = [Line2D([0],[0], marker='o', color='w', markerfacecolor='#1f77b4', markersize=7, label='IL-33-induced & AX-1177-reversed, robust statistics; filled = serum FDR<0.05'),
           Line2D([0],[0], marker='s', color='w', markerfacecolor='#e377c2', markersize=7, label='large replicated IL-33 effect, model statistics unreliable; filled = serum FDR<0.05'),
           Line2D([0],[0], marker='*', color='w', markerfacecolor='#d62728', markersize=12, label='ST2 (soluble IL-33 receptor)'),
           Line2D([0],[0], marker='o', color='w', markerfacecolor='#cfcfcf', markersize=6, label='other serum assays with a matching gene in the RNA-seq table')]
ax.legend(handles=handles, fontsize=7.5, loc='lower right')
for sp in ['top','right']: ax.spines[sp].set_visible(False)
fig.tight_layout(); fig.savefig('/tmp/outputs/figures/Fig4_triangulation.png', dpi=160)
print('robust n', rob.sum(), 'robust&sig', (rob&sig).sum(), 'unrel n', unrel.sum(), 'unrel&sig', (unrel&sig).sum())
print(m[rob&sig][['assay','gene','OR','adj.p.value','lfc_IL33_v_Veh_HUVEC_6h']].to_string())
print(m[unrel][['assay','gene','OR','adj.p.value','lfc_IL33_v_Veh_HUVEC_6h']].to_string())
