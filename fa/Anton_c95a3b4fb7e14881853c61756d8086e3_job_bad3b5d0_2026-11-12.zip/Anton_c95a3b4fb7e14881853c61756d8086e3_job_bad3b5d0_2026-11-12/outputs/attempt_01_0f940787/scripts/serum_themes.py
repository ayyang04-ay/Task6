import pandas as pd, numpy as np, re, sys
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
s = pd.read_csv('serum_rna_merged.csv')
themes = {
 'IL-33/ST2 & IL-1 family axis': ['ST2','IL-1RT1','IL-1RT2','IL-18R1','IL18-INFI','IL18-CVDII','IL-18BP','IL-1ra','IL1RL2','IL1B','IRAK1','IRAK4','RAGE','EN-RAGE','EGFR'],
 'Type-2 / eosinophil / mast cell': ['IL5-IMO','IL-5R-alpha','CCL11-INFI','CCL11-IMO','CCL17','CCL24','MCP-4','CCL18','IL-4RA','IL13RA1','FCER2','RNASE3','TPSAB1','HPGDS','IL17RB','CLEC10A','SIGLEC6','KIT','SCF-INFI','SCF-CVDII','SCF-ONCII','IL10-INFI','IL10-IMO'],
 'Neutrophil activation / granule': ['PRTN3','AZU1','MPO','CD177','LCN2','RETN','DEFA1','CEACAM8','PGLYRP1','OSM','HGF','HGF-ONCII','MMP-9','ARG1','FCAR','TREM1','CLEC5A','PI3','S100P','LILRA5','FCGR3B','G-CSF','IL8','CXCL1-INFI','CXCL1-CVDII','CXCL5','CXCL6','NCF2','S100A11','VSTM1','CLEC4D','SIRPB1','CHI3L1','CHIT1','ITGB2','SELL','GM-CSF-R-alpha','ANXA1','CD300E'],
 'Endothelial activation / injury / coagulation': ['SELE','SELP','vWF','VCAM1','ICAM1','ICAM-2','TM','ANGPT2','ANGPT1','TIE1','TIE2','ESM-1','PECAM-1','CDH5','EGFL7','CD93','t-PA','PAI','TFPI','TF','ADAM-TS13','PTX3','ADM','ENG','NOS3','LYVE1','FLT1','VEGFA-INFI','VEGFA-ONCII','VEGFR-2','VEGFR-3','PGF-CVDII','PGF-ODA','JAM-A','ESAM','PODXL','CLEC14A','ROBO1','LOX-1','GP1BA','GP6','CD40-L','PAR-1','PROC','F7','F11','PLC','SYND1','SDC4','NRP1','NRP2','EPHB4','SCARF1','CD300LG','TEK'],
 'Epithelial / lung injury': ['PSP-D','SFTPA1','SCGB3A2','KRT19','WFDC2','AGR2','MUC-16','TFF3','ITGB6','CEACAM5','Ep-CAM','AREG-ONCII','AREG-IMO','TGF-alpha-INFI','TGF-alpha-ONCII','PIgR','TACSTD2','MSLN','CDH1','KLK6'],
 'Kidney / cardiac / organ stress': ['KIM1-CVDII','KIM1-ODA','CST3','REN','NT-proBNP-CVDIII','NT-proBNP-MET','TNNI3','GDF-15','FABP4','MB','IGFBP-7','TFF3','AMBP','LCN2','PVALB'],
 'IFN / antiviral / lymphocyte': ['CXCL10','CXCL11','CXCL9','IFN-gamma','IFNL1','DDX58','LAMP3','SIGLEC1','BST2','TRIM21','TRIM5','IRF9','LAG3','GZMA','GZMB','GZMH','CD8A','CD4','IL7','IL7R','TRAIL-INFI','TRAIL-ONCII','FASLG','CRTAM','CD5','CD6','NCR1','KLRD1','PD-L1','IL-12B','IL12','TNFB','CD28','CD27'],
 'Myeloid cytokines / acute phase': ['IL6','IL6-ONCII','IL6-CVDII','IL6-IMO','TNF','MCP-1-INFI','MCP-1-CVDIII','MCP-3','MCP-2','CCL20','CCL3-INFI','CCL3-CVDII','CCL4','CSF-1','OPG-INFI','OPG-CVDIII','TNF-R1','TNF-R2','IL-6RA','LIF-R','OSMR','CX3CL1','CD163','IL-27','IL15','IL32','IL2-RA','TNFRSF9','CD40','U-PAR','IL-10RB','CASP-8','SAA4'],
}
allr = []
for th, names in themes.items():
    sub = s[s.assay.isin(names)].copy()
    missing = [n for n in names if n not in set(s.assay)]
    sub = sub.sort_values('p.value')
    print(f'===== {th}  (n assays {len(sub)}; FDR<0.05: {(sub["adj.p.value"]<0.05).sum()}; p<0.05: {(sub["p.value"]<0.05).sum()}; median OR {sub.OR.median():.2f})' + (f' | not in delivery: {missing}' if missing else ''))
    print(sub[['rank','panel_s','assay','OR','l95','u95','p.value','adj.p.value']].to_string(index=False, float_format=lambda x: f'{x:.3g}'))
    allr.append((th, len(sub), (sub['adj.p.value']<0.05).sum(), (sub['p.value']<0.05).sum(), sub.OR.median()))
print()
print(pd.DataFrame(allr, columns=['theme','n','n_FDR<0.05','n_p<0.05','median_OR']).to_string(index=False))
print('background: n=%d, FDR<0.05 %.1f%%, p<0.05 %.1f%%, median OR %.2f' % (len(s), 100*(s['adj.p.value']<0.05).mean(), 100*(s['p.value']<0.05).mean(), s.OR.median()))
