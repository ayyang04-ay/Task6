import pandas as pd, numpy as np, re, sys
sys.path.insert(0,'.')
from olink_map import OLINK2GENE
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
D = pd.read_parquet('derived.parquet')
s = pd.read_csv('serum_clean.csv')
def base(a): return re.sub(r'-(ONCII|CVDII|CVDIII|IMO|INFI|CRE|NEUI|NEX|ODA|MET)$','',a)
s['base'] = s.assay.map(base); s['gene'] = s.base.map(lambda b: OLINK2GENE.get(b, b))
sym2id = {}
for i, g in ann.symbol.items():
    # keep the highest-AveExpr id for duplicate symbols
    if g not in sym2id or ann.AveExpr[i] > ann.AveExpr[sym2id[g]]: sym2id[g] = i
s['ens'] = s.gene.map(sym2id)
cols = ['IL33_v_Veh_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HGMEC_6h','IL33_v_Veh_HUVEC_24h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_24h']
for c in cols:
    s['lfc_'+c] = s.ens.map(lfc[c]); s['q_'+c] = s.ens.map(q[c]); s['se_'+c] = s.ens.map(se[c])
s['AveExpr'] = s.ens.map(ann.AveExpr)
s.to_csv('serum_rna_merged.csv', index=False)
m = s[s.ens.notna()].copy()
print('serum assays mapped to RNA-seq genes:', len(m), '; unique genes', m.gene.nunique())
# IL-33-induced & reversed in HUVEC at 6h (robust: FDR<0.05 both, lfc>=1 & <=-1)
ind6 = (m['q_IL33_v_Veh_HUVEC_6h']<0.05)&(m['lfc_IL33_v_Veh_HUVEC_6h']>=1)&(m['q_C47IL33_v_IL33IC_HUVEC_6h']<0.05)&(m['lfc_C47IL33_v_IL33IC_HUVEC_6h']<=-1)
ind24 = (m['q_IL33_v_Veh_HUVEC_24h']<0.05)&(m['lfc_IL33_v_Veh_HUVEC_24h']>=1)&(m['q_C47IL33_v_IL33IC_HUVEC_24h']<0.05)&(m['lfc_C47IL33_v_IL33IC_HUVEC_24h']<=-1)
big6 = (m['lfc_IL33_v_Veh_HUVEC_6h']>=2)&(m['lfc_C47IL33_v_IL33IC_HUVEC_6h']<=-2)&~ind6   # large but not significant (SE artefact candidates)
m['class'] = np.where(ind6&ind24,'induced+reversed 6h&24h', np.where(ind6,'induced+reversed 6h', np.where(ind24,'induced+reversed 24h', np.where(big6,'large lfc, NOT significant (6h)','-'))))
show = m[m['class']!='-'].sort_values(['class','p.value'])
def f(x): return f'{x:.3g}'
out = show[['class','panel_s','assay','gene','OR','l95','u95','p.value','adj.p.value','AveExpr','lfc_IL33_v_Veh_HUVEC_6h','lfc_C47IL33_v_IL33IC_HUVEC_6h','se_C47IL33_v_IL33IC_HUVEC_6h','lfc_C47IL33_v_IL33IC_HGMEC_6h','q_C47IL33_v_IL33IC_HGMEC_6h','lfc_IL33_v_Veh_HUVEC_24h','lfc_C47IL33_v_IL33IC_HUVEC_24h','q_C47IL33_v_IL33IC_HUVEC_24h']]
out.columns = ['class','panel','assay','gene','OR','l95','u95','p','adjp','Ave','IL33_6h','C47_HU_6h','se','C47_HG_6h','q_HG6','IL33_24h','C47_HU_24h','q_HU24']
print(out.to_string(index=False, float_format=f))
# enrichment: are IL33-induced/reversed proteins enriched among outcome-associated serum proteins?
from scipy import stats
m['sig_serum'] = m['adj.p.value']<0.05
m['il33'] = ind6|ind24
ct = pd.crosstab(m.il33, m.sig_serum); print(ct); print('Fisher:', stats.fisher_exact(ct))
print('median OR il33-induced: %.2f vs others %.2f; MWU p=%.3g' % (m.loc[m.il33,'OR'].median(), m.loc[~m.il33,'OR'].median(), stats.mannwhitneyu(np.log(m.loc[m.il33,'OR']), np.log(m.loc[~m.il33,'OR'])).pvalue))
