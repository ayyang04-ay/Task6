import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
D = pd.read_parquet('derived.parquet'); fl = pd.read_parquet('se_flags.parquet')
sym = ann.symbol
def star(x): return '***' if x<0.001 else ('**' if x<0.01 else ('*' if x<0.05 else ''))
def table(idx):
    out = pd.DataFrame({'symbol':sym[idx], 'Ave':ann.AveExpr[idx].round(1), 'flag':fl.flag[idx].map({True:'!',False:''})})
    for tp in ['6h','24h']:
        out[f'IL33_{tp}'] = [f'{lfc.loc[g, f"IL33_v_Veh_HUVEC_{tp}"]:+.2f}' + star(q.loc[g, f"IL33_v_Veh_HUVEC_{tp}"]) for g in idx]
        out[f'C47_HU_{tp}'] = [f'{lfc.loc[g, f"C47IL33_v_IL33IC_HUVEC_{tp}"]:+.2f}' + star(q.loc[g, f"C47IL33_v_IL33IC_HUVEC_{tp}"]) for g in idx]
        out[f'resid_{tp}'] = D.loc[idx, f'resid_C47IL33_v_Veh_HUVEC_{tp}'].round(2)
        out[f'C47_HG_{tp}'] = [f'{lfc.loc[g, f"C47IL33_v_IL33IC_HGMEC_{tp}"]:+.2f}' + star(q.loc[g, f"C47IL33_v_IL33IC_HGMEC_{tp}"]) for g in idx]
    return out
a6 = 'IL33_v_Veh_HUVEC_6h'; a24='IL33_v_Veh_HUVEC_24h'
# 24h top induced
idx = lfc.index[(q[a24]<0.05)&(lfc[a24]>=1.5)&(ann.AveExpr>-3)]
idx = lfc.loc[idx, a24].sort_values(ascending=False).index
print('IL33-induced HUVEC 24h (FDR<0.05, lfc>=1.5, AveExpr>-3): n=', len(idx))
print(table(idx[:120]).to_string())
# down-regulated genes 6h & 24h
idx = lfc.index[(q[a6]<0.05)&(lfc[a6]<=-1.5)&(ann.AveExpr>0)]
idx = lfc.loc[idx, a6].sort_values().index
print('IL33-repressed HUVEC 6h (FDR<0.05, lfc<=-1.5, AveExpr>0): n=', len(idx))
print(table(idx[:50]).to_string())
idx = lfc.index[(q[a24]<0.05)&(lfc[a24]<=-1)&(ann.AveExpr>0)]
idx = lfc.loc[idx, a24].sort_values().index
print('IL33-repressed HUVEC 24h (FDR<0.05, lfc<=-1, AveExpr>0): n=', len(idx))
print(table(idx[:50]).to_string())
