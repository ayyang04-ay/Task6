import pandas as pd, numpy as np, time
from scipy import stats
t0=time.time()
F='/tmp/world/filesystem/'
# 1. serum
s = pd.read_excel(F+'AX-1177_serum_proteomics.xlsx')
print('serum shape', s.shape)
st = s[s.assay=='ST2'].iloc[0]; print('ST2:', round(st.OR,3), round(st.l95,3), round(st.u95,3), st['p.value'], st['adj.p.value'], 'rank', int(s['p.value'].rank()[s.assay=='ST2'].iloc[0]))
print('FDR<0.05:', (s['adj.p.value']<0.05).sum(), ' OR>1 among them:', ((s['adj.p.value']<0.05)&(s.OR>1)).sum(), ' OR>1 overall: %.1f%%' % (100*(s.OR>1).mean()))
print(s[s.assay.isin(['HGF','IL6','OPG-INFI','IL-18R1','CCL20','MCP-3','IL1B','PTX3','IL5-IMO','G-CSF','CXCL6','NT-proBNP-MET','TNNI3','SELE','vWF','TF'])][['assay','OR','l95','u95','p.value','adj.p.value']].round(4).to_string(index=False))
# 2. HUVEC file via pandas
h6 = pd.read_excel(F+'AX-1177_rnaseq_huvec_il33.xlsx', sheet_name=0); h24 = pd.read_excel(F+'AX-1177_rnaseq_huvec_il33.xlsx', sheet_name=1)
print('huvec', h6.shape, h24.shape, h6.Comparison.unique(), h24.Comparison.unique())
print('6h FDR<0.05', (h6['adj.P.Val']<0.05).sum(), '& |lfc|>=1', ((h6['adj.P.Val']<0.05)&(h6.logFC.abs()>=1)).sum(), '| 24h', (h24['adj.P.Val']<0.05).sum(), ((h24['adj.P.Val']<0.05)&(h24.logFC.abs()>=1)).sum())
# 3. contrasts via openpyxl read-only (independent of my XML parser)
import openpyxl
wb = openpyxl.load_workbook(F+'AX-1177_rnaseq_contrasts.xlsx', read_only=True)
ws = wb['6h']
rows = []
for k, r in enumerate(ws.iter_rows(values_only=True)):
    if k == 0: hdr = r[:11]; continue
    if r[0] is None: break
    rows.append(r[:11])
c = pd.DataFrame(rows, columns=hdr)
print('contrasts via openpyxl', c.shape, c.Comparison.nunique(), 'elapsed %.0fs' % (time.time()-t0))
par = pd.read_parquet('contrasts_6h.parquet')
print('same n rows:', len(c)==len(par), ' sum logFC diff:', abs(c.logFC.sum()-par.logFC.sum()), ' sum t diff:', abs(c.t.sum()-par.t.sum()), ' adjP<0.05 counts equal:', ((c['adj.P.Val']<0.05).sum()==(par['adj.P.Val']<0.05).sum()))
a = c[c.Comparison=='Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs'].set_index('ensembl'); b = h6.set_index('ensembl')
j = a.join(b, lsuffix='_rev', rsuffix='_il33', how='inner')
core = (j['adj.P.Val_il33']<0.05)&(j['adj.P.Val_rev']<0.05)&(j.logFC_il33.abs()>=1)&(j.logFC_rev.abs()>=1)&(np.sign(j.logFC_il33)!=np.sign(j.logFC_rev))
x = j.loc[core,'logFC_il33']; y = j.loc[core,'logFC_rev']
print('core6:', core.sum(), 'up', (core&(j.logFC_il33>0)).sum(), 'slope %.3f r %.3f' % ((x*y).sum()/(x*x).sum(), np.corrcoef(x,y)[0,1]))
hg = c[c.Comparison=='Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs'].set_index('ensembl')
jj = j.join(hg[['logFC','adj.P.Val']].rename(columns={'logFC':'lfc_hg','adj.P.Val':'q_hg'}))
print('HGMEC same-dir sig among core:', ((jj.q_hg<0.05)&(np.sign(jj.lfc_hg)==np.sign(jj.logFC_rev))&core).sum())
a24 = c[c.Comparison=='Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs'].set_index('ensembl'); b24 = h24.set_index('ensembl'); j24 = a24.join(b24, lsuffix='_rev', rsuffix='_il33')
core24 = (j24['adj.P.Val_il33']<0.05)&(j24['adj.P.Val_rev']<0.05)&(j24.logFC_il33.abs()>=1)&(j24.logFC_rev.abs()>=1)&(np.sign(j24.logFC_il33)!=np.sign(j24.logFC_rev))
x = j24.loc[core24,'logFC_il33']; y = j24.loc[core24,'logFC_rev']
print('core24:', core24.sum(), 'slope %.3f' % ((x*y).sum()/(x*x).sum()))
for comp in [k for k in c.Comparison.unique() if '_vs_IC119_' in k or '_vs_DMSO_' in k or '_vs_PBS_' in k]:
    g = c[c.Comparison==comp]
    cred = ((g['adj.P.Val']<0.05)&(g.logFC.abs()>=1)&(g.AveExpr>=3)).sum()
    print('  %-38s FDR<0.05: %3d ; credible: %d' % (comp, (g['adj.P.Val']<0.05).sum(), cred))
# 4. lung via pandas
L = pd.read_excel(F+'AX-1177_postmortem_lung.xlsx', header=0)
L = L.dropna(how='all')
L.columns = [str(x).strip() for x in L.columns]
L['donor'] = L['Sample ID'].astype(str)
cat = L.groupby('donor')['Disease Category'].first()
L['cat'] = L.donor.map(cat)
for col in ['IL-33, bronchial and bronchiolar basal epithelial cells','IL-33, endothelial cells','IL-33, vascular smooth muscle cells']:
    v = L[col].map(lambda x: (2+4.5)/2 if isinstance(x,str) and x.startswith('=') else x)
    L[col+'_n'] = pd.to_numeric(v, errors='coerce')
    d = L.groupby('donor').agg(cat=('cat','first'), v=(col+'_n','mean'))
    a_ = d.loc[d['cat']=='COVID pos pneumonia','v'].dropna(); b_ = d.loc[d['cat']!='COVID pos pneumonia','v'].dropna()
    print(col[:28], '| donors', len(d), '| donor median %.2f | COVID+ vs - MWU p=%.3f | blocks at 5.5: %d' % (d.v.median(), stats.mannwhitneyu(a_, b_).pvalue, (L[col+'_n']==5.5).sum()))
print('blocks', len(L), 'donors', L.donor.nunique(), cat.value_counts().to_dict())
print('total elapsed %.0fs' % (time.time()-t0))
