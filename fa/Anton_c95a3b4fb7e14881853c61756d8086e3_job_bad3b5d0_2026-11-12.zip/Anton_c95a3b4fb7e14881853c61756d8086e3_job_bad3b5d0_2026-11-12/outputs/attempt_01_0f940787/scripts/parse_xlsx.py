import sys, re, time
import xml.etree.ElementTree as ET
import pandas as pd, numpy as np

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'

def load_sst(path):
    out = []
    for ev, el in ET.iterparse(path, events=('end',)):
        if el.tag == NS+'si':
            out.append(''.join(t.text or '' for t in el.iter(NS+'t')))
            el.clear()
    return out

def col2idx(ref):
    m = re.match(r'([A-Z]+)(\d+)', ref)
    s = m.group(1); n = 0
    for ch in s: n = n*26 + (ord(ch)-64)
    return n-1, int(m.group(2))

def parse_sheet(path, sst, ncols=11):
    rows = []; hidden = []; rownum = []
    types = {}
    t0 = time.time()
    for ev, el in ET.iterparse(path, events=('end',)):
        if el.tag == NS+'row':
            cells = el.findall(NS+'c')
            if cells:
                vals = [None]*ncols
                for c in cells:
                    ci, ri = col2idx(c.get('r'))
                    t = c.get('t')
                    v = c.find(NS+'v')
                    f = c.find(NS+'f')
                    if f is not None:
                        types[('formula', ci)] = types.get(('formula', ci), 0)+1
                    if v is None:
                        is_ = c.find(NS+'is')
                        if is_ is not None:
                            val = ''.join(x.text or '' for x in is_.iter(NS+'t'))
                        else:
                            val = None
                    elif t == 's':
                        val = sst[int(v.text)]
                    elif t in ('str','e','b'):
                        val = v.text
                        types[(t, ci)] = types.get((t, ci), 0)+1
                    else:
                        val = float(v.text)
                    if ci < ncols: vals[ci] = val
                    else: types[('extra_col', ci)] = types.get(('extra_col', ci), 0)+1
                rows.append(vals); hidden.append(el.get('hidden') == '1'); rownum.append(int(el.get('r')))
            el.clear()
    print('parsed', path, len(rows), 'rows in', round(time.time()-t0,1), 's; odd types:', types, file=sys.stderr)
    return rows, hidden, rownum

if __name__ == '__main__':
    d = sys.argv[1]; out = sys.argv[2]
    sst = load_sst(f'{d}/xl/sharedStrings.xml')
    print('sst', len(sst), file=sys.stderr)
    import glob, os
    wbxml = open(f'{d}/xl/workbook.xml').read()
    names = re.findall(r'<sheet name="([^"]+)" sheetId="\d+" r:id="rId(\d+)"', wbxml)
    for name, rid in names:
        path = f'{d}/xl/worksheets/sheet{rid}.xml'
        rows, hidden, rownum = parse_sheet(path, sst)
        hdr = rows[0]
        df = pd.DataFrame(rows[1:], columns=hdr)
        df['xl_row'] = rownum[1:]
        df['xl_hidden'] = hidden[1:]
        df.to_parquet(f'{out}_{name}.parquet')
        print(name, df.shape, file=sys.stderr)
        print(df.head(3).to_string(), file=sys.stderr)
