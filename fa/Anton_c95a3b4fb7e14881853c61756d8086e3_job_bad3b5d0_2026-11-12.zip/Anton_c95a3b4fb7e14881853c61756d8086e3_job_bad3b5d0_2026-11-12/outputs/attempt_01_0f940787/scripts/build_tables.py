import pandas as pd, numpy as np, re, sys
from scipy import stats
sys.path.insert(0,'.')
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); q = pd.read_parquet('q.parquet'); p = pd.read_parquet('p.parquet'); t = pd.read_parquet('t.parquet'); se = pd.read_parquet('se.parquet').abs()
D = pd.read_parquet('derived.parquet'); fl = pd.read_parquet('se_flags.parquet')
s = pd.read_csv('serum_annot.csv'); s['se_log'] = (np.log(s.u95)-np.log(s.l95))/(2*1.959964); s['z'] = np.log(s.OR)/s.se_log
sym = ann.symbol
i6, i24 = 'IL33_v_Veh_HUVEC_6h','IL33_v_Veh_HUVEC_24h'
hu6, hu24, hg6, hg24 = 'C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_6h','C47IL33_v_IL33IC_HGMEC_24h'
best = s.sort_values('p.value').drop_duplicates('gene').set_index('gene')
nass = s.groupby('gene').size()
def gene_table(idx):
    o = pd.DataFrame({'ensembl':idx, 'symbol':sym[idx].values, 'AveExpr_all114':ann.AveExpr[idx].round(2).values, 'SE_unreliable_flag':fl.flag[idx].values})
    for nm,c in [('IL33_vs_veh_HUVEC_6h',i6),('AX1177rev_HUVEC_6h',hu6),('AX1177rev_HGMEC_6h',hg6),('IL33_vs_veh_HUVEC_24h',i24),('AX1177rev_HUVEC_24h',hu24),('AX1177rev_HGMEC_24h',hg24)]:
        o[nm+'_log2FC'] = lfc.loc[idx,c].round(3).values; o[nm+'_adjP'] = q.loc[idx,c].values
    o['AX1177rev_HUVEC_6h_vs_IL33alone_log2FC'] = lfc.loc[idx,'C47IL33_v_IL33_HUVEC_6h'].round(3).values
    o['residual_AX1177+IL33_vs_veh_HUVEC_6h_log2FC(derived)'] = D.loc[idx,'resid_C47IL33_v_Veh_HUVEC_6h'].round(3).values
    o['residual_AX1177+IL33_vs_veh_HUVEC_24h_log2FC(derived)'] = D.loc[idx,'resid_C47IL33_v_Veh_HUVEC_24h'].round(3).values
    o['AXalone_vs_isotype_HUVEC_6h_log2FC'] = lfc.loc[idx,'C47_v_IC_HUVEC_6h'].round(3).values
    o['serum_assay(best p)'] = o.symbol.map(lambda g: best.assay.get(g, '')); o['serum_n_assays'] = o.symbol.map(lambda g: nass.get(g, 0))
    o['serum_OR'] = o.symbol.map(lambda g: best.OR.get(g, np.nan)); o['serum_l95'] = o.symbol.map(lambda g: best.l95.get(g, np.nan)); o['serum_u95'] = o.symbol.map(lambda g: best.u95.get(g, np.nan))
    o['serum_p'] = o.symbol.map(lambda g: best['p.value'].get(g, np.nan)); o['serum_adjP'] = o.symbol.map(lambda g: best['adj.p.value'].get(g, np.nan))
    return o
core6 = (q[i6]<0.05)&(q[hu6]<0.05)&(lfc[i6].abs()>=1)&(lfc[hu6].abs()>=1)&(np.sign(lfc[i6])!=np.sign(lfc[hu6]))
core24 = (q[i24]<0.05)&(q[hu24]<0.05)&(lfc[i24].abs()>=1)&(lfc[hu24].abs()>=1)&(np.sign(lfc[i24])!=np.sign(lfc[hu24]))
T_core6 = gene_table(lfc.index[core6]).sort_values('IL33_vs_veh_HUVEC_6h_log2FC', ascending=False)
T_core6['also_sig_same_dir_HGMEC_6h'] = (T_core6.AX1177rev_HGMEC_6h_adjP<0.05)&(np.sign(T_core6.AX1177rev_HGMEC_6h_log2FC)==np.sign(T_core6.AX1177rev_HUVEC_6h_log2FC))
T_core6['in_24h_core'] = T_core6.ensembl.isin(lfc.index[core24])
T_core24 = gene_table(lfc.index[core24]).sort_values('IL33_vs_veh_HUVEC_24h_log2FC', ascending=False)
T_flag = gene_table(fl.index[fl.flag]); T_flag['median_SE_26contrasts'] = fl.se_med[T_flag.ensembl].values; T_flag['expected_SE'] = fl.exp_se[T_flag.ensembl].values; T_flag['SE_max_over_min'] = fl.ratio[T_flag.ensembl].values
T_flag['masked_large_IL33_effect'] = (T_flag.IL33_vs_veh_HUVEC_6h_log2FC.abs()>=1.5)&(T_flag.AX1177rev_HUVEC_6h_log2FC.abs()>=1.5)&(np.sign(T_flag.IL33_vs_veh_HUVEC_6h_log2FC)!=np.sign(T_flag.AX1177rev_HUVEC_6h_log2FC))
T_flag = T_flag.sort_values(['masked_large_IL33_effect','median_SE_26contrasts'], ascending=[False,False])
# antibody-alone hits
rows=[]
for c in [c for c in lfc.columns if c.startswith('C47_v_')]:
    sg = q.index[q[c]<0.05]
    for g in sg:
        l = lfc.loc[g,c]; a = ann.AveExpr[g]
        cls = 'tiny effect (|log2FC|<0.3)' if abs(l)<0.3 else ('low-count gene (AveExpr<1)' if a<1 else 'other (not replicated)')
        rows.append((c, g, sym[g], round(a,2), round(l,3), round(t.loc[g,c],2), round(se.loc[g,c],5), q.loc[g,c], bool(fl.flag[g]), cls))
T_alone = pd.DataFrame(rows, columns=['contrast','ensembl','symbol','AveExpr_all114','log2FC','t','SE','adjP','SE_unreliable_flag','classification'])
T_deg = pd.read_csv('deg_counts.csv')
# serum
S = s[['rank','panel_s','assay','gene','OR','l95','u95','z','p.value','adj.p.value','m0','m1','theme']].copy()
S = S.rename(columns={'panel_s':'panel (Olink Target 96)','rank':'rank_as_delivered','m0':'n_missing_no_endpoint(of 56)','m1':'n_missing_endpoint(of 44)','theme':'analyst_theme','gene':'gene_symbol_mapped'})
S['duplicate_analyte_across_panels'] = s.base.duplicated(keep=False).values
S['hidden_row_in_delivered_xlsx'] = s.assay.isin(['HGF-ONCII','IL6-ONCII']).values
S['gene_in_RNAseq_table'] = s.ens.notna().values
S['IL33_vs_veh_HUVEC_6h_log2FC'] = s.lfc_IL33_v_Veh_HUVEC_6h.round(3); S['IL33_vs_veh_HUVEC_6h_adjP'] = s.q_IL33_v_Veh_HUVEC_6h
S['AX1177rev_HUVEC_6h_log2FC'] = s.lfc_C47IL33_v_IL33IC_HUVEC_6h.round(3); S['AX1177rev_HUVEC_6h_adjP'] = s.q_C47IL33_v_IL33IC_HUVEC_6h
S['AX1177rev_HGMEC_6h_log2FC'] = s.lfc_C47IL33_v_IL33IC_HGMEC_6h.round(3); S['AX1177rev_HGMEC_6h_adjP'] = s.q_C47IL33_v_IL33IC_HGMEC_6h
S['IL33_signature_robust_6h'] = ((s.q_IL33_v_Veh_HUVEC_6h<0.05)&(s.lfc_IL33_v_Veh_HUVEC_6h>=1)&(s.q_C47IL33_v_IL33IC_HUVEC_6h<0.05)&(s.lfc_C47IL33_v_IL33IC_HUVEC_6h<=-1)).values
S['RNAseq_SE_unreliable_flag'] = s.ens.map(fl.flag)
from statsmodels.stats.multitest import multipletests
S['adjP_recomputed_over_1094_delivered'] = multipletests(s['p.value'], method='fdr_bh')[1]
# themes
rows=[]
for th in [x for x in s.theme.dropna().unique() if x!='']:
    a = s[s.theme==th]; b = s[s.theme!=th]
    ct = [[(a['adj.p.value']<0.05).sum(), (a['adj.p.value']>=0.05).sum()],[(b['adj.p.value']<0.05).sum(), (b['adj.p.value']>=0.05).sum()]]
    orr, pf = stats.fisher_exact(ct)
    rows.append((th, len(a), int((a['adj.p.value']<0.05).sum()), round(100*(a['adj.p.value']<0.05).mean(),1), int((a['p.value']<0.05).sum()), round(a.z.median(),2), round(a.OR.median(),2), round(orr,2), pf, '; '.join(a.sort_values('p.value').assay.head(8))))
rows.append(('ALL ASSAYS (background)', len(s), int((s['adj.p.value']<0.05).sum()), round(100*(s['adj.p.value']<0.05).mean(),1), int((s['p.value']<0.05).sum()), round(s.z.median(),2), round(s.OR.median(),2), np.nan, np.nan, ''))
T_themes = pd.DataFrame(rows, columns=['analyst_theme','n_assays','n_FDR<0.05','pct_FDR<0.05','n_p<0.05','median_z','median_OR','enrichment_OR_vs_rest','fisher_p','top_assays']).sort_values('median_z', ascending=False)
# lung
df = pd.read_pickle('lung_blocks.pkl'); don = pd.read_pickle('lung_donors2.pkl')
Lb = df[['xl_row','sample_id','block_id','tissue_rna','lobe','disease_category_d','gender_d','age_d','sars_cov2_d','notes_d','HE_eos','EPX','EDN','MBP','2D7','IL5Ra_NEduplex','NE','IL5Ra_TRYPduplex','TRYP','IL33_epi','IL33_endo','IL33_vsmc']].copy()
Lb.columns = ['xlsx_row','donor_id','block_id','tissue_RNA_id','lobe','disease_category(donor)','sex','age','SARS_CoV_2','approved_lung_conditions','HE_eosinophils_apparent','EPX','EDN','MBP','2D7','IL5Ra(NE duplex)','neutrophil_elastase','IL5Ra(tryptase duplex)','tryptase','IL33_basal_epithelium','IL33_endothelium','IL33_vascular_smooth_muscle']
Ld = don.drop(columns=['path']).reset_index().rename(columns={'sample_id':'donor_id','cat':'category'})
Ld['pathology_text'] = don['path'].values
with pd.ExcelWriter('/tmp/outputs/tables/AX-1177_supporting_tables.xlsx', engine='openpyxl') as xw:
    readme = pd.DataFrame({'sheet':['RNAseq_core_6h','RNAseq_core_24h','RNAseq_unreliable_SE','RNAseq_DEG_counts','AntibodyAlone_hits','Serum_all_annotated','Serum_themes','Lung_blocks_clean','Lung_donors'],
      'content':['515 genes IL-33-responsive (IL-33red vs vehicle, HUVEC 6 h) AND reversed by AX-1177 (AX-1177+IL-33 vs isotype+IL-33): both FDR<0.05, |log2FC|>=1, opposite sign. AX1177rev = Compound_47+IL33 vs IL33+IC119.',
                 '155 genes meeting the same definition at 24 h',
                 '377 genes whose standard errors are unreliable in the single 114-library model (median SE >5x expected for expression level, or SE varying >20-fold between contrasts). masked_large_IL33_effect = large, replicated IL-33 effect with uninformative p-values',
                 'Number of genes per contrast at successive filters',
                 'All 632 gene x contrast FDR<0.05 hits in the 16 antibody-alone contrasts, with classification',
                 'All 1,094 delivered serum assays with Wald z, gene mapping, analyst theme, duplicate/hidden flags and matching RNA-seq statistics',
                 'Summary of outcome association by analyst-curated protein theme',
                 'Post-mortem lung: 74 blocks, cleaned (N+ grades read as N; IL-33 columns as delivered, formula evaluated)',
                 'Post-mortem lung: 31 donors, donor means and text-derived pathology flags']})
    readme.to_excel(xw, 'README', index=False)
    T_core6.to_excel(xw, 'RNAseq_core_6h', index=False); T_core24.to_excel(xw, 'RNAseq_core_24h', index=False); T_flag.to_excel(xw, 'RNAseq_unreliable_SE', index=False)
    T_deg.to_excel(xw, 'RNAseq_DEG_counts', index=False); T_alone.to_excel(xw, 'AntibodyAlone_hits', index=False)
    S.to_excel(xw, 'Serum_all_annotated', index=False); T_themes.to_excel(xw, 'Serum_themes', index=False)
    Lb.to_excel(xw, 'Lung_blocks_clean', index=False); Ld.to_excel(xw, 'Lung_donors', index=False)
T_core6.to_csv('T_core6.csv', index=False); T_core24.to_csv('T_core24.csv', index=False); T_flag.to_csv('T_flag.csv', index=False); T_themes.to_csv('T_themes.csv', index=False)
print(len(T_core6), len(T_core24), len(T_flag), len(T_alone), len(S))
print(T_alone.classification.value_counts())
print(T_core6.also_sig_same_dir_HGMEC_6h.sum(), T_core6.in_24h_core.sum())
print(T_flag.masked_large_IL33_effect.sum())
print(T_themes.to_string())
