import pandas as pd, numpy as np, sys
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
D = pd.read_parquet('derived.parquet')
main = ['IL33_v_Veh_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33_HUVEC_6h','C47IL33_v_IL33IC_HGMEC_6h','C47IL33_v_IL33_HGMEC_6h','IL33_v_Veh_HUVEC_24h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_24h','C47IL33_v_IL33_HGMEC_24h','C47_v_IC_HUVEC_6h','C47_v_IC_HUVEC_24h','C47_v_IC_HGMEC_6h','C47_v_IC_HGMEC_24h']
def show(genes, cols=main, full=False):
    rows=[]
    for g in genes:
        ids = ann.index[ann.symbol==g]
        if len(ids)==0:
            print(g, 'ABSENT'); continue
        for i in ids:
            r = {'symbol':g, 'Ave':round(ann.AveExpr[i],1)}
            for c in cols:
                star = '***' if q.loc[i,c]<0.001 else ('**' if q.loc[i,c]<0.01 else ('*' if q.loc[i,c]<0.05 else ''))
                r[c.replace('C47IL33_v_','C47+33v').replace('IL33_v_Veh','IL33vVeh').replace('_HUVEC','_HU').replace('_HGMEC','_HG').replace('C47_v_IC','C47vIC')] = f'{lfc.loc[i,c]:+.2f}{star}' + (f' (se {se.loc[i,c]:.2g})' if full else '')
            rows.append(r)
    print(pd.DataFrame(rows).to_string(index=False))
if __name__ == '__main__':
    show(sys.argv[1].split(','), full=(len(sys.argv)>2))
