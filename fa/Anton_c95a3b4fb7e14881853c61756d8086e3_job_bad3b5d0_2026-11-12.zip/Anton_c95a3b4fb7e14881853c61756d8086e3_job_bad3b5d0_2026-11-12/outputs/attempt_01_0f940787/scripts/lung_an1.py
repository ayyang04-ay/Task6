import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200); pd.set_option('display.max_columns', 40)
df = pd.read_pickle('lung_blocks.pkl')
df['cat'] = df.disease_category_d.map({'COVID neg pneumonia':'NegPneu','COVID pos pneumonia':'PosPneu','COVID neg non-pneumonia':'NegNonPneu'})
markers = ['IL33_epi','IL33_endo','IL33_vsmc','EPX','EDN','MBP','2D7','IL5Ra_NEduplex','NE','IL5Ra_TRYPduplex','TRYP']
print('value counts of IL33 scores (blocks):')
for m in ['IL33_epi','IL33_endo','IL33_vsmc']:
    print(m, df[m].value_counts(dropna=False).sort_index().to_dict())
print()
print('BLOCK-level by category (naive):')
print(df.groupby('cat')[markers].agg(['mean','median','count']).T.to_string(float_format=lambda x: f'{x:.2f}'))
don = df.groupby('sample_id', sort=False).agg(cat=('cat','first'), n_blocks=('block_id','size'), age=('age_d','first'), sex=('gender_d','first'), notes=('notes_d','first'), **{m:(m,'mean') for m in markers}, **{m+'_max':(m,'max') for m in ['IL33_epi','IL33_endo','IL33_vsmc']}, **{m+'_min':(m,'min') for m in ['IL33_epi','IL33_endo','IL33_vsmc']})
don.to_pickle('lung_donors.pkl')
print()
print('DONOR-level means by category:')
print(don.groupby('cat')[markers].agg(['mean','median','min','max','count']).T.to_string(float_format=lambda x: f'{x:.2f}'))
print()
def tests(a, b, label):
    out = []
    for m in markers:
        x = a[m].dropna(); y = b[m].dropna()
        u = stats.mannwhitneyu(x, y, alternative='two-sided')
        out.append((m, len(x), len(y), x.median(), y.median(), x.mean(), y.mean(), u.pvalue))
    r = pd.DataFrame(out, columns=['marker','n_a','n_b','med_a','med_b','mean_a','mean_b','MWU_p'])
    print(label); print(r.to_string(float_format=lambda x: f'{x:.3g}'))
tests(don[don.cat=='PosPneu'], don[don.cat!='PosPneu'], 'DONOR-level: COVID+ (n=16) vs COVID- (n=15)')
tests(don[don.cat=='PosPneu'], don[don.cat=='NegPneu'], 'DONOR-level: COVID+ pneumonia vs COVID- pneumonia')
tests(don[don.cat!='NegNonPneu'], don[don.cat=='NegNonPneu'], 'DONOR-level: pneumonia (any) vs non-pneumonia')
tests(df[df.cat=='PosPneu'], df[df.cat!='PosPneu'], 'BLOCK-level (pseudo-replicated): COVID+ vs COVID-')
print()
print('Kruskal-Wallis donor-level across 3 categories:')
for m in markers:
    gs = [g[m].dropna().values for _,g in don.groupby('cat')]
    print(m, 'p=%.3g' % stats.kruskal(*gs).pvalue)
