import pandas as pd, numpy as np
pd.set_option('display.width', 320); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 60); pd.set_option('display.max_colwidth', 80)
f = pd.read_csv('fgsea_all.csv')
print(f.groupby(['contrast','rank_by']).apply(lambda g: (g.padj<0.05).sum()).unstack().to_string())
H = f[f.pathway.str.startswith('HALLMARK')]
for rb in ['t']:
    P = H[H.rank_by==rb].pivot(index='pathway', columns='contrast', values='NES')
    Q = H[H.rank_by==rb].pivot(index='pathway', columns='contrast', values='padj')
    cols = ['IL33_v_Veh_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HGMEC_6h','IL33_v_Veh_HUVEC_24h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_24h','C47_v_IC_HUVEC_6h','C47_v_IC_HUVEC_24h','C47_v_IC_HGMEC_6h','C47_v_IC_HGMEC_24h','C47_v_IC_A549_6h','C47_v_IC_A549_24h','C47_v_IC_MCF7_6h','C47_v_IC_MCF7_24h']
    S = P[cols].round(2).astype(str)
    for c in cols:
        S[c] = [f'{P.loc[i,c]:+.2f}' + ('*' if Q.loc[i,c]<0.05 else ' ') for i in P.index]
    S.index = S.index.str.replace('HALLMARK_','')
    S.columns = [c.replace('C47IL33_v_IL33IC','C47rev').replace('IL33_v_Veh','IL33').replace('C47_v_IC','C47alone') for c in cols]
    o = P['IL33_v_Veh_HUVEC_6h'].sort_values(ascending=False).index.str.replace('HALLMARK_','')
    print('rank_by', rb); print(S.loc[o].to_string())
