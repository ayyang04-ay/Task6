import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from plotutil import repel_labels
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); q = pd.read_parquet('q.parquet'); fl = pd.read_parquet('se_flags.parquet')
sym = ann.symbol
plt.rcParams.update({'font.size': 9, 'axes.titlesize': 10, 'axes.labelsize': 9})
fig, axes = plt.subplots(2, 2, figsize=(13.5, 12))
def scatter(ax, xcol, ycol, title, xl, yl, labels):
    x = lfc[xcol]; y = lfc[ycol]
    sig_any = (q[xcol]<0.05)|(q[ycol]<0.05)
    core = (q[xcol]<0.05)&(q[ycol]<0.05)&(x.abs()>=1)&(y.abs()>=1)&(np.sign(x)!=np.sign(y))
    other = sig_any & ~core & ~fl.flag
    ax.scatter(x[other], y[other], s=3, c='#c8c8c8', alpha=0.5, rasterized=True)
    ax.scatter(x[core], y[core], s=8, c='#1f77b4', alpha=0.8, rasterized=True)
    fm = fl.flag & ((x.abs()>=1.5)&(y.abs()>=1.5)&(np.sign(x)!=np.sign(y))) & ~core
    ax.scatter(x[fm], y[fm], s=28, facecolors='none', edgecolors='#d62728', linewidths=1.3)
    ax.plot([-14, 14], [14, -14], 'k--', lw=0.8)
    ax.axhline(0, c='k', lw=0.4); ax.axvline(0, c='k', lw=0.4)
    ax.set_xlim(-6, 13); ax.set_ylim(-13.5, 6)
    xs = x[core]; ys = y[core]
    slope = (xs*ys).sum()/(xs*xs).sum(); r = np.corrcoef(xs, ys)[0,1]
    ax.set_title(f'{title}\ncore genes n={core.sum()} ({(core&(x>0)).sum()} up, {(core&(x<0)).sum()} down); slope={slope:.2f}, r={r:.2f}')
    ax.set_xlabel(xl); ax.set_ylabel(yl)
    pts=[]; cols=[]
    for g in labels:
        ids = ann.index[sym==g]
        if len(ids)==0: continue
        i = ids[0]; pts.append((x[i], y[i], g)); cols.append('#d62728' if (fl.flag[i] and not core[i]) else 'black')
    repel_labels(ax, pts, fontsize=7, colors=cols)
    return core
labs6 = ['CSF2','SELE','CCL20','CXCL6','VCAM1','CX3CL1','CSF3','CXCL8','CXCL1','TNF','CXCL2','ICAM1','IL6','F3','TNFRSF11B','CCL2','IL18R1','IL1B','PTX3','IL1RL1','THBD']
scatter(axes[0,0], 'IL33_v_Veh_HUVEC_6h', 'C47IL33_v_IL33IC_HUVEC_6h', 'A. HUVEC, 6 h: AX-1177 reverses the IL-33 programme', 'IL-33red vs vehicle (log2FC)', 'AX-1177 + IL-33 vs isotype + IL-33 (log2FC)', labs6)
labs24 = ['CSF2','CXCL6','CSF3','CCL20','C3','KYNU','CXCL5','CXCL10','IL6','CXCL8','CXCL1','EBI3','PLA1A']
scatter(axes[0,1], 'IL33_v_Veh_HUVEC_24h', 'C47IL33_v_IL33IC_HUVEC_24h', 'B. HUVEC, 24 h: smaller programme, still reversed', 'IL-33red vs vehicle (log2FC)', 'AX-1177 + IL-33 vs isotype + IL-33 (log2FC)', labs24)
# C: HUVEC vs HGMEC reversal at 6h
ax = axes[1,0]
xc, yc = 'C47IL33_v_IL33IC_HUVEC_6h', 'C47IL33_v_IL33IC_HGMEC_6h'
x = lfc[xc]; y = lfc[yc]; il = lfc['IL33_v_Veh_HUVEC_6h']
core = (q['IL33_v_Veh_HUVEC_6h']<0.05)&(q[xc]<0.05)&(il.abs()>=1)&(x.abs()>=1)&(np.sign(il)!=np.sign(x))
sigHG = core & (q[yc]<0.05) & (np.sign(x)==np.sign(y))
ax.scatter(x[core&~sigHG], y[core&~sigHG], s=8, c='#b0b0b0', alpha=0.7, rasterized=True)
ax.scatter(x[sigHG], y[sigHG], s=8, c='#2ca02c', alpha=0.8, rasterized=True)
fm = fl.flag & (x.abs()>=1.5) & (il.abs()>=1.5) & (np.sign(il)!=np.sign(x)) & ~core
ax.scatter(x[fm], y[fm], s=28, facecolors='none', edgecolors='#d62728', linewidths=1.3)
ax.plot([-14,7],[-14,7],'k--',lw=0.8); ax.axhline(0,c='k',lw=0.4); ax.axvline(0,c='k',lw=0.4)
xs, ys = x[core], y[core]
ax.set_title(f'C. Glomerular microvascular EC (HGMEC), 6 h: same genes, ~half the magnitude\n{sigHG.sum()} of {core.sum()} core genes ({100*sigHG.sum()/core.sum():.0f}%) also FDR<0.05, same direction; slope={(xs*ys).sum()/(xs*xs).sum():.2f}, r={np.corrcoef(xs,ys)[0,1]:.2f}')
ax.set_xlabel('HUVEC: AX-1177 + IL-33 vs isotype + IL-33 (log2FC)'); ax.set_ylabel('HGMEC: AX-1177 + IL-33 vs isotype + IL-33 (log2FC)')
pts=[]; cols=[]
for g in ['CSF2','SELE','VCAM1','CCL20','CXCL6','CSF3','CXCL3','CXCL2','IL6','ICAM1','CXCL8','CXCL1','BIRC3','CD69','F3','CXCL5']:
    i = ann.index[sym==g][0]; pts.append((x[i], y[i], g)); cols.append('#d62728' if (fl.flag[i] and not core[i]) else 'black')
ax.set_xlim(-13.5, 6); ax.set_ylim(-13.5, 6)
repel_labels(ax, pts, fontsize=7, colors=cols)
print('panel C: core', core.sum(), 'sig same dir in HGMEC', sigHG.sum(), 'same sign', (np.sign(xs)==np.sign(ys)).mean())
# D: DEG counts
ax = axes[1,1]
d = pd.read_csv('deg_counts.csv').set_index('contrast')
order = ['IL33_v_Veh_HUVEC_6h','IL33_v_Veh_HUVEC_24h','C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_6h','C47IL33_v_IL33IC_HGMEC_24h',
         'C47_v_IC_HUVEC_6h','C47_v_IC_HUVEC_24h','C47_v_IC_HGMEC_6h','C47_v_IC_HGMEC_24h','C47_v_IC_A549_6h','C47_v_IC_A549_24h','C47_v_IC_MCF7_6h','C47_v_IC_MCF7_24h','C47_v_PBS_A549_6h','C47_v_PBS_A549_24h','C47_v_PBS_MCF7_6h','C47_v_PBS_MCF7_24h','C47_v_DMSO_A549_6h','C47_v_DMSO_A549_24h','C47_v_DMSO_MCF7_6h','C47_v_DMSO_MCF7_24h']
def nm(o):
    o2 = o.replace('IL33_v_Veh_','IL-33 vs vehicle | ').replace('C47IL33_v_IL33IC_','AX+IL-33 vs iso+IL-33 | ').replace('C47_v_IC_','AX alone vs isotype | ').replace('C47_v_PBS_','AX alone vs PBS | ').replace('C47_v_DMSO_','AX alone vs DMSO | ')
    return o2.replace('_',' ')
names = [nm(o) for o in order]
yy = np.arange(len(order))[::-1]
a = d.loc[order,'FDR<0.05'].values; b = d.loc[order,'&|lfc|>=1&Ave>=3'].values
ax.barh(yy+0.2, a, height=0.38, color='#c7c7c7', label='FDR<0.05 (as delivered)')
ax.barh(yy-0.2, b, height=0.38, color='#1f77b4', label='FDR<0.05 & |log2FC|≥1 & AveExpr≥3')
ax.set_xscale('symlog', linthresh=1); ax.set_xlim(0, 40000)
for yi, ai, bi in zip(yy, a, b):
    ax.text(ai*1.12+0.25, yi+0.2, str(ai), va='center', fontsize=6.5, color='#555555'); ax.text(bi*1.12+0.25, yi-0.2, str(bi), va='center', fontsize=6.5, color='#1f77b4')
ax.set_yticks(yy); ax.set_yticklabels(names, fontsize=7)
ax.axhline(yy[5]-0.5, color='k', lw=0.5, ls=':')
ax.set_xlabel('number of genes (symlog scale)'); ax.set_title('D. Antibody alone: 0 credible genes in 16/16 contrasts\n(the 14-73 raw "hits" are low-count or sub-0.3-log2 artefacts)')
ax.legend(fontsize=7, loc='lower right')
handles = [Line2D([0],[0], marker='o', color='w', markerfacecolor='#1f77b4', markersize=6, label='core: IL-33-responsive AND AX-1177-reversed (both FDR<0.05, |log2FC|≥1)'),
           Line2D([0],[0], marker='o', color='w', markerfacecolor='#c8c8c8', markersize=6, label='other genes FDR<0.05 in either contrast'),
           Line2D([0],[0], marker='o', color='w', markerfacecolor='none', markeredgecolor='#d62728', markersize=7, label='large effect replicated in independent arms, but model SE unreliable (Fig. 5)'),
           Line2D([0],[0], marker='o', color='w', markerfacecolor='#2ca02c', markersize=6, label='panel C: core gene also FDR<0.05 in HGMEC')]
fig.legend(handles=handles, loc='lower center', ncol=2, fontsize=8, frameon=False)
fig.tight_layout(rect=[0,0.045,1,1])
fig.savefig('/tmp/outputs/figures/Fig1_pharmacology_rnaseq.png', dpi=160)
print('saved')
