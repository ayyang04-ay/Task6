import pandas as pd, numpy as np
from scipy import stats
df = pd.read_pickle('lung_blocks.pkl')
rs = np.random.RandomState(11)
def within_r(x, a, b):
    xa = x[a]-x.groupby('sample_id')[a].transform('mean'); xb = x[b]-x.groupby('sample_id')[b].transform('mean')
    return np.corrcoef(xa, xb)[0,1]
for a in ['IL33_endo','IL33_epi','IL33_vsmc']:
    for b in ['NE','EPX','TRYP']:
        x = df[['sample_id',a,b]].dropna(); x = x[x.groupby('sample_id')[a].transform('size')>=2].copy()
        obs = within_r(x, a, b)
        n=0; B=5000
        for _ in range(B):
            y = x.copy(); y[b] = y.groupby('sample_id')[b].transform(lambda v: rs.permutation(v.values))
            if abs(within_r(y, a, b)) >= abs(obs)-1e-12: n+=1
        # also Spearman on within-donor ranks via leave-one-donor-out robustness
        loo = []
        for sid in x.sample_id.unique():
            loo.append(within_r(x[x.sample_id!=sid], a, b))
        print(f'{a} vs {b}: within-donor r={obs:.3f}; permutation p={(n+1)/(B+1):.4f}; leave-one-donor-out r range [{min(loo):.2f}, {max(loo):.2f}]')
