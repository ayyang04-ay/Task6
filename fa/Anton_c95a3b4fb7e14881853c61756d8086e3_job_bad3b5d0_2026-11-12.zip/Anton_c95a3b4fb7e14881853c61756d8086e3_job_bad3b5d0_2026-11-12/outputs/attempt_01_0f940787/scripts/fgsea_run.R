suppressMessages({library(fgsea); library(data.table)})
set.seed(1)
tw <- read.csv('t_wide.csv', check.names=FALSE, row.names=1)
lw <- read.csv('lfc_wide.csv', check.names=FALSE, row.names=1)
H <- fread('msig_H.csv'); R <- fread('msig_reactome.csv')
mk <- function(x) split(x$ensembl_gene, x$gs_name)
sets <- c(mk(H), mk(R))
contrasts <- setdiff(colnames(tw), c('symbol','AveExpr','flag'))
res <- list()
for (c in contrasts) {
  # t-based ranking, all genes with AveExpr > 0 (reduce low-count noise); exclude SE-flagged genes? keep but note
  keep <- tw$AveExpr > 0
  st <- tw[keep, c]; names(st) <- rownames(tw)[keep]
  st <- st[is.finite(st)]
  fg <- fgseaMultilevel(sets, sort(st, decreasing=TRUE), minSize=15, maxSize=500, eps=0, nPermSimple=10000)
  fg$contrast <- c; fg$rank_by <- 't'
  res[[paste0(c,'_t')]] <- fg[, .(contrast, rank_by, pathway, size, NES, pval, padj)]
  sl <- lw[keep, c]; names(sl) <- rownames(lw)[keep]
  fg2 <- fgseaMultilevel(sets, sort(sl, decreasing=TRUE), minSize=15, maxSize=500, eps=0, nPermSimple=10000)
  fg2$contrast <- c; fg2$rank_by <- 'logFC'
  res[[paste0(c,'_l')]] <- fg2[, .(contrast, rank_by, pathway, size, NES, pval, padj)]
  cat(c, 'done\n')
}
out <- rbindlist(res)
fwrite(out, 'fgsea_all.csv')
