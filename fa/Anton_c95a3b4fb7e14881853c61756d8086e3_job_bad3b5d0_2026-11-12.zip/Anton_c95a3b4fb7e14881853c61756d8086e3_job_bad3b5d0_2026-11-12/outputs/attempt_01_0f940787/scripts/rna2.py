import pandas as pd, numpy as np, itertools
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
sym = ann.symbol
alone = [c for c in lfc.columns if c.startswith('C47_v_')]
sig = {c: set(q.index[q[c]<0.05]) for c in alone}
M = pd.DataFrame(index=alone, columns=alone, dtype=float)
for a in alone:
    for b in alone:
        M.loc[a,b] = len(sig[a]&sig[b])
print('Overlap of FDR<0.05 gene sets among antibody-alone contrasts:')
print(M.astype(int).to_string())
allsig = set().union(*sig.values())
print('union of antibody-alone sig genes:', len(allsig))
cnt = pd.Series({g: sum(g in s for s in sig.values()) for g in allsig}).sort_values(ascending=False)
top = cnt[cnt>=2]
out = pd.DataFrame({'symbol':sym[top.index], 'AveExpr':ann.AveExpr[top.index], 'n_contrasts':top})
for c in alone:
    out[c.replace('C47_v_','')] = [f'{lfc.loc[g,c]:+.2f}' + ('*' if q.loc[g,c]<0.05 else '') for g in top.index]
print(out.to_string())
# characterize antibody-alone sig genes
rows=[]
for c in alone:
    s = q[c]<0.05
    rows.append((c, s.sum(), (ann.AveExpr[s]<0).sum(), ((lfc.loc[s,c].abs()<0.3)).sum(), ((lfc.loc[s,c].abs()>=2)&(ann.AveExpr[s]<1)).sum(), (s&(lfc[c].abs()>=1)&(ann.AveExpr>=3)).sum(), (s&(lfc[c].abs().between(0.3,1))).sum()))
print(pd.DataFrame(rows, columns=['contrast','n_sig','AveExpr<0','|lfc|<0.3 (tiny)','|lfc|>=2 & AveExpr<1 (low-count)','|lfc|>=1 & AveExpr>=3 (credible)','0.3<=|lfc|<1']).to_string())
