import pandas as pd, numpy as np, itertools
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
sym = ann.symbol
# derived contrasts (HUVEC)
D = pd.DataFrame(index=lfc.index)
for tp in ['6h','24h']:
    D[f'resid_C47IL33_v_Veh_HUVEC_{tp}'] = lfc[f'IL33_v_Veh_HUVEC_{tp}'] + lfc[f'C47IL33_v_IL33_HUVEC_{tp}']
    D[f'IL33IC_v_Veh_HUVEC_{tp}'] = lfc[f'IL33_v_Veh_HUVEC_{tp}'] + lfc[f'C47IL33_v_IL33_HUVEC_{tp}'] - lfc[f'C47IL33_v_IL33IC_HUVEC_{tp}']
    for cl in ['HUVEC','HGMEC']:
        D[f'IL33IC_v_IL33_{cl}_{tp}'] = lfc[f'C47IL33_v_IL33_{cl}_{tp}'] - lfc[f'C47IL33_v_IL33IC_{cl}_{tp}']
for cl in ['A549','MCF7']:
    for tp in ['6h','24h']:
        D[f'IC_v_PBS_{cl}_{tp}'] = lfc[f'C47_v_PBS_{cl}_{tp}'] - lfc[f'C47_v_IC_{cl}_{tp}']
        D[f'DMSO_v_PBS_{cl}_{tp}'] = lfc[f'C47_v_PBS_{cl}_{tp}'] - lfc[f'C47_v_DMSO_{cl}_{tp}']
        D[f'IC_v_DMSO_{cl}_{tp}'] = lfc[f'C47_v_DMSO_{cl}_{tp}'] - lfc[f'C47_v_IC_{cl}_{tp}']
D.to_parquet('derived.parquet')
# Reversal analysis
for tp in ['6h','24h']:
    a = f'IL33_v_Veh_HUVEC_{tp}'; b = f'C47IL33_v_IL33IC_HUVEC_{tp}'; b2 = f'C47IL33_v_IL33_HUVEC_{tp}'
    s = (q[a]<0.05)&(lfc[a].abs()>=1)
    x = lfc.loc[s,a]; y = lfc.loc[s,b]; y2 = lfc.loc[s,b2]
    print(f'--- HUVEC {tp}: IL33-responsive genes (FDR<0.05, |lfc|>=1): n={s.sum()}')
    print('  corr(IL33 effect, C47 effect vs IL33+IC119): pearson %.3f spearman %.3f; slope (OLS through origin) %.3f' % (np.corrcoef(x,y)[0,1], stats.spearmanr(x,y).statistic, (x*y).sum()/(x*x).sum()))
    print('  corr(IL33 effect, C47 effect vs IL33 alone): pearson %.3f; slope %.3f' % (np.corrcoef(x,y2)[0,1], (x*y2).sum()/(x*x).sum()))
    rev = -y/x
    print('  fraction reversed (per gene, -C47/IL33): median %.2f, IQR %.2f-%.2f; pct genes with >=80%% reversal: %.1f%%; >=50%%: %.1f%%' % (rev.median(), rev.quantile(.25), rev.quantile(.75), 100*(rev>=0.8).mean(), 100*(rev>=0.5).mean()))
    res = D.loc[s, f'resid_C47IL33_v_Veh_HUVEC_{tp}']
    print('  residual (C47+IL33 vs Veh, derived): median |resid| %.2f vs median |IL33 lfc| %.2f; n with |resid|>=1: %d (%.1f%%)' % (res.abs().median(), x.abs().median(), (res.abs()>=1).sum(), 100*(res.abs()>=1).mean()))
    # restrict to robust genes: AveExpr>=1 or strongly significant
    s2 = s & (q[a]<1e-6)
    x = lfc.loc[s2,a]; y = lfc.loc[s2,b]; res = D.loc[s2, f'resid_C47IL33_v_Veh_HUVEC_{tp}']
    print(f'  strongly significant subset (FDR<1e-6): n={s2.sum()}; slope %.3f; corr %.3f; median frac reversed %.2f; n |resid|>=1: %d' % ((x*y).sum()/(x*x).sum(), np.corrcoef(x,y)[0,1], (-y/x).median(), (res.abs()>=1).sum()))
    # isotype effect: IL33+IC119 vs IL33
    iso = D[f'IL33IC_v_IL33_HUVEC_{tp}']
    print('  isotype (IL33+IC119 vs IL33) derived logFC among IL33-responsive genes: median %.3f, sd %.3f, corr with IL33 effect %.3f, slope %.3f' % (iso[s].median(), iso[s].std(), np.corrcoef(lfc.loc[s,a], iso[s])[0,1], (lfc.loc[s,a]*iso[s]).sum()/(lfc.loc[s,a]**2).sum()))
