# Sensitivity of the reversal slope to the definition of the IL-33 programme
import pandas as pd, numpy as np
lfc = pd.read_parquet('lfc.parquet'); q = pd.read_parquet('q.parquet'); ann = pd.read_parquet('ann.parquet')
for tp in ['6h','24h']:
    i=f'IL33_v_Veh_HUVEC_{tp}'; c=f'C47IL33_v_IL33IC_HUVEC_{tp}'
    for fdr in [0.05, 0.01, 0.001]:
        for thr in [0.585, 1, 2]:
            core = (q[i]<fdr)&(q[c]<fdr)&(lfc[i].abs()>=thr)&(lfc[c].abs()>=thr)&(np.sign(lfc[i])!=np.sign(lfc[c]))
            x = lfc.loc[core,i]; y = lfc.loc[core,c]
            sel = (q[i]<fdr)&(lfc[i].abs()>=thr)&(ann.AveExpr>0); xs = lfc.loc[sel,i]; ys = lfc.loc[sel,c]
            print(f'{tp} FDR<{fdr} |lfc|>={thr}: core n={core.sum():4d} slope {(x*y).sum()/(x*x).sum():+.2f} r {np.corrcoef(x,y)[0,1]:+.2f} | IL33-only selection n={sel.sum():4d} slope {(xs*ys).sum()/(xs*xs).sum():+.2f}')
