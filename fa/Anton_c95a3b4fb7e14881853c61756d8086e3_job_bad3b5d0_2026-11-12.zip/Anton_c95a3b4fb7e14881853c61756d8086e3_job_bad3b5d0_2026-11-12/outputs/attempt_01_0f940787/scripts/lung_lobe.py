import pandas as pd, numpy as np, re
from scipy import stats
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
df = pd.read_pickle('lung_blocks.pkl')
def lobe_class(s):
    s = str(s).upper().replace(' ','')
    if s.startswith('NOT'): return np.nan
    if 'UL' in s: return 'upper'
    if 'LL' in s: return 'lower'
    return np.nan
df['lobe_c'] = df.lobe.map(lobe_class)
print(df.lobe_c.value_counts(dropna=False))
m = ['IL33_epi','IL33_endo','IL33_vsmc','NE','EPX','TRYP']
g = df.dropna(subset=['lobe_c']).groupby(['sample_id','lobe_c'])[m].mean().unstack()
g = g.dropna(subset=[('IL33_endo','upper'),('IL33_endo','lower')])
print('donors with both upper and lower lobe blocks:', len(g))
for k in m:
    d = (g[(k,'lower')]-g[(k,'upper')]).dropna()
    w = stats.wilcoxon(d) if (d!=0).sum()>0 else None
    print(f'{k}: lower-upper mean diff {d.mean():+.2f} (n={len(d)}; lower<upper in {(d<0).sum()}, >: {(d>0).sum()}, =: {(d==0).sum()}); Wilcoxon p={w.pvalue:.3f}' if w else k)
