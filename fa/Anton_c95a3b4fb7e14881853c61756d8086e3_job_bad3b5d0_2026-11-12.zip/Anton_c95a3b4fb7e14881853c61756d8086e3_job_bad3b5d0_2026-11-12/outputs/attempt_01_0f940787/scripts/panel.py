import pandas as pd, numpy as np, re, sys
sys.path.insert(0,'.')
from olink_map import OLINK2GENE
pd.set_option('display.width', 330); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 50)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
D = pd.read_parquet('derived.parquet'); fl = pd.read_parquet('se_flags.parquet')
sym = ann.symbol
i6, i24 = 'IL33_v_Veh_HUVEC_6h','IL33_v_Veh_HUVEC_24h'
hu6, hu24, hg6, hg24 = 'C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_6h','C47IL33_v_IL33IC_HGMEC_24h'
hu6b, hu24b, hg6b, hg24b = [c.replace('IL33IC','IL33') for c in (hu6,hu24,hg6,hg24)]
def rev(c, thr=1): return (q[c]<0.05)&(lfc[c]<=-thr)
def ind(c, thr=1): return (q[c]<0.05)&(lfc[c]>=thr)
A = ind(i6)&rev(hu6)&rev(hu6b)            # HUVEC 6h induced & reversed vs both comparators
B = ind(i24)&rev(hu24)&rev(hu24b)         # HUVEC 24h
C = rev(hg6)&rev(hg6b)                    # HGMEC 6h reversed vs both comparators
Dd = rev(hg24)&rev(hg24b)                 # HGMEC 24h
print('HUVEC6h', A.sum(), 'HUVEC24h', B.sum(), 'HGMEC6h', C.sum(), 'HGMEC24h', Dd.sum())
print('A&C (both cell types at 6h):', (A&C).sum(), '| A&B (HUVEC both timepoints):', (A&B).sum(), '| A&B&C:', (A&B&C).sum(), '| all four:', (A&B&C&Dd).sum())
s = pd.read_csv('serum_rna_merged.csv')
best = s.sort_values('p.value').drop_duplicates('gene').set_index('gene')
def tab(mask):
    idx = lfc.index[mask]
    o = pd.DataFrame({'symbol':sym[idx], 'Ave':ann.AveExpr[idx].round(1), 'IL33_6h':lfc.loc[idx,i6].round(2), 'C47_HU6':lfc.loc[idx,hu6].round(2), 'C47_HG6':lfc.loc[idx,hg6].round(2), 'IL33_24h':lfc.loc[idx,i24].round(2), 'C47_HU24':lfc.loc[idx,hu24].round(2), 'C47_HG24':lfc.loc[idx,hg24].round(2)})
    o['serum_assay'] = o.symbol.map(lambda g: best.assay.get(g, ''))
    o['serum_OR'] = o.symbol.map(lambda g: best.OR.get(g, np.nan))
    o['serum_p'] = o.symbol.map(lambda g: best['p.value'].get(g, np.nan))
    o['serum_adjp'] = o.symbol.map(lambda g: best['adj.p.value'].get(g, np.nan))
    return o
t4 = tab(A&B&C&Dd).sort_values('IL33_6h', ascending=False)
print('=== significant in ALL FOUR endothelial conditions (induced in HUVEC 6h&24h; reversed in HUVEC 6h/24h and HGMEC 6h/24h vs both comparators) n=', len(t4)); print(t4.to_string(float_format=lambda v: f'{v:.3g}'))
t3 = tab(A&B&C&~Dd).sort_values('IL33_6h', ascending=False)
print('=== HUVEC 6h+24h and HGMEC 6h (not HGMEC 24h) n=', len(t3)); print(t3.to_string(float_format=lambda v: f'{v:.3g}'))
t2 = tab(A&C&~B).sort_values('IL33_6h', ascending=False)
print('=== both cell types at 6h only (transient) n=', len(t2)); print(t2.head(80).to_string(float_format=lambda v: f'{v:.3g}'))
pd.concat([t4.assign(tier='all4'), t3.assign(tier='HU6+HU24+HG6'), t2.assign(tier='6h both cell types'), tab(A&~C).assign(tier='HUVEC 6h only')]).to_csv('panel_candidates.csv')
