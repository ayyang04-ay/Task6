# Post-mortem lung: extra checks (COPD history, IL-5Ra vs neutrophil/eosinophil markers, eosinophils on H&E, DAD)
import pandas as pd, numpy as np
from scipy import stats
df = pd.read_pickle('lung_blocks.pkl'); don = pd.read_pickle('lung_donors2.pkl')
for f in ['copd_note','copd_or_emph','emphysema_path','DAD']:
    for m in ['IL33_epi','IL33_endo','IL33_vsmc']:
        a = don.loc[don[f], m].dropna(); b = don.loc[~don[f], m].dropna()
        print(f'{f:15s} {m:10s} n={len(a)} vs {len(b)}: mean {a.mean():.2f} vs {b.mean():.2f}; MWU p={stats.mannwhitneyu(a,b).pvalue:.3f}')
print(pd.crosstab(don['cat'], don.DAD)); print('DAD COVID+ vs COVID-: Fisher p =', stats.fisher_exact([[7,9],[0,15]])[1])
d = df.groupby('sample_id')[['IL5Ra_NEduplex','NE','EPX','EDN','MBP','TRYP']].mean()
for b in ['NE','EPX','EDN','MBP']:
    r = stats.spearmanr(d.IL5Ra_NEduplex, d[b]); print(f'IL-5Ra (NE duplex) vs {b}: donor-level rho={r.statistic:.2f} p={r.pvalue:.2g}')
print('NE > EPX in', (d.NE>d.EPX).sum(), 'of', len(d), 'donors')
