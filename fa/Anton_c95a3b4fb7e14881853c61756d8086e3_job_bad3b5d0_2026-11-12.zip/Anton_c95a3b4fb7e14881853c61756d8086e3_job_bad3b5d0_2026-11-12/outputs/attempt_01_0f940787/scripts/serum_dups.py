import pandas as pd, numpy as np, re
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
s = pd.read_csv('serum_rna_merged.csv')
s['z'] = np.log(s.OR)/((np.log(s.u95)-np.log(s.l95))/(2*1.959964))
s['se_log'] = (np.log(s.u95)-np.log(s.l95))/(2*1.959964)
d = s[s.base.duplicated(keep=False)].sort_values(['base','p.value'])
print(d[['base','panel_s','assay','rank','OR','l95','u95','z','p.value','adj.p.value','m0','m1']].to_string(index=False, float_format=lambda v: f'{v:.3g}'))
# concordance
pairs = []
for b,g in d.groupby('base'):
    g = g.sort_values('p.value')
    for i in range(len(g)):
        for j in range(i+1,len(g)):
            pairs.append((b, g.iloc[i].z, g.iloc[j].z, np.log(g.iloc[i].OR), np.log(g.iloc[j].OR)))
pp = pd.DataFrame(pairs, columns=['base','z1','z2','l1','l2'])
print('n pairs', len(pp), ' corr z:', np.corrcoef(pp.z1,pp.z2)[0,1], ' corr logOR:', np.corrcoef(pp.l1,pp.l2)[0,1], ' sign agreement:', (np.sign(pp.z1)==np.sign(pp.z2)).mean())
# unique analytes and de-duplicated hit counts
best = s.sort_values('p.value').drop_duplicates('base')
print('unique analytes:', s.base.nunique(), '; rows', len(s))
print('rows FDR<0.05:', (s['adj.p.value']<0.05).sum(), '; unique analytes with >=1 assay FDR<0.05:', (best['adj.p.value']<0.05).sum())
# z ranking
s['rank_z'] = s.z.abs().rank(ascending=False).astype(int)
print(s.sort_values('rank_z').head(30)[['rank','rank_z','panel_s','assay','OR','l95','u95','z','se_log','p.value','adj.p.value']].to_string(index=False, float_format=lambda v: f'{v:.3g}'))
print('ST2: rank by p = %d, rank by OR = %d, rank by |z| = %d' % (s.loc[s.assay=='ST2','rank'].iloc[0], (s.OR.rank(ascending=False))[s.assay=='ST2'].iloc[0], s.loc[s.assay=='ST2','rank_z'].iloc[0]))
# Fragile: wide CIs
s['ci_ratio'] = s.u95/s.l95
print('assays FDR<0.05 with CI ratio (u95/l95) > 20:', ((s['adj.p.value']<0.05)&(s.ci_ratio>20)).sum())
print(s[(s['adj.p.value']<0.05)&(s.ci_ratio>20)][['rank','assay','OR','l95','u95','ci_ratio','p.value']].to_string(index=False, float_format=lambda v: f'{v:.3g}'))
# protective
print(s[(s.OR<1)&(s['p.value']<0.05)][['rank','panel_s','assay','OR','l95','u95','p.value','adj.p.value']].to_string(index=False, float_format=lambda v: f'{v:.3g}'))
# missingness vs significance
s['anymiss'] = (s.m0+s.m1)>0
print(pd.crosstab(s.anymiss, s['adj.p.value']<0.05))
print('max missing per group: m0', s.m0.max(), 'm1', s.m1.max())
