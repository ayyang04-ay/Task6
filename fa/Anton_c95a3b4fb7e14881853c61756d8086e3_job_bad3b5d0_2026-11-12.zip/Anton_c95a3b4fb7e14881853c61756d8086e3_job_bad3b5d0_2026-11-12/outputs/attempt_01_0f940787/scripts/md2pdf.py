import re, os, sys
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, LongTable, TableStyle, PageBreak, KeepTogether, HRFlowable, ListFlowable, ListItem
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import matplotlib
from PIL import Image as PILImage
fd = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
pdfmetrics.registerFont(TTFont('DV', os.path.join(fd, 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B', os.path.join(fd, 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DV-I', os.path.join(fd, 'DejaVuSans-Oblique.ttf')))
pdfmetrics.registerFont(TTFont('DV-BI', os.path.join(fd, 'DejaVuSans-BoldOblique.ttf')))
pdfmetrics.registerFont(TTFont('DVM', os.path.join(fd, 'DejaVuSansMono.ttf')))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily('DV', normal='DV', bold='DV-B', italic='DV-I', boldItalic='DV-BI')

src, out, base = sys.argv[1], sys.argv[2], sys.argv[3]
md = open(src).read()
W, H = A4
LM = RM = 1.7*cm; TM = 1.6*cm; BM = 1.6*cm
FW = W - LM - RM
body = ParagraphStyle('body', fontName='DV', fontSize=8.8, leading=12.2, spaceAfter=5, alignment=TA_LEFT)
h1 = ParagraphStyle('h1', parent=body, fontName='DV-B', fontSize=15, leading=19, spaceAfter=8, spaceBefore=0, textColor=colors.HexColor('#102a43'))
h2 = ParagraphStyle('h2', parent=body, fontName='DV-B', fontSize=11.5, leading=15, spaceBefore=10, spaceAfter=5, textColor=colors.HexColor('#102a43'))
h3 = ParagraphStyle('h3', parent=body, fontName='DV-B', fontSize=9.6, leading=13, spaceBefore=7, spaceAfter=4, textColor=colors.HexColor('#243b53'))
bullet = ParagraphStyle('bullet', parent=body, leftIndent=12, bulletIndent=2, spaceAfter=3)
quote = ParagraphStyle('quote', parent=body, fontName='DV-B', fontSize=9.2, leading=13, leftIndent=10, rightIndent=6, spaceBefore=4, spaceAfter=6, textColor=colors.HexColor('#0b4f8a'), borderPadding=(6,6,6,8), backColor=colors.HexColor('#eef5fb'))
cell = ParagraphStyle('cell', parent=body, fontSize=7.3, leading=9.4, spaceAfter=0)
cellh = ParagraphStyle('cellh', parent=cell, fontName='DV-B')
cap = ParagraphStyle('cap', parent=body, fontSize=7.6, leading=10, textColor=colors.HexColor('#333333'), spaceAfter=8)

def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'\*\*\*(.+?)\*\*\*', r'<b><i>\1</i></b>', t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'<i>\1</i>', t)
    t = re.sub(r'`(.+?)`', r'<font name="DVM" size="7.6">\1</font>', t)
    return t

def cells(l): return [c.strip() for c in l.strip().strip('|').split('|')]

def make_table(tbl_lines):
    rows = [cells(t) for k,t in enumerate(tbl_lines) if k != 1]
    ncol = len(rows[0])
    w = []
    for c in range(ncol):
        lens = [len(re.sub(r'[*`]', '', r[c])) if c < len(r) else 0 for r in rows]
        mx = max(lens); avg = sum(lens)/len(lens)
        longest_word = max((len(wd) for r in rows for wd in (r[c] if c < len(r) else '').replace('**','').split()), default=1)
        w.append(max(min(0.5*mx + 0.5*avg, 75), longest_word*1.05, 3.5))
    tot = sum(w); widths = [FW*x/tot for x in w]
    # enforce a minimum width so the longest word fits (approx 3.9 pt per char at 7.3pt)
    minw = [max(16, 4.1*max((len(wd) for r in rows for wd in (r[c] if c < len(r) else '').replace('**','').replace('*','').split()), default=1) + 8) for c in range(ncol)]
    for _ in range(20):
        deficit = sum(max(0, m - x) for m, x in zip(minw, widths))
        if deficit < 0.5: break
        surplus_idx = [k for k in range(ncol) if widths[k] > minw[k] + 1]
        sur_tot = sum(widths[k]-minw[k] for k in surplus_idx)
        for k in range(ncol):
            if widths[k] < minw[k]: widths[k] = minw[k]
        for k in surplus_idx:
            widths[k] -= deficit*(widths[k]-minw[k])/sur_tot if sur_tot > 0 else 0
    data = []
    for ri, r in enumerate(rows):
        data.append([Paragraph(inline(r[c] if c < len(r) else ''), cellh if ri == 0 else cell) for c in range(ncol)])
    t = LongTable(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ('GRID', (0,0), (-1,-1), 0.4, colors.HexColor('#9aa5b1')),
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#e6ecf2')),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 3.5), ('RIGHTPADDING', (0,0), (-1,-1), 3.5), ('TOPPADDING', (0,0), (-1,-1), 2.5), ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f7f9fb')]),
    ]))
    return t

story = []
lines = md.split('\n')
i = 0
para = []
def flush():
    global para
    if para:
        story.append(Paragraph(inline(' '.join(para)), body)); para = []
while i < len(lines):
    l = lines[i]
    if l.startswith('# '):
        flush(); story.append(Paragraph(inline(l[2:]), h1)); i += 1
    elif l.startswith('## '):
        flush(); story.append(Paragraph(inline(l[3:]), h2)); i += 1
    elif l.startswith('### '):
        flush(); story.append(Paragraph(inline(l[4:]), h3)); i += 1
    elif l.strip() == '---':
        flush(); story.append(Spacer(1, 3)); story.append(HRFlowable(width='100%', thickness=0.6, color=colors.HexColor('#9aa5b1'))); story.append(Spacer(1, 3)); i += 1
    elif l.startswith('|'):
        flush(); j = i; tbl = []
        while j < len(lines) and lines[j].startswith('|'):
            tbl.append(lines[j]); j += 1
        story.append(Spacer(1, 2)); story.append(make_table(tbl)); story.append(Spacer(1, 7)); i = j
    elif l.startswith('!['):
        flush()
        m = re.match(r'!\[(.*?)\]\((.*?)\)', l)
        captxt, path = m.group(1), os.path.join(base, m.group(2))
        im = PILImage.open(path); iw, ih = im.size
        maxw, maxh = FW, H - TM - BM - 60
        sc = min(maxw/iw, maxh/ih)
        story.append(KeepTogether([Image(path, width=iw*sc, height=ih*sc), Spacer(1, 3), Paragraph(inline(captxt), cap)])); i += 1
    elif l.startswith('> '):
        flush(); story.append(Paragraph(inline(l[2:]), quote)); i += 1
    elif re.match(r'^(- |\d+\. )', l):
        flush()
        items = []
        while i < len(lines) and re.match(r'^(- |\d+\. )', lines[i]):
            m = re.match(r'^(- |(\d+)\. )(.*)', lines[i])
            num = m.group(2); txt = m.group(3)
            items.append(Paragraph(inline(txt), bullet, bulletText=(num + '.') if num else '•'))
            i += 1
        story.extend(items); story.append(Spacer(1, 3))
    elif l.strip() == '':
        flush(); i += 1
    else:
        para.append(l.strip()); i += 1
flush()

def footer(canvas, doc):
    canvas.saveState(); canvas.setFont('DV', 7); canvas.setFillColor(colors.HexColor('#666666'))
    canvas.drawString(LM, 0.9*cm, 'AX-1177 portfolio audit memo — based solely on the five delivered files')
    canvas.drawRightString(W - RM, 0.9*cm, 'Page %d' % doc.page); canvas.restoreState()
doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=LM, rightMargin=RM, topMargin=TM, bottomMargin=BM, title='AX-1177 portfolio audit memo', author='')
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print('built', out)
