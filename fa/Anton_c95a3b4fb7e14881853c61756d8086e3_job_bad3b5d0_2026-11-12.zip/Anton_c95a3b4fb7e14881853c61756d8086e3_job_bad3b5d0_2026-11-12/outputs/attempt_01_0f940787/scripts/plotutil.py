import numpy as np
def repel_labels(ax, pts, fontsize=7, colors=None, pad=2):
    """Greedy label placement. pts: list of (x, y, text). Draws annotate with thin leader lines."""
    fig = ax.figure
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    placed = []
    trans = ax.transData
    offsets = [(6,6),(6,-10),(-6,6),(-6,-10),(14,0),(-14,0),(0,14),(0,-16),(18,12),(18,-16),(-18,12),(-18,-16),(28,4),(-28,4),(28,-8),(-28,-8),(0,24),(0,-26),(36,16),(-36,16),(36,-20),(-36,-20),(48,0),(-48,0),(0,34),(0,-36),(50,26),(-50,26),(50,-30),(-50,-30)]
    # point boxes to avoid
    pt_disp = [trans.transform((x,y)) for x,y,_ in pts]
    for k,(x,y,text) in enumerate(pts):
        px, py = pt_disp[k]
        w = fontsize*0.62*len(text)*fig.dpi/72.0; h = fontsize*1.25*fig.dpi/72.0
        best = None
        for dx,dy in offsets:
            dxp = dx*fig.dpi/72.0; dyp = dy*fig.dpi/72.0
            if dx >= 0: x0 = px+dxp
            else: x0 = px+dxp-w
            y0 = py+dyp
            box = (x0-pad, y0-pad, x0+w+pad, y0+h+pad)
            ok = True
            for b in placed:
                if not (box[2] < b[0] or box[0] > b[2] or box[3] < b[1] or box[1] > b[3]):
                    ok = False; break
            if ok:
                # avoid covering other labelled points
                for j,(qx,qy) in enumerate(pt_disp):
                    if j!=k and box[0] <= qx <= box[2] and box[1] <= qy <= box[3]:
                        ok = False; break
            if ok:
                best = (dx,dy,box); break
        if best is None:
            dx,dy = offsets[0]; dxp = dx*fig.dpi/72.0; dyp = dy*fig.dpi/72.0
            best = (dx,dy,(px+dxp, py+dyp, px+dxp+w, py+dyp+h))
        dx,dy,box = best
        placed.append(box)
        c = colors[k] if colors is not None else 'black'
        ax.annotate(text, (x,y), xytext=(dx,dy), textcoords='offset points', fontsize=fontsize, color=c,
                    ha='left' if dx>=0 else 'right', va='bottom',
                    arrowprops=dict(arrowstyle='-', lw=0.4, color='#666666', shrinkA=0, shrinkB=2) if (abs(dx)+abs(dy))>14 else None)
