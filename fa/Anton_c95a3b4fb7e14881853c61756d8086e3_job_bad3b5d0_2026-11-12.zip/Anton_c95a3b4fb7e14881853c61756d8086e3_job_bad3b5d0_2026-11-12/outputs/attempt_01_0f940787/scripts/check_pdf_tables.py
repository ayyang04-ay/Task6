import re, sys, os
sys.argv = ['x', '/tmp/outputs/AX-1177_portfolio_audit_memo.md', '/tmp/work/build/_check.pdf', '/tmp/outputs']
src = open('md2pdf.py').read()
# execute builder but intercept story before build
src = src.replace("doc.build(story, onFirstPage=footer, onLaterPages=footer)", "pass")
exec(compile(src, 'md2pdf_check', 'exec'))
from reportlab.platypus import LongTable, Paragraph, Image
n_over = 0; nt = 0
for f in story:
    if isinstance(f, LongTable):
        nt += 1
        widths = f._colWidths
        print(f'table {nt}: ncol={len(widths)} widths(pt)={[round(w,1) for w in widths]} total={sum(widths):.1f} (frame {FW:.1f}); rows={len(f._cellvalues)}')
        maxh = 0
        for r, row in enumerate(f._cellvalues):
            rowh = 0
            for c, p in enumerate(row):
                avail = widths[c] - 7
                w, h = p.wrap(avail, 10000)
                rowh = max(rowh, h)
                lw = p.getActualLineWidths0()
                if lw and max(lw) > avail + 0.5:
                    n_over += 1
                    print(f'   OVERFLOW table {nt} row {r} col {c}: line width {max(lw):.1f} > {avail:.1f}: {p.getPlainText()[:60]}')
            maxh = max(maxh, rowh)
        print(f'   tallest row: {maxh:.0f} pt (page body height {H-TM-BM:.0f})')
    elif isinstance(f, Image):
        print('image', round(f.drawWidth), 'x', round(f.drawHeight))
print('overflow cells:', n_over)
