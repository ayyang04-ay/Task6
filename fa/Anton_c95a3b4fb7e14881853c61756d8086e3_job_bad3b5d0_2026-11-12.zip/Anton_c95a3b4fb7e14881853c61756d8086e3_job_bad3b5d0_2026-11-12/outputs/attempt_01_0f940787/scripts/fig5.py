import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from plotutil import repel_labels
plt.rcParams.update({'font.size': 9, 'axes.titlesize': 10, 'axes.labelsize': 9})
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); q = pd.read_parquet('q.parquet'); t = pd.read_parquet('t.parquet'); se = pd.read_parquet('se.parquet').abs(); fl = pd.read_parquet('se_flags.parquet'); D = pd.read_parquet('derived.parquet')
fig = plt.figure(figsize=(15, 10.5)); gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.05])
# A: median SE vs AveExpr
ax = fig.add_subplot(gs[0,0])
ok = ~fl.flag
ax.scatter(fl.AveExpr[ok], fl.se_med[ok], s=2, c='#bdbdbd', rasterized=True)
ax.scatter(fl.AveExpr[fl.flag], fl.se_med[fl.flag], s=9, c='#d62728', rasterized=True)
o = fl.sort_values('AveExpr'); ax.plot(o.AveExpr, o.exp_se, c='k', lw=1)
ax.set_yscale('log'); ax.set_xlabel('AveExpr (mean log2 expression across all 114 libraries, 4 cell lines)'); ax.set_ylabel('median standard error across the 26 contrasts (log2 units)')
pts=[]
for g in ['CD93','CXCL1','CDH5','VWF','ENG','SELE','VCAM1','CXCL8','IL1RL1','PTX3','CCL2','ICAM1','PTGS2','GATA3','KRT8','AKR1C2','XBP1','G6PD','GAPDH','PECAM1','KDR','TFF1']:
    i = ann.index[ann.symbol==g][0]; pts.append((fl.AveExpr[i], fl.se_med[i], g))
repel_labels(ax, pts, fontsize=7)
ax.set_title(f'A. Standard errors are broken for {int(fl.flag.sum())} genes ({100*fl.flag.mean():.1f}%): lineage markers and\nvery abundant genes – a side-effect of one model across four unlike cell lines')
ax.legend(handles=[Line2D([0],[0], marker='o', color='w', markerfacecolor='#d62728', markersize=6, label='flagged: median SE >5× expected, or SE varies >20-fold between contrasts'), Line2D([0],[0], color='k', lw=1, label='expected SE (running median)')], fontsize=7, loc='upper right')
# B: tiny effects with huge t in antibody-alone contrasts
ax = fig.add_subplot(gs[0,1])
alone = [c for c in lfc.columns if c.startswith('C47_v_')]
X=[]; 
for c in alone:
    sgn = q[c]<0.05
    X.append(pd.DataFrame({'lfc':lfc.loc[sgn,c].abs(), 'nlq':-np.log10(q.loc[sgn,c]), 'ave':ann.AveExpr[sgn], 'flag':fl.flag[sgn], 'sym':ann.symbol[sgn], 'c':c}))
X = pd.concat(X)
lo = X.ave<1; tiny = X.lfc<0.3
ax.scatter(X.lfc[lo&~tiny], X.nlq[lo&~tiny], s=10, c='#7f7f7f', alpha=0.6, label=f'low-count gene (AveExpr<1), |log2FC|≥2: n={(lo&~tiny).sum()}')
ax.scatter(X.lfc[tiny], X.nlq[tiny], s=14, c='#d62728', alpha=0.8, label=f'|log2FC|<0.3 (≤23% change), deflated SE: n={tiny.sum()}')
rest = ~(lo&~tiny)&~tiny
ax.scatter(X.lfc[rest], X.nlq[rest], s=14, c='#1f77b4', label=f'other: n={rest.sum()} (none with AveExpr≥3 & |log2FC|≥1; none replicated)')
ax.set_yscale('log'); ax.set_xlim(-0.75, 4.6); ax.set_xlabel('|log2FC|, AX-1177 alone vs isotype / PBS / DMSO (no IL-33)'); ax.set_ylabel('−log10 adj.P (as delivered)')
pts=[]
for _, r in X[tiny].sort_values('nlq', ascending=False).head(9).iterrows():
    pts.append((r.lfc, r.nlq, f'{r.sym} ({r.c.split("_")[3]} {r.c.split("_")[4]})'))
repel_labels(ax, pts, fontsize=6.5)
ax.set_title(f'B. None of the {len(X)} antibody-alone "hits" (16 contrasts) is credible: sub-0.3-log2\nchanges with impossible precision, on/off noise in low-count genes, nothing replicated')
ax.legend(fontsize=7, loc='center right', bbox_to_anchor=(1.0, 0.62))
# C: replication check for flagged biomarker genes
ax = fig.add_subplot(gs[1,:])
genes = ['SELE','VCAM1','CXCL8','CXCL1','ICAM1','CCL2','PTGS2','PTX3','IL1RL1']
xpos = np.arange(len(genes))
series = [('IL-33 vs vehicle (HUVEC)', lambda i: lfc.loc[i,'IL33_v_Veh_HUVEC_6h'], '#1f77b4', 'o', -0.24),
          ('isotype+IL-33 vs AX-1177+IL-33 (HUVEC, independent libraries)', lambda i: -lfc.loc[i,'C47IL33_v_IL33IC_HUVEC_6h'], '#1f77b4', 's', -0.12),
          ('isotype+IL-33 vs AX-1177+IL-33 (HGMEC)', lambda i: -lfc.loc[i,'C47IL33_v_IL33IC_HGMEC_6h'], '#2ca02c', 's', 0.0),
          ('null: isotype+IL-33 vs IL-33 (HUVEC)', lambda i: D.loc[i,'IL33IC_v_IL33_HUVEC_6h'], '#7f7f7f', 'x', 0.10),
          ('null: isotype+IL-33 vs IL-33 (HGMEC)', lambda i: D.loc[i,'IL33IC_v_IL33_HGMEC_6h'], '#7f7f7f', '+', 0.16),
          ('null: AX-1177 vs isotype, no IL-33 (HUVEC)', lambda i: lfc.loc[i,'C47_v_IC_HUVEC_6h'], '#7f7f7f', 'v', 0.22),
          ('null: AX-1177 vs isotype, no IL-33 (HGMEC)', lambda i: lfc.loc[i,'C47_v_IC_HGMEC_6h'], '#7f7f7f', '^', 0.28)]
for name, f, col, mk, off in series:
    vals = [f(ann.index[ann.symbol==g][0]) for g in genes]
    ax.scatter(xpos+off, vals, c=col, marker=mk, s=48, label=name, zorder=3)
for k,g in enumerate(genes):
    i = ann.index[ann.symbol==g][0]
    ax.text(k, 12.6, f'reported SE {se.loc[i,"C47IL33_v_IL33IC_HUVEC_6h"]:.3g}\nadj.P {q.loc[i,"C47IL33_v_IL33IC_HUVEC_6h"]:.2g}', ha='center', fontsize=7.5, color='#d62728')
ax.axhline(0, c='k', lw=0.5); ax.set_xticks(xpos); ax.set_xticklabels([{'CXCL8':'CXCL8 (IL-8)','CCL2':'CCL2 (MCP-1)','IL1RL1':'IL1RL1 (ST2)','PTGS2':'PTGS2 (COX-2)','SELE':'SELE (E-selectin)'}.get(g,g) for g in genes])
ax.set_ylim(-1.5, 14.5); ax.set_ylabel('log2 fold change at 6 h')
ax.set_title('C. The classic endothelial-activation genes: effects replicate across independent arms and both cell types, nulls sit at zero –\nyet the model reports SEs of 1.7–1,140 log2 units. Treat as real-but-unconfirmed; do not cite their p-values in either direction.')
ax.legend(fontsize=7.5, ncol=2, loc='upper right', bbox_to_anchor=(1.0, 0.86))
for a in fig.axes:
    for sp in ['top','right']: a.spines[sp].set_visible(False)
fig.tight_layout(); fig.savefig('/tmp/outputs/figures/Fig5_model_artefact.png', dpi=160)
print(len(X), tiny.sum(), (lo&~tiny).sum(), rest.sum())
print(X[rest].sort_values('ave', ascending=False).head(30).to_string())
