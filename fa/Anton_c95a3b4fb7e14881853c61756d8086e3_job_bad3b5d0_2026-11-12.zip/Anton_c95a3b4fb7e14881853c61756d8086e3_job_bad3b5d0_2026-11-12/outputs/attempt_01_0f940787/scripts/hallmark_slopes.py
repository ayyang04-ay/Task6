# Reversal of pre-defined (Hallmark) gene sets: slope of AX-1177 effect on IL-33 effect, HUVEC
import pandas as pd, numpy as np
lfc = pd.read_parquet('lfc.parquet'); ann = pd.read_parquet('ann.parquet'); H = pd.read_csv('msig_H.csv')
for sname in ['HALLMARK_INTERFERON_ALPHA_RESPONSE','HALLMARK_INTERFERON_GAMMA_RESPONSE','HALLMARK_TNFA_SIGNALING_VIA_NFKB']:
    ids = [g for g in H.loc[H.gs_name==sname,'ensembl_gene'].unique() if g in lfc.index and ann.AveExpr[g]>0]
    for tp in ['6h','24h']:
        i=f'IL33_v_Veh_HUVEC_{tp}'; c=f'C47IL33_v_IL33IC_HUVEC_{tp}'; c2=f'C47IL33_v_IL33_HUVEC_{tp}'
        x = lfc.loc[ids,i]; y = lfc.loc[ids,c]; y2 = lfc.loc[ids,c2]; up = x>=1
        print(f'{sname[9:]:32s} {tp}: n={len(ids)}; slope vs iso+IL33 {(x*y).sum()/(x*x).sum():+.2f}; vs IL33 {(x*y2).sum()/(x*x).sum():+.2f}; induced>=2x: {up.sum()}, median reversal {100*(-y[up]/x[up]).median():.0f}%')
