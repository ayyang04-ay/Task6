import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
sym = ann.symbol
# DEG counts at different thresholds
rows=[]
for c in lfc.columns:
    for thr in [0, 0.585, 1, 2]:
        sig = (q[c]<0.05) & (lfc[c].abs()>=thr)
        rows.append((c, thr, sig.sum(), (sig&(lfc[c]>0)).sum(), (sig&(lfc[c]<0)).sum()))
r = pd.DataFrame(rows, columns=['contrast','abs_lfc_thr','n','up','down'])
print(r.pivot(index='contrast', columns='abs_lfc_thr', values='n').loc[lfc.columns].to_string())
print()
# IL33 6h vs 24h in HUVEC
a, b = 'IL33_v_Veh_HUVEC_6h','IL33_v_Veh_HUVEC_24h'
s6 = (q[a]<0.05)&(lfc[a].abs()>=1); s24 = (q[b]<0.05)&(lfc[b].abs()>=1)
print('IL33 6h sig(|lfc|>=1):', s6.sum(), 'up', (s6&(lfc[a]>0)).sum(), 'down', (s6&(lfc[a]<0)).sum())
print('IL33 24h sig(|lfc|>=1):', s24.sum(), 'up', (s24&(lfc[b]>0)).sum(), 'down', (s24&(lfc[b]<0)).sum())
print('overlap', (s6&s24).sum(), ' same direction', (s6&s24&(np.sign(lfc[a])==np.sign(lfc[b]))).sum())
print('6h only', (s6&~s24).sum(), ' 24h only', (~s6&s24).sum())
u = s6|s24
print('corr of logFC 6h vs 24h among union: pearson', np.corrcoef(lfc.loc[u,a], lfc.loc[u,b])[0,1], 'spearman', stats.spearmanr(lfc.loc[u,a], lfc.loc[u,b]).statistic)
# slope 24h on 6h among 6h sig up genes
x = lfc.loc[s6&(lfc[a]>0), a]; y = lfc.loc[s6&(lfc[a]>0), b]
print('6h-up genes: median logFC 6h %.2f ; median logFC 24h %.2f ; median ratio %.2f; slope(through origin) %.2f' % (x.median(), y.median(), (y/x).median(), (x*y).sum()/(x*x).sum()))
