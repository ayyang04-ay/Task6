import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
D = pd.read_parquet('derived.parquet'); fl = pd.read_parquet('se_flags.parquet')
sym = ann.symbol
def star(x): return '***' if x<0.001 else ('**' if x<0.01 else ('*' if x<0.05 else ''))
for tp in ['6h','24h']:
    hu = f'C47IL33_v_IL33IC_HUVEC_{tp}'; hg = f'C47IL33_v_IL33IC_HGMEC_{tp}'; il = f'IL33_v_Veh_HUVEC_{tp}'
    # IL33-responsive robust genes in HUVEC
    s = (q[il]<0.01)&(lfc[il].abs()>=1)&(q[hu]<0.01)&(np.sign(lfc[il])!=np.sign(lfc[hu]))
    x = lfc.loc[s,hu]; y = lfc.loc[s,hg]
    print(f'--- {tp}: robust IL33-responsive & C47-reversed genes in HUVEC: n={s.sum()}')
    print('   HGMEC vs HUVEC reversal logFC: pearson %.3f, spearman %.3f, slope through origin (HGMEC on HUVEC) %.3f' % (np.corrcoef(x,y)[0,1], stats.spearmanr(x,y).statistic, (x*y).sum()/(x*x).sum()))
    print('   of these, significant same-direction in HGMEC (FDR<0.05): %d (%.0f%%); same sign: %.0f%%' % (((q.loc[s,hg]<0.05)&(np.sign(y)==np.sign(x))).sum(), 100*((q.loc[s,hg]<0.05)&(np.sign(y)==np.sign(x))).mean(), 100*(np.sign(y)==np.sign(x)).mean()))
    # HGMEC-sig genes: do they replicate in HUVEC?
    s2 = (q[hg]<0.01)&(lfc[hg].abs()>=1)&(ann.AveExpr>-2)
    x2 = lfc.loc[s2,hg]; y2 = lfc.loc[s2,hu]
    print(f'   HGMEC-defined C47-responsive genes (FDR<0.01,|lfc|>=1, Ave>-2): n={s2.sum()}; same sign in HUVEC {100*(np.sign(x2)==np.sign(y2)).mean():.0f}%; sig in HUVEC {100*((q.loc[s2,hu]<0.05)&(np.sign(x2)==np.sign(y2))).mean():.0f}%; corr {np.corrcoef(x2,y2)[0,1]:.3f}')
    # genes C47-responsive in HGMEC but not HUVEC
    only = s2 & ~((q[hu]<0.05)&(np.sign(lfc[hg])==np.sign(lfc[hu])))
    o = pd.DataFrame({'symbol':sym[only], 'Ave':ann.AveExpr[only].round(1), 'flag':fl.flag[only], 'HGMEC':lfc.loc[only,hg].round(2), 'q_HGMEC':q.loc[only,hg], 'HUVEC':lfc.loc[only,hu].round(2), 'q_HUVEC':q.loc[only,hu], 'IL33_HUVEC':lfc.loc[only,il].round(2), 'C47alone_HGMEC':lfc.loc[only,f'C47_v_IC_HGMEC_{tp}'].round(2), 'q_alone':q.loc[only,f'C47_v_IC_HGMEC_{tp}']})
    print(f'   HGMEC-only C47-responsive genes: n={only.sum()}')
    print(o.sort_values('q_HGMEC').head(40).to_string(float_format=lambda v: f'{v:.3g}'))
