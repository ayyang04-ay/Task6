import pandas as pd, numpy as np
pd.set_option('display.width', 330); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 50)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs(); D = pd.read_parquet('derived.parquet'); fl = pd.read_parquet('se_flags.parquet')
genes = ['SELE','VCAM1','ICAM1','CXCL8','CXCL1','CCL2','PTX3','IL1RL1','PTGS2','TNFAIP2','SLC7A2','CD44']
rows=[]
for g in genes:
    i = ann.index[ann.symbol==g][0]
    for tp in ['6h','24h']:
        rows.append({'gene':g, 'time':tp,
            'IL33-Veh (HUVEC)': lfc.loc[i,f'IL33_v_Veh_HUVEC_{tp}'],
            'IL33IC-C47IL33 (HUVEC, indep. arms)': -lfc.loc[i,f'C47IL33_v_IL33IC_HUVEC_{tp}'],
            'IL33IC-C47IL33 (HGMEC)': -lfc.loc[i,f'C47IL33_v_IL33IC_HGMEC_{tp}'],
            'null: IL33IC-IL33 (HUVEC)': D.loc[i,f'IL33IC_v_IL33_HUVEC_{tp}'],
            'null: IL33IC-IL33 (HGMEC)': D.loc[i,f'IL33IC_v_IL33_HGMEC_{tp}'],
            'null: C47-IC (HUVEC)': lfc.loc[i,f'C47_v_IC_HUVEC_{tp}'],
            'null: C47-IC (HGMEC)': lfc.loc[i,f'C47_v_IC_HGMEC_{tp}'],
            'reported SE': se.loc[i,f'C47IL33_v_IL33IC_HUVEC_{tp}'], 'reported adj.P': q.loc[i,f'C47IL33_v_IL33IC_HUVEC_{tp}']})
R = pd.DataFrame(rows)
print(R.to_string(index=False, float_format=lambda v: f'{v:.3g}'))
R.to_csv('replication_check.csv', index=False)
# Genome-wide: how well do the two independent estimates agree? among unflagged robust genes
i6='IL33_v_Veh_HUVEC_6h'; c6='C47IL33_v_IL33IC_HUVEC_6h'
core = (q[i6]<0.05)&(q[c6]<0.05)&(lfc[i6].abs()>=1)&(lfc[c6].abs()>=1)&(~fl.flag)
d = lfc.loc[core,i6] + lfc.loc[core,c6]
print('unflagged core genes (n=%d): difference between independent estimates: median |diff| %.2f, 90th pct %.2f' % (core.sum(), d.abs().median(), d.abs().quantile(.9)))
fg = [ann.index[ann.symbol==g][0] for g in genes]
d2 = lfc.loc[fg,i6] + lfc.loc[fg,c6]
print('flagged biomarker genes: |diff| between independent estimates:', dict(zip(genes, d2.abs().round(2))))
