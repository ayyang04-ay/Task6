import pandas as pd, numpy as np
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
r = pd.DataFrame({'symbol':ann.symbol, 'AveExpr':ann.AveExpr, 'se_min':se.min(1), 'se_med':se.median(1), 'se_max':se.max(1)})
r['ratio'] = r.se_max/r.se_min
# expected SE by AveExpr: rolling median of se_med
o = r.sort_values('AveExpr')
o['exp_se'] = o.se_med.rolling(501, center=True, min_periods=50).median()
o['exp_se_p99'] = o.se_med.rolling(501, center=True, min_periods=50).quantile(0.99)
r['exp_se'] = o.exp_se; r['rel'] = r.se_med/r.exp_se
print(r.rel.describe(percentiles=[.5,.9,.95,.99,.995,.999]))
for thr in [3,5,10,20]:
    print('genes with median SE > %dx expected for their AveExpr: %d' % (thr, (r.rel>thr).sum()))
r['flag_infl'] = (r.rel>5)
r['flag_ratio'] = (r.ratio>20)
r['flag'] = r.flag_infl | r.flag_ratio
print('flag_infl', r.flag_infl.sum(), 'flag_ratio', r.flag_ratio.sum(), 'either', r.flag.sum(), 'both', (r.flag_infl&r.flag_ratio).sum())
r.to_parquet('se_flags.parquet')
# Which flagged genes have large effects in key contrasts?
key = ['IL33_v_Veh_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HGMEC_6h','IL33_v_Veh_HUVEC_24h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_24h']
fl = r[r.flag].copy()
for c in key:
    fl[c] = lfc.loc[fl.index, c].round(2); fl['q_'+c] = q.loc[fl.index, c]
big = fl[(fl['IL33_v_Veh_HUVEC_6h'].abs()>=1.5)&(fl['C47IL33_v_IL33IC_HUVEC_6h'].abs()>=1.5)&(np.sign(fl['IL33_v_Veh_HUVEC_6h'])!=np.sign(fl['C47IL33_v_IL33IC_HUVEC_6h']))]
print('Flagged (unreliable SE) genes with |lfc|>=1.5 IL33 response AND opposite C47 effect at 6h in HUVEC: n=', len(big))
print(big.sort_values('IL33_v_Veh_HUVEC_6h', ascending=False)[['symbol','AveExpr','se_med','rel','ratio']+key+['q_IL33_v_Veh_HUVEC_6h','q_C47IL33_v_IL33IC_HUVEC_6h']].to_string(float_format=lambda x: f'{x:.3g}'))
# the tiny-lfc/huge-t false positives: sig with |lfc|<0.3
tiny = []
for c in lfc.columns:
    s = (q[c]<0.05)&(lfc[c].abs()<0.3)
    for g in s.index[s]:
        tiny.append((c, ann.symbol[g], ann.AveExpr[g], lfc.loc[g,c], t.loc[g,c], se.loc[g,c], r.loc[g,'exp_se'], r.loc[g,'ratio'], r.loc[g,'flag']))
tiny = pd.DataFrame(tiny, columns=['contrast','symbol','AveExpr','lfc','t','se','exp_se','se_ratio_maxmin','flag'])
print('sig (FDR<0.05) with |lfc|<0.3 across all 26 contrasts:', len(tiny), '; flagged by SE rule:', tiny.flag.sum())
print(tiny.groupby('contrast').agg(n=('symbol','size'), flagged=('flag','sum')).to_string())
al = tiny[tiny.contrast.str.startswith('C47_v_')]
print(al.sort_values('t', key=abs, ascending=False).head(40).to_string(float_format=lambda x: f'{x:.3g}'))
