# Analysis scripts (as run)

These are the scripts used for the re-analysis, in the order they were run. They read the delivered files from
`/tmp/world/filesystem/` and write intermediates to `/tmp/work/` (paths are hard-coded; adjust to re-run elsewhere).
Python scripts were run in a conda environment with pandas, numpy, scipy, statsmodels, matplotlib and openpyxl;
`fgsea_run.R` needs R with fgsea and the MSigDB 7.5.1 gene sets exported by msigdbr.

| Step | Script | Purpose |
|---|---|---|
| 1 | `parse_xlsx.py` | Stream-parse the large RNA-seq workbooks (all rows, including filtered/hidden ones) to parquet |
| 2 | `build_wide.py` | Gene x contrast matrices of logFC, t, P, adj.P and SE (= logFC / t) for all 26 contrasts |
| 3 | `se_artifact.py`, `replication_check.py` | Flag genes with unreliable standard errors; cross-arm replication check for the flagged biomarker genes |
| 4 | `rna1.py`-`rna5.py` (`rna3.py` also writes the derived contrasts), `residuals.py`, `timecourse.py`, `hgmec.py`, `alone_corr.py`, `alone_replication.py`, `sensitivity_core.py`, `hallmark_slopes.py`, `facts.py` | IL-33 response, reversal by AX-1177, residuals, kinetics, second cell type, antibody-alone analysis, sensitivity checks, headline numbers |
| 5 | `fgsea_run.R`, `fgsea_view.py`, `fgsea_view2.py`, `setscores.py` | Gene-set enrichment (Hallmark, Reactome) |
| 6 | `olink_map.py`, `overlap.py`, `serum_themes.py`, `serum_dups.py`, `panel.py` | Serum table checks, assay-to-gene mapping, protein themes, duplicate-assay concordance, biomarker triangulation |
| 7 | `lung_clean.py`, `lung_an1.py`, `lung_an2.py`, `lung_an3.py`, `lung_lobe.py`, `lung_perm.py`, `lung_extra.py` | Post-mortem lung: cleaning, donor-level comparisons, pathology-text features, within-donor analyses, permutation tests |
| 8 | `fig1.py`-`fig5.py`, `plotutil.py` | Figures |
| 9 | `build_tables.py`, `add_sheets.py` | Supporting Excel workbook |
| 10 | `build_docs.py`, `md2pdf.py`, `check_pdf_tables.py` | DOCX (pandoc) and PDF (reportlab) versions of the memo; table-fit check for the PDF |
| check | `verify_independent.py` | Re-derives the headline numbers from the raw workbooks through a separate code path |
| helper | `show.py` | Print one or more genes across the key contrasts |
