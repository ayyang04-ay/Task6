import pandas as pd, numpy as np
d = pd.read_parquet('all_contrasts.parquet')
short = {
 'Compound_47_vs_IC119_HUVEC_6hrs':'C47_v_IC_HUVEC_6h',
 'Compound_47_vs_IC119_HUVEC_24hrs':'C47_v_IC_HUVEC_24h',
 'Compound_47_vs_IC119_HGMEC_6hrs':'C47_v_IC_HGMEC_6h',
 'Compound_47_vs_IC119_HGMEC_24hrs':'C47_v_IC_HGMEC_24h',
 'Compound_47_IL33_vs_IL33_HUVEC_6hrs':'C47IL33_v_IL33_HUVEC_6h',
 'Compound_47_IL33_vs_IL33_HUVEC_24hrs':'C47IL33_v_IL33_HUVEC_24h',
 'Compound_47_IL33_vs_IL33_HGMEC_6hrs':'C47IL33_v_IL33_HGMEC_6h',
 'Compound_47_IL33_vs_IL33_HGMEC_24hrs':'C47IL33_v_IL33_HGMEC_24h',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_6hrs':'C47IL33_v_IL33IC_HUVEC_6h',
 'Compound_47_IL33_vs_IL33_IC119_HUVEC_24hrs':'C47IL33_v_IL33IC_HUVEC_24h',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_6hrs':'C47IL33_v_IL33IC_HGMEC_6h',
 'Compound_47_IL33_vs_IL33_IC119_HGMEC_24hrs':'C47IL33_v_IL33IC_HGMEC_24h',
 'Compound_47_vs_IC119_A549_6hrs':'C47_v_IC_A549_6h',
 'Compound_47_vs_IC119_A549_24hrs':'C47_v_IC_A549_24h',
 'Compound_47_vs_IC119_MCF7_6hrs':'C47_v_IC_MCF7_6h',
 'Compound_47_vs_IC119_MCF7_24hrs':'C47_v_IC_MCF7_24h',
 'Compound_47_vs_DMSO_A549_6hrs':'C47_v_DMSO_A549_6h',
 'Compound_47_vs_DMSO_A549_24hrs':'C47_v_DMSO_A549_24h',
 'Compound_47_vs_DMSO_MCF7_6hrs':'C47_v_DMSO_MCF7_6h',
 'Compound_47_vs_DMSO_MCF7_24hrs':'C47_v_DMSO_MCF7_24h',
 'Compound_47_vs_PBS_A549_6hrs':'C47_v_PBS_A549_6h',
 'Compound_47_vs_PBS_A549_24hrs':'C47_v_PBS_A549_24h',
 'Compound_47_vs_PBS_MCF7_6hrs':'C47_v_PBS_MCF7_6h',
 'Compound_47_vs_PBS_MCF7_24hrs':'C47_v_PBS_MCF7_24h',
 'IL33_vs_Nontreated_HUVEC_6_hrs':'IL33_v_Veh_HUVEC_6h',
 'IL33_vs_Nontreated_HUVEC_24_hrs':'IL33_v_Veh_HUVEC_24h',
}
d['c'] = d.Comparison.map(short)
assert d.c.notna().all()
ann = d.drop_duplicates('ensembl').set_index('ensembl')[['symbol','entrez','gene_name','AveExpr']]
W = {}
for v in ['logFC','t','P.Value','adj.P.Val','B']:
    W[v] = d.pivot(index='ensembl', columns='c', values=v)[list(short.values())]
lfc, t, p, q = W['logFC'], W['t'], W['P.Value'], W['adj.P.Val']
se = lfc/t
ann.to_parquet('ann.parquet'); lfc.to_parquet('lfc.parquet'); t.to_parquet('t.parquet'); p.to_parquet('p.parquet'); q.to_parquet('q.parquet'); se.to_parquet('se.parquet')
print(lfc.shape)
