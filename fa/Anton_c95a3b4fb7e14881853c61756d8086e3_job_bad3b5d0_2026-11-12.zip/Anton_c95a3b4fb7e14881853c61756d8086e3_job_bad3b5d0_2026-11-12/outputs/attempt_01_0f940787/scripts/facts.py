import pandas as pd, numpy as np
from scipy import stats
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs(); D = pd.read_parquet('derived.parquet'); fl = pd.read_parquet('se_flags.parquet')
i6, i24 = 'IL33_v_Veh_HUVEC_6h','IL33_v_Veh_HUVEC_24h'; hu6, hu24, hg6, hg24 = 'C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_6h','C47IL33_v_IL33IC_HGMEC_24h'
def g(s): return ann.index[ann.symbol==s][0]
print('== RNA-seq')
for c in [i6,i24,hu6,hu24,hg6,hg24]:
    print(c, 'FDR<0.05:', (q[c]<0.05).sum(), '| &|lfc|>=1:', ((q[c]<0.05)&(lfc[c].abs()>=1)).sum())
core6 = (q[i6]<0.05)&(q[hu6]<0.05)&(lfc[i6].abs()>=1)&(lfc[hu6].abs()>=1)&(np.sign(lfc[i6])!=np.sign(lfc[hu6]))
core24 = (q[i24]<0.05)&(q[hu24]<0.05)&(lfc[i24].abs()>=1)&(lfc[hu24].abs()>=1)&(np.sign(lfc[i24])!=np.sign(lfc[hu24]))
print('core6', core6.sum(), 'up', (core6&(lfc[i6]>0)).sum(), 'down', (core6&(lfc[i6]<0)).sum(), '| core24', core24.sum(), 'up', (core24&(lfc[i24]>0)).sum(), '| both', (core6&core24).sum())
up6 = core6&(lfc[i6]>0)
print('6h core-up: median lfc 6h %.2f (%.1fx), 24h %.2f (%.1fx)' % (lfc.loc[up6,i6].median(), 2**lfc.loc[up6,i6].median(), lfc.loc[up6,i24].median(), 2**lfc.loc[up6,i24].median()))
for tp,i,c in [('6h',i6,hu6),('24h',i24,hu24)]:
    s = (q[i]<1e-4)&(lfc[i].abs()>=1); x = lfc.loc[s,i]; y = lfc.loc[s,c]; y2 = lfc.loc[s,c.replace('IL33IC','IL33')]
    print(tp, 'unbiased signature n=%d: slope vs iso+IL33 %.2f; vs IL33 alone %.2f; r %.2f' % (s.sum(), (x*y).sum()/(x*x).sum(), (x*y2).sum()/(x*x).sum(), np.corrcoef(x,y)[0,1]))
    cr = core6 if tp=='6h' else core24; x = lfc.loc[cr,i]; y = lfc.loc[cr,c]
    print(tp, 'core: slope %.2f r %.2f median reversal %.0f%%' % ((x*y).sum()/(x*x).sum(), np.corrcoef(x,y)[0,1], 100*(-y/x).median()))
ok = ann.AveExpr>4
print('all-gene r (AveExpr>4, n=%d): 6h %.2f; 24h %.2f' % (ok.sum(), np.corrcoef(lfc.loc[ok,i6], -lfc.loc[ok,hu6])[0,1], np.corrcoef(lfc.loc[ok,i24], -lfc.loc[ok,hu24])[0,1]))
x = lfc.loc[core6,hu6]; y = lfc.loc[core6,hg6]
print('HGMEC 6h vs HUVEC core: slope %.2f r %.2f; sig same dir %d (%.0f%%)' % ((x*y).sum()/(x*x).sum(), np.corrcoef(x,y)[0,1], ((q.loc[core6,hg6]<0.05)&(np.sign(x)==np.sign(y))).sum(), 100*((q.loc[core6,hg6]<0.05)&(np.sign(x)==np.sign(y))).mean()))
x = lfc.loc[core24,hu24]; y = lfc.loc[core24,hg24]
print('HGMEC 24h vs HUVEC core24: slope %.2f r %.2f; sig same dir %d of %d (%.0f%%)' % ((x*y).sum()/(x*x).sum(), np.corrcoef(x,y)[0,1], ((q.loc[core24,hg24]<0.05)&(np.sign(x)==np.sign(y))).sum(), core24.sum(), 100*((q.loc[core24,hg24]<0.05)&(np.sign(x)==np.sign(y))).mean()))
for s_ in ['CSF2','CSF3','CXCL6','CCL20','IL6','CX3CL1','TNFRSF11B','IL18R1','F3','THBD','SERPINE1','CCL7','IL1B','CSF1','CTSS','CXCL5','EBI3','CCL5','TNFRSF9','NFKBIA','TNFAIP3','TRAF1','ICAM1','C3','CXCL10','PLA1A']:
    i = g(s_)
    print(f'{s_:10s} Ave {ann.AveExpr[i]:5.1f} | IL33 6h {lfc.loc[i,i6]:+.2f} ({2**lfc.loc[i,i6]:.0f}x; q={q.loc[i,i6]:.1e}) rev HU {lfc.loc[i,hu6]:+.2f} (q={q.loc[i,hu6]:.1e}) HG {lfc.loc[i,hg6]:+.2f} (q={q.loc[i,hg6]:.1e}) | 24h IL33 {lfc.loc[i,i24]:+.2f} ({2**lfc.loc[i,i24]:.1f}x; q={q.loc[i,i24]:.1e}) rev HU {lfc.loc[i,hu24]:+.2f} (q={q.loc[i,hu24]:.1e}) HG {lfc.loc[i,hg24]:+.2f} (q={q.loc[i,hg24]:.1e})')
print('flagged genes', fl.flag.sum(), '%.2f%%' % (100*fl.flag.mean()))
