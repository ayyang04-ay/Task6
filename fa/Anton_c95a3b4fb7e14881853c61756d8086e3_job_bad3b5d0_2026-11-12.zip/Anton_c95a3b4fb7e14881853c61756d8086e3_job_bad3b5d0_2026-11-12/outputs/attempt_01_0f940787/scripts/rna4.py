import pandas as pd, numpy as np, itertools
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
D = pd.read_parquet('derived.parquet')
sym = ann.symbol
def table(idx):
    out = pd.DataFrame({'symbol':sym[idx], 'Ave':ann.AveExpr[idx].round(1)})
    for tp in ['6h','24h']:
        out[f'IL33_{tp}'] = [f'{lfc.loc[g, f"IL33_v_Veh_HUVEC_{tp}"]:+.2f}' + ('*' if q.loc[g, f"IL33_v_Veh_HUVEC_{tp}"]<0.05 else ' ') for g in idx]
        out[f'C47vIL33IC_HUVEC_{tp}'] = [f'{lfc.loc[g, f"C47IL33_v_IL33IC_HUVEC_{tp}"]:+.2f}' + ('*' if q.loc[g, f"C47IL33_v_IL33IC_HUVEC_{tp}"]<0.05 else ' ') for g in idx]
        out[f'resid_{tp}'] = D.loc[idx, f'resid_C47IL33_v_Veh_HUVEC_{tp}'].round(2)
        out[f'C47vIL33IC_HGMEC_{tp}'] = [f'{lfc.loc[g, f"C47IL33_v_IL33IC_HGMEC_{tp}"]:+.2f}' + ('*' if q.loc[g, f"C47IL33_v_IL33IC_HGMEC_{tp}"]<0.05 else ' ') for g in idx]
    return out
a6 = 'IL33_v_Veh_HUVEC_6h'; a24='IL33_v_Veh_HUVEC_24h'
top_up6 = lfc.index[(q[a6]<0.05)&(lfc[a6]>=2)]
top_up6 = lfc.loc[top_up6, a6].sort_values(ascending=False).index
print('IL33-induced genes HUVEC 6h (FDR<0.05, lfc>=2): n=', len(top_up6))
print(table(top_up6[:150]).to_string())
