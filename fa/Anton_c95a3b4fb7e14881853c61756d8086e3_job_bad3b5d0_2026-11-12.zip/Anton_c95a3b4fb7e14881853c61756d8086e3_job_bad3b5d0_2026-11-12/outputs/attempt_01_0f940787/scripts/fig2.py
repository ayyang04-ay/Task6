import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
plt.rcParams.update({'font.size': 9, 'axes.titlesize': 10, 'axes.labelsize': 9})
s = pd.read_csv('serum_annot.csv')
fig, axes = plt.subplots(1, 2, figsize=(14.5, 10.5), gridspec_kw={'width_ratios':[1.15,1]})
ax = axes[0]
groups = [
 ('IL-33 receptor (decoy)', ['ST2'], '#d62728'),
 ('IL-33-induced & AX-1177-reversed in endothelium\n(robust statistics) – outcome-associated', ['IL6','OPG-INFI','IL-18R1','CCL20','MCP-3','IL1B','CSF-1','CTSS','TF'], '#1f77b4'),
 ('IL-33-induced & AX-1177-reversed in endothelium\n(robust statistics) – NOT outcome-associated', ['CX3CL1','G-CSF','CXCL10','CXCL5','CCL5','TNFRSF9','CXCL6'], '#6baed6'),
 ('Large IL-33 effect in endothelium, model statistics unreliable', ['PTX3','IL8','MCP-1-INFI','SELE','ICAM1','VCAM1','CXCL1-INFI'], '#e377c2'),
 ('Neutrophil activation (not endothelial IL-33 targets)', ['HGF','OSM','PRTN3','CD177','RETN','LCN2'], '#ff7f0e'),
 ('Type-2 / eosinophil / mast cell', ['IL-4RA','RNASE3','IL-5R-alpha','CCL17','MCP-4','CCL18','CCL11-INFI','TPSAB1','IL5-IMO'], '#9467bd'),
 ('Interferon / antiviral', ['CXCL9','IFNL1','CXCL10','IFN-gamma'], '#bcbd22'),
]
y = 0; yt=[]; yl=[]
for title, names, col in groups:
    ax.text(0.13, y, title, fontsize=7.5, fontweight='bold', va='center', color=col); y -= 1.15
    for a in names:
        r = s[s.assay==a].iloc[0]
        lo, hi = max(r.l95, 0.2), min(r.u95, 120)
        ax.plot([lo, hi], [y, y], c=col, lw=1.4)
        if r.u95 > 120: ax.annotate('', xy=(135, y), xytext=(110, y), arrowprops=dict(arrowstyle='->', color=col, lw=1.2))
        ax.plot(min(r.OR, 120), y, 'o', c=col, ms=5, mfc=col if r['adj.p.value']<0.05 else 'white')
        lab = a.replace('-INFI','').replace('-IMO','').replace('MCP-3','MCP-3 (CCL7)').replace('MCP-1','MCP-1 (CCL2)').replace('OPG','OPG (TNFRSF11B)').replace('TF','Tissue factor (F3)') if a!='TPSAB1' else 'Tryptase (TPSAB1)'
        lab = {'ST2':'ST2 (sST2, IL1RL1)','IL8':'IL-8 (CXCL8)','RNASE3':'ECP (RNASE3)','CCL17':'TARC (CCL17)','MCP-4':'MCP-4 (CCL13)','CCL11':'Eotaxin (CCL11)','IL5':'IL-5','G-CSF':'G-CSF (CSF3)','CSF-1':'M-CSF (CSF1)'}.get(lab, lab)
        yt.append(y); yl.append(lab)
        ax.text(150, y, f'{r.OR:.2f} [{r.l95:.2f}–{r.u95:.3g}]  p={r["p.value"]:.2g}; FDR={r["adj.p.value"]:.2g}', fontsize=6.6, va='center')
        y -= 1
    y -= 0.5
ax.axvline(1, c='k', lw=0.6)
ax.set_xscale('log'); ax.set_xlim(0.12, 60000); ax.set_ylim(y+0.5, 1.2)
ax.set_xticks([0.25,0.5,1,2,4,10,40,100]); ax.set_xticklabels(['0.25','0.5','1','2','4','10','40','100'])
ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=7.5)
ax.set_xlabel('Odds ratio per log unit (95% CI) for ICU / invasive ventilation / death ≤30 d\nadjusted for age, sex, NEWS2; n=100 hospitalised COVID-19 (44 events). Filled = FDR<0.05')
ax.set_title('A. Serum at enrolment vs outcome: selected assays of 1,094')
for sp in ['top','right']: ax.spines[sp].set_visible(False)
# B: theme summary
ax = axes[1]
s['se_log'] = (np.log(s.u95)-np.log(s.l95))/(2*1.959964); s['z'] = np.log(s.OR)/s.se_log
order = ['IL-33/ST2 & IL-1 family','Neutrophil activation / granule','Myeloid cytokines / acute phase','Epithelial / lung injury','Endothelial / coagulation','Kidney / cardiac stress','IFN / antiviral / lymphocyte','Type-2 / eosinophil / mast cell']
rows=[]
for th in order:
    sub = s[s.theme==th]; rows.append((th, len(sub), (sub['adj.p.value']<0.05).mean()*100, sub.z.median(), sub.z.quantile(.25), sub.z.quantile(.75)))
rows.append(('All assays (background)', len(s), (s['adj.p.value']<0.05).mean()*100, s.z.median(), s.z.quantile(.25), s.z.quantile(.75)))
T = pd.DataFrame(rows, columns=['theme','n','pct','zmed','z25','z75'])
yy = np.arange(len(T))[::-1]
colors = ['#d62728','#ff7f0e','#8c564b','#17becf','#2ca02c','#7f7f7f','#bcbd22','#9467bd','#c8c8c8']
rs = np.random.RandomState(1)
for yi, (_, r), c in zip(yy, T.iterrows(), colors):
    sub = s[s.theme==r.theme] if r.theme in order else s
    ax.scatter(sub.z, np.full(len(sub), yi) + rs.uniform(-0.2,0.2,len(sub)), s=9 if r.theme in order else 2, c=c, alpha=0.8 if r.theme in order else 0.25, rasterized=True)
    ax.plot([r.z25, r.z75], [yi-0.36, yi-0.36], c='k', lw=1.5); ax.plot(r.zmed, yi-0.36, 'k|', ms=9, mew=2)
ax.set_yticks(yy); ax.set_yticklabels([f'{r.theme}\n(n={r.n}; {r.pct:.0f}% FDR<0.05)' for _, r in T.iterrows()], fontsize=7.5)
ax.axvline(0, c='k', lw=0.4); ax.axvline(1.96, c='k', lw=0.4, ls=':'); ax.axvline(-1.96, c='k', lw=0.4, ls=':')
ax.set_xlabel('Wald z per assay (log OR / SE); black bar = median and IQR\nassay groups curated by the analyst from the delivered assay list')
ax.set_title('B. What tracks with deterioration: neutrophil / myeloid / IL-1-family\nproteins – not type-2 and not interferon; whole panel is shifted (82% OR>1)')
for sp in ['top','right']: ax.spines[sp].set_visible(False)
fig.tight_layout()
fig.savefig('/tmp/outputs/figures/Fig2_serum_proteomics.png', dpi=160)
print((s.OR>1).mean())
