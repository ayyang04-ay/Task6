import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 320); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 60)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); q = pd.read_parquet('q.parquet')
D = pd.read_parquet('derived.parquet'); fl = pd.read_parquet('se_flags.parquet')
H = pd.read_csv('msig_H.csv')
allc = pd.concat([lfc, D], axis=1)
expressed = ann.index[ann.AveExpr>1]   # restrict to reasonably expressed genes for set means
sets = ['HALLMARK_INTERFERON_ALPHA_RESPONSE','HALLMARK_INTERFERON_GAMMA_RESPONSE','HALLMARK_TNFA_SIGNALING_VIA_NFKB','HALLMARK_INFLAMMATORY_RESPONSE','HALLMARK_IL6_JAK_STAT3_SIGNALING','HALLMARK_COMPLEMENT','HALLMARK_COAGULATION','HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION','HALLMARK_E2F_TARGETS','HALLMARK_G2M_CHECKPOINT','HALLMARK_HYPOXIA','HALLMARK_APOPTOSIS','HALLMARK_TGF_BETA_SIGNALING','HALLMARK_ANGIOGENESIS','HALLMARK_UNFOLDED_PROTEIN_RESPONSE','HALLMARK_OXIDATIVE_PHOSPHORYLATION','HALLMARK_MYC_TARGETS_V1','HALLMARK_CHOLESTEROL_HOMEOSTASIS']
rows = {}
for sname in sets:
    ids = [g for g in H.loc[H.gs_name==sname,'ensembl_gene'].unique() if g in allc.index and g in set(expressed)]
    rows[sname.replace('HALLMARK_','')+f' (n={len(ids)})'] = allc.loc[ids].median()
R = pd.DataFrame(rows).T
order = ['IL33_v_Veh_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33_HUVEC_6h','resid_C47IL33_v_Veh_HUVEC_6h','IL33IC_v_IL33_HUVEC_6h','C47IL33_v_IL33IC_HGMEC_6h','C47IL33_v_IL33_HGMEC_6h','IL33IC_v_IL33_HGMEC_6h',
         'IL33_v_Veh_HUVEC_24h','C47IL33_v_IL33IC_HUVEC_24h','C47IL33_v_IL33_HUVEC_24h','resid_C47IL33_v_Veh_HUVEC_24h','IL33IC_v_IL33_HUVEC_24h','C47IL33_v_IL33IC_HGMEC_24h','C47IL33_v_IL33_HGMEC_24h','IL33IC_v_IL33_HGMEC_24h',
         'C47_v_IC_HUVEC_6h','C47_v_IC_HUVEC_24h','C47_v_IC_HGMEC_6h','C47_v_IC_HGMEC_24h']
print('Median logFC of expressed (AveExpr>1) Hallmark set genes:')
print(R[order].T.round(2).to_string())
order2 = [c for c in allc.columns if ('A549' in c or 'MCF7' in c)]
print(R[order2].T.round(2).to_string())
