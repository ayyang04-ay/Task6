import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 3000); pd.set_option('display.max_columns', 40)
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); t = pd.read_parquet('t.parquet'); p = pd.read_parquet('p.parquet'); q = pd.read_parquet('q.parquet'); se = pd.read_parquet('se.parquet').abs()
D = pd.read_parquet('derived.parquet'); fl = pd.read_parquet('se_flags.parquet')
sym = ann.symbol
i6, i24 = 'IL33_v_Veh_HUVEC_6h','IL33_v_Veh_HUVEC_24h'; c6, c24 = 'C47IL33_v_IL33IC_HUVEC_6h','C47IL33_v_IL33IC_HUVEC_24h'
# robust "core" signature at 6h: significant IL33 effect AND significant opposite C47 effect (independent arms), |lfc|>=1 for both
core6 = (q[i6]<0.05)&(q[c6]<0.05)&(lfc[i6].abs()>=1)&(lfc[c6].abs()>=1)&(np.sign(lfc[i6])!=np.sign(lfc[c6]))
core24 = (q[i24]<0.05)&(q[c24]<0.05)&(lfc[i24].abs()>=1)&(lfc[c24].abs()>=1)&(np.sign(lfc[i24])!=np.sign(lfc[c24]))
print('core IL33-responsive & C47-reversed (both FDR<0.05, |lfc|>=1): 6h n=%d (up %d, down %d); 24h n=%d (up %d, down %d); both %d' % (core6.sum(), (core6&(lfc[i6]>0)).sum(), (core6&(lfc[i6]<0)).sum(), core24.sum(), (core24&(lfc[i24]>0)).sum(), (core24&(lfc[i24]<0)).sum(), (core6&core24).sum()))
for nm, s, i, c, tp in [('6h', core6, i6, c6, '6h'), ('24h', core24, i24, c24, '24h')]:
    x = lfc.loc[s,i]; y = lfc.loc[s,c]; res = D.loc[s, f'resid_C47IL33_v_Veh_HUVEC_{tp}']
    print(f'  {nm}: slope C47-vs-IL33IC on IL33 = {(x*y).sum()/(x*x).sum():.3f}; corr {np.corrcoef(x,y)[0,1]:.3f}; median %reversal {100*(-y/x).median():.0f}% (IQR {100*(-y/x).quantile(.25):.0f}-{100*(-y/x).quantile(.75):.0f}); residual |lfc|>=1 vs vehicle: {(res.abs()>=1).sum()} genes ({100*(res.abs()>=1).mean():.1f}%)')
# a cleaner, unbiased estimate of neutralisation completeness: define signature ONLY by IL33 vs Veh (strict FDR), evaluate residual = (C47+IL33 vs Veh) using IL33IC arm as independent: 
for tp,i,c in [('6h',i6,c6),('24h',i24,c24)]:
    s = (q[i]<1e-4)&(lfc[i].abs()>=1)
    x = lfc.loc[s,i]; y = lfc.loc[s,c]; y2 = lfc.loc[s, c.replace('IL33IC','IL33')]
    print(f'  {tp}: signature by IL33 vs Veh only (FDR<1e-4,|lfc|>=1) n={s.sum()}: slope vs IL33+IC119 arm {(x*y).sum()/(x*x).sum():.3f}; vs IL33 arm {(x*y2).sum()/(x*x).sum():.3f}')
# time-course among core6 up genes
up6 = core6&(lfc[i6]>0)
ratio = lfc.loc[up6,i24]/lfc.loc[up6,i6]
print('6h core up genes n=%d: median lfc 6h %.2f, 24h %.2f; ratio 24h/6h median %.2f; sustained (ratio>=0.6): %d; transient (ratio<0.3): %d' % (up6.sum(), lfc.loc[up6,i6].median(), lfc.loc[up6,i24].median(), ratio.median(), (ratio>=0.6).sum(), (ratio<0.3).sum()))
tab = pd.DataFrame({'symbol':sym[up6], 'Ave':ann.AveExpr[up6].round(1), 'IL33_6h':lfc.loc[up6,i6].round(2), 'C47_6h':lfc.loc[up6,c6].round(2), 'IL33_24h':lfc.loc[up6,i24].round(2), 'q_IL33_24h':q.loc[up6,i24], 'C47_24h':lfc.loc[up6,c24].round(2), 'q_C47_24h':q.loc[up6,c24], 'ratio':ratio.round(2),
                    'HG_6h':lfc.loc[up6,'C47IL33_v_IL33IC_HGMEC_6h'].round(2), 'qHG6':q.loc[up6,'C47IL33_v_IL33IC_HGMEC_6h'], 'HG_24h':lfc.loc[up6,'C47IL33_v_IL33IC_HGMEC_24h'].round(2), 'qHG24':q.loc[up6,'C47IL33_v_IL33IC_HGMEC_24h']})
tab.to_csv('core6_up.csv')
sus = tab[(tab.ratio>=0.5)&(tab.q_IL33_24h<0.05)&(tab.q_C47_24h<0.05)&(tab.IL33_6h>=2)].sort_values('IL33_24h', ascending=False)
print('SUSTAINED (6h lfc>=2; 24h sig IL33 & sig C47 reversal; ratio>=0.5): n=', len(sus)); print(sus.to_string(float_format=lambda v: f'{v:.3g}'))
tr = tab[(tab.ratio<0.3)&(tab.IL33_6h>=3)].sort_values('IL33_6h', ascending=False)
print('TRANSIENT (6h lfc>=3; ratio<0.3): n=', len(tr)); print(tr.head(50).to_string(float_format=lambda v: f'{v:.3g}'))
