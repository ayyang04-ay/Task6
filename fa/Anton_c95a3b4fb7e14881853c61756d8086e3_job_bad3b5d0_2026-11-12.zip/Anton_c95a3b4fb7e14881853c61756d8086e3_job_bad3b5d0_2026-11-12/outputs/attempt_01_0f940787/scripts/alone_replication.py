# Antibody-alone contrasts: do any hits replicate across independent settings? Is the antibody-alone effect related to the IL-33 effect?
import pandas as pd, numpy as np
from scipy import stats
ann = pd.read_parquet('ann.parquet'); lfc = pd.read_parquet('lfc.parquet'); q = pd.read_parquet('q.parquet')
alone = [c for c in lfc.columns if c.startswith('C47_v_')]
settings = {}
for c in alone: settings.setdefault('_'.join(c.split('_')[3:]), []).append(c)
up = pd.DataFrame({k: np.any([(q[c]<0.05)&(lfc[c]>0) for c in cs], axis=0) for k,cs in settings.items()}, index=lfc.index)
dn = pd.DataFrame({k: np.any([(q[c]<0.05)&(lfc[c]<0) for c in cs], axis=0) for k,cs in settings.items()}, index=lfc.index)
print('unique genes hit in any antibody-alone contrast:', ((up|dn).any(axis=1)).sum())
multi = (up.sum(1)>=2)|(dn.sum(1)>=2)
for g in multi.index[multi]:
    print('  same direction in >=2 independent settings:', ann.symbol[g], round(ann.AveExpr[g],1), {c.replace('C47_v_',''): round(lfc.loc[g,c],2) for c in alone if q.loc[g,c]<0.05})
i6='IL33_v_Veh_HUVEC_6h'; hu6='C47IL33_v_IL33IC_HUVEC_6h'
core6 = (q[i6]<0.05)&(q[hu6]<0.05)&(lfc[i6].abs()>=1)&(lfc[hu6].abs()>=1)&(np.sign(lfc[i6])!=np.sign(lfc[hu6]))
for c in ['C47_v_IC_HUVEC_6h','C47_v_IC_HUVEC_24h','C47_v_IC_HGMEC_6h','C47_v_IC_HGMEC_24h']:
    x = lfc.loc[core6,i6]; y = lfc.loc[core6,c]
    print(f'{c}: slope of antibody-alone effect on IL-33 effect over the 515 core genes = {(x*y).sum()/(x*x).sum():+.3f}; Spearman {stats.spearmanr(x,y).statistic:+.2f}')
